import re
from typing import Any, Optional, Callable


class NlpEngine:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._pipelines: dict[str, Any] = {}
        self._global_models: dict[str, Any] = {}

    def register_pipeline(self, name: str, pipeline: Any) -> None:
        self._pipelines[name] = pipeline

    def get_pipeline(self, name: str) -> Any:
        if name not in self._pipelines:
            raise KeyError(f"No pipeline registered: {name}")
        return self._pipelines[name]

    def load_model(self, model_key: str, loader: Callable[[], Any]) -> Any:
        if model_key not in self._global_models:
            self._global_models[model_key] = loader()
        return self._global_models[model_key]

    def process(self, text: str, pipeline_name: str = "default", **kwargs) -> dict:
        pipeline = self.get_pipeline(pipeline_name)
        return pipeline.run(text, **kwargs)

    def batch_process(self, texts: list[str], pipeline_name: str = "default", **kwargs) -> list[dict]:
        pipeline = self.get_pipeline(pipeline_name)
        return [pipeline.run(t, **kwargs) for t in texts]

    def evaluate(self, text: str, metrics: Optional[list[str]] = None) -> dict:
        metrics = metrics or ["length", "word_count", "sentence_count", "vocabulary_richness"]
        result = {}
        if "length" in metrics:
            result["length"] = len(text)
        if "word_count" in metrics:
            result["word_count"] = len(text.split())
        if "sentence_count" in metrics:
            sentences = re.split(r'[.!?]+', text)
            result["sentence_count"] = len([s for s in sentences if s.strip()])
        if "vocabulary_richness" in metrics:
            words = text.lower().split()
            unique = len(set(words))
            total = len(words)
            result["vocabulary_richness"] = round(unique / total, 4) if total else 0.0
        return result

    def __repr__(self) -> str:
        return f"NlpEngine(pipelines={list(self._pipelines.keys())})"

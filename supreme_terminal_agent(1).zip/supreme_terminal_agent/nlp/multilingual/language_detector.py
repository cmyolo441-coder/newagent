import re
from typing import Optional


class LanguageDetector:
    _CHARACTERISTICS: dict[str, dict[str, list[str]]] = {
        "en": {
            "common_words": ["the", "and", "is", "in", "it", "of", "to", "a", "you", "that",
                             "have", "for", "not", "with", "this", "but", "are", "was", "all",
                             "can", "has", "had", "her", "his", "its", "our", "their", "them",
                             "then", "than", "from", "they", "what", "when", "where", "which",
                             "who", "how", "will", "would", "could", "should", "may", "also",
                             "very", "just", "about", "some", "any", "every", "each", "both",
                             "many", "much", "more", "most", "other", "such", "only", "into",
                             "over", "after", "before", "between", "under", "again", "further"],
            "common_chars": list("abcdefghijklmnopqrstuvwxyz"),
            "diacritics": [],
        },
        "es": {
            "common_words": ["el", "la", "los", "las", "de", "del", "en", "un", "una", "que",
                             "y", "es", "por", "con", "para", "no", "su", "al", "lo", "como",
                             "más", "pero", "sus", "le", "ya", "este", "entre", "cuando",
                             "todo", "ella", "ellos", "sobre", "también", "fue", "era",
                             "muy", "sin", "porque", "había", "dos", "donde", "cómo"],
            "common_chars": list("abcdefghijklmnñopqrstuvwxyz"),
            "diacritics": ["á", "é", "í", "ó", "ú", "ü", "ñ"],
        },
        "fr": {
            "common_words": ["le", "la", "les", "des", "de", "du", "un", "une", "et", "est",
                             "dans", "pour", "sur", "avec", "pas", "que", "qui", "nous",
                             "vous", "ils", "elles", "ce", "cette", "ces", "son", "sa",
                             "ses", "leur", "leurs", "plus", "très", "aussi", "mais",
                             "être", "avoir", "faire", "comme", "tout", "par", "sur"],
            "common_chars": list("abcdefghijklmnopqrstuvwxyz"),
            "diacritics": ["é", "è", "ê", "ë", "à", "â", "ù", "û", "ü", "ô", "î", "ï", "ç"],
        },
        "de": {
            "common_words": ["der", "die", "das", "den", "dem", "des", "ein", "eine", "einen",
                             "einer", "eines", "und", "ist", "sind", "im", "in", "mit",
                             "auf", "für", "von", "aus", "bei", "nach", "vor", "durch",
                             "über", "an", "zu", "nicht", "oder", "aber", "wie", "wenn",
                             "dann", "auch", "werden", "hat", "haben", "sich", "sie", "ich"],
            "common_chars": list("abcdefghijklmnopqrstuvwxyz"),
            "diacritics": ["ä", "ö", "ü", "ß"],
        },
        "it": {
            "common_words": ["il", "lo", "la", "gli", "le", "dei", "del", "della", "un",
                             "uno", "una", "e", "è", "sono", "che", "per", "con", "su",
                             "tra", "fra", "nel", "nella", "non", "di", "da", "in", "a",
                             "ha", "ho", "hai", "hanno", "essere", "avere", "fare",
                             "questo", "quello", "molto", "più", "anche", "come"],
            "common_chars": list("abcdefghijklmnopqrstuvwxyz"),
            "diacritics": ["à", "è", "é", "ì", "ò", "ù"],
        },
        "pt": {
            "common_words": ["o", "a", "os", "as", "de", "do", "da", "dos", "das", "em",
                             "no", "na", "nos", "nas", "um", "uma", "uns", "umas", "para",
                             "com", "por", "que", "e", "é", "não", "se", "mais", "como",
                             "já", "muito", "pode", "ser", "ter", "sobre", "entre",
                             "depois", "antes", "também", "quando", "onde", "mim"],
            "common_chars": list("abcdefghijklmnopqrstuvwxyz"),
            "diacritics": ["á", "à", "â", "ã", "é", "ê", "í", "ó", "ô", "õ", "ú", "ç"],
        },
        "nl": {
            "common_words": ["de", "het", "een", "van", "in", "op", "voor", "met", "aan",
                             "naar", "over", "door", "bij", "uit", "dat", "die", "dit",
                             "het", "niet", "en", "of", "maar", "als", "ook", "nog",
                             "zijn", "heeft", "hebben", "wordt", "zou", "kan", "moet",
                             "daar", "er", "tot", "hun", "haar", "wel"],
            "common_chars": list("abcdefghijklmnopqrstuvwxyz"),
            "diacritics": ["ë", "ï", "ü", "é", "è"],
        },
        "ru": {
            "common_words": ["и", "в", "не", "на", "что", "с", "как", "это", "но", "он",
                             "она", "они", "мы", "вы", "ты", "к", "у", "за", "от", "из",
                             "по", "для", "до", "о", "об", "же", "бы", "мне", "меня",
                             "тебя", "его", "её", "их", "все", "так", "ещё", "уже"],
            "common_chars": list("абвгдеёжзийклмнопрстуфхцчшщъыьэюя"),
            "diacritics": [],
        },
        "ja": {
            "common_words": ["は", "が", "の", "を", "に", "へ", "と", "で", "から", "まで",
                             "も", "か", "ね", "よ", "です", "ます", "した", "する", "いる",
                             "ある", "こと", "もの", "ため", "これ", "それ", "あれ",
                             "この", "その", "あの", "私", "彼", "彼女", "たち", "たち"],
            "common_chars": [],
            "diacritics": [],
        },
        "zh": {
            "common_words": ["的", "了", "是", "在", "我", "有", "和", "就", "不", "人",
                             "都", "一", "一个", "上", "也", "很", "到", "说", "要",
                             "去", "你", "会", "着", "没有", "看", "好", "自己", "这"],
            "common_chars": [],
            "diacritics": [],
        },
        "ar": {
            "common_words": ["في", "من", "على", "إلى", "عن", "مع", "كان", "هذا", "هذه",
                             "ذلك", "هو", "هي", "هم", "نحن", "أنتم", "لقد", "قد",
                             "سوف", "لا", "ما", "لم", "لن", "إذا", "إن", "أن", "إلى"],
            "common_chars": list("ابتثجحخدذرزسشصضطظعغفقكلمنهويءآأؤإئ"),
            "diacritics": [],
        },
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.detect(text)

    def detect(self, text: str) -> dict:
        text_lower = text.lower()
        scores: dict[str, float] = {}
        for lang_code, chars in self._CHARACTERISTICS.items():
            score = self._score_language(text_lower, lang_code, chars)
            scores[lang_code] = score
        if not scores:
            return {"language": "unknown", "confidence": 0.0, "all_scores": {}}
        total = sum(scores.values())
        best_lang = max(scores, key=scores.get)
        best_score = scores[best_lang]
        confidence = round(best_score / total, 4) if total > 0 else 0.0
        normalized_scores = {k: round(v / total, 4) for k, v in scores.items()}
        return {
            "language": best_lang,
            "language_name": self._get_language_name(best_lang),
            "confidence": confidence,
            "all_scores": normalized_scores,
        }

    def _score_language(self, text: str, lang_code: str, chars: dict) -> float:
        score = 0.0
        words = text.split()
        common_words = set(chars.get("common_words", []))
        diacritics = chars.get("diacritics", [])
        lang_chars = chars.get("common_chars", [])
        matching_common = sum(1 for w in words if w in common_words)
        score += matching_common * 2.0
        if diacritics:
            for char in text:
                if char in diacritics:
                    score += 1.0
        if lang_code in ("ja", "zh"):
            cjk_count = sum(1 for c in text if ord(c) >= 0x4E00)
            if lang_code == "ja":
                hiragana = sum(1 for c in text if 0x3040 <= ord(c) <= 0x309F)
                katakana = sum(1 for c in text if 0x30A0 <= ord(c) <= 0x30FF)
                score += hiragana * 3 + katakana * 3
                score -= cjk_count * 0.5
            else:
                score += cjk_count * 3
                hiragana = sum(1 for c in text if 0x3040 <= ord(c) <= 0x309F)
                score -= hiragana * 2
        if lang_code == "ar":
            arabic_count = sum(1 for c in text if 0x0600 <= ord(c) <= 0x06FF)
            score += arabic_count * 2
        if lang_code == "ru":
            cyrillic_count = sum(1 for c in text if 0x0400 <= ord(c) <= 0x04FF)
            score += cyrillic_count * 2
        if lang_chars and lang_code not in ("ja", "zh", "ar", "ru"):
            allowed = sum(1 for c in text if c.isalpha() and (c in lang_chars or c in diacritics))
            disallowed = sum(1 for c in text if c.isalpha() and c not in lang_chars and c not in diacritics)
            score += allowed * 0.3
            score -= disallowed * 0.5
        return max(score, 0.0)

    @staticmethod
    def _get_language_name(code: str) -> str:
        names = {
            "en": "English", "es": "Spanish", "fr": "French", "de": "German",
            "it": "Italian", "pt": "Portuguese", "nl": "Dutch", "ru": "Russian",
            "ja": "Japanese", "zh": "Chinese", "ar": "Arabic",
        }
        return names.get(code, "Unknown")

    def detect_batch(self, texts: list[str]) -> list[dict]:
        return [self.detect(t) for t in texts]

    @property
    def supported_languages(self) -> list[str]:
        return list(self._CHARACTERISTICS.keys())

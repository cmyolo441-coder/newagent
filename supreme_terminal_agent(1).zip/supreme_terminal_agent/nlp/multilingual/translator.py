import re
from typing import Optional


class Translator:
    _DICTIONARY: dict[str, dict[str, str]] = {
        "en": {
            "hello": "hello",
            "goodbye": "goodbye",
            "thank you": "thank you",
            "yes": "yes",
            "no": "no",
            "please": "please",
            "sorry": "sorry",
            "help": "help",
            "how are you": "how are you",
            "fine": "fine",
            "good": "good",
            "bad": "bad",
            "big": "big",
            "small": "small",
            "water": "water",
            "food": "food",
            "friend": "friend",
            "family": "family",
            "love": "love",
            "work": "work",
            "home": "home",
            "today": "today",
            "tomorrow": "tomorrow",
            "yesterday": "yesterday",
            "now": "now",
            "later": "later",
            "morning": "morning",
            "afternoon": "afternoon",
            "evening": "evening",
            "night": "night",
        },
        "es": {
            "hello": "hola",
            "goodbye": "adiós",
            "thank you": "gracias",
            "yes": "sí",
            "no": "no",
            "please": "por favor",
            "sorry": "lo siento",
            "help": "ayuda",
            "how are you": "cómo estás",
            "fine": "bien",
            "good": "bueno",
            "bad": "malo",
            "big": "grande",
            "small": "pequeño",
            "water": "agua",
            "food": "comida",
            "friend": "amigo",
            "family": "familia",
            "love": "amor",
            "work": "trabajo",
            "home": "hogar",
            "today": "hoy",
            "tomorrow": "mañana",
            "yesterday": "ayer",
            "now": "ahora",
            "later": "después",
            "morning": "mañana",
            "afternoon": "tarde",
            "evening": "noche",
            "night": "noche",
        },
        "fr": {
            "hello": "bonjour",
            "goodbye": "au revoir",
            "thank you": "merci",
            "yes": "oui",
            "no": "non",
            "please": "s'il vous plaît",
            "sorry": "désolé",
            "help": "aide",
            "how are you": "comment allez-vous",
            "fine": "bien",
            "good": "bon",
            "bad": "mauvais",
            "big": "grand",
            "small": "petit",
            "water": "eau",
            "food": "nourriture",
            "friend": "ami",
            "family": "famille",
            "love": "amour",
            "work": "travail",
            "home": "maison",
            "today": "aujourd'hui",
            "tomorrow": "demain",
            "yesterday": "hier",
            "now": "maintenant",
            "later": "plus tard",
            "morning": "matin",
            "afternoon": "après-midi",
            "evening": "soir",
            "night": "nuit",
        },
        "de": {
            "hello": "hallo",
            "goodbye": "tschüss",
            "thank you": "danke",
            "yes": "ja",
            "no": "nein",
            "please": "bitte",
            "sorry": "entschuldigung",
            "help": "hilfe",
            "how are you": "wie geht's",
            "fine": "gut",
            "good": "gut",
            "bad": "schlecht",
            "big": "groß",
            "small": "klein",
            "water": "wasser",
            "food": "essen",
            "friend": "freund",
            "family": "familie",
            "love": "liebe",
            "work": "arbeit",
            "home": "zuhause",
            "today": "heute",
            "tomorrow": "morgen",
            "yesterday": "gestern",
            "now": "jetzt",
            "later": "später",
            "morning": "morgen",
            "afternoon": "nachmittag",
            "evening": "abend",
            "night": "nacht",
        },
        "it": {
            "hello": "ciao",
            "goodbye": "arrivederci",
            "thank you": "grazie",
            "yes": "sì",
            "no": "no",
            "please": "per favore",
            "sorry": "mi dispiace",
            "help": "aiuto",
            "how are you": "come stai",
            "fine": "bene",
            "good": "buono",
            "bad": "cattivo",
            "big": "grande",
            "small": "piccolo",
            "water": "acqua",
            "food": "cibo",
            "friend": "amico",
            "family": "famiglia",
            "love": "amore",
            "work": "lavoro",
            "home": "casa",
            "today": "oggi",
            "tomorrow": "domani",
            "yesterday": "ieri",
            "now": "adesso",
            "later": "dopo",
            "morning": "mattina",
            "afternoon": "pomeriggio",
            "evening": "sera",
            "night": "notte",
        },
        "pt": {
            "hello": "olá",
            "goodbye": "tchau",
            "thank you": "obrigado",
            "yes": "sim",
            "no": "não",
            "please": "por favor",
            "sorry": "desculpe",
            "help": "ajuda",
            "how are you": "como está",
            "fine": "bem",
            "good": "bom",
            "bad": "mau",
            "big": "grande",
            "small": "pequeno",
            "water": "água",
            "food": "comida",
            "friend": "amigo",
            "family": "família",
            "love": "amor",
            "work": "trabalho",
            "home": "casa",
            "today": "hoje",
            "tomorrow": "amanhã",
            "yesterday": "ontem",
            "now": "agora",
            "later": "depois",
            "morning": "manhã",
            "afternoon": "tarde",
            "evening": "noite",
            "night": "noite",
        },
        "nl": {
            "hello": "hallo",
            "goodbye": "dag",
            "thank you": "dank je",
            "yes": "ja",
            "no": "nee",
            "please": "alsjeblieft",
            "sorry": "sorry",
            "help": "hulp",
            "how are you": "hoe gaat het",
            "fine": "goed",
            "good": "goed",
            "bad": "slecht",
            "big": "groot",
            "small": "klein",
            "water": "water",
            "food": "eten",
            "friend": "vriend",
            "family": "familie",
            "love": "liefde",
            "work": "werk",
            "home": "thuis",
            "today": "vandaag",
            "tomorrow": "morgen",
            "yesterday": "gisteren",
            "now": "nu",
            "later": "later",
            "morning": "morgen",
            "afternoon": "middag",
            "evening": "avond",
            "night": "nacht",
        },
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        source = kwargs.get("source_lang", "en")
        target = kwargs.get("target_lang", "es")
        return self.translate(text, source, target)

    def translate(self, text: str, source_lang: str = "en", target_lang: str = "es") -> dict:
        if source_lang not in self._DICTIONARY or target_lang not in self._DICTIONARY:
            return {"error": f"Unsupported language pair: {source_lang} -> {target_lang}"}
        text_lower = text.lower().strip()
        source_dict = self._DICTIONARY.get(source_lang, {})
        target_dict = self._DICTIONARY.get(target_lang, {})
        reverse_map = {v: k for k, v in source_dict.items()}
        translated_words: list[str] = []
        matched_count = 0
        for word in re.findall(r'\b\w+\b|[^\w\s]', text_lower):
            if word in self._DICTIONARY.get(source_lang, {}):
                english_word = word
            elif word in reverse_map:
                english_word = reverse_map[word]
            else:
                translated_words.append(word)
                continue
            target_word = target_dict.get(english_word)
            if target_word:
                translated_words.append(target_word)
                matched_count += 1
            else:
                translated_words.append(word)
        translated = " ".join(translated_words)
        translated = self._fix_punctuation_spacing(translated)
        return {
            "original": text,
            "translated": translated,
            "source_language": source_lang,
            "target_language": target_lang,
            "coverage": round(matched_count / max(len(translated_words), 1), 4),
        }

    @staticmethod
    def _fix_punctuation_spacing(text: str) -> str:
        text = re.sub(r'\s+([.,!?;:])', r'\1', text)
        text = re.sub(r'([({[])\s+', r'\1', text)
        text = re.sub(r"\s+([)}\]]')", r'\1', text)
        return text.strip()

    def supported_languages(self) -> list[str]:
        return list(self._DICTIONARY.keys())

    def translate_batch(self, texts: list[str], source_lang: str = "en", target_lang: str = "es") -> list[dict]:
        return [self.translate(t, source_lang, target_lang) for t in texts]

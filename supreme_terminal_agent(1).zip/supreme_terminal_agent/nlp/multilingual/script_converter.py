import re
from typing import Optional


class ScriptConverter:
    _LATIN_TO_CYRILLIC: dict[str, str] = {
        "shch": "щ", "sh": "ш", "ch": "ч", "zh": "ж", "kh": "х",
        "ts": "ц", "yu": "ю", "ya": "я", "ye": "е", "yo": "ё",
        "a": "а", "b": "б", "v": "в", "g": "г", "d": "д",
        "e": "е", "z": "з", "i": "и", "y": "й", "k": "к",
        "l": "л", "m": "м", "n": "н", "o": "о", "p": "п",
        "r": "р", "s": "с", "t": "т", "u": "у", "f": "ф",
        "": "",
    }

    _CYRILLIC_TO_LATIN: dict[str, str] = {
        "щ": "shch", "ш": "sh", "ч": "ch", "ж": "zh", "х": "kh",
        "ц": "ts", "ю": "yu", "я": "ya", "ё": "yo", "й": "y",
        "а": "a", "б": "b", "в": "v", "г": "g", "д": "d",
        "е": "e", "з": "z", "и": "i", "к": "k", "л": "l",
        "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
        "с": "s", "т": "t", "у": "u", "ф": "f", "ы": "y",
        "э": "e", "ь": "", "ъ": "",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        target_script = kwargs.get("target_script", "latin")
        source_script = kwargs.get("source_script", "auto")
        return self.convert(text, target_script, source_script)

    def convert(self, text: str, target_script: str = "latin", source_script: str = "auto") -> dict:
        if source_script == "auto":
            source_script = self.detect_script(text)
        if source_script == target_script:
            return {
                "original": text,
                "converted": text,
                "source_script": source_script,
                "target_script": target_script,
                "changes": 0,
            }
        if source_script == "cyrillic" and target_script == "latin":
            converted = self._cyrillic_to_latin(text)
        elif source_script == "latin" and target_script == "cyrillic":
            converted = self._latin_to_cyrillic(text)
        else:
            converted = text
        changes = sum(1 for a, b in zip(text, converted) if a != b) if len(text) == len(converted) else max(len(text), len(converted))
        return {
            "original": text,
            "converted": converted,
            "source_script": source_script,
            "target_script": target_script,
            "changes": changes,
        }

    def detect_script(self, text: str) -> str:
        cyrillic_count = sum(1 for c in text if 0x0400 <= ord(c) <= 0x04FF)
        latin_count = sum(1 for c in text if 'a' <= c.lower() <= 'z')
        greek_count = sum(1 for c in text if 0x0370 <= ord(c) <= 0x03FF)
        arabic_count = sum(1 for c in text if 0x0600 <= ord(c) <= 0x06FF)
        if cyrillic_count > latin_count and cyrillic_count > greek_count:
            return "cyrillic"
        if latin_count > cyrillic_count and latin_count > greek_count:
            return "latin"
        if greek_count:
            return "greek"
        if arabic_count:
            return "arabic"
        return "latin"

    def _cyrillic_to_latin(self, text: str) -> str:
        result = ""
        i = 0
        while i < len(text):
            char = text[i]
            matched = False
            for cyrillic, latin in sorted(self._CYRILLIC_TO_LATIN.items(), key=lambda x: -len(x[0])):
                if text[i:i + len(cyrillic)].lower() == cyrillic:
                    if char.isupper():
                        result += latin.capitalize() if latin else ""
                    else:
                        result += latin
                    i += len(cyrillic)
                    matched = True
                    break
            if not matched:
                result += char
                i += 1
        return result

    def _latin_to_cyrillic(self, text: str) -> str:
        result = ""
        i = 0
        text_lower = text.lower()
        while i < len(text):
            matched = False
            for latin, cyrillic in sorted(self._LATIN_TO_CYRILLIC.items(), key=lambda x: -len(x[0])):
                if text_lower[i:i + len(latin)] == latin:
                    if text[i].isupper():
                        result += cyrillic.upper() if cyrillic else ""
                    else:
                        result += cyrillic
                    i += len(latin)
                    matched = True
                    break
            if not matched:
                result += text[i]
                i += 1
        return result

    def add_mapping(self, source_script: str, target_script: str, source_char: str, target_char: str) -> None:
        if source_script == "cyrillic" and target_script == "latin":
            self._CYRILLIC_TO_LATIN[source_char] = target_char
        elif source_script == "latin" and target_script == "cyrillic":
            self._LATIN_TO_CYRILLIC[source_char] = target_char

    def batch_convert(self, texts: list[str], target_script: str = "latin") -> list[dict]:
        return [self.convert(t, target_script) for t in texts]

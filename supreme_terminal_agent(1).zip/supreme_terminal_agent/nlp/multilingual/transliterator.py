import re
from typing import Optional


class Transliterator:
    _TRANSLITERATION_TABLES: dict[str, dict[str, str]] = {
        "ru_to_en": {
            "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "ye", "ё": "yo",
            "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
            "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
            "ф": "f", "х": "kh", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "shch",
            "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
            "А": "A", "Б": "B", "В": "V", "Г": "G", "Д": "D", "Е": "Ye", "Ё": "Yo",
            "Ж": "Zh", "З": "Z", "И": "I", "Й": "Y", "К": "K", "Л": "L", "М": "M",
            "Н": "N", "О": "O", "П": "P", "Р": "R", "С": "S", "Т": "T", "У": "U",
            "Ф": "F", "Х": "Kh", "Ц": "Ts", "Ч": "Ch", "Ш": "Sh", "Щ": "Shch",
            "Ъ": "", "Ы": "Y", "Ь": "", "Э": "E", "Ю": "Yu", "Я": "Ya",
        },
        "el_to_en": {
            "α": "a", "β": "v", "γ": "g", "δ": "d", "ε": "e", "ζ": "z", "η": "i",
            "θ": "th", "ι": "i", "κ": "k", "λ": "l", "μ": "m", "ν": "n", "ξ": "x",
            "ο": "o", "π": "p", "ρ": "r", "σ": "s", "τ": "t", "υ": "y", "φ": "f",
            "χ": "ch", "ψ": "ps", "ω": "o",
            "Α": "A", "Β": "V", "Γ": "G", "Δ": "D", "Ε": "E", "Ζ": "Z", "Η": "I",
            "Θ": "Th", "Ι": "I", "Κ": "K", "Λ": "L", "Μ": "M", "Ν": "N", "Ξ": "X",
            "Ο": "O", "Π": "P", "Ρ": "R", "Σ": "S", "Τ": "T", "Υ": "Y", "Φ": "F",
            "Χ": "Ch", "Ψ": "Ps", "Ω": "O",
        },
        "ar_to_en": {
            "ا": "a", "ب": "b", "ت": "t", "ث": "th", "ج": "j", "ح": "h", "خ": "kh",
            "د": "d", "ذ": "dh", "ر": "r", "ز": "z", "س": "s", "ش": "sh", "ص": "s",
            "ض": "d", "ط": "t", "ظ": "z", "ع": "a", "غ": "gh", "ف": "f", "ق": "q",
            "ك": "k", "ل": "l", "م": "m", "ن": "n", "ه": "h", "و": "w", "ي": "y",
            "ء": "'", "آ": "aa", "ة": "h", "ى": "a", "ئ": "'",
        },
        "zh_to_en": {
            "的": "de", "一": "yi", "是": "shi", "不": "bu", "了": "le",
            "人": "ren", "我": "wo", "在": "zai", "有": "you", "他": "ta",
            "这": "zhe", "中": "zhong", "大": "da", "来": "lai", "上": "shang",
            "国": "guo", "个": "ge", "到": "dao", "说": "shuo", "们": "men",
            "为": "wei", "和": "he", "你": "ni", "地": "di", "出": "chu",
            "子": "zi", "会": "hui", "时": "shi", "要": "yao", "生": "sheng",
        },
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        source_script = kwargs.get("source_script", "ru")
        target_script = kwargs.get("target_script", "en")
        return self.transliterate(text, source_script, target_script)

    def transliterate(self, text: str, source_script: str = "ru", target_script: str = "en") -> dict:
        table_key = f"{source_script}_to_{target_script}"
        table = self._TRANSLITERATION_TABLES.get(table_key)
        if table is None:
            return {
                "error": f"No transliteration table for {source_script} -> {target_script}",
                "original": text,
                "transliterated": text,
            }
        result = []
        for char in text:
            if char in table:
                result.append(table[char])
            else:
                result.append(char)
        transliterated = "".join(result)
        return {
            "original": text,
            "transliterated": transliterated,
            "source_script": source_script,
            "target_script": target_script,
            "chars_transliterated": sum(1 for c in text if c in table),
        }

    def detect_script(self, text: str) -> str:
        script_ranges: list[tuple[str, tuple[int, int]]] = [
            ("cyrillic", (0x0400, 0x04FF)),
            ("greek", (0x0370, 0x03FF)),
            ("arabic", (0x0600, 0x06FF)),
            ("hebrew", (0x0590, 0x05FF)),
            ("devanagari", (0x0900, 0x097F)),
            ("cjk", (0x4E00, 0x9FFF)),
            ("hiragana", (0x3040, 0x309F)),
            ("katakana", (0x30A0, 0x30FF)),
            ("hangul", (0xAC00, 0xD7AF)),
            ("thai", (0x0E00, 0x0E7F)),
        ]
        scores: dict[str, int] = {}
        for char in text:
            cp = ord(char)
            for script_name, (start, end) in script_ranges:
                if start <= cp <= end:
                    scores[script_name] = scores.get(script_name, 0) + 1
        if not scores:
            return "latin"
        return max(scores, key=scores.get)

    def add_table(self, source: str, target: str, table: dict[str, str]) -> None:
        key = f"{source}_to_{target}"
        self._TRANSLITERATION_TABLES[key] = table

    def supported_scripts(self) -> list[str]:
        scripts: set[str] = set()
        for key in self._TRANSLITERATION_TABLES:
            parts = key.split("_to_")
            if len(parts) == 2:
                scripts.add(parts[0])
                scripts.add(parts[1])
        return sorted(scripts)

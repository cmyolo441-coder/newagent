import re
from typing import Optional


class LocaleHandler:
    _LOCALES: dict[str, dict[str, dict[str, str]]] = {
        "en_US": {
            "date_format": "%m/%d/%Y",
            "time_format": "%I:%M %p",
            "decimal_separator": ".",
            "thousands_separator": ",",
            "currency_symbol": "$",
            "currency_code": "USD",
            "unit_system": "imperial",
            "first_day_of_week": 0,
            "timezone": "America/New_York",
        },
        "en_GB": {
            "date_format": "%d/%m/%Y",
            "time_format": "%H:%M",
            "decimal_separator": ".",
            "thousands_separator": ",",
            "currency_symbol": "£",
            "currency_code": "GBP",
            "unit_system": "imperial",
            "first_day_of_week": 0,
            "timezone": "Europe/London",
        },
        "es_ES": {
            "date_format": "%d/%m/%Y",
            "time_format": "%H:%M",
            "decimal_separator": ",",
            "thousands_separator": ".",
            "currency_symbol": "€",
            "currency_code": "EUR",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "Europe/Madrid",
        },
        "fr_FR": {
            "date_format": "%d/%m/%Y",
            "time_format": "%H:%M",
            "decimal_separator": ",",
            "thousands_separator": " ",
            "currency_symbol": "€",
            "currency_code": "EUR",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "Europe/Paris",
        },
        "de_DE": {
            "date_format": "%d.%m.%Y",
            "time_format": "%H:%M",
            "decimal_separator": ",",
            "thousands_separator": ".",
            "currency_symbol": "€",
            "currency_code": "EUR",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "Europe/Berlin",
        },
        "it_IT": {
            "date_format": "%d/%m/%Y",
            "time_format": "%H:%M",
            "decimal_separator": ",",
            "thousands_separator": ".",
            "currency_symbol": "€",
            "currency_code": "EUR",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "Europe/Rome",
        },
        "pt_BR": {
            "date_format": "%d/%m/%Y",
            "time_format": "%H:%M",
            "decimal_separator": ",",
            "thousands_separator": ".",
            "currency_symbol": "R$",
            "currency_code": "BRL",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "America/Sao_Paulo",
        },
        "nl_NL": {
            "date_format": "%d-%m-%Y",
            "time_format": "%H:%M",
            "decimal_separator": ",",
            "thousands_separator": ".",
            "currency_symbol": "€",
            "currency_code": "EUR",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "Europe/Amsterdam",
        },
        "ru_RU": {
            "date_format": "%d.%m.%Y",
            "time_format": "%H:%M",
            "decimal_separator": ",",
            "thousands_separator": " ",
            "currency_symbol": "₽",
            "currency_code": "RUB",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "Europe/Moscow",
        },
        "ja_JP": {
            "date_format": "%Y/%m/%d",
            "time_format": "%H:%M",
            "decimal_separator": ".",
            "thousands_separator": ",",
            "currency_symbol": "¥",
            "currency_code": "JPY",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "Asia/Tokyo",
        },
        "zh_CN": {
            "date_format": "%Y/%m/%d",
            "time_format": "%H:%M",
            "decimal_separator": ".",
            "thousands_separator": ",",
            "currency_symbol": "¥",
            "currency_code": "CNY",
            "unit_system": "metric",
            "first_day_of_week": 0,
            "timezone": "Asia/Shanghai",
        },
        "ar_SA": {
            "date_format": "%d/%m/%Y",
            "time_format": "%I:%M %p",
            "decimal_separator": ".",
            "thousands_separator": ",",
            "currency_symbol": "﷼",
            "currency_code": "SAR",
            "unit_system": "metric",
            "first_day_of_week": 6,
            "timezone": "Asia/Riyadh",
        },
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._current_locale = self.config.get("locale", "en_US")

    def process(self, text: str = "", **kwargs) -> dict:
        target_locale = kwargs.get("locale", self._current_locale)
        return self.get_locale_info(target_locale)

    def get_locale_info(self, locale: str = "") -> dict:
        locale = locale or self._current_locale
        if locale not in self._LOCALES:
            return {"error": f"Locale not supported: {locale}", "locale": locale}
        return {
            "locale": locale,
            "info": self._LOCALES[locale],
        }

    def format_number(self, number: float, locale: str = "") -> str:
        locale = locale or self._current_locale
        info = self._LOCALES.get(locale, self._LOCALES["en_US"])
        dec_sep = info["decimal_separator"]
        thou_sep = info["thousands_separator"]
        parts = str(number).split(".")
        int_part = parts[0]
        if len(int_part) > 3:
            groups = []
            for i in range(len(int_part), 0, -3):
                start = max(0, i - 3)
                groups.append(int_part[start:i])
            int_part = thou_sep.join(reversed(groups))
        if len(parts) > 1:
            return f"{int_part}{dec_sep}{parts[1]}"
        return int_part

    def parse_number(self, text: str, locale: str = "") -> float:
        locale = locale or self._current_locale
        info = self._LOCALES.get(locale, self._LOCALES["en_US"])
        dec_sep = info["decimal_separator"]
        thou_sep = info["thousands_separator"]
        cleaned = text.replace(thou_sep, "").replace(dec_sep, ".")
        match = re.search(r'-?\d+(?:\.\d+)?', cleaned)
        return float(match.group(0)) if match else 0.0

    def format_currency(self, amount: float, locale: str = "") -> str:
        locale = locale or self._current_locale
        info = self._LOCALES.get(locale, self._LOCALES["en_US"])
        formatted = self.format_number(amount, locale)
        return f"{info['currency_symbol']}{formatted}"

    def get_currency_code(self, locale: str = "") -> str:
        locale = locale or self._current_locale
        info = self._LOCALES.get(locale, self._LOCALES["en_US"])
        return info.get("currency_code", "USD")

    def get_unit_system(self, locale: str = "") -> str:
        locale = locale or self._current_locale
        info = self._LOCALES.get(locale, self._LOCALES["en_US"])
        return info.get("unit_system", "metric")

    def set_locale(self, locale: str) -> None:
        if locale not in self._LOCALES:
            raise ValueError(f"Unsupported locale: {locale}. Supported: {list(self._LOCALES.keys())}")
        self._current_locale = locale

    def add_locale(self, locale: str, info: dict) -> None:
        required_keys = {"date_format", "time_format", "decimal_separator", "thousands_separator",
                         "currency_symbol", "currency_code", "unit_system"}
        missing = required_keys - set(info.keys())
        if missing:
            raise ValueError(f"Missing locale info keys: {missing}")
        self._LOCALES[locale] = info

    def supported_locales(self) -> list[str]:
        return list(self._LOCALES.keys())

import re
from typing import Optional


class QuestionAnalyzer:
    _QUESTION_TYPES: dict[str, list[str]] = {
        "factual": [
            r"\b(what is|what are|who is|who are|where is|where are|when is|when was)",
            r"\b(what time|what date|what year|what month)",
            r"\b(how many|how much|how long|how far|how often|how old)",
        ],
        "definition": [
            r"\b(what does|what is|define|explain|describe|clarify|what do you mean)",
            r"\b(what is the meaning|what is the definition|what is meant)",
        ],
        "yes_no": [
            r"^(is|are|was|were|has|have|had|do|does|did|can|could|will|would|shall|should|may|might|must) \w+",
            r"\bdo you|does it|can it|is it|are they|was it|were they|has it|have they",
        ],
        "choice": [
            r"\b(or\b.*\?$)",
            r"\b(which one|which of these|prefer|rather|better)",
            r"\b(would you rather|do you prefer|which is better)",
        ],
        "how_to": [
            r"\b(how (?:to|do I|can I|could I|would I|should I|does one|can one))",
            r"\b(how do you|how can you|how to)",
            r"\b(steps|instructions|method|procedure|process|tutorial|guide)",
        ],
        "reason": [
            r"\b(why|what for|for what reason|how come|what is the reason)",
            r"\b(why is|why are|why was|why did|why does|why do|why can't|why won't)",
        ],
        "hypothetical": [
            r"\b(what if|what would|what could|suppose|imagine|if.*then)",
            r"\b(would you|could you|might you) if",
            r"\b(if you could|if you were|if there was)",
        ],
        "opinion": [
            r"\b(what do you think|do you think|in your opinion|what is your opinion|how do you feel)",
            r"\b(what are your thoughts|what's your take|what do you say)",
        ],
        "clarification": [
            r"\b(what do you mean|could you clarify|can you explain|i don't understand|what does that mean)",
            r"\b(can you rephrase|in other words|what i mean is)",
            r"\b(did you say|did you mean|are you saying|are you implying)",
        ],
    }

    _QUESTION_WORDS: dict[str, str] = {
        "who": "person", "whom": "person", "whose": "possession",
        "what": "thing", "which": "choice",
        "where": "location", "when": "time",
        "why": "reason", "how": "manner",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.analyze(text)

    def analyze(self, text: str) -> dict:
        qtype = self.classify_type(text)
        qword = self.extract_question_word(text)
        return {
            "is_question": self._is_question(text),
            "question_type": qtype,
            "question_word": qword,
            "question_word_type": self._QUESTION_WORDS.get(qword, "unknown"),
            "expected_answer_type": self._expected_answer_type(qtype, qword),
            "is_polar": qtype == "yes_no",
            "is_wh": qword in self._QUESTION_WORDS,
            "confidence": self._compute_confidence(text, qtype),
        }

    def classify_type(self, text: str) -> str:
        text_clean = text.strip()
        for qtype, patterns in self._QUESTION_TYPES.items():
            for pattern in patterns:
                if re.search(pattern, text_clean, re.IGNORECASE):
                    return qtype
        if text_clean.endswith("?"):
            return "yes_no"
        return "unknown"

    @staticmethod
    def extract_question_word(text: str) -> str:
        match = re.match(r'\b(who|whom|whose|what|which|where|when|why|how)\b', text.strip(), re.IGNORECASE)
        if match:
            return match.group(1).lower()
        return ""

    @staticmethod
    def _is_question(text: str) -> bool:
        text = text.strip()
        if text.endswith("?"):
            return True
        if re.match(r'^(is|are|was|were|has|have|had|do|does|did|can|could|will|would|shall|should|may|might|must) ', text, re.IGNORECASE):
            return True
        if re.match(r'^(what|who|where|when|why|how|which|whose|whom) ', text, re.IGNORECASE):
            return True
        return False

    @staticmethod
    def _expected_answer_type(qtype: str, qword: str) -> str:
        mapping = {
            "factual": "fact",
            "definition": "definition",
            "yes_no": "boolean",
            "choice": "option",
            "how_to": "instruction",
            "reason": "explanation",
            "hypothetical": "speculation",
            "opinion": "opinion",
            "clarification": "restatement",
        }
        qword_map = {
            "who": "person_name",
            "what": "entity",
            "where": "location_name",
            "when": "date_time",
            "why": "reason_text",
            "how": "description",
            "which": "selection",
        }
        return qword_map.get(qword, mapping.get(qtype, "unknown"))

    @staticmethod
    def _compute_confidence(text: str, qtype: str) -> float:
        if text.endswith("?"):
            return 0.9 if qtype != "unknown" else 0.5
        if re.match(r'^(what|who|where|when|why|how) ', text.strip(), re.IGNORECASE):
            return 0.7
        return 0.4

    def batch_analyze(self, texts: list[str]) -> list[dict]:
        return [self.analyze(t) for t in texts]

import re
from typing import Optional


class SlotFiller:
    _INTENT_SLOTS: dict[str, dict[str, list[tuple[str, str]]]] = {
        "greeting": {
            "recipient": [(r"\b(?:hello|hi|hey)\s+(\w+)", "name")],
        },
        "command": {
            "action": [(r"^(run|execute|do|make|create|generate|start|stop|delete|remove|add|show|list|get|set|update|install) (\w+)", "verb")],
            "target": [(r"(?:run|execute|do|make|create|generate|start|stop|delete|remove|add|show|list|get|set|update|install) (\w+)", "noun")],
            "parameters": [(r"(?:--|-)(\w+)=(\w+)", "flag=value")],
        },
        "question": {
            "subject": [(r"(?:what|who|where|when|why|how) (?:is|are|was|were|does|do|did|can|could|will|would) (\w+)", "noun")],
            "property": [(r"(?:what|who) (\w+)", "property")],
            "entity": [(r"\b(\w+)\?$", "entity")],
        },
        "request": {
            "action": [(r"(?:i want|i need|i would like|i'd like|i wish|can i|could i|may i) (?:to )?(\w+)", "verb")],
            "object": [(r"(?:i want|i need|i would like|i'd like|i wish|can i|could i|may i) (?:to )?\w+ (\w+)", "noun")],
        },
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        intent = kwargs.get("intent", "unknown")
        return self.fill(text, intent)

    def fill(self, text: str, intent: str) -> dict:
        slots: dict[str, list[dict]] = {}
        intent_slots = self._INTENT_SLOTS.get(intent, {})
        for slot_name, patterns in intent_slots.items():
            matches: list[dict] = []
            for pattern, slot_type in patterns:
                for match in re.finditer(pattern, text, re.IGNORECASE):
                    matches.append({
                        "value": match.group(1) if match.lastindex and match.lastindex >= 1 else match.group(0),
                        "type": slot_type,
                        "span": (match.start(), match.end()),
                    })
            if matches:
                slots[slot_name] = matches
        general_slots = self._extract_general(text)
        for key, val in general_slots.items():
            slots.setdefault(key, []).extend(val)
        return {
            "slots": slots,
            "filled": any(slots.values()),
            "slot_count": sum(len(v) for v in slots.values()),
        }

    def _extract_general(self, text: str) -> dict[str, list[dict]]:
        slots: dict[str, list[dict]] = {}
        for match in re.finditer(r"(?:--|-)(\w+)=(\w+)", text):
            slots.setdefault("flags", []).append({
                "name": match.group(1),
                "value": match.group(2),
                "type": "flag",
            })
        for match in re.finditer(r'"([^"]*)"', text):
            slots.setdefault("quoted", []).append({
                "value": match.group(1),
                "type": "quoted_string",
                "span": (match.start(), match.end()),
            })
        for match in re.finditer(r"'([^']*)'", text):
            slots.setdefault("quoted", []).append({
                "value": match.group(1),
                "type": "quoted_string",
                "span": (match.start(), match.end()),
            })
        urls = re.findall(r'https?://\S+', text)
        if urls:
            slots["url"] = [{"value": u, "type": "url"} for u in urls]
        emails = re.findall(r'\S+@\S+\.\S+', text)
        if emails:
            slots["email"] = [{"value": e, "type": "email"} for e in emails]
        numbers = re.findall(r'\b\d+\b', text)
        if numbers:
            slots["numbers"] = [{"value": n, "type": "number"} for n in numbers]
        return slots

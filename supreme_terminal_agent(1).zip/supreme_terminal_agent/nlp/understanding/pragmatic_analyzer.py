import re
from typing import Optional


class PragmaticAnalyzer:
    _POLITENESS_MARKERS: dict[str, list[str]] = {
        "please": ["please", "plz", "pls"],
        "thank_you": ["thank", "thanks", "thank you", "appreciate"],
        "sorry": ["sorry", "apologize", "apologies", "pardon", "excuse"],
        "would_you": ["would you", "could you", "can you", "will you", "would you mind"],
        "may_i": ["may i", "can i", "could i", "might i"],
        "title": ["sir", "ma'am", "madam", "mr.", "mrs.", "ms.", "dr.", "prof."],
    }

    _IMPOLITENESS_MARKERS: list[str] = [
        "shut up", "stupid", "idiot", "dumb", "shut it", "nonsense",
        "ridiculous", "absurd", "outrageous", "unacceptable",
        "you're wrong", "that's wrong", "that's incorrect",
        "stop talking", "be quiet", "leave me alone",
    ]

    _FORMALITY_WORDS: dict[str, list[str]] = {
        "formal": ["however", "therefore", "thus", "hence", "consequently",
                    "nevertheless", "nonetheless", "furthermore", "moreover",
                    "accordingly", "subsequently", "additionally", "regarding",
                    "with respect to", "in accordance with", "prior to",
                    "subsequent to", "upon", "commence", "terminate",
                    "utilize", "demonstrate", "indicate", "constitute",
                    "sufficient", "approximately", "substantially"],
        "informal": ["but", "so", "then", "yeah", "nah", "gonna", "wanna",
                      "gotta", "kinda", "sorta", "lots", "stuff", "thing",
                      "cool", "awesome", "great", "hey", "hi", "ok", "okay",
                      "sure", "alright", "anyway", "whatever", "basically",
                      "actually", "honestly", "literally", "pretty",
                      "really", "very", "quite", "just", "like"],
    }

    _SPEECH_ACT_PATTERNS: dict[str, list[tuple[str, float]]] = {
        "assertive": [
            (r"\b(is|are|was|were|has|have|had|will|would|can|could)\b", 0.5),
            (r"\b(I think|I believe|I know|I'm sure|I'm certain)\b", 0.8),
            (r"\b(the fact is|the truth is|definitely|certainly|absolutely)\b", 0.9),
        ],
        "directive": [
            (r"\b(must|should|need to|have to|ought to|better)\b", 0.7),
            (r"^(run|execute|do|make|create|generate|start|stop|show|list|get|set)\b", 0.9),
            (r"\b(don't|do not|never|stop|cease)\b", 0.8),
        ],
        "commissive": [
            (r"\b(I will|I'll|I promise|I swear|I guarantee|I pledge)\b", 1.0),
            (r"\b(I intend|I plan|I aim|I'm going to|I'll try)\b", 0.8),
        ],
        "expressive": [
            (r"\b(sorry|thank|thanks|apologize|regret|happy|glad|sad|angry|excited|worried|afraid)\b", 0.9),
            (r"\b(congratulations|well done|good job|excellent|wonderful|fantastic)\b", 1.0),
        ],
        "declarative": [
            (r"\b(I declare|I pronounce|I name|I christen|I appoint|I sentence|I resign)\b", 1.0),
            (r"\b(the meeting is|the session is|the game is|we are)\b", 0.5),
        ],
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.analyze(text)

    def analyze(self, text: str) -> dict:
        return {
            "politeness": self._analyze_politeness(text),
            "formality": self._analyze_formality(text),
            "speech_act": self._classify_speech_act(text),
            "implicature": self._detect_implicature(text),
            "presupposition": self._detect_presuppositions(text),
            "sarcasm_risk": self._detect_sarcasm(text),
        }

    def _analyze_politeness(self, text: str) -> dict:
        text_lower = text.lower()
        positives = 0
        negatives = 0
        markers_found: dict[str, list[str]] = {}
        for category, markers in self._POLITENESS_MARKERS.items():
            found = [m for m in markers if m in text_lower]
            if found:
                markers_found[category] = found
                positives += len(found)
        for marker in self._IMPOLITENESS_MARKERS:
            if marker in text_lower:
                negatives += 1
        total = positives + negatives
        score = round((positives - negatives) / max(total, 1), 4) if total > 0 else 0.0
        if score > 0.3:
            level = "very polite"
        elif score > 0:
            level = "polite"
        elif score == 0:
            level = "neutral"
        elif score > -0.3:
            level = "impolite"
        else:
            level = "very impolite"
        return {
            "score": score,
            "level": level,
            "positive_markers": markers_found,
            "negative_markers": [m for m in self._IMPOLITENESS_MARKERS if m in text_lower],
        }

    def _analyze_formality(self, text: str) -> dict:
        text_lower = text.lower()
        formal_count = 0
        informal_count = 0
        for word in self._FORMALITY_WORDS["formal"]:
            if word in text_lower:
                formal_count += 1
        for word in self._FORMALITY_WORDS["informal"]:
            if word in text_lower:
                informal_count += 1
        total = formal_count + informal_count
        if total == 0:
            return {"score": 0.0, "level": "neutral", "formal_count": 0, "informal_count": 0}
        ratio = formal_count / max(informal_count, 1)
        normalized = round(ratio / (ratio + 1), 4)
        if normalized > 0.7:
            level = "very formal"
        elif normalized > 0.5:
            level = "formal"
        elif normalized > 0.3:
            level = "informal"
        else:
            level = "very informal"
        return {
            "score": normalized,
            "level": level,
            "formal_count": formal_count,
            "informal_count": informal_count,
        }

    def _classify_speech_act(self, text: str) -> dict:
        scores: dict[str, float] = {}
        for act, patterns in self._SPEECH_ACT_PATTERNS.items():
            total = 0.0
            for pattern, weight in patterns:
                for match in re.finditer(pattern, text, re.IGNORECASE):
                    total += weight
            if total > 0:
                scores[act] = total
        if not scores:
            return {"speech_act": "unknown", "confidence": 0.0}
        best = max(scores, key=scores.get)
        total_score = sum(scores.values())
        confidence = round(scores[best] / total_score, 4) if total_score > 0 else 0.0
        return {"speech_act": best, "confidence": confidence, "all_scores": scores}

    @staticmethod
    def _detect_implicature(text: str) -> list[dict]:
        implicatures: list[dict] = []
        patterns = [
            (r"\b(can you|could you|would you|will you)\b", "request_implicature",
             "Question about ability may imply a request"),
            (r"\b(do you know|do you have|do you see)\b", "indirect_question",
             "Question about knowledge may imply a request for information"),
            (r"\b(I think|I believe|I guess|I suppose)\b", "hedge",
             "Hedging may imply uncertainty"),
            (r"\b(it's (?:cold|hot|warm|noisy|quiet) (?:in here|here))\b", "indirect_request",
             "Statement about environment may imply a request to change it"),
            (r"\b(I wonder|I was wondering)\b", "indirect_question",
             "Expression of wonder may imply a question"),
        ]
        for pattern, impl_type, desc in patterns:
            if re.search(pattern, text, re.IGNORECASE):
                implicatures.append({"type": impl_type, "description": desc})
        return implicatures

    @staticmethod
    def _detect_presuppositions(text: str) -> list[dict]:
        presuppositions: list[dict] = []
        patterns = [
            (r"\b(stop|cease|quit|give up|abandon) (\w+)", "factual",
             "Speaker presupposes the action was happening"),
            (r"\b(know|realize|understand|recognize|appreciate) that\b", "factual",
             "Speaker presupposes the embedded proposition is true"),
            (r"\b(regret|apologize|forgive|blame|accuse) (\w+)", "factual",
             "Speaker presupposes the event occurred"),
            (r"\b(again|another|more|else|additional|further)\b", "existential",
             "Speaker presupposes prior existence"),
            (r"\b(my|your|his|her|its|our|their) (\w+)", "possessive",
             "Speaker presupposes existence of the possessed entity"),
            (r"\b(the\s+\w+)", "definite",
             "Speaker presupposes existence of the referred entity"),
        ]
        for pattern, pres_type, desc in patterns:
            if re.search(pattern, text, re.IGNORECASE):
                presuppositions.append({"type": pres_type, "description": desc})
        return presuppositions

    @staticmethod
    def _detect_sarcasm(text: str) -> dict:
        text_lower = text.lower()
        risk = 0.0
        sarcasm_indicators = [
            (r"\b(yeah|sure|right|of course|obviously|certainly|absolutely)\s*(\.\.\.|!|, right|, sure)", 0.4),
            (r"\bfantastic\b.*!(?:\s+as if|.*not)", 0.3),
            (r"\bgreat\b.*(?:not|just what I needed|another)", 0.3),
            (r"\b(?:as if|like I care|who cares|whatever)\b", 0.5),
            (r"\b(?:thanks a lot|thanks for nothing|big deal)\b", 0.6),
            (r"\b(?:yeah right|sure thing|oh really|no kidding|you don't say)\b", 0.7),
            (r"\b(?:brilliant|genius|smart)\b.*(?:idea|move|thinking)", 0.2),
            (r"(!{2,}|\.{3,})", 0.2),
        ]
        for pattern, weight in sarcasm_indicators:
            if re.search(pattern, text_lower):
                risk += weight
        risk = min(risk, 1.0)
        return {
            "risk_score": round(risk, 4),
            "likely_sarcastic": risk >= 0.5,
            "indicators_found": risk > 0,
        }

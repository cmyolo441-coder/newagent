import re
from typing import Any, Optional


class ContextUnderstander:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._history: list[dict] = []
        self._max_history = self.config.get("max_history", 50)

    def process(self, text: str, **kwargs) -> dict:
        context = kwargs.get("context", {})
        return self.understand(text, context)

    def understand(self, text: str, context: Optional[dict] = None) -> dict:
        context = context or {}
        history_context = self._build_history_context()
        return {
            "text": text,
            "context": context,
            "history_context": history_context,
            "is_followup": self._is_followup(text, history_context),
            "has_anaphora": self._has_anaphora(text),
            "references_previous": self._references_previous(text, history_context),
            "context_shift": self._detect_context_shift(text, history_context),
        }

    def update_history(self, utterance: str, metadata: Optional[dict] = None) -> None:
        self._history.append({"text": utterance, "metadata": metadata or {}})
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

    def clear_history(self) -> None:
        self._history.clear()

    def _build_history_context(self) -> dict:
        if not self._history:
            return {"last_utterance": "", "recent_topics": [], "turn_count": 0}
        recent = self._history[-5:]
        return {
            "last_utterance": recent[-1]["text"] if recent else "",
            "recent_topics": self._extract_topics(recent),
            "turn_count": len(self._history),
            "history_text": " ".join(h["text"] for h in self._history[-10:] if h["text"]),
        }

    @staticmethod
    def _extract_topics(history: list[dict]) -> list[str]:
        all_words: list[str] = []
        for h in history:
            all_words.extend(re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', h.get("text", "")))
        return list(set(all_words))[:10]

    @staticmethod
    def _is_followup(text: str, history_context: dict) -> bool:
        if not history_context.get("last_utterance"):
            return False
        if text.lower().startswith(("and", "or", "but", "so", "then", "also", "because", "although")):
            return True
        if re.match(r'^(yes|no|yeah|nope|sure|ok|okay|right|correct|wrong|maybe|probably)', text.strip(), re.IGNORECASE):
            return True
        if len(text.split()) <= 3:
            return True
        return False

    @staticmethod
    def _has_anaphora(text: str) -> bool:
        anaphora_words = {"it", "they", "them", "their", "he", "him", "his", "she", "her", "hers",
                          "this", "that", "these", "those", "such", "so", "there", "then",
                          "the former", "the latter", "the same"}
        return any(w in text.lower().split() for w in anaphora_words)

    @staticmethod
    def _references_previous(text: str, history_context: dict) -> bool:
        last = history_context.get("last_utterance", "").lower()
        if not last:
            return False
        last_words = set(last.split())
        current_words = set(text.lower().split())
        common = last_words & current_words
        return len(common) >= 2

    @staticmethod
    def _detect_context_shift(text: str, history_context: dict) -> bool:
        shift_markers = {"anyway", "anyhow", "so", "well", "by the way", "incidentally",
                          "speaking of", "that reminds me", "on a different note",
                          "meanwhile", "regardless", "nevertheless", "nonetheless",
                          "in any case", "at any rate", "in other news"}
        text_lower = text.lower()
        for marker in shift_markers:
            if marker in text_lower:
                return True
        last = history_context.get("last_utterance", "")
        if last and not self._references_previous(text, history_context):
            return True
        return False

    def reset(self) -> None:
        self._history.clear()

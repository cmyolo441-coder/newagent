from typing import Any, Optional

from ..analysis.intent_classifier import IntentClassifier
from ..analysis.ner_tagger import NerTagger
from ..parsing.semantic_parser import SemanticParser
from .slot_filler import SlotFiller
from .dialog_act_classifier import DialogActClassifier


class NluEngine:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self.intent_classifier = IntentClassifier(config.get("intent_config"))
        self.ner_tagger = NerTagger(config.get("ner_config"))
        self.semantic_parser = SemanticParser(config.get("semantic_config"))
        self.slot_filler = SlotFiller(config.get("slot_config"))
        self.dialog_act_classifier = DialogActClassifier(config.get("dialog_act_config"))

    def process(self, text: str, **kwargs) -> dict:
        return self.understand(text)

    def understand(self, text: str) -> dict:
        intent_result = self.intent_classifier.classify(text)
        entities_result = self.ner_tagger.extract(text)
        semantic_result = self.semantic_parser.process(text)
        slots_result = self.slot_filler.fill(text, intent_result.get("intent", "unknown"))
        dialog_act_result = self.dialog_act_classifier.classify(text)
        return {
            "text": text,
            "intent": intent_result,
            "entities": [e.to_dict() for e in entities_result],
            "semantic_roles": semantic_result.get("roles", []),
            "slots": slots_result,
            "dialog_act": dialog_act_result,
            "confidence": self._compute_overall_confidence(intent_result, dialog_act_result),
        }

    def _compute_overall_confidence(self, intent: dict, dialog_act: dict) -> float:
        intent_conf = intent.get("confidence", 0.0)
        dialog_conf = dialog_act.get("confidence", 0.0)
        return round((intent_conf + dialog_conf) / 2.0, 4)

    def batch_understand(self, texts: list[str]) -> list[dict]:
        return [self.understand(t) for t in texts]

    def __repr__(self) -> str:
        return "NluEngine(intent+ner+semantic+slots+dialog_act)"


NLUEngine = NluEngine

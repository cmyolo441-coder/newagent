import re
from typing import Optional


class DialogActClassifier:
    _ACTS: dict[str, list[tuple[str, float]]] = {
        "statement": [
            (r"^[A-Z][^.?]*\.$", 0.6),
            (r"\b(I think|I believe|I know|I feel|in my opinion|the fact is|actually|basically|essentially)\b", 0.8),
            (r"\b(is|are|was|were|has|have|had)\s+\w+\s+\w+\.$", 0.5),
            (r"^[A-Z]\w+ (?:is|are|was|were|has|have|had) \w+", 0.5),
        ],
        "question": [
            (r"\?$", 1.0),
            (r"^(what|who|where|when|why|how|which|whose|whom)", 1.0),
            (r"\b(can you|could you|would you|will you|do you|does it|is it|are you|have you|has it)\b", 0.9),
            (r"\b(do you know|can you tell|would you mind|could you explain)\b", 0.9),
            (r"^(is|are|was|were|has|have|had|do|does|did|can|could|will|would|shall|should|may|might|must) \w+", 0.8),
        ],
        "request": [
            (r"\b(can you|could you|will you|would you|please)\b", 0.9),
            (r"\b(I want|I need|I would like|I'd like|I wish|I hope|I ask)\b", 0.9),
            (r"\b(may I|can I|could I|would it be possible|is it possible)\b", 1.0),
            (r"\b(can you please|could you please|will you please)\b", 1.0),
        ],
        "command": [
            (r"^(run|execute|do|make|create|generate|build|start|stop|restart|delete|remove|add|show|list|get|set|update|install|configure|enable|disable)\b", 1.0),
            (r"^(don't|do not|never|stop|cease|quit)\b", 0.9),
            (r"\byou (must|need to|have to|should|shall|will|are to)\b", 0.7),
        ],
        "offer": [
            (r"\b(I can|I will|I would|I could|let me|allow me|shall I)\b", 0.9),
            (r"\b(would you like|do you want|can I get|can I offer)\b", 1.0),
            (r"\b(how about|what about|i recommend|i suggest)\b", 0.8),
        ],
        "promise": [
            (r"\b(I promise|I swear|I guarantee|I assure|I pledge|I vow)\b", 1.0),
            (r"\b(I will definitely|certainly|absolutely|positively)\b", 0.8),
        ],
        "threat": [
            (r"\b(or else|or I will|or else I will|if you don't)\b", 0.9),
            (r"\b(I will|I'm going to) \w+ (you|your)\b", 0.7),
            (r"\b(watch out|be careful|you'd better)\b", 0.8),
        ],
        "apology": [
            (r"\b(sorry|apologize|apologies|my bad|excuse me|pardon me|forgive me|i regret)\b", 1.0),
        ],
        "gratitude": [
            (r"\b(thank|thanks|appreciate|grateful|thankful|much obliged)\b", 1.0),
        ],
        "greeting": [
            (r"^(hello|hi|hey|greetings|good morning|good afternoon|good evening|howdy)\b", 1.0),
            (r"\b(nice to meet you|how are you|how do you do|what's up)\b", 0.9),
        ],
        "goodbye": [
            (r"^(bye|goodbye|farewell|see you|later|peace|adios)\b", 1.0),
            (r"\b(take care|have a good one|talk later|catch you)\b", 0.9),
        ],
        "confirm": [
            (r"\b(confirm|verify|double.check|are you sure|is that correct|is that right)\b", 1.0),
            (r"\b(did you|have you|did it|was it|is it true)\b", 0.8),
            (r"\?$", 0.3),
        ],
        "clarify": [
            (r"\b(what do you mean|could you clarify|can you explain|i don't understand|what does that mean)\b", 1.0),
            (r"\b(can you rephrase|in other words|what i mean is|i mean)\b", 0.9),
        ],
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.classify(text)

    def classify(self, text: str) -> dict:
        scores: dict[str, float] = {}
        for act, patterns in self._ACTS.items():
            total = 0.0
            for pattern, weight in patterns:
                for match in re.finditer(pattern, text.strip(), re.IGNORECASE):
                    total += weight
            if total > 0:
                scores[act] = total
        if not scores:
            return {"dialog_act": "unknown", "confidence": 0.0, "all_scores": {}}
        best_act = max(scores, key=scores.get)
        total_score = sum(scores.values())
        confidence = round(scores[best_act] / total_score, 4) if total_score > 0 else 0.0
        return {
            "dialog_act": best_act,
            "confidence": confidence,
            "all_scores": {k: round(v, 4) for k, v in sorted(scores.items(), key=lambda x: -x[1])},
        }

    def classify_top_n(self, text: str, n: int = 3) -> list[dict]:
        result = self.classify(text)
        scores = result.get("all_scores", {})
        return [{"act": act, "score": score}
                for act, score in sorted(scores.items(), key=lambda x: -x[1])[:n]]

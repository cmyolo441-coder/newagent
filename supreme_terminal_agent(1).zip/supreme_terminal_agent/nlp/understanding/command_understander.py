import re
import shlex
from typing import Optional


class CommandUnderstander:
    _COMMAND_PATTERNS: dict[str, str] = {
        "file_operation": r"\b(?:read|write|create|delete|remove|copy|move|rename|list|show|open|edit|save|load|export|import)\b",
        "process_control": r"\b(?:run|execute|start|stop|restart|kill|pause|resume|launch|spawn|terminate)\b",
        "search": r"\b(?:search|find|locate|grep|lookup|query|scan|seek|hunt)\b",
        "navigation": r"\b(?:cd|change dir|go to|navigate|enter|back|up|home)\b",
        "network": r"\b(?:ping|curl|wget|ssh|scp|ftp|http|connect|disconnect|download|upload)\b",
        "system": r"\b(?:install|update|upgrade|configure|setup|uninstall|purge|clean|check|status|info)\b",
        "help": r"\b(?:help|manual|man|info|usage|guide|tutorial|docs)\b",
        "query": r"\b(?:what is|who is|tell me|show me|list|find|get)\b",
    }

    _MODIFIERS: dict[str, list[str]] = {
        "recursive": ["-r", "--recursive", "-R"],
        "force": ["-f", "--force"],
        "verbose": ["-v", "--verbose", "-vv"],
        "quiet": ["-q", "--quiet"],
        "interactive": ["-i", "--interactive"],
        "all": ["-a", "--all"],
        "dry_run": ["-n", "--dry-run", "--dry_run"],
        "yes": ["-y", "--yes"],
        "output": ["-o", "--output"],
        "input": ["-i", "--input"],
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.understand(text)

    def understand(self, text: str) -> dict:
        return {
            "is_command": self._is_command(text),
            "command_type": self._classify(text),
            "parts": self._parse_parts(text),
            "arguments": self._extract_arguments(text),
            "flags": self._extract_flags(text),
            "modifiers": self._detect_modifiers(text),
            "target": self._extract_target(text),
            "parameters": self._extract_key_value_params(text),
        }

    @staticmethod
    def _is_command(text: str) -> bool:
        text = text.strip()
        if re.match(r'^\w[\w.-]*(\s+.*)?$', text) and not text.endswith((".", "?", "!")):
            return True
        if re.search(r'(?:--|-)\w+', text):
            return True
        return False

    def _classify(self, text: str) -> str:
        text_lower = text.lower()
        for cmd_type, pattern in self._COMMAND_PATTERNS.items():
            if re.search(pattern, text_lower):
                return cmd_type
        if re.match(r'^[a-zA-Z][\w.-]*(\s+.*)?$', text.strip()):
            return "executable"
        return "unknown"

    @staticmethod
    def _parse_parts(text: str) -> dict:
        try:
            parts = shlex.split(text)
        except (ValueError, shlex.ShlexError):
            # Fallback: simple whitespace split if shlex fails
            parts = text.strip().split()
        return {
            "command": parts[0] if parts else "",
            "args": parts[1:] if len(parts) > 1 else [],
            "count": len(parts),
        }

    @staticmethod
    def _extract_arguments(text: str) -> list[str]:
        args: list[str] = []
        try:
            parts = shlex.split(text)
        except (ValueError, shlex.ShlexError):
            parts = text.strip().split()
        for p in parts[1:]:
            if not p.startswith("-"):
                args.append(p)
        return args

    @staticmethod
    def _extract_flags(text: str) -> dict[str, str]:
        flags: dict[str, str] = {}
        for match in re.finditer(r'(?:--)(\w[\w-]*)(?:[= ](\S+))?', text):
            name = match.group(1)
            value = match.group(2) if match.group(2) else "true"
            flags[name] = value
        for match in re.finditer(r'(?:^| )-([a-zA-Z])(?: (\S+))?', text):
            name = match.group(1)
            value = match.group(2) if match.group(2) else "true"
            if name not in flags:
                flags[name] = value
        return flags

    def _detect_modifiers(self, text: str) -> dict[str, bool]:
        modifiers: dict[str, bool] = {}
        for mod_name, patterns in self._MODIFIERS.items():
            modifiers[mod_name] = any(p in text.split() for p in patterns)
        return modifiers

    @staticmethod
    def _extract_target(text: str) -> str:
        parts = text.strip().split()
        targets = [p for p in parts[1:] if not p.startswith("-") and not p.startswith("'") and not p.startswith('"')]
        return targets[0] if targets else ""

    @staticmethod
    def _extract_key_value_params(text: str) -> dict[str, str]:
        params: dict[str, str] = {}
        for match in re.finditer(r'(?:--|=)?(\w+)=(\S+)', text):
            params[match.group(1)] = match.group(2)
        return params

    def batch_understand(self, commands: list[str]) -> list[dict]:
        return [self.understand(cmd) for cmd in commands]

import re
from collections import Counter
from typing import Optional


class TopicModeler:
    _STOP_WORDS: set[str] = {
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "by", "with", "from", "is", "are", "was", "were", "be", "been",
        "being", "have", "has", "had", "do", "does", "did", "will", "would",
        "could", "should", "may", "might", "shall", "can", "must", "need",
        "dare", "ought", "used", "i", "you", "he", "she", "it", "we", "they",
        "me", "him", "her", "us", "them", "my", "your", "his", "its", "our",
        "their", "mine", "yours", "hers", "ours", "theirs", "this", "that",
        "these", "those", "some", "any", "all", "each", "every", "both",
        "few", "many", "much", "several", "no", "not", "only", "just",
        "so", "than", "too", "very", "as", "if", "because", "while",
        "when", "where", "why", "how", "what", "which", "who", "whom",
        "whose", "about", "between", "through", "during", "before",
        "after", "above", "below", "between", "under", "over", "again",
        "further", "once", "here", "there", "up", "down", "off", "out",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._n_topics = self.config.get("num_topics", 5)
        self._n_words = self.config.get("num_words_per_topic", 10)

    def process(self, text: str, **kwargs) -> dict:
        return self.model(text)

    def model(self, text: str) -> dict:
        tokens = self._preprocess(text)
        word_freq = Counter(tokens)
        bigrams = self._extract_bigrams(tokens)
        trigrams = self._extract_trigrams(tokens)
        topics = self._extract_topics(word_freq)
        return {
            "topics": topics,
            "top_words": word_freq.most_common(self._n_words),
            "bigrams": bigrams.most_common(20),
            "trigrams": trigrams.most_common(10),
            "term_frequency": dict(word_freq.most_common(50)),
            "total_terms": len(tokens),
            "unique_terms": len(word_freq),
        }

    def _preprocess(self, text: str) -> list[str]:
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\d+', ' ', text)
        tokens = text.split()
        return [t for t in tokens if t not in self._STOP_WORDS and len(t) > 2]

    def _extract_topics(self, word_freq: Counter) -> list[dict]:
        words = [w for w, _ in word_freq.most_common(50)]
        if not words:
            return [{"topic": 0, "words": [], "score": 0.0}]
        topic_size = max(1, len(words) // max(self._n_topics, 1))
        topics: list[dict] = []
        for i in range(self._n_topics):
            start = i * topic_size
            chunk = words[start:start + self._n_words]
            if not chunk:
                break
            score = round(1.0 / (i + 1), 4)
            topics.append({
                "topic": i,
                "words": chunk,
                "score": score,
                "label": self._label_topic(chunk),
            })
        return topics

    @staticmethod
    def _label_topic(words: list[str]) -> str:
        return words[0].upper() + "..." if words else "Unknown"

    @staticmethod
    def _extract_bigrams(tokens: list[str]) -> Counter:
        return Counter(f"{tokens[i]} {tokens[i + 1]}" for i in range(len(tokens) - 1))

    @staticmethod
    def _extract_trigrams(tokens: list[str]) -> Counter:
        return Counter(f"{tokens[i]} {tokens[i + 1]} {tokens[i + 2]}" for i in range(len(tokens) - 2))

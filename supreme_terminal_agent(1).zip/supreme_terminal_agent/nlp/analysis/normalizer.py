import re
import unicodedata
from typing import Optional


class Normalizer:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._lowercase = self.config.get("lowercase", True)
        self._remove_diacritics = self.config.get("remove_diacritics", True)
        self._collapse_whitespace = self.config.get("collapse_whitespace", True)
        self._remove_urls = self.config.get("remove_urls", False)
        self._remove_emails = self.config.get("remove_emails", False)
        self._remove_numbers = self.config.get("remove_numbers", False)
        self._remove_punct = self.config.get("remove_punctuation", False)

    def process(self, text: str, **kwargs) -> dict:
        return {
            "normalized": self.normalize(text),
            "steps_applied": self._applied_steps(),
        }

    def normalize(self, text: str) -> str:
        result = text
        if self._remove_diacritics:
            result = self._strip_diacritics(result)
        if self._lowercase:
            result = result.lower()
        if self._collapse_whitespace:
            result = re.sub(r'\s+', ' ', result).strip()
        if self._remove_urls:
            result = re.sub(r'https?://\S+|www\.\S+', '', result)
        if self._remove_emails:
            result = re.sub(r'\S+@\S+\.\S+', '', result)
        if self._remove_numbers:
            result = re.sub(r'\d+', '', result)
        if self._remove_punct:
            result = re.sub(r'[^\w\s]', '', result)
        return result.strip()

    @staticmethod
    def _strip_diacritics(text: str) -> str:
        nfkd = unicodedata.normalize('NFKD', text)
        return ''.join(c for c in nfkd if not unicodedata.combining(c))

    def _applied_steps(self) -> list[str]:
        steps = []
        if self._lowercase:
            steps.append("lowercase")
        if self._remove_diacritics:
            steps.append("remove_diacritics")
        if self._collapse_whitespace:
            steps.append("collapse_whitespace")
        if self._remove_urls:
            steps.append("remove_urls")
        if self._remove_emails:
            steps.append("remove_emails")
        if self._remove_numbers:
            steps.append("remove_numbers")
        if self._remove_punct:
            steps.append("remove_punctuation")
        return steps

    def normalize_batch(self, texts: list[str]) -> list[str]:
        return [self.normalize(t) for t in texts]

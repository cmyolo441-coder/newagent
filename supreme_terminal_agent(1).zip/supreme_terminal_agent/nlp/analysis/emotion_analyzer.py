import re
from typing import Optional


class EmotionAnalyzer:
    _EMOTION_LEXICON: dict[str, set[str]] = {
        "joy": {
            "happy", "glad", "delighted", "joyful", "cheerful", "elated", "euphoric",
            "thrilled", "ecstatic", "exuberant", "jubilant", "merry", "upbeat",
            "optimistic", "hopeful", "content", "satisfied", "pleased", "grateful",
            "thankful", "blessed", "lucky", "fortunate", "smile", "laugh", "chuckle",
            "giggle", "celebrate", "rejoice", "excited", "enthusiastic", "eager",
            "fun", "enjoyable", "wonderful", "great", "amazing", "fantastic",
            "bliss", "blissful", "radiant", "glowing", "bright",
        },
        "sadness": {
            "sad", "unhappy", "miserable", "depressed", "gloomy", "somber",
            "melancholy", "sorrowful", "mournful", "grief", "grieving", "heartbroken",
            "devastated", "crushed", "despairing", "hopeless", "despondent",
            "dejected", "downcast", "disheartened", "discouraged", "disappointed",
            "dismal", "bleak", "dreary", "tearful", "crying", "weeping", "sobbing",
            "lonely", "isolated", "abandoned", "forsaken", "desolate", "empty",
            "numb", "hurt", "aching", "pain", "suffering", "miss", "longing",
            "regret", "remorse", "guilt", "shame", "wistful", "nostalgic",
        },
        "anger": {
            "angry", "furious", "enraged", "livid", "irate", "outraged", "incensed",
            "infuriated", "seething", "fuming", "wrathful", "hostile", "aggressive",
            "frustrated", "annoyed", "irritated", "exasperated", "agitated",
            "resentful", "bitter", "spiteful", "vengeful", "fierce", "violent",
            "mad", "fuming", "explosive", "volatile", "tense", "fuming",
            "hate", "hatred", "despise", "loathing", "contempt", "disgust",
            "jealous", "envious", "offended", "insulted", "provoked",
        },
        "fear": {
            "afraid", "scared", "frightened", "terrified", "horrified", "panicked",
            "anxious", "worried", "nervous", "apprehensive", "dread", "dreading",
            "alarmed", "startled", "shocked", "petrified", "paralyzed", "frozen",
            "terrified", "timid", "shy", "cautious", "wary", "vigilant", "alert",
            "uneasy", "restless", "tense", "jittery", "jumpy", "spooked", "creeped",
            "threatened", "endangered", "insecure", "unsafe", "vulnerable",
            "phobia", "phobic", "panic", "terror", "horror", "dread",
        },
        "surprise": {
            "surprised", "amazed", "astonished", "astounded", "stunned", "shocked",
            "dumbfounded", "flabbergasted", "bewildered", "perplexed", "confused",
            "startled", "jolted", "staggered", "speechless", "thunderstruck",
            "unexpected", "unforeseen", "sudden", "abrupt", "unanticipated",
            "wow", "gosh", "oh", "aha", "eureka", "incredible", "unbelievable",
            "remarkable", "extraordinary", "unexpected", "miraculous", "phenomenal",
        },
        "disgust": {
            "disgusted", "disgusting", "revolted", "repulsed", "repugnant",
            "nauseated", "sickened", "appalled", "horrified", "outraged",
            "abhorrent", "detestable", "loathsome", "odious", "vile", "foul",
            "gross", "nasty", "repellent", "repulsive", "objectionable",
            "distasteful", "unpleasant", "offensive", "appalling", "shocking",
            "sick", "vomit", "nausea",
        },
        "trust": {
            "trust", "trusting", "trustworthy", "trusted", "reliable", "dependable",
            "faithful", "loyal", "devoted", "committed", "dedicated", "honest",
            "truthful", "sincere", "genuine", "authentic", "transparent", "open",
            "confident", "believing", "faith", "belief", "conviction", "assurance",
            "certainty", "sure", "secure", "safe", "protected", "supported",
        },
        "anticipation": {
            "anticipate", "anticipation", "expect", "expectation", "expecting",
            "await", "awaiting", "hope", "hoping", "look forward", "eager",
            "impatient", "anxious", "keen", "excited", "enthusiastic", "curious",
            "interested", "intrigued", "fascinated", "preparing", "ready",
            "planning", "prospect", "future", "upcoming", "coming", "approaching",
            "pending", "impending", "looming", "threatening", "promising",
            "potential", "possible", "likely", "probable",
        },
    }

    _INTENSIFIERS: set[str] = {
        "very", "extremely", "incredibly", "absolutely", "completely", "totally",
        "utterly", "deeply", "profoundly", "truly", "really", "so", "quite",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.analyze(text)

    def analyze(self, text: str) -> dict:
        tokens = text.lower().split()
        emotion_scores = self._score_emotions(tokens)
        primary = self._primary_emotion(emotion_scores)
        return {
            "emotions": emotion_scores,
            "primary_emotion": primary,
            "top_emotions": sorted(emotion_scores.items(), key=lambda x: -x[1])[:3],
            "intensity": self._compute_intensity(tokens, emotion_scores),
            "dominant_emotion_score": max(emotion_scores.values()) if emotion_scores else 0.0,
        }

    def _score_emotions(self, tokens: list[str]) -> dict[str, float]:
        scores: dict[str, float] = {emotion: 0.0 for emotion in self._EMOTION_LEXICON}
        for i, token in enumerate(tokens):
            intensity = 1.0
            if i > 0 and tokens[i - 1] in self._INTENSIFIERS:
                intensity = 1.5
            for emotion, lexicon in self._EMOTION_LEXICON.items():
                if token in lexicon:
                    scores[emotion] += intensity
        return scores

    @staticmethod
    def _primary_emotion(scores: dict[str, float]) -> str:
        if not scores:
            return "neutral"
        return max(scores, key=scores.get)

    @staticmethod
    def _compute_intensity(tokens: list[str], scores: dict[str, float]) -> float:
        total_score = sum(scores.values())
        max_intensity = total_score / max(len(tokens), 1)
        return round(min(max_intensity * 2, 1.0), 4)

    def analyze_batch(self, texts: list[str]) -> list[dict]:
        return [self.analyze(t) for t in texts]

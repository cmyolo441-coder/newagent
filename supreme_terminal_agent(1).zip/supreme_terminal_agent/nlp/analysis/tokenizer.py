import re
from typing import Optional


class Tokenizer:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._split_contractions = self.config.get("split_contractions", True)
        self._keep_punct = self.config.get("keep_punctuation", False)

    def process(self, text: str, **kwargs) -> dict:
        tokens = self.tokenize(text)
        return {
            "tokens": tokens,
            "token_count": len(tokens),
            "types": len(set(tokens)),
            "sentences_as_tokens": self.tokenize_sentences(text),
        }

    def tokenize(self, text: str) -> list[str]:
        if not text or not text.strip():
            return []
        text = text.strip()
        if self._split_contractions:
            text = re.sub(r"\b(can)'(t)\b", r"\1 not", text, flags=re.IGNORECASE)
            text = re.sub(r"\b(ain)'(t)\b", r"\1 not", text, flags=re.IGNORECASE)
            text = re.sub(r"\b(\w+)'(re)\b", r"\1 are", text, flags=re.IGNORECASE)
            text = re.sub(r"\b(\w+)'(ve)\b", r"\1 have", text, flags=re.IGNORECASE)
            text = re.sub(r"\b(\w+)'(ll)\b", r"\1 will", text, flags=re.IGNORECASE)
            text = re.sub(r"\b(\w+)'(d)\b", r"\1 would", text, flags=re.IGNORECASE)
            text = re.sub(r"\b(\w+)'(m)\b", r"\1 am", text, flags=re.IGNORECASE)
            text = re.sub(r"\b(\w+)n'(t)\b", r"\1 not", text, flags=re.IGNORECASE)
        if self._keep_punct:
            tokens = re.findall(r"\b\w+\b|[^\w\s]", text)
        else:
            tokens = re.findall(r"\b\w+\b", text)
        return tokens

    def tokenize_sentences(self, text: str) -> list[list[str]]:
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        return [self.tokenize(s) for s in sentences if s.strip()]

    def tokenize_by_whitespace(self, text: str) -> list[str]:
        return text.split()

    def count_tokens(self, text: str) -> int:
        return len(self.tokenize(text))

import re
from typing import Optional


class Stemmer:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._min_length = self.config.get("min_word_length", 3)

    def process(self, text: str, **kwargs) -> dict:
        tokens = text.split() if isinstance(text, str) else text
        stems = [self.stem(t) for t in tokens]
        return {
            "stems": stems,
            "original": tokens,
            "stem_map": dict(zip(tokens, stems)),
        }

    def stem(self, word: str) -> str:
        if len(word) < self._min_length:
            return word
        word = word.lower()
        word = self._remove_plural(word)
        word = self._remove_verb_tense(word)
        word = self._remove_adverbial(word)
        word = self._remove_adjectival(word)
        word = self._remove_diminutive(word)
        if word.endswith("ion") and len(word) > 5:
            word = word[:-3]
        if word.endswith("ment") and len(word) > 6:
            word = word[:-4]
        if word.endswith("ness") and len(word) > 5:
            word = word[:-4]
        if word.endswith("ity") and len(word) > 5:
            word = word[:-3]
        if word.endswith("ence") and len(word) > 6:
            word = word[:-4]
        if word.endswith("ance") and len(word) > 6:
            word = word[:-4]
        if word.endswith("able") and len(word) > 6:
            word = word[:-4]
        if word.endswith("ible") and len(word) > 6:
            word = word[:-4]
        if word.endswith("al") and len(word) > 4:
            word = word[:-2]
        return word

    def _remove_plural(self, word: str) -> str:
        if word.endswith("ses") or word.endswith("xes") or word.endswith("ches") or word.endswith("shes"):
            return word[:-2]
        if word.endswith("ies") and len(word) > 4:
            return word[:-3] + "y"
        if word.endswith("ves") and len(word) > 4:
            return word[:-3] + "f"
        if word.endswith("s") and not word.endswith("ss") and len(word) > 3:
            return word[:-1]
        return word

    def _remove_verb_tense(self, word: str) -> str:
        if word.endswith("ing"):
            base = word[:-3]
            if len(base) >= 2:
                if base.endswith("i"):
                    return base + "y"
                return base
        if word.endswith("ied"):
            return word[:-3] + "y"
        if word.endswith("ed"):
            base = word[:-2]
            if len(base) >= 2:
                return base
        if word.endswith("en") and len(word) > 4:
            return word[:-2]
        return word

    def _remove_adverbial(self, word: str) -> str:
        if word.endswith("ily"):
            return word[:-3] + "y"
        if word.endswith("ly"):
            return word[:-2]
        return word

    def _remove_adjectival(self, word: str) -> str:
        if word.endswith("iest"):
            return word[:-4] + "y"
        if word.endswith("est") and len(word) > 5:
            return word[:-3]
        if word.endswith("ier"):
            return word[:-3] + "y"
        if word.endswith("er") and len(word) > 4:
            return word[:-2]
        return word

    def _remove_diminutive(self, word: str) -> str:
        if word.endswith("ling") and len(word) > 6:
            return word[:-4]
        if word.endswith("let") and len(word) > 5:
            return word[:-3]
        if word.endswith("ish") and len(word) > 5:
            return word[:-3]
        return word

    def stem_sentence(self, sentence: str) -> list[str]:
        return [self.stem(w) for w in sentence.split()]

import re
from typing import Optional


class Lemmatizer:
    _VERB_SUFFIXES: list[tuple[str, str]] = [
        ("ies", "y"), ("ves", "f"), ("es", "e"), ("s", ""),
        ("ing", ""), ("ied", "y"), ("ed", ""), ("en", ""),
        ("tion", "te"), ("sion", "de"),
    ]
    _NOUN_SUFFIXES: list[tuple[str, str]] = [
        ("ies", "y"), ("ves", "f"), ("men", "man"), ("ches", "ch"),
        ("shes", "sh"), ("xes", "x"), ("zes", "z"), ("ses", "s"),
        ("es", "e"), ("s", ""),
    ]
    _ADJ_SUFFIXES: list[tuple[str, str]] = [
        ("iest", "y"), ("est", ""), ("ier", "y"), ("er", ""),
    ]
    _IRREGULAR: dict[str, str] = {
        "was": "be", "were": "be", "been": "be", "being": "be", "am": "be",
        "is": "be", "are": "be",
        "had": "have", "has": "have", "having": "have",
        "did": "do", "does": "do", "done": "do", "doing": "do",
        "went": "go", "gone": "go", "going": "go", "goes": "go",
        "said": "say", "says": "say", "saying": "say",
        "made": "make", "makes": "make", "making": "make",
        "took": "take", "taken": "take", "takes": "take", "taking": "take",
        "came": "come", "comes": "come", "coming": "come",
        "saw": "see", "seen": "see", "sees": "see", "seeing": "see",
        "knew": "know", "known": "know", "knows": "know",
        "got": "get", "gotten": "get", "gets": "get",
        "gave": "give", "given": "give", "gives": "give",
        "found": "find", "finds": "find",
        "thought": "think", "thinks": "think",
        "told": "tell", "tells": "tell",
        "wrote": "write", "written": "write", "writes": "write",
        "ran": "run", "runs": "run",
        "put": "put", "puts": "put",
        "set": "set", "sets": "set",
        "let": "let", "lets": "let",
        "read": "read", "reads": "read",
        "cut": "cut", "cuts": "cut",
        "better": "good", "best": "good",
        "worse": "bad", "worst": "bad",
        "more": "much", "most": "much",
        "less": "little", "least": "little",
        "further": "far", "furthest": "far",
        "older": "old", "oldest": "old", "elder": "old", "eldest": "old",
        "children": "child", "men": "man", "women": "woman",
        "people": "person", "teeth": "tooth", "feet": "foot",
        "mice": "mouse", "geese": "goose", "oxen": "ox",
        "lives": "life", "leaves": "leaf", "wolves": "wolf",
        "halves": "half", "selves": "self", "shelves": "shelf",
        "thieves": "thief", "knives": "knife", "wives": "wife",
        "cacti": "cactus", "foci": "focus", "fungi": "fungus",
        "indices": "index", "matrices": "matrix", "vertices": "vertex",
        "analyses": "analysis", "theses": "thesis", "crises": "crisis",
        "data": "datum", "criteria": "criterion", "phenomena": "phenomenon",
        "bacteria": "bacterium", "curricula": "curriculum",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        tokens = text.split() if isinstance(text, str) else text
        lemmas = [self.lemmatize(t) for t in tokens]
        return {
            "lemmas": lemmas,
            "original": tokens,
            "lemma_map": dict(zip(tokens, lemmas)),
        }

    def lemmatize(self, word: str) -> str:
        word_lower = word.lower()
        if word_lower in self._IRREGULAR:
            return self._IRREGULAR[word_lower]
        for suffix, replacement in self._VERB_SUFFIXES:
            if word_lower.endswith(suffix) and len(word_lower) > len(suffix) + 1:
                return word[:-len(suffix)] + replacement
        for suffix, replacement in self._NOUN_SUFFIXES:
            if word_lower.endswith(suffix) and len(word_lower) > len(suffix) + 1:
                return word[:-len(suffix)] + replacement
        for suffix, replacement in self._ADJ_SUFFIXES:
            if word_lower.endswith(suffix) and len(word_lower) > len(suffix) + 1:
                return word[:-len(suffix)] + replacement
        if word_lower.endswith("ly"):
            base = word[:-2]
            if base.endswith("i"):
                return base[:-1] + "y"
            return base + "l" if len(base) > 2 and base[-1] != "l" else base
        return word

    def lemmatize_sentence(self, sentence: str) -> list[str]:
        return [self.lemmatize(w) for w in sentence.split()]

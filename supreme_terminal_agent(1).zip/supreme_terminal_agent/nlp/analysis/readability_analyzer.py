import re
import math
from typing import Optional


class ReadabilityAnalyzer:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.analyze(text)

    def analyze(self, text: str) -> dict:
        word_count = self._count_words(text)
        sentence_count = self._count_sentences(text)
        syllable_count = self._count_syllables(text)
        char_count = sum(len(w) for w in self._get_words(text))
        complex_word_count = self._count_complex_words(text)
        return {
            "word_count": word_count,
            "sentence_count": sentence_count,
            "syllable_count": syllable_count,
            "char_count": char_count,
            "complex_word_count": complex_word_count,
            "avg_word_length": round(char_count / max(word_count, 1), 2),
            "avg_sentence_length": round(word_count / max(sentence_count, 1), 2),
            "avg_syllables_per_word": round(syllable_count / max(word_count, 1), 2),
            "flesch_reading_ease": self._flesch_reading_ease(word_count, sentence_count, syllable_count),
            "flesch_kincaid_grade": self._flesch_kincaid_grade(word_count, sentence_count, syllable_count),
            "gunning_fog": self._gunning_fog(word_count, sentence_count, complex_word_count),
            "coleman_liau": self._coleman_liau(word_count, sentence_count, char_count),
            "smog": self._smog(sentence_count, complex_word_count),
            "automated_readability": self._automated_readability(word_count, sentence_count, char_count),
            "dale_chall": self._dale_chall(word_count, complex_word_count),
            "readability_consensus": "",
        }

    @staticmethod
    def _get_words(text: str) -> list[str]:
        return re.findall(r'\b\w+\b', text.lower())

    @staticmethod
    def _count_words(text: str) -> int:
        return len(ReadabilityAnalyzer._get_words(text))

    @staticmethod
    def _count_sentences(text: str) -> int:
        sentences = re.split(r'[.!?]+', text)
        return max(len([s for s in sentences if s.strip()]), 1)

    @staticmethod
    def _count_syllables(text: str) -> int:
        words = ReadabilityAnalyzer._get_words(text)
        total = 0
        for word in words:
            total += ReadabilityAnalyzer._syllables_in_word(word)
        return max(total, 1)

    @staticmethod
    def _syllables_in_word(word: str) -> int:
        word = word.lower()
        count = 0
        vowels = "aeiouy"
        if len(word) <= 3:
            return 1
        for i, char in enumerate(word):
            if char in vowels:
                if i == 0 or word[i - 1] not in vowels:
                    count += 1
        if word.endswith("e"):
            count -= 1
        if word.endswith("le") and len(word) > 2 and word[-3] not in vowels:
            count += 1
        if word.endswith("es") or word.endswith("ed"):
            if count > 1:
                count -= 1
        return max(count, 1)

    @staticmethod
    def _count_complex_words(text: str) -> int:
        words = ReadabilityAnalyzer._get_words(text)
        return sum(1 for w in words if ReadabilityAnalyzer._syllables_in_word(w) >= 3)

    @staticmethod
    def _flesch_reading_ease(words: int, sentences: int, syllables: int) -> float:
        if words == 0 or sentences == 0:
            return 0.0
        return round(206.835 - 1.015 * (words / sentences) - 84.6 * (syllables / words), 2)

    @staticmethod
    def _flesch_kincaid_grade(words: int, sentences: int, syllables: int) -> float:
        if words == 0 or sentences == 0:
            return 0.0
        return round(0.39 * (words / sentences) + 11.8 * (syllables / words) - 15.59, 2)

    @staticmethod
    def _gunning_fog(words: int, sentences: int, complex_words: int) -> float:
        if sentences == 0:
            return 0.0
        return round(0.4 * ((words / sentences) + 100 * (complex_words / words)), 2)

    @staticmethod
    def _coleman_liau(words: int, sentences: int, chars: int) -> float:
        if words == 0 or sentences == 0:
            return 0.0
        l = chars / words * 100
        s = sentences / words * 100
        return round(0.0588 * l - 0.296 * s - 15.8, 2)

    @staticmethod
    def _smog(sentences: int, complex_words: int) -> float:
        if sentences < 30:
            return round(1.0430 * math.sqrt(complex_words * (30 / max(sentences, 1))) + 3.1291, 2)
        return round(1.0430 * math.sqrt(complex_words * (30 / sentences)) + 3.1291, 2)

    @staticmethod
    def _automated_readability(words: int, sentences: int, chars: int) -> float:
        if words == 0 or sentences == 0:
            return 0.0
        return round(4.71 * (chars / words) + 0.5 * (words / sentences) - 21.43, 2)

    @staticmethod
    def _dale_chall(words: int, complex_words: int) -> float:
        if words == 0:
            return 0.0
        difficult = complex_words / words * 100
        if difficult > 5:
            return round(0.1579 * difficult + 3.6365, 2)
        return round(0.1579 * difficult + 3.6365, 2)

    def text_statistics(self, text: str) -> dict:
        words = self._get_words(text)
        return {
            "short_words": len([w for w in words if len(w) <= 3]),
            "long_words": len([w for w in words if len(w) >= 7]),
            "unique_words": len(set(words)),
            "lexical_density": round(len(set(words)) / max(len(words), 1), 4),
        }

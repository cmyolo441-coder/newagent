import re
from collections import Counter
from typing import Optional


class KeywordExtractor:
    _STOP_WORDS: set[str] = {
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "by", "with", "from", "is", "are", "was", "were", "be", "been",
        "being", "have", "has", "had", "do", "does", "did", "will", "would",
        "could", "should", "may", "might", "shall", "can", "must", "need",
        "dare", "ought", "used", "i", "you", "he", "she", "it", "we", "they",
        "me", "him", "her", "us", "them", "my", "your", "his", "its", "our",
        "their", "mine", "yours", "hers", "ours", "theirs", "this", "that",
        "these", "those", "some", "any", "all", "each", "every", "both",
        "few", "many", "much", "several", "no", "not", "only", "just",
        "so", "than", "too", "very", "as", "if", "because", "while",
        "when", "where", "why", "how", "what", "which", "who", "whom",
        "whose", "about", "between", "through", "during", "before",
        "after", "above", "below", "between", "under", "over", "again",
        "further", "once", "here", "there", "up", "down", "off", "out",
        "also", "into", "over", "then", "now", "than",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._top_n = self.config.get("top_n", 20)
        self._min_word_length = self.config.get("min_word_length", 3)

    def process(self, text: str, **kwargs) -> dict:
        return self.extract(text)

    def extract(self, text: str) -> dict:
        tokens = self._tokenize(text)
        word_freq = Counter(tokens)
        bigrams = self._extract_ngrams(tokens, 2)
        trigrams = self._extract_ngrams(tokens, 3)
        tfidf_scores = self._compute_tfidf(word_freq, len(tokens))
        combined = self._combine_scores(word_freq, tfidf_scores, bigrams, trigrams)
        return {
            "keywords": combined[:self._top_n],
            "unigrams": word_freq.most_common(self._top_n),
            "bigrams": bigrams.most_common(self._top_n),
            "trigrams": trigrams.most_common(self._top_n),
            "tfidf": tfidf_scores,
        }

    def _tokenize(self, text: str) -> list[str]:
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        tokens = text.split()
        return [t for t in tokens if t not in self._STOP_WORDS and len(t) >= self._min_word_length and t.isalpha()]

    @staticmethod
    def _extract_ngrams(tokens: list[str], n: int) -> Counter:
        return Counter(" ".join(tokens[i:i + n]) for i in range(len(tokens) - n + 1))

    @staticmethod
    def _compute_tfidf(word_freq: Counter, total_terms: int) -> dict[str, float]:
        if total_terms == 0:
            return {}
        max_freq = max(word_freq.values()) if word_freq else 1
        return {word: round((freq / max_freq) * (1.0 + 1.0 / (1.0 + freq / total_terms)), 4)
                for word, freq in word_freq.most_common()}

    @staticmethod
    def _combine_scores(word_freq: Counter, tfidf: dict, bigrams: Counter, trigrams: Counter) -> list[dict]:
        combined: list[dict] = []
        for word, freq in word_freq.most_common(100):
            tfidf_score = tfidf.get(word, 0.0)
            score = round(tfidf_score * (1 + 0.1 * freq), 4)
            combined.append({"keyword": word, "frequency": freq, "tfidf": tfidf_score, "score": score})
        for ngram, freq in bigrams.most_common(50):
            score = round(freq * 0.5, 4)
            combined.append({"keyword": ngram, "frequency": freq, "tfidf": 0.0, "score": score})
        for ngram, freq in trigrams.most_common(20):
            score = round(freq * 0.3, 4)
            combined.append({"keyword": ngram, "frequency": freq, "tfidf": 0.0, "score": score})
        combined.sort(key=lambda x: -x["score"])
        return combined

    def extract_from_batch(self, texts: list[str]) -> list[dict]:
        return [self.extract(t) for t in texts]

import re
from typing import Optional


class IntentClassifier:
    _INTENT_PATTERNS: dict[str, list[tuple[str, float]]] = {
        "greeting": [
            (r"\b(hello|hi|hey|greetings|good morning|good afternoon|good evening|howdy|sup|yo|what's up)\b", 1.0),
            (r"\b(nice to meet you|pleased to meet|how are you|how do you do)\b", 0.9),
        ],
        "farewell": [
            (r"\b(bye|goodbye|see you|farewell|later|peace|adios|cya|take care|have a good one)\b", 1.0),
            (r"\b(good night|sleep well|catch you later|see ya|talk to you later)\b", 0.9),
        ],
        "question": [
            (r"^what|^who|^where|^when|^why|^how|^which|^whose|^whom", 1.0),
            (r"\?$", 0.8),
            (r"\b(can you|could you|would you|will you|do you|does it|is it|are you)\b", 0.7),
            (r"\b(tell me|explain|describe|define|what is|what are|who is)\b", 0.6),
        ],
        "command": [
            (r"^(run|execute|do|make|create|generate|build|start|stop|restart|delete|remove|add|show|list|get|set|update|install|configure|enable|disable)", 1.0),
            (r"\b(please )?(run|execute|do|make|create|generate)\b", 0.8),
            (r"\byou (must|need to|have to|should|shall|will)\b", 0.7),
            (r"^[A-Z]+[\s\S]+$", 0.5),
        ],
        "request": [
            (r"\b(can I|could I|may I|would I|do you mind if)\b", 1.0),
            (r"\b(I want|I need|I would like|I'd like|I wish|I hope|please)\b", 0.9),
            (r"\b(can you please|could you please|would you please|will you please)\b", 0.8),
        ],
        "affirmation": [
            (r"^(yes|yeah|yep|sure|ok|okay|alright|definitely|certainly|absolutely|indeed|right|correct|true|agree)", 1.0),
            (r"\b(that's right|that is correct|you're right|you are right|sounds good|works for me)\b", 0.9),
        ],
        "negation": [
            (r"^(no|nope|nah|not|never|nothing|nowhere|nobody|none)", 1.0),
            (r"\b(I don't|I do not|I can't|I cannot|I won't|I will not|I wouldn't)\b", 0.9),
            (r"\b(that's wrong|that is incorrect|not true|false|incorrect)\b", 0.8),
        ],
        "gratitude": [
            (r"\b(thank|thanks|thank you|thanks a lot|thanks so much|many thanks|appreciate it|grateful)\b", 1.0),
            (r"\b(you're the best|you are awesome|you rock|much obliged)\b", 0.9),
        ],
        "apology": [
            (r"\b(sorry|apologize|apologies|my bad|excuse me|pardon|forgive|regret)\b", 1.0),
            (r"\b(I'm sorry|I am sorry|so sorry|very sorry)\b", 1.0),
        ],
        "help": [
            (r"\b(help|assist|support|aid|guide|tutorial|documentation|how to|what can you)\b", 1.0),
            (r"\b(can you help|need help|need assistance|help me)\b", 1.0),
        ],
        "confirmation": [
            (r"\b(confirm|verify|double.check|make sure|are you sure|is that correct)\b", 1.0),
            (r"\b(did you|have you|are you sure|is it correct|is that right)\b", 0.8),
        ],
        "complaint": [
            (r"\b(complaint|complain|issue|problem|bug|error|broken|not working|doesn't work|failed)\b", 1.0),
            (r"\b(this is wrong|that is wrong|it's broken|terrible|awful|horrible|disappointed)\b", 0.8),
        ],
        "smalltalk": [
            (r"\b(how are you|how's it going|what's up|how do you do|nice weather|cold today|hot today)\b", 1.0),
            (r"\b(what are you doing|how are things|how is everything|how's life)\b", 0.9),
        ],
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.classify(text)

    def classify(self, text: str) -> dict:
        scores: dict[str, float] = {}
        matched_patterns: dict[str, list[str]] = {}
        for intent, patterns in self._INTENT_PATTERNS.items():
            total = 0.0
            matched: list[str] = []
            for pattern, weight in patterns:
                for match in re.finditer(pattern, text.strip(), re.IGNORECASE):
                    total += weight
                    matched.append(match.group(0))
            if total > 0:
                scores[intent] = total
                matched_patterns[intent] = matched
        if not scores:
            return {
                "intent": "unknown",
                "confidence": 0.0,
                "all_scores": {},
                "matched_patterns": {},
            }
        top_intent = max(scores, key=scores.get)
        total_matches = sum(scores.values())
        confidence = min(scores[top_intent] / max(total_matches / len(scores), 0.01), 1.0)
        normalized_scores = {k: round(v / len(patterns), 4) for k, v in scores.items()}
        return {
            "intent": top_intent,
            "confidence": round(confidence, 4),
            "all_scores": normalized_scores,
            "matched_patterns": matched_patterns,
        }

    def classify_multi(self, text: str, threshold: float = 0.3) -> list[dict]:
        result = self.classify(text)
        intents = [(intent, score) for intent, score in result.get("all_scores", {}).items() if score >= threshold]
        return [{"intent": i, "score": s} for i, s in sorted(intents, key=lambda x: -x[1])]

import re
from typing import Optional


class Chunk:
    def __init__(self, text: str, chunk_type: str, tokens: list[str]):
        self.text = text
        self.type = chunk_type
        self.tokens = tokens

    def to_dict(self) -> dict:
        return {"text": self.text, "type": self.type, "tokens": self.tokens}


class Chunker:
    _DETERMINERS: set[str] = {"the", "a", "an", "this", "that", "these", "those", "some", "any",
                               "each", "every", "no", "another", "both", "all", "few", "many",
                               "much", "several", "enough", "either", "neither"}
    _ADJECTIVES: set[str] = {"good", "new", "first", "last", "long", "great", "little", "own",
                              "other", "old", "right", "big", "high", "different", "small", "large",
                              "next", "early", "young", "important", "public", "bad", "same",
                              "able", "free", "local", "open", "possible", "short", "sure",
                              "white", "black", "red", "blue", "green", "full", "strong", "real",
                              "beautiful", "happy", "sad", "angry", "clear", "deep", "easy",
                              "hard", "heavy", "light", "natural", "necessary", "political",
                              "popular", "private", "quick", "ready", "special", "true", "whole"}
    _ADVERBS: set[str] = {"very", "quite", "rather", "pretty", "extremely", "incredibly",
                           "too", "enough", "so", "almost", "nearly", "just", "only", "really",
                           "definitely", "certainly", "absolutely", "simply", "hardly", "barely",
                           "scarcely", "nearly", "almost", "completely", "totally", "entirely",
                           "fully", "partially", "partly", "highly", "deeply", "strongly", "well",
                           "badly", "carefully", "easily", "quickly", "slowly", "always",
                           "never", "often", "sometimes", "usually", "rarely", "seldom",
                           "now", "then", "here", "there", "today", "yesterday", "tomorrow"}

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        tokens = text.split() if isinstance(text, str) else text
        chunks = self.chunk(tokens)
        return {
            "chunks": [c.to_dict() for c in chunks],
            "chunk_types": [c.type for c in chunks],
            "chunk_texts": [c.text for c in chunks],
        }

    def chunk(self, tokens: list[str]) -> list[Chunk]:
        chunks: list[Chunk] = []
        i = 0
        while i < len(tokens):
            token = tokens[i]
            if self._is_determiner(token) and i + 1 < len(tokens):
                np = self._extract_np(tokens, i)
                chunks.append(np)
                i += len(np.tokens)
            elif self._is_noun(token) and i > 0 and chunks and chunks[-1].type == "NP":
                chunks[-1].tokens.append(token)
                chunks[-1].text += " " + token
                i += 1
            elif token.lower() in {"and", "or", "but", "yet", "so", "nor"}:
                chunks.append(Chunk(token, "CC", [token]))
                i += 1
            elif token.lower() in {"in", "on", "at", "by", "with", "from", "to", "for", "of",
                                    "about", "into", "through", "during", "before", "after",
                                    "between", "under", "over", "across", "near", "off", "up"}:
                pp = self._extract_pp(tokens, i)
                chunks.append(pp)
                i += len(pp.tokens)
            elif self._is_verb(token):
                vp = self._extract_vp(tokens, i)
                chunks.append(vp)
                i += len(vp.tokens)
            elif token.endswith(",") or token.endswith(";"):
                chunks.append(Chunk(token, "PUNCT", [token]))
                i += 1
            else:
                chunks.append(Chunk(token, "OTHER", [token]))
                i += 1
        return chunks

    def _extract_np(self, tokens: list[str], start: int) -> Chunk:
        np_tokens: list[str] = []
        i = start
        while i < len(tokens):
            if self._is_determiner(tokens[i]) and i == start:
                np_tokens.append(tokens[i])
                i += 1
            elif self._is_adverb(tokens[i]) and (i == start + 1 or self._is_adjective(tokens[i - 1])):
                np_tokens.append(tokens[i])
                i += 1
            elif self._is_adjective(tokens[i]) and (i == start + 1 or self._is_adjective(tokens[i - 1]) or self._is_determiner(tokens[i - 1]) or self._is_adverb(tokens[i - 1])):
                np_tokens.append(tokens[i])
                i += 1
            elif self._is_noun(tokens[i]):
                np_tokens.append(tokens[i])
                i += 1
            else:
                break
        return Chunk(" ".join(np_tokens), "NP", np_tokens)

    def _extract_vp(self, tokens: list[str], start: int) -> Chunk:
        vp_tokens: list[str] = [tokens[start]]
        i = start + 1
        while i < len(tokens) and self._is_verb(tokens[i]):
            vp_tokens.append(tokens[i])
            i += 1
        if i < len(tokens) and tokens[i].lower() in {"the", "a", "an"}:
            while i < len(tokens) and not tokens[i].endswith((".", "!", "?")):
                vp_tokens.append(tokens[i])
                i += 1
        elif i < len(tokens) and tokens[i].lower() in {"in", "on", "at", "to", "for", "with", "from"}:
            while i < len(tokens):
                vp_tokens.append(tokens[i])
                i += 1
                if i < len(tokens) and tokens[i].endswith((".", "!", "?")):
                    break
        return Chunk(" ".join(vp_tokens), "VP", vp_tokens)

    def _extract_pp(self, tokens: list[str], start: int) -> Chunk:
        pp_tokens: list[str] = [tokens[start]]
        i = start + 1
        while i < len(tokens):
            if self._is_determiner(tokens[i]) or self._is_adjective(tokens[i]) or self._is_noun(tokens[i]) or self._is_adverb(tokens[i]):
                pp_tokens.append(tokens[i])
                i += 1
            else:
                break
            if i < len(tokens) and tokens[i].endswith((".", "!", "?")):
                break
        return Chunk(" ".join(pp_tokens), "PP", pp_tokens)

    @classmethod
    def _is_determiner(cls, token: str) -> bool:
        return token.lower() in cls._DETERMINERS

    @classmethod
    def _is_adjective(cls, token: str) -> bool:
        return token.lower() in cls._ADJECTIVES or token.endswith(("ous", "ive", "able", "ible", "al", "ful", "less", "ish", "ic", "ical", "ant", "ent", "ary", "ory", "like", "some", "ular", "ian"))

    @classmethod
    def _is_noun(cls, token: str) -> bool:
        return token[0].isupper() or token.endswith(("tion", "sion", "ment", "ness", "ity", "ance", "ence", "ship", "dom", "ist", "er", "or", "ee", "ism", "ity", "logy", "graphy", "ment", "ure", "ture", "sure", "sis", "ics", "ology", "onomy", "ative", "tive", "sive"))

    @classmethod
    def _is_verb(cls, token: str) -> bool:
        return token.lower() in {"is", "are", "was", "were", "be", "been", "being", "am",
                                  "has", "have", "had", "having",
                                  "do", "does", "did", "doing", "done",
                                  "will", "would", "shall", "should", "can", "could", "may",
                                  "might", "must",
                                  "go", "get", "make", "take", "give", "find", "see", "know",
                                  "think", "say", "tell", "ask", "want", "need", "like", "love",
                                  "hate", "try", "use", "work", "help", "keep", "start",
                                  "become", "show", "leave", "put", "set", "bring", "run",
                                  "move", "stand", "sit", "let", "begin", "going", "trying",
                                  "working"} or token.endswith(("ed", "ing", "en", "ize", "ise", "ate", "ify"))

    @classmethod
    def _is_adverb(cls, token: str) -> bool:
        return token.lower() in cls._ADVERBS or token.endswith("ly")

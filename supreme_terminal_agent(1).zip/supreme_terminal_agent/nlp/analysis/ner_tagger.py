import re
from typing import Optional


class Entity:
    def __init__(self, text: str, label: str, start: int, end: int, confidence: float = 1.0):
        self.text = text
        self.label = label
        self.start = start
        self.end = end
        self.confidence = confidence

    def to_dict(self) -> dict:
        return {
            "text": self.text,
            "label": self.label,
            "start": self.start,
            "end": self.end,
            "confidence": self.confidence,
        }


class NerTagger:
    _PERSON_PREFIXES: set[str] = {"mr", "mrs", "ms", "dr", "prof", "sr", "jr", "sir", "lady", "lord",
                                    "president", "senator", "governor", "mayor", "general", "colonel"}
    _MONTHS: set[str] = {"january", "february", "march", "april", "may", "june", "july", "august",
                          "september", "october", "november", "december"}
    _DAYS: set[str] = {"monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"}
    _COUNTRIES: set[str] = {"usa", "uk", "united states", "united kingdom", "canada", "australia",
                             "germany", "france", "italy", "spain", "japan", "china", "india", "brazil",
                             "russia", "mexico", "korea", "netherlands", "sweden", "norway", "switzerland",
                             "argentina", "egypt", "turkey", "israel", "saudi arabia", "singapore"}
    _CURRENCIES: dict[str, str] = {"$": "USD", "€": "EUR", "£": "GBP", "¥": "JPY", "₹": "INR",
                                    "C$": "CAD", "A$": "AUD", "CHF": "CHF", "CNY": "CNY"}

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        entities = self.extract(text)
        return {
            "entities": [e.to_dict() for e in entities],
            "entity_count": len(entities),
            "by_type": self._group_by_type(entities),
        }

    def extract(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        entities.extend(self._extract_person(text))
        entities.extend(self._extract_organization(text))
        entities.extend(self._extract_location(text))
        entities.extend(self._extract_date(text))
        entities.extend(self._extract_time(text))
        entities.extend(self._extract_money(text))
        entities.extend(self._extract_percent(text))
        entities.extend(self._extract_email(text))
        entities.extend(self._extract_url(text))
        entities.extend(self._extract_phone(text))
        return self._deduplicate(entities)

    def _extract_person(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        prefix_pattern = "(?:" + "|".join(self._PERSON_PREFIXES) + r")\s+[A-Z][a-z]+"
        for match in re.finditer(rf'(?:{prefix_pattern})', text):
            entities.append(Entity(match.group(0), "PERSON", match.start(), match.end(), 0.85))
        for match in re.finditer(r'\b[A-Z][a-z]+\s+[A-Z][a-z]+\b', text):
            if not any(e.start <= match.start() < e.end for e in entities):
                entities.append(Entity(match.group(0), "PERSON", match.start(), match.end(), 0.7))
        return entities

    def _extract_organization(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        patterns = [
            r'\b[A-Z][a-z]+ (?:Inc|Corp|Ltd|LLC|LP|PLC|GmbH|AG|SA|NV|Co|Company|Corporation|Group|Holdings|Limited)\b',
            r'\b(?:Inc|Corp|Ltd|LLC|PLC|GmbH|AG|SA|NV)\b',
            r'\b[A-Z][a-z]+ (?:University|College|Institute|School|Academy|Foundation)\b',
            r'\b(?:University|College|Institute|School|Academy)\s+of\s+[A-Z][a-z]+\b',
            r'\b(?:IBM|NASA|FBI|CIA|NYPD|UCLA|MIT|NYU|UCSF|NATO|UN|EU|WHO|UNICEF|WTO|IMF|BBC|CNN|NBC|ABC|CBS|FOX)\b',
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, text):
                entities.append(Entity(match.group(0), "ORG", match.start(), match.end(), 0.8))
        return entities

    def _extract_location(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        for country in self._COUNTRIES:
            for match in re.finditer(rf'\b{re.escape(country)}\b', text, re.IGNORECASE):
                entities.append(Entity(match.group(0).title(), "LOC", match.start(), match.end(), 0.9))
        for match in re.finditer(r'\b[A-Z][a-z]+ (?:City|Town|Village|County|State|Province|Region|Mountain|River|Lake|Island|Bay|Gulf|Park|Street|Road|Avenue|Boulevard|Lane|Drive|Way|Place|Court)\b', text):
            entities.append(Entity(match.group(0), "LOC", match.start(), match.end(), 0.75))
        for match in re.finditer(r'\b(?:in|at|from|to|near|between)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b', text):
            loc = match.group(1)
            if loc[0].isupper():
                start = text.find(loc, match.start())
                entities.append(Entity(loc, "LOC", start, start + len(loc), 0.6))
        return entities

    def _extract_date(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        month_pattern = "(?:" + "|".join(self._MONTHS) + ")"
        day_pattern = r"(?:1st|2nd|3rd|4th|5th|6th|7th|8th|9th|10th|11th|12th|13th|14th|15th|16th|17th|18th|19th|20th|21st|22nd|23rd|24th|25th|26th|27th|28th|29th|30th|31st|\d{1,2})"
        year_pattern = r"\d{4}"
        patterns = [
            rf'\b{month_pattern}\s+{day_pattern}(?:,?\s+{year_pattern})?\b',
            rf'\b{day_pattern}\s+{month_pattern}\s+{year_pattern}\b',
            rf'\b{day_pattern}/{day_pattern}/{year_pattern}\b',
            rf'\b{year_pattern}-{day_pattern}-{day_pattern}\b',
            rf'\b{self._days_pattern()}\b',
            r'\b(today|yesterday|tomorrow|next week|next month|last week|last month)\b',
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                entities.append(Entity(match.group(0), "DATE", match.start(), match.end(), 0.85))
        return entities

    @classmethod
    def _days_pattern(cls) -> str:
        return "(?:" + "|".join(cls._DAYS) + ")"

    def _extract_time(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        patterns = [
            r'\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|am|pm)?\b',
            r'\b\d{1,2}\s*(?:AM|PM|am|pm)\b',
            r'\b(?:noon|midnight|morning|afternoon|evening|night|dawn|dusk)\b',
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                entities.append(Entity(match.group(0), "TIME", match.start(), match.end(), 0.8))
        return entities

    def _extract_money(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        for sym, code in self._CURRENCIES.items():
            escaped = re.escape(sym)
            pattern = escaped + r'\s*\d+(?:,\d{3})*(?:\.\d+)?\b'
            for match in re.finditer(pattern, text):
                entities.append(Entity(match.group(0), "MONEY", match.start(), match.end(), 0.9))
        pattern = r'\b\d+(?:,\d{3})*(?:\.\d+)?\s*(?:dollars|euros|pounds|yen|rupees|pesos|francs|cents)\b'
        for match in re.finditer(pattern, text, re.IGNORECASE):
            entities.append(Entity(match.group(0), "MONEY", match.start(), match.end(), 0.85))
        return entities

    def _extract_percent(self, text: str) -> list[Entity]:
        entities: list[Entity] = []
        for match in re.finditer(r'\b\d+(?:\.\d+)?\s*%\b', text):
            entities.append(Entity(match.group(0), "PERCENT", match.start(), match.end(), 0.95))
        for match in re.finditer(r'\b(?:half|quarter|third|two-thirds|three-quarters)\s+(?:of\s+)?\b', text, re.IGNORECASE):
            entities.append(Entity(match.group(0), "PERCENT", match.start(), match.end(), 0.5))
        return entities

    @staticmethod
    def _extract_email(text: str) -> list[Entity]:
        entities: list[Entity] = []
        for match in re.finditer(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b', text):
            entities.append(Entity(match.group(0), "EMAIL", match.start(), match.end(), 0.99))
        return entities

    @staticmethod
    def _extract_url(text: str) -> list[Entity]:
        entities: list[Entity] = []
        for match in re.finditer(r'https?://\S+|www\.\S+', text):
            entities.append(Entity(match.group(0), "URL", match.start(), match.end(), 0.99))
        return entities

    @staticmethod
    def _extract_phone(text: str) -> list[Entity]:
        entities: list[Entity] = []
        for match in re.finditer(r'\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b', text):
            entities.append(Entity(match.group(0), "PHONE", match.start(), match.end(), 0.9))
        return entities

    @staticmethod
    def _deduplicate(entities: list[Entity]) -> list[Entity]:
        seen: set[tuple[int, int, str]] = set()
        result: list[Entity] = []
        for e in sorted(entities, key=lambda x: (x.start, -x.confidence)):
            key = (e.start, e.end, e.label)
            if key not in seen:
                seen.add(key)
                result.append(e)
        return result

    @staticmethod
    def _group_by_type(entities: list[Entity]) -> dict[str, list[dict]]:
        groups: dict[str, list[dict]] = {}
        for e in entities:
            groups.setdefault(e.label, []).append(e.to_dict())
        return groups

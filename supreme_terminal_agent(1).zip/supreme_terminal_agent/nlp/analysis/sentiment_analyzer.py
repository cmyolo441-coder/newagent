import re
from typing import Optional


class SentimentAnalyzer:
    _POSITIVE_WORDS: set[str] = {
        "good", "great", "excellent", "amazing", "wonderful", "fantastic", "terrific",
        "beautiful", "brilliant", "outstanding", "superb", "magnificent", "splendid",
        "marvelous", "fabulous", "awesome", "incredible", "perfect", "lovely", "delightful",
        "pleasant", "enjoyable", "nice", "fine", "happy", "glad", "pleased", "satisfied",
        "thrilled", "ecstatic", "joyful", "cheerful", "optimistic", "hopeful", "positive",
        "successful", "impressive", "remarkable", "exceptional", "extraordinary",
        "wonderful", "beneficial", "helpful", "useful", "valuable", "effective",
        "efficient", "powerful", "strong", "robust", "reliable", "trustworthy",
        "innovative", "creative", "intelligent", "smart", "brilliant", "genius",
        "love", "like", "adore", "enjoy", "appreciate", "admire", "respect",
        "celebrate", "praise", "recommend", "approve", "support", "welcome",
        "win", "victory", "success", "achievement", "accomplishment", "triumph",
        "profit", "gain", "benefit", "advantage", "opportunity", "improvement",
        "growth", "progress", "development", "advancement", "breakthrough",
        "abundant", "plentiful", "generous", "kind", "caring", "compassionate",
        "hopeful", "promising", "bright", "sunny", "clear", "calm", "peaceful",
        "safe", "secure", "protected", "free", "easy", "simple", "comfortable",
        "cozy", "warm", "friendly", "welcoming", "graceful", "elegant", "charming",
    }

    _NEGATIVE_WORDS: set[str] = {
        "bad", "terrible", "awful", "horrible", "dreadful", "atrocious", "abysmal",
        "poor", "inferior", "mediocre", "lousy", "crappy", "rotten", "sucky",
        "ugly", "hideous", "disgusting", "revolting", "repulsive", "nasty",
        "unpleasant", "disagreeable", "annoying", "irritating", "frustrating",
        "sad", "unhappy", "miserable", "depressing", "gloomy", "somber", "bleak",
        "angry", "furious", "enraged", "livid", "irate", "fuming", "outraged",
        "hate", "detest", "despise", "loathe", "dislike", "abhor",
        "terrible", "horrific", "traumatic", "devastating", "catastrophic",
        "disastrous", "calamitous", "ruinous", "destructive", "damaging",
        "harmful", "dangerous", "risky", "threatening", "menacing", "ominous",
        "fail", "failure", "loss", "defeat", "collapse", "decline", "deterioration",
        "problem", "issue", "difficulty", "trouble", "struggle", "hardship",
        "crisis", "emergency", "disaster", "catastrophe", "tragedy", "calamity",
        "worst", "worse", "terrible", "awful", "horrible", "dreadful", "shameful",
        "painful", "agonizing", "excruciating", "torturous", "suffering",
        "ugly", "unsightly", "repugnant", "repellent", "offensive", "vile",
        "wicked", "evil", "cruel", "vicious", "brutal", "savage", "ruthless",
        "selfish", "greedy", "arrogant", "conceited", "vain", "egotistical",
        "lazy", "slothful", "careless", "reckless", "foolish", "stupid", "dumb",
        "weak", "feeble", "fragile", "vulnerable", "helpless", "hopeless",
        "desperate", "depressed", "anxious", "worried", "fearful", "afraid",
        "scared", "terrified", "horrified", "panicked", "nervous", "tense",
    }

    _INTENSIFIERS: set[str] = {
        "very", "extremely", "incredibly", "unbelievably", "highly", "deeply",
        "profoundly", "absolutely", "completely", "totally", "utterly", "entirely",
        "fully", "quite", "rather", "pretty", "somewhat", "fairly", "remarkably",
        "exceptionally", "extraordinarily", "terribly", "awfully", "dreadfully",
        "immensely", "vastly", "greatly", "seriously", "really", "truly", "so",
    }

    _NEGATORS: set[str] = {
        "not", "no", "never", "neither", "nor", "nowhere", "nothing", "nobody",
        "none", "hardly", "barely", "scarcely", "rarely", "seldom", "doesn't",
        "don't", "didn't", "won't", "wouldn't", "couldn't", "shouldn't", "can't",
        "isn't", "aren't", "wasn't", "weren't", "haven't", "hasn't", "hadn't",
        "mustn't", "needn't", "dare not", "without", "lack", "lacking",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.analyze(text)

    def analyze(self, text: str) -> dict:
        tokens = text.lower().split()
        score, pos_count, neg_count = self._score_tokens(tokens)
        return {
            "sentiment": self._label(score),
            "score": round(score, 4),
            "positive_count": pos_count,
            "negative_count": neg_count,
            "positive_words": self._find_matches(tokens, self._POSITIVE_WORDS),
            "negative_words": self._find_matches(tokens, self._NEGATIVE_WORDS),
            "compound": round(score / max(len(tokens), 1) * 100, 4),
            "subjectivity": round((pos_count + neg_count) / max(len(tokens), 1), 4),
        }

    def _score_tokens(self, tokens: list[str]) -> tuple[float, int, int]:
        score = 0.0
        pos_count = 0
        neg_count = 0
        negate = False
        intensifier = 1.0
        for token in tokens:
            if token in self._NEGATORS:
                negate = not negate
                continue
            if token in self._INTENSIFIERS:
                intensifier = 1.5 if token in {"very", "extremely", "incredibly", "unbelievably", "absolutely", "completely", "totally"} else 1.2
                continue
            if token in self._POSITIVE_WORDS:
                val = 1.0 * intensifier
                if negate:
                    val *= -0.5
                score += val
                pos_count += 1
                intensifier = 1.0
                negate = False
            elif token in self._NEGATIVE_WORDS:
                val = -1.0 * intensifier
                if negate:
                    val *= -0.5
                score += val
                neg_count += 1
                intensifier = 1.0
                negate = False
            else:
                intensifier = 1.0
        return score, pos_count, neg_count

    @staticmethod
    def _label(score: float) -> str:
        if score > 2:
            return "very positive"
        if score > 0.5:
            return "positive"
        if score > -0.5:
            return "neutral"
        if score > -2:
            return "negative"
        return "very negative"

    @staticmethod
    def _find_matches(tokens: list[str], lexicon: set[str]) -> list[str]:
        return [t for t in tokens if t in lexicon]

    def analyze_sentence(self, sentence: str) -> dict:
        return self.analyze(sentence)

    def analyze_batch(self, texts: list[str]) -> list[dict]:
        return [self.analyze(t) for t in texts]

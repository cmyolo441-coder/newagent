import re
from typing import Optional


class PosTagger:
    _TAG_MAP: dict[str, str] = {
        "NN": "Noun", "NNS": "NounPlural", "NNP": "ProperNoun", "NNPS": "ProperNounPlural",
        "VB": "Verb", "VBD": "VerbPast", "VBG": "VerbGerund", "VBN": "VerbPastParticiple",
        "VBP": "VerbPresent", "VBZ": "Verb3rdPerson",
        "JJ": "Adjective", "JJR": "AdjectiveComparative", "JJS": "AdjectiveSuperlative",
        "RB": "Adverb", "RBR": "AdverbComparative", "RBS": "AdverbSuperlative",
        "DT": "Determiner", "PRP": "Pronoun", "PRP$": "PossessivePronoun",
        "IN": "Preposition", "CC": "Conjunction", "CD": "CardinalNumber",
        "TO": "To", "MD": "Modal", "UH": "Interjection", "EX": "ExistentialThere",
        "FW": "ForeignWord", "LS": "ListMarker", "RP": "Particle",
        "SYM": "Symbol", "WDT": "WhDeterminer", "WP": "WhPronoun", "WP$": "WhPossessive",
        "WRB": "WhAdverb", "POS": "PossessiveEnding",
        ",": "Comma", ".": "Period", ":": "Colon", "''": "Quote", "``": "Quote",
    }

    _DETERMINERS: set[str] = {"the", "a", "an", "this", "that", "these", "those", "some", "any",
                               "each", "every", "no", "another", "both", "all", "few", "many", "much",
                               "several", "enough", "either", "neither", "what", "which", "whose"}
    _PREPOSITIONS: set[str] = {"in", "on", "at", "by", "with", "from", "to", "for", "of", "about",
                                "into", "through", "during", "before", "after", "above", "below",
                                "between", "under", "over", "across", "along", "around", "behind",
                                "beside", "beyond", "down", "inside", "near", "off", "out", "outside",
                                "past", "throughout", "toward", "underneath", "up", "upon", "within",
                                "without", "against", "among", "amongst", "amid", "amidst"}
    _CONJUNCTIONS: set[str] = {"and", "or", "but", "yet", "so", "for", "nor", "because", "although",
                                "while", "since", "if", "unless", "after", "before", "until", "when",
                                "where", "whether", "rather", "than", "as", "like", "that"}
    _PRONOUNS: set[str] = {"i", "you", "he", "she", "it", "we", "they", "me", "him", "her", "us",
                            "them", "my", "your", "his", "its", "our", "their", "mine", "yours",
                            "hers", "ours", "theirs", "myself", "yourself", "himself", "herself",
                            "itself", "ourselves", "yourselves", "themselves", "this", "that",
                            "these", "those", "who", "whom", "whose", "which", "what"}
    _MODALS: set[str] = {"can", "could", "may", "might", "must", "shall", "should", "will", "would"}
    _BE_VERBS: set[str] = {"am", "is", "are", "was", "were", "be", "been", "being"}
    _HAVE_VERBS: set[str] = {"have", "has", "had", "having"}
    _DO_VERBS: set[str] = {"do", "does", "did", "doing", "done"}
    _QUESTION_WORDS: set[str] = {"who", "whom", "whose", "which", "what", "when", "where", "why", "how"}
    _COMMON_VERBS: set[str] = {"go", "get", "make", "take", "give", "find", "see", "know", "think",
                                "say", "tell", "ask", "want", "need", "like", "love", "hate", "try",
                                "use", "work", "help", "keep", "start", "become", "show", "leave",
                                "put", "set", "bring", "run", "move", "stand", "sit", "let", "begin"}
    _COMMON_NOUNS: set[str] = {"time", "year", "people", "way", "day", "man", "woman", "child",
                                "world", "life", "hand", "part", "place", "case", "week", "company",
                                "system", "program", "question", "government", "number", "night",
                                "point", "home", "water", "room", "mother", "area", "money", "story",
                                "fact", "month", "lot", "right", "study", "book", "eye", "job", "word",
                                "business", "issue", "side", "kind", "head", "house", "service",
                                "friend", "father", "power", "hour", "game", "line", "end", "member",
                                "law", "car", "city", "community", "name", "president", "team",
                                "minute", "idea", "kid", "body", "information", "back", "parent",
                                "face", "others", "level", "office", "door", "health", "person"}

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        tokens = text.split() if isinstance(text, str) else text
        tags = self.tag(tokens)
        return {
            "tokens": tokens,
            "tags": tags,
            "tagged": [(t, tg) for t, tg in zip(tokens, tags)],
        }

    def tag(self, tokens: list[str]) -> list[str]:
        return [self._tag_token(t, i, tokens) for i, t in enumerate(tokens)]

    def _tag_token(self, token: str, i: int, tokens: list[str]) -> str:
        lower = token.lower()
        if not token.isalpha():
            if token.isdigit():
                return "CD"
            if re.match(r'^[^\w\s]+$', token):
                return token if token in (",", ".", ":", ";", "!", "?") else "SYM"
            return "FW"
        if token[0].isupper() and i > 0 and not tokens[i - 1].endswith("."):
            return "NNP"
        if lower in self._DETERMINERS:
            return "DT"
        if lower in self._PREPOSITIONS:
            return "IN"
        if lower in self._CONJUNCTIONS:
            return "CC"
        if lower in self._PRONOUNS:
            return "PRP" if lower in {"i", "you", "he", "she", "it", "we", "they", "me", "him",
                                        "her", "us", "them", "myself", "yourself", "himself",
                                        "herself", "itself", "ourselves", "yourselves", "themselves",
                                        "who", "whom", "which", "what"} else "PRP$"
        if lower in self._MODALS:
            return "MD"
        if lower in self._BE_VERBS:
            return "VB" if lower in ("be", "been", "being") else "VBP" if lower in ("am", "are") else "VBD" if lower in ("was", "were") else "VBZ"
        if lower in self._HAVE_VERBS:
            return "VB" if lower == "having" else "VBP" if lower in ("have") else "VBZ" if lower == "has" else "VBD"
        if lower in self._DO_VERBS:
            return "VB" if lower in ("doing", "done") else "VBP" if lower == "do" else "VBZ" if lower == "does" else "VBD"
        if lower.endswith("ing"):
            return "VBG"
        if lower.endswith("ed"):
            return "VBD"
        if lower.endswith("ly"):
            return "RB"
        if lower.endswith("er") and len(lower) > 4:
            return "JJR"
        if lower.endswith("est") and len(lower) > 5:
            return "JJS"
        if lower.endswith("s"):
            plural_noun = lower[:-1] in self._COMMON_NOUNS
            if plural_noun:
                return "NNS"
            if lower.endswith("es"):
                return "VBZ"
            return "NNS"
        if lower.endswith("tion") or lower.endswith("sion") or lower.endswith("ment") or lower.endswith("ness"):
            return "NN"
        if lower in self._COMMON_VERBS:
            return "VB"
        if lower in self._QUESTION_WORDS:
            return "WP" if lower in ("who", "whom", "whose", "which", "what") else "WRB"
        if lower in self._COMMON_NOUNS:
            return "NN"
        if lower.endswith("ing"):
            return "VBG"
        if lower.endswith("tion") or lower.endswith("sion") or lower.endswith("ment") or lower.endswith("ness"):
            return "NN"
        return "NN"

    def tag_sentence(self, sentence: str) -> list[tuple[str, str]]:
        tokens = sentence.split()
        tags = self.tag(tokens)
        return list(zip(tokens, tags))

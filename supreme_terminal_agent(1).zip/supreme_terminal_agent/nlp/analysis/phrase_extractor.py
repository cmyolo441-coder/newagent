import re
from collections import Counter
from typing import Optional


class PhraseExtractor:
    _NOUN_TAGS: list[str] = ["NN", "NNP", "NNS", "NNPS"]
    _ADJ_TAGS: list[str] = ["JJ", "JJR", "JJS"]
    _STOP_WORDS: set[str] = {
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "by", "with", "from", "is", "are", "was", "were",
    }
    _NOUN_SUFFIXES: tuple[str, ...] = ("tion", "sion", "ment", "ness", "ity", "ance", "ence",
                                        "ship", "dom", "ist", "er", "or", "ism", "logy",
                                        "graphy", "ture", "sure", "sis", "ics", "ology")

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.extract(text)

    def extract(self, text: str) -> dict:
        tokens = text.split()
        noun_phrases = self._extract_noun_phrases(tokens)
        verb_phrases = self._extract_verb_phrases(tokens)
        adj_phrases = self._extract_adjective_phrases(tokens)
        prep_phrases = self._extract_prepositional_phrases(tokens)
        all_phrases = noun_phrases + verb_phrases + adj_phrases + prep_phrases
        phrase_freq = Counter(all_phrases)
        return {
            "noun_phrases": list(set(noun_phrases)),
            "verb_phrases": list(set(verb_phrases)),
            "adjective_phrases": list(set(adj_phrases)),
            "prepositional_phrases": list(set(prep_phrases)),
            "all_phrases": sorted(set(all_phrases)),
            "phrase_frequencies": phrase_freq.most_common(30),
            "total_phrases": len(set(all_phrases)),
        }

    def _extract_noun_phrases(self, tokens: list[str]) -> list[str]:
        phrases: list[str] = []
        i = 0
        while i < len(tokens):
            if self._is_noun(tokens[i]):
                np_parts: list[str] = []
                if i > 0 and self._is_determiner(tokens[i - 1]):
                    np_parts.append(tokens[i - 1])
                if i > 0 and self._is_adjective(tokens[i - 1]) and not self._is_determiner(tokens[i - 1]):
                    np_parts.append(tokens[i - 1])
                np_parts.append(tokens[i])
                j = i + 1
                while j < len(tokens) and (self._is_noun(tokens[j]) or self._is_adjective(tokens[j])):
                    np_parts.append(tokens[j])
                    j += 1
                phrase = " ".join(np_parts)
                if len(phrase.split()) >= 2 and phrase.lower() not in self._STOP_WORDS:
                    phrases.append(phrase)
                i = j
            else:
                i += 1
        return phrases

    def _extract_verb_phrases(self, tokens: list[str]) -> list[str]:
        phrases: list[str] = []
        i = 0
        while i < len(tokens):
            if self._is_verb(tokens[i]):
                vp_parts: list[str] = [tokens[i]]
                j = i + 1
                while j < len(tokens) and (self._is_verb(tokens[j]) or tokens[j].lower() in {"the", "a", "an", "to"}):
                    vp_parts.append(tokens[j])
                    j += 1
                if j < len(tokens) and self._is_noun(tokens[j]):
                    vp_parts.append(tokens[j])
                    j += 1
                phrase = " ".join(vp_parts)
                if len(phrase.split()) >= 2:
                    phrases.append(phrase)
                i = j
            else:
                i += 1
        return phrases

    def _extract_adjective_phrases(self, tokens: list[str]) -> list[str]:
        phrases: list[str] = []
        i = 0
        while i < len(tokens):
            if self._is_adjective(tokens[i]):
                adj_parts: list[str] = [tokens[i]]
                if i > 0 and tokens[i - 1].lower() in {"very", "quite", "rather", "pretty", "extremely", "too", "so"}:
                    adj_parts.insert(0, tokens[i - 1])
                j = i + 1
                while j < len(tokens) and self._is_adjective(tokens[j]):
                    adj_parts.append(tokens[j])
                    j += 1
                phrase = " ".join(adj_parts)
                if len(phrase.split()) >= 2:
                    phrases.append(phrase)
                i = j
            else:
                i += 1
        return phrases

    def _extract_prepositional_phrases(self, tokens: list[str]) -> list[str]:
        phrases: list[str] = []
        prepositions = {"in", "on", "at", "by", "with", "from", "to", "for", "of", "about",
                        "into", "through", "during", "before", "after", "between", "under",
                        "over", "across", "near", "behind", "beside", "beyond", "upon"}
        i = 0
        while i < len(tokens):
            if tokens[i].lower() in prepositions:
                pp_parts: list[str] = [tokens[i]]
                j = i + 1
                while j < len(tokens) and len(pp_parts) < 6:
                    if self._is_noun(tokens[j]) or self._is_adjective(tokens[j]) or self._is_determiner(tokens[j]):
                        pp_parts.append(tokens[j])
                        j += 1
                    else:
                        break
                    if j < len(tokens) and tokens[j] in {",", ";", ".", "!", "?"}:
                        break
                phrase = " ".join(pp_parts)
                if len(phrase.split()) >= 2:
                    phrases.append(phrase)
                i = j
            else:
                i += 1
        return phrases

    @classmethod
    def _is_noun(cls, token: str) -> bool:
        return token[0].isupper() or token.endswith(cls._NOUN_SUFFIXES) or token.lower() in {
            "time", "year", "people", "way", "day", "man", "woman", "child", "world",
            "life", "hand", "part", "place", "case", "week", "company", "system",
            "program", "question", "government", "number", "night", "point", "home",
            "water", "room", "mother", "area", "money", "story", "fact", "month",
            "lot", "right", "study", "book", "eye", "job", "word", "business",
            "issue", "side", "kind", "head", "house", "service", "friend", "father",
            "power", "hour", "game", "line", "end", "member", "law", "car", "city",
            "community", "name", "president", "team", "minute", "idea", "kid",
            "body", "information", "back", "parent", "face", "level", "office",
            "door", "health", "person", "thing", "something", "anything", "nothing",
        }

    @classmethod
    def _is_verb(cls, token: str) -> bool:
        return token.lower() in {
            "is", "are", "was", "were", "be", "been", "being", "am",
            "has", "have", "had", "having",
            "do", "does", "did", "doing", "done",
            "will", "would", "shall", "should", "can", "could", "may", "might", "must",
            "go", "get", "make", "take", "give", "find", "see", "know", "think",
            "say", "tell", "ask", "want", "need", "like", "love", "hate", "try",
            "use", "work", "help", "keep", "start", "become", "show", "leave",
            "put", "set", "bring", "run", "move", "stand", "sit", "let", "begin",
        } or token.endswith(("ed", "ing", "en", "ize", "ise", "ate", "ify"))

    @classmethod
    def _is_adjective(cls, token: str) -> bool:
        return token.lower() in {
            "good", "new", "first", "last", "long", "great", "little", "own",
            "other", "old", "right", "big", "high", "different", "small", "large",
            "next", "early", "young", "important", "public", "bad", "same",
            "able", "free", "local", "open", "possible", "short", "sure",
            "white", "black", "red", "blue", "green", "full", "strong", "real",
            "beautiful", "happy", "sad", "angry", "clear", "deep", "easy",
            "hard", "heavy", "light", "natural", "necessary", "political",
            "popular", "private", "quick", "ready", "special", "true", "whole",
        } or token.endswith(("ous", "ive", "able", "ible", "al", "ful", "less",
                              "ish", "ic", "ical", "ant", "ent", "ary", "ory", "like"))

    @classmethod
    def _is_determiner(cls, token: str) -> bool:
        return token.lower() in {"the", "a", "an", "this", "that", "these", "those",
                                  "some", "any", "each", "every", "no", "another",
                                  "both", "all", "few", "many", "much", "several"}

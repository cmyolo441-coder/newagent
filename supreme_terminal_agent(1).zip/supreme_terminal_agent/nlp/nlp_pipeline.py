from typing import Any, Optional


class NlpPipeline:
    def __init__(self, stages: Optional[list[tuple[str, Any]]] = None, name: str = "default"):
        self.name = name
        self.stages: list[tuple[str, Any]] = stages or []

    def add_stage(self, name: str, processor: Any) -> None:
        self.stages.append((name, processor))

    def insert_stage(self, index: int, name: str, processor: Any) -> None:
        self.stages.insert(index, (name, processor))

    def remove_stage(self, name: str) -> None:
        self.stages = [(n, p) for n, p in self.stages if n != name]

    def run(self, text: str, **kwargs) -> dict:
        if not isinstance(text, str):
            raise TypeError(f"Expected str, got {type(text).__name__}")
        state: dict[str, Any] = {"text": text, "meta": kwargs}
        for stage_name, processor in self.stages:
            try:
                result = processor.process(state["text"], **state.get("meta", {}))
                if result is not None:
                    if isinstance(result, dict):
                        state.update(result)
                    else:
                        state[stage_name] = result
            except Exception as exc:
                state.setdefault("errors", {})[stage_name] = str(exc)
        return state

    def describe(self) -> str:
        lines = [f"Pipeline: {self.name}"]
        for i, (name, proc) in enumerate(self.stages):
            proc_name = getattr(proc, "__class__", type(proc)).__name__
            lines.append(f"  [{i}] {name} -> {proc_name}")
        return "\n".join(lines)

    def __len__(self) -> int:
        return len(self.stages)

    def __repr__(self) -> str:
        return f"NlpPipeline(name={self.name!r}, stages={len(self.stages)})"

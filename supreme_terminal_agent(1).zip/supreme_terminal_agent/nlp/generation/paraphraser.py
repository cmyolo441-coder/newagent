import re
import random
from typing import Optional


class Paraphraser:
    _SYNONYM_MAP: dict[str, list[str]] = {
        "good": ["great", "excellent", "fine", "positive", "beneficial", "satisfactory"],
        "bad": ["poor", "terrible", "awful", "negative", "inferior", "unfavorable"],
        "big": ["large", "huge", "enormous", "massive", "substantial", "considerable"],
        "small": ["little", "tiny", "minor", "compact", "modest", "petite"],
        "happy": ["glad", "pleased", "delighted", "content", "cheerful", "joyful"],
        "sad": ["unhappy", "miserable", "gloomy", "sorrowful", "downcast", "melancholy"],
        "important": ["significant", "crucial", "vital", "essential", "critical", "paramount"],
        "different": ["distinct", "unique", "diverse", "varied", "dissimilar", "contrasting"],
        "difficult": ["hard", "challenging", "tough", "demanding", "arduous", "strenuous"],
        "easy": ["simple", "effortless", "straightforward", "uncomplicated", "painless"],
        "fast": ["quick", "rapid", "swift", "speedy", "brisk", "hasty"],
        "slow": ["gradual", "leisurely", "unhurried", "relaxed", "sluggish", "plodding"],
        "help": ["assist", "aid", "support", "guide", "facilitate", "contribute"],
        "make": ["create", "build", "form", "construct", "produce", "fashion"],
        "use": ["utilize", "employ", "apply", "leverage", "employ", "operate"],
        "get": ["obtain", "acquire", "receive", "gain", "secure", "attain"],
        "show": ["display", "demonstrate", "present", "exhibit", "indicate", "reveal"],
        "think": ["believe", "consider", "suppose", "deem", "reckon", "opine"],
        "change": ["modify", "alter", "adjust", "transform", "revise", "amend"],
        "need": ["require", "necessitate", "demand", "call for", "entail"],
        "want": ["desire", "wish", "prefer", "would like", "seek", "aspire to"],
        "nice": ["pleasant", "lovely", "delightful", "agreeable", "charming", "enjoyable"],
        "new": ["fresh", "novel", "recent", "modern", "contemporary", "innovative"],
        "old": ["ancient", "aged", "elderly", "antique", "vintage", "former"],
        "often": ["frequently", "regularly", "commonly", "repeatedly", "habitually"],
        "very": ["extremely", "exceedingly", "immensely", "remarkably", "profoundly"],
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._num_variants = self.config.get("num_variants", 3)

    def process(self, text: str, **kwargs) -> dict:
        return self.paraphrase(text, **kwargs)

    def paraphrase(self, text: str, **kwargs) -> dict:
        num_variants = kwargs.get("num_variants", self._num_variants)
        variants: list[str] = []
        variants.append(self._synonym_replace(text))
        if not text.endswith("."):
            text_with_period = text + "."
            variants.append(self._synonym_replace(text_with_period))
        else:
            variants.append(self._synonym_replace(text.rstrip(".")))
            variants.append(self._synonym_replace(text))
        variants.append(self._restructure(text))
        while len(variants) < num_variants:
            variants.append(self._synonym_replace(text, aggressive=True))
        variants = list(set(variants))
        variants = self._rank_variants(variants, text)
        return {
            "original": text,
            "variants": variants[:num_variants],
            "num_variants": min(len(variants), num_variants),
            "changes": [self._diff_summary(text, v) for v in variants[:num_variants]],
        }

    def _synonym_replace(self, text: str, aggressive: bool = False) -> str:
        words = text.split()
        result: list[str] = []
        replaced = False
        for word in words:
            word_clean = word.lower().strip(".,!?;:'\"")
            punct = word[len(word_clean):] if word != word_clean else ""
            if word_clean in self._SYNONYM_MAP and (aggressive or not replaced):
                synonyms = self._SYNONYM_MAP[word_clean]
                new_word = random.choice(synonyms)
                if word[0].isupper():
                    new_word = new_word.capitalize()
                result.append(new_word + punct)
                replaced = True
            else:
                result.append(word)
        return " ".join(result)

    def _restructure(self, text: str) -> str:
        sentences = re.split(r'(?<=[.!?])\s+', text)
        restructured: list[str] = []
        for sentence in sentences:
            restructured.append(self._restructure_sentence(sentence))
        return " ".join(restructured)

    def _restructure_sentence(self, sentence: str) -> str:
        patterns = [
            (r"(\w+) is (\w+)", r"\2 is \1"),
            (r"(\w+) was (\w+)", r"\2 was \1"),
            (r"(\w+) are (\w+)", r"\2 are \1"),
            (r"(\w+) were (\w+)", r"\2 were \1"),
            (r"If (\w+), then (\w+)", r"\2 if \1"),
            (r"(\w+) because (\w+)", r"Because \2, \1"),
        ]
        result = sentence
        if random.random() > 0.5:
            for old, new in patterns:
                if re.match(old, result, re.IGNORECASE):
                    result = re.sub(old, new, result, flags=re.IGNORECASE)
                    break
        return result

    @staticmethod
    def _diff_summary(original: str, variant: str) -> dict:
        if original == variant:
            return {"changed": False, "edit_distance": 0}
        orig_words = original.split()
        var_words = variant.split()
        changes = sum(1 for a, b in zip(orig_words, var_words) if a != b)
        if len(orig_words) != len(var_words):
            changes += abs(len(orig_words) - len(var_words))
        return {"changed": True, "edit_distance": changes}

    @staticmethod
    def _rank_variants(variants: list[str], original: str) -> list[str]:
        def diversity(v: str) -> int:
            return sum(a != b for a, b in zip(original.split(), v.split()))
        return sorted(variants, key=diversity, reverse=True)

import re
from typing import Optional


class Simplifier:
    _COMPLEX_WORDS: dict[str, str] = {
        "utilize": "use",
        "utilizes": "uses",
        "utilized": "used",
        "utilizing": "using",
        "demonstrate": "show",
        "demonstrates": "shows",
        "demonstrated": "showed",
        "demonstrating": "showing",
        "terminate": "end",
        "terminates": "ends",
        "terminated": "ended",
        "terminating": "ending",
        "commence": "start",
        "commences": "starts",
        "commenced": "started",
        "commencing": "starting",
        "facilitate": "help",
        "facilitates": "helps",
        "facilitated": "helped",
        "facilitating": "helping",
        "implement": "do",
        "implements": "does",
        "implemented": "did",
        "implementing": "doing",
        "obtain": "get",
        "obtains": "gets",
        "obtained": "got",
        "obtaining": "getting",
        "possess": "have",
        "possesses": "has",
        "possessed": "had",
        "possessing": "having",
        "sufficient": "enough",
        "approximately": "about",
        "numerous": "many",
        "subsequent": "next",
        "previous": "last",
        "prior to": "before",
        "subsequent to": "after",
        "in order to": "to",
        "in the event that": "if",
        "with the exception of": "except",
        "in spite of": "despite",
        "on the condition that": "if",
        "in the absence of": "without",
        "in regard to": "about",
        "with regard to": "about",
        "in reference to": "about",
        "with reference to": "about",
        "in relation to": "about",
        "with respect to": "about",
        "in accordance with": "by",
        "on behalf of": "for",
        "in the vicinity of": "near",
        "at this point in time": "now",
        "at the present time": "now",
        "in the near future": "soon",
        "in the majority of cases": "mostly",
        "a large number of": "many",
        "a small number of": "few",
        "the majority of": "most",
        "the minority of": "few",
        "due to the fact that": "because",
        "in light of the fact that": "because",
        "on the grounds that": "because",
        "for the purpose of": "for",
        "with the result that": "so",
        "it is possible that": "maybe",
        "it may be that": "maybe",
        "it appears that": "seems",
        "it would appear that": "seems",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return self.simplify(text)

    def simplify(self, text: str) -> dict:
        simplified = self._replace_complex_words(text)
        simplified = self._split_long_sentences(simplified)
        simplified = self._remove_redundancy(simplified)
        return {
            "original": text,
            "simplified": simplified,
            "changes": self._count_changes(text, simplified),
            "original_complexity": self._complexity_score(text),
            "simplified_complexity": self._complexity_score(simplified),
            "complexity_reduction": round(self._complexity_score(text) - self._complexity_score(simplified), 4),
        }

    def _replace_complex_words(self, text: str) -> str:
        result = text
        sorted_phrases = sorted(self._COMPLEX_WORDS.keys(), key=len, reverse=True)
        for complex_phrase, simple_phrase in sorted_phrases:
            pattern = re.compile(re.escape(complex_phrase), re.IGNORECASE)
            result = pattern.sub(simple_phrase, result)
        return result

    @staticmethod
    def _split_long_sentences(text: str) -> str:
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        simplified: list[str] = []
        for sentence in sentences:
            words = sentence.split()
            if len(words) > 20:
                parts = []
                for clause in re.split(r'(?:,|;| -- | — )', sentence):
                    clause = clause.strip()
                    if clause:
                        parts.append(clause.rstrip("."))
                if parts:
                    simplified.append(". ".join(parts) + ".")
                else:
                    simplified.append(sentence)
            else:
                simplified.append(sentence)
        return " ".join(simplified)

    @staticmethod
    def _remove_redundancy(text: str) -> str:
        redundancies = [
            (r"\b(very unique|absolutely unique|completely unique|totally unique)\b", "unique"),
            (r"\b(advance planning|advance warning|advance notice)\b", r"\1"),
            (r"\b(close proximity)\b", "proximity"),
            (r"\b(consensus of opinion)\b", "consensus"),
            (r"\b(empty space)\b", "space"),
            (r"\b(end result)\b", "result"),
            (r"\b(estimated at about)\b", "estimated at"),
            (r"\b(extra added)\b", "added"),
            (r"\b(foreign imports)\b", "imports"),
            (r"\b(future plans)\b", "plans"),
            (r"\b(general public)\b", "public"),
            (r"\b(necessary requirement)\b", "requirement"),
            (r"\b(new innovation)\b", "innovation"),
            (r"\b(past experience)\b", "experience"),
            (r"\b(past history)\b", "history"),
            (r"\b(repeat again)\b", "repeat"),
            (r"\b(safe haven)\b", "haven"),
            (r"\b(sudden impulse)\b", "impulse"),
            (r"\b(unexpected surprise)\b", "surprise"),
            (r"\b(usual custom)\b", "custom"),
        ]
        result = text
        for pattern, replacement in redundancies:
            result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
        return result

    @staticmethod
    def _count_changes(original: str, simplified: str) -> dict:
        return {
            "word_count_original": len(original.split()),
            "word_count_simplified": len(simplified.split()),
            "difference": len(simplified.split()) - len(original.split()),
            "length_original": len(original),
            "length_simplified": len(simplified),
        }

    @staticmethod
    def _complexity_score(text: str) -> float:
        words = re.findall(r'\b\w+\b', text.lower())
        if not words:
            return 0.0
        avg_len = sum(len(w) for w in words) / len(words)
        long_words_ratio = sum(1 for w in words if len(w) >= 7) / len(words)
        return round(avg_len * (1 + long_words_ratio), 4)

    def simplify_batch(self, texts: list[str]) -> list[dict]:
        return [self.simplify(t) for t in texts]

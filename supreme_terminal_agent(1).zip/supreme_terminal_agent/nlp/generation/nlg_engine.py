from typing import Any, Optional

from .text_generator import TextGenerator
from .paraphraser import Paraphraser
from .summarizer import Summarizer
from .expander import Expander
from .simplifier import Simplifier
from .style_transfer import StyleTransfer


class NlgEngine:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self.text_generator = TextGenerator(config.get("generator_config"))
        self.paraphraser = Paraphraser(config.get("paraphraser_config"))
        self.summarizer = Summarizer(config.get("summarizer_config"))
        self.expander = Expander(config.get("expander_config"))
        self.simplifier = Simplifier(config.get("simplifier_config"))
        self.style_transfer = StyleTransfer(config.get("style_config"))

    def process(self, text: str = "", **kwargs) -> dict:
        mode = kwargs.get("mode", "generate")
        if mode == "generate":
            prompt = kwargs.get("prompt", text)
            return self.generate(prompt, **kwargs)
        elif mode == "paraphrase":
            return self.paraphrase(text, **kwargs)
        elif mode == "summarize":
            return self.summarize(text, **kwargs)
        elif mode == "expand":
            return self.expand(text, **kwargs)
        elif mode == "simplify":
            return self.simplify_text(text, **kwargs)
        elif mode == "transfer":
            return self.transfer_style(text, **kwargs)

    def generate(self, prompt: str = "", **kwargs) -> dict:
        return self.text_generator.generate(prompt, **kwargs)

    def paraphrase(self, text: str, **kwargs) -> dict:
        return self.paraphraser.paraphrase(text, **kwargs)

    def summarize(self, text: str, **kwargs) -> dict:
        return self.summarizer.summarize(text, **kwargs)

    def expand(self, text: str, **kwargs) -> dict:
        return self.expander.expand(text, **kwargs)

    def simplify_text(self, text: str, **kwargs) -> dict:
        return self.simplifier.simplify(text, **kwargs)

    def transfer_style(self, text: str, **kwargs) -> dict:
        return self.style_transfer.transfer(text, **kwargs)

    def __repr__(self) -> str:
        return "NlgEngine(generate+paraphrase+summarize+expand+simplify+transfer)"

import re
import random
from typing import Optional


class StyleTransfer:
    _FORMAL_MARKERS: dict[str, list[str]] = {
        "transition": ["however", "therefore", "thus", "furthermore", "moreover", "nevertheless"],
        "verb": ["utilize", "demonstrate", "terminate", "commence", "facilitate"],
        "modal": ["shall", "must", "ought to"],
        "connector": ["in addition", "consequently", "accordingly", "subsequently"],
    }

    _INFORMAL_MARKERS: dict[str, list[str]] = {
        "transition": ["but", "so", "anyway", "well", "then"],
        "verb": ["use", "show", "end", "start", "help"],
        "modal": ["can", "will", "should"],
        "connector": ["also", "plus", "then", "like"],
    }

    _FORMAL_WORDS: dict[str, str] = {
        "use": "utilize", "show": "demonstrate", "end": "terminate",
        "start": "commence", "help": "facilitate", "get": "obtain",
        "have": "possess", "enough": "sufficient", "about": "approximately",
        "many": "numerous", "next": "subsequent", "last": "previous",
        "before": "prior to", "after": "subsequent to",
        "to": "in order to", "if": "in the event that",
        "except": "with the exception of", "despite": "in spite of",
        "without": "in the absence of",
        "for": "for the purpose of", "so": "with the result that",
        "now": "at the present time", "soon": "in the near future",
        "maybe": "it is possible that", "seems": "it appears that",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        target_style = kwargs.get("style", "formal")
        return self.transfer(text, target_style)

    def transfer(self, text: str, target_style: str = "formal") -> dict:
        if target_style == "formal":
            result = self._to_formal(text)
        elif target_style == "informal":
            result = self._to_informal(text)
        elif target_style == "simple":
            from .simplifier import Simplifier
            simplifier = Simplifier()
            result = simplifier.simplify(text)["simplified"]
        else:
            result = text
        change_log = self._detect_changes(text, result)
        return {
            "original": text,
            "transferred": result,
            "target_style": target_style,
            "changes": change_log,
            "confidence": self._estimate_confidence(text, result),
        }

    def _to_formal(self, text: str) -> str:
        result = text
        sorted_words = sorted(self._FORMAL_WORDS.items(), key=lambda x: -len(x[0]))
        for informal_word, formal_word in sorted_words:
            pattern = re.compile(r'\b' + re.escape(informal_word) + r'\b', re.IGNORECASE)
            result = pattern.sub(formal_word, result)
        result = self._add_formal_markers(result)
        result = re.sub(r"\b(can't|won't|don't|doesn't|didn't|isn't|aren't|wasn't|weren't|haven't|hasn't|hadn't|wouldn't|couldn't|shouldn't|mustn't|needn't)\b",
                        lambda m: self._expand_contraction(m.group(0)), result)
        if result and not result.endswith((".", "!", "?")):
            result += "."
        return result

    def _to_informal(self, text: str) -> str:
        result = text
        reverse_map = {v: k for k, v in self._FORMAL_WORDS.items() if k not in {"prior to", "subsequent to", "in order to", "in the event that", "with the exception of", "in spite of", "in the absence of", "for the purpose of", "with the result that", "at the present time", "in the near future", "it is possible that", "it appears that"}}
        for formal_word, informal_word in reverse_map.items():
            pattern = re.compile(r'\b' + re.escape(formal_word) + r'\b', re.IGNORECASE)
            result = pattern.sub(informal_word, result)
        result = result.replace(", however,", ", but,")
        result = result.replace("however,", "but,")
        result = result.replace("therefore,", "so,")
        result = result.replace("thus,", "so,")
        result = result.replace("furthermore,", "also,")
        return result

    @staticmethod
    def _add_formal_markers(text: str) -> str:
        if len(text.split()) >= 5 and not any(w in text.lower() for w in ["however", "therefore", "thus"]):
            sentences = re.split(r'(?<=[.!?])\s+', text.strip())
            if len(sentences) >= 2:
                sentence = random.choice(sentences[1:])
                formal_marker = random.choice(["However,", "Therefore,", "Furthermore,", "Moreover,"])
                text = text.replace(sentence, f"{formal_marker} {sentence[0].lower()}{sentence[1:]}")
        return text

    @staticmethod
    def _expand_contraction(contraction: str) -> str:
        mapping = {
            "can't": "cannot", "won't": "will not", "don't": "do not",
            "doesn't": "does not", "didn't": "did not", "isn't": "is not",
            "aren't": "are not", "wasn't": "was not", "weren't": "were not",
            "haven't": "have not", "hasn't": "has not", "hadn't": "had not",
            "wouldn't": "would not", "couldn't": "could not", "shouldn't": "should not",
            "mustn't": "must not", "needn't": "need not",
        }
        return mapping.get(contraction.lower(), contraction)

    @staticmethod
    def _detect_changes(original: str, transferred: str) -> dict:
        return {
            "word_count_change": len(transferred.split()) - len(original.split()),
            "length_change": len(transferred) - len(original),
            "identical": original == transferred,
        }

    @staticmethod
    def _estimate_confidence(original: str, transferred: str) -> float:
        if original == transferred:
            return 0.5
        diff_count = sum(1 for a, b in zip(original.split(), transferred.split()) if a != b)
        max_len = max(len(original.split()), len(transferred.split()))
        if max_len == 0:
            return 0.0
        return round(min(diff_count / max_len * 2, 1.0), 4)

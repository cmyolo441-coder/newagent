import re
from collections import Counter
from typing import Optional


class Summarizer:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._max_sentences = self.config.get("max_sentences", 3)
        self._ratio = self.config.get("ratio", 0.3)

    def process(self, text: str, **kwargs) -> dict:
        return self.summarize(text, **kwargs)

    def summarize(self, text: str, **kwargs) -> dict:
        max_sentences = kwargs.get("max_sentences", self._max_sentences)
        sentences = self._split_sentences(text)
        if len(sentences) <= max_sentences:
            return {
                "summary": text,
                "original_length": len(sentences),
                "summary_length": len(sentences),
                "compression_ratio": 1.0,
                "method": "truncation",
            }
        word_freq = self._compute_word_frequencies(sentences)
        sentence_scores = self._score_sentences(sentences, word_freq)
        summary_sentences = self._select_top_sentences(sentence_scores, max_sentences)
        summary = " ".join(summary_sentences)
        return {
            "summary": summary,
            "original_length": len(sentences),
            "summary_length": len(summary_sentences),
            "compression_ratio": round(len(summary_sentences) / max(len(sentences), 1), 4),
            "method": "extractive",
            "scored_sentences": sentence_scores,
        }

    def summarize_by_ratio(self, text: str, ratio: float = 0.3) -> dict:
        sentences = self._split_sentences(text)
        max_sentences = max(1, int(len(sentences) * ratio))
        return self.summarize(text, max_sentences=max_sentences)

    def summarize_keyword(self, text: str, keywords: list[str]) -> dict:
        sentences = self._split_sentences(text)
        scored: list[tuple[float, str]] = []
        for sent in sentences:
            score = sum(1 for kw in keywords if kw.lower() in sent.lower())
            scored.append((score, sent))
        scored.sort(key=lambda x: -x[0])
        selected = [s for _, s in scored if _ > 0][:self._max_sentences]
        if not selected:
            return self.summarize(text)
        return {
            "summary": " ".join(selected),
            "method": "keyword",
            "keyword_matches": sum(1 for s in selected if any(kw.lower() in s.lower() for kw in keywords)),
        }

    @staticmethod
    def _split_sentences(text: str) -> list[str]:
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        return [s.strip() for s in sentences if len(s.strip()) > 5]

    @staticmethod
    def _compute_word_frequencies(sentences: list[str]) -> Counter:
        word_freq: Counter = Counter()
        stop_words = {"the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
                       "of", "by", "with", "from", "is", "are", "was", "were", "be", "been",
                       "being", "have", "has", "had", "do", "does", "did", "will", "would",
                       "could", "should", "may", "might", "shall", "can", "must", "i", "you",
                       "he", "she", "it", "we", "they", "me", "him", "her", "us", "them",
                       "my", "your", "his", "its", "our", "their"}
        for sentence in sentences:
            words = re.findall(r'\b\w+\b', sentence.lower())
            for word in words:
                if word not in stop_words:
                    word_freq[word] += 1
        return word_freq

    @staticmethod
    def _score_sentences(sentences: list[str], word_freq: Counter) -> list[dict]:
        scored: list[dict] = []
        for i, sentence in enumerate(sentences):
            words = re.findall(r'\b\w+\b', sentence.lower())
            if not words:
                score = 0.0
            else:
                word_scores = [word_freq.get(w, 0) for w in words]
                score = sum(word_scores) / len(words)
            position_bonus = 1.0 if i == 0 else (0.5 if i <= 2 else 0.0)
            score += position_bonus
            scored.append({
                "sentence": sentence,
                "score": round(score, 4),
                "position": i,
                "word_count": len(words),
            })
        return scored

    @staticmethod
    def _select_top_sentences(scored: list[dict], n: int) -> list[str]:
        sorted_scores = sorted(scored, key=lambda x: (-x["score"], x["position"]))
        selected = sorted_scores[:n]
        selected.sort(key=lambda x: x["position"])
        return [s["sentence"] for s in selected]

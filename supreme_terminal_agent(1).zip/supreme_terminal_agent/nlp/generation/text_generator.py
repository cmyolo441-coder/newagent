import re
import random
from typing import Optional


class TextGenerator:
    _TEMPLATES: dict[str, list[str]] = {
        "greeting": [
            "Hello! How can I help you today?",
            "Hi there! What can I do for you?",
            "Greetings! How may I assist you?",
            "Hey! How can I be of service?",
        ],
        "farewell": [
            "Goodbye! Have a great day.",
            "See you later! Take care.",
            "Farewell! It was nice talking to you.",
            "Bye! Feel free to come back anytime.",
        ],
        "acknowledgment": [
            "I understand. Let me process that.",
            "Got it. Working on it now.",
            "I see. Let me handle that for you.",
            "Understood. Give me a moment.",
        ],
        "confirmation": [
            "I confirm that {input}.",
            "Yes, {input}.",
            "That is correct: {input}.",
            "Confirmed: {input}.",
        ],
        "negation": [
            "No, that is not the case.",
            "I'm sorry, but that is incorrect.",
            "Unfortunately, that is not accurate.",
            "That does not seem to be right.",
        ],
        "apology": [
            "I apologize for the inconvenience.",
            "I'm sorry about that.",
            "My apologies for the issue.",
            "I'm sorry, I'll do better next time.",
        ],
        "help": [
            "I can help you with various tasks including answering questions, running commands, and processing information.",
            "I'm here to assist you. You can ask me questions, give me commands, or request information.",
            "Let me know what you need help with. I can handle queries, tasks, and data processing.",
        ],
        "error": [
            "I encountered an error: {error}.",
            "Something went wrong: {error}.",
            "An error occurred: {error}.",
            "Sorry, I ran into an issue: {error}.",
        ],
        "thinking": [
            "Let me think about that...",
            "Processing your request...",
            "Working on it...",
            "Let me analyze that...",
        ],
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._templates = dict(self._TEMPLATES)
        if self.config.get("custom_templates"):
            self._templates.update(self.config["custom_templates"])

    def process(self, text: str = "", **kwargs) -> dict:
        return self.generate(text, **kwargs)

    def generate(self, prompt: str = "", **kwargs) -> dict:
        template = kwargs.get("template", "")
        if template and template in self._templates:
            return self._from_template(template, **kwargs)
        if not prompt:
            return self._fallback(**kwargs)
        return {
            "generated_text": self._generate_response(prompt),
            "template_used": template or "dynamic",
            "confidence": 0.7,
        }

    def _from_template(self, template_name: str, **kwargs) -> dict:
        options = self._templates.get(template_name, [""])
        text = random.choice(options)
        text = self._fill_template(text, kwargs)
        return {"generated_text": text, "template_used": template_name, "confidence": 0.9}

    def _generate_response(self, prompt: str) -> str:
        prompt_lower = prompt.lower().strip()
        if re.match(r"^(hello|hi|hey|greetings|howdy)", prompt_lower):
            return random.choice(self._templates["greeting"])
        if re.search(r"\b(help|assist|support|what can you)\b", prompt_lower):
            return random.choice(self._templates["help"])
        if re.match(r"^(bye|goodbye|see you|farewell)", prompt_lower):
            return random.choice(self._templates["farewell"])
        if re.search(r"\b(yes|yeah|correct|right|true|confirm)\b", prompt_lower):
            return random.choice(self._templates["acknowledgment"])
        if re.search(r"\b(thank|thanks)\b", prompt_lower):
            return "You're welcome! Happy to help."
        return random.choice(self._templates["acknowledgment"])

    @staticmethod
    def _fill_template(text: str, kwargs: dict) -> str:
        for key, value in kwargs.items():
            placeholder = "{" + key + "}"
            if placeholder in text:
                text = text.replace(placeholder, str(value))
        return text

    def _fallback(self, **kwargs) -> dict:
        return {
            "generated_text": "I don't have enough information to generate a response.",
            "template_used": "none",
            "confidence": 0.0,
        }

    def add_template(self, name: str, texts: list[str]) -> None:
        self._templates[name] = texts

    def generate_batch(self, prompts: list[str], **kwargs) -> list[dict]:
        return [self.generate(p, **kwargs) for p in prompts]

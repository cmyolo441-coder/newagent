import re
from typing import Optional


class Expander:
    _EXPANSION_RULES: list[tuple[str, str, str]] = [
        (r"(?:i\.e\.|i\. ?e\.)", "that is"),
        (r"(?:e\.g\.|e\. ?g\.)", "for example"),
        (r"(?:etc\.|etc)", "and so on"),
        (r"(?:vs\.|vs|v\.)", "versus"),
        (r"(?:w/|w\/)", "with"),
        (r"(?:w/o|w\/o)", "without"),
        (r"(?:c\.f\.)", "compare"),
        (r"(?:n\.b\.)", "note well"),
        (r"(?:a\.k\.a\.)", "also known as"),
        (r"\b(can't)\b", "cannot"),
        (r"\b(won't)\b", "will not"),
        (r"\b(don't)\b", "do not"),
        (r"\b(doesn't)\b", "does not"),
        (r"\b(didn't)\b", "did not"),
        (r"\b(haven't)\b", "have not"),
        (r"\b(hasn't)\b", "has not"),
        (r"\b(hadn't)\b", "had not"),
        (r"\b(wasn't)\b", "was not"),
        (r"\b(weren't)\b", "were not"),
        (r"\b(isn't)\b", "is not"),
        (r"\b(aren't)\b", "are not"),
        (r"\b(won't)\b", "will not"),
        (r"\b(wouldn't)\b", "would not"),
        (r"\b(couldn't)\b", "could not"),
        (r"\b(shouldn't)\b", "should not"),
        (r"\b(mustn't)\b", "must not"),
        (r"\b(mightn't)\b", "might not"),
        (r"\b(needn't)\b", "need not"),
    ]

    _ELABORATION_PATTERNS: dict[str, list[str]] = {
        "definition": [
            "In other words, {clause}.",
            "More specifically, {clause}.",
            "That is to say, {clause}.",
            "To clarify, {clause}.",
            "Put differently, {clause}.",
        ],
        "example": [
            "For instance, {clause}.",
            "As an example, {clause}.",
            "To illustrate, {clause}.",
            "Consider for example {clause}.",
            "A good example is {clause}.",
        ],
        "detail": [
            "Additionally, {clause}.",
            "Furthermore, {clause}.",
            "Moreover, {clause}.",
            "In addition, {clause}.",
            "Beyond that, {clause}.",
        ],
        "consequence": [
            "As a result, {clause}.",
            "Consequently, {clause}.",
            "Therefore, {clause}.",
            "Thus, {clause}.",
            "This leads to {clause}.",
        ],
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._max_expansions = self.config.get("max_expansions", 3)

    def process(self, text: str, **kwargs) -> dict:
        return self.expand(text, **kwargs)

    def expand(self, text: str, **kwargs) -> dict:
        max_expansions = kwargs.get("max_expansions", self._max_expansions)
        expanded = self._expand_abbreviations(text)
        elaborated = self._elaborate_clauses(expanded, max_expansions)
        return {
            "original": text,
            "expanded": expanded,
            "elaborated": elaborated,
            "abbreviations_expanded": self._count_abbreviation_expansions(text, expanded),
            "word_count_change": len(elaborated.split()) - len(text.split()),
        }

    def _expand_abbreviations(self, text: str) -> str:
        result = text
        for pattern, replacement in self._EXPANSION_RULES:
            result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
        return result

    def _elaborate_clauses(self, text: str, max_expansions: int) -> str:
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        if len(sentences) > max_expansions + 1:
            return text
        expansions_done = 0
        for i, sentence in enumerate(sentences):
            if expansions_done >= max_expansions:
                break
            if len(sentence.split()) < 8 and sentence.strip():
                elaboration_type = self._choose_elaboration_type(sentence)
                patterns = self._ELABORATION_PATTERNS.get(elaboration_type, self._ELABORATION_PATTERNS["detail"])
                import random
                pattern = random.choice(patterns)
                elaboration = pattern.format(clause=sentence.strip().rstrip(".").strip().lower())
                sentences[i] = elaboration
                expansions_done += 1
        return " ".join(sentences)

    @staticmethod
    def _choose_elaboration_type(sentence: str) -> str:
        sent_lower = sentence.lower()
        if any(w in sent_lower for w in ["is", "are", "was", "were", "means", "refers", "called"]):
            return "definition"
        if any(w in sent_lower for w in ["like", "such as", "including", "especially"]):
            return "example"
        if any(w in sent_lower for w in ["because", "since", "as", "due to", "therefore"]):
            return "consequence"
        return "detail"

    @staticmethod
    def _count_abbreviation_expansions(original: str, expanded: str) -> int:
        orig_words = set(original.lower().split())
        expanded_words = set(expanded.lower().split())
        return len(expanded_words - orig_words)

    def expand_abbreviations_only(self, text: str) -> str:
        return self._expand_abbreviations(text)

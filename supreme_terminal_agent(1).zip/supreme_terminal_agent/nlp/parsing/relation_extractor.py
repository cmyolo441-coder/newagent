import re
from typing import Optional


class Relation:
    def __init__(self, subject: str, predicate: str, obj: str, confidence: float = 1.0):
        self.subject = subject
        self.predicate = predicate
        self.object = obj
        self.confidence = confidence

    def to_dict(self) -> dict:
        return {
            "subject": self.subject,
            "predicate": self.predicate,
            "object": self.object,
            "confidence": self.confidence,
        }

    def __repr__(self) -> str:
        return f"Relation({self.subject} -- {self.predicate} --> {self.object})"


class RelationExtractor:
    _PATTERNS: list[tuple[str, str, str]] = [
        (r"(\w+) (is|are|was|were|am) (\w+)", "be"),
        (r"(\w+) (has|have|had) (\w+)", "have"),
        (r"(\w+) (likes|loves|hates|prefers|wants|needs|knows|believes|thinks) (\w+)", "mental"),
        (r"(\w+) (created|made|built|wrote|developed|designed|produced|formed) (\w+)", "creation"),
        (r"(\w+) (killed|destroyed|broke|removed|deleted|eliminated|ended) (\w+)", "destruction"),
        (r"(\w+) (owns|possesses|controls|manages|leads|runs|operates) (\w+)", "possession"),
        (r"(\w+) (works at|works for|employed by|joins|joined|leads) (\w+)", "affiliation"),
        (r"(\w+) (located in|located at|based in|sits in|stands on|lives in|resides in) (\w+)", "location"),
        (r"(\w+) (said|stated|claimed|announced|reported|mentioned|noted) that (\w+)", "communication"),
        (r"(\w+) (caused|led to|resulted in|triggered|sparked) (\w+)", "causation"),
    ]

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        relations = self.extract(text)
        return {
            "relations": [r.to_dict() for r in relations],
            "triples": [(r.subject, r.predicate, r.object) for r in relations],
            "entity_network": self._build_network(relations),
        }

    def extract(self, text: str) -> list[Relation]:
        relations: list[Relation] = []
        sentences = re.split(r'[.!?]+', text)
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            for pattern, rel_type in self._PATTERNS:
                for match in re.finditer(pattern, sentence, re.IGNORECASE):
                    groups = match.groups()
                    if len(groups) >= 3:
                        conf = self._compute_confidence(match.group(0), rel_type)
                        relations.append(Relation(
                            subject=groups[0],
                            predicate=groups[1],
                            obj=groups[2],
                            confidence=conf,
                        ))
        return self._deduplicate(relations)

    @staticmethod
    def _compute_confidence(text: str, rel_type: str) -> float:
        base = {"be": 0.6, "have": 0.7, "mental": 0.5, "creation": 0.8,
                "destruction": 0.8, "possession": 0.7, "affiliation": 0.75,
                "location": 0.85, "communication": 0.65, "causation": 0.7}
        return base.get(rel_type, 0.5)

    @staticmethod
    def _deduplicate(relations: list[Relation]) -> list[Relation]:
        seen: set[tuple[str, str, str]] = set()
        result: list[Relation] = []
        for r in relations:
            key = (r.subject.lower(), r.predicate.lower(), r.object.lower())
            if key not in seen:
                seen.add(key)
                result.append(r)
        return result

    def _build_network(self, relations: list[Relation]) -> dict:
        entities: dict[str, set[str]] = {}
        for r in relations:
            entities.setdefault(r.subject, set()).add(r.object)
            entities.setdefault(r.object, set()).add(r.subject)
        return {k: list(v) for k, v in entities.items()}

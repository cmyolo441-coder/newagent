import re
from typing import Optional


class SentenceParser:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._abbreviations: set[str] = set(self.config.get("abbreviations", [
            "mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "ave", "dept",
            "etc", "vs", "inc", "ltd", "co", "corp", "gen", "sgt", "capt",
            "lt", "col", "maj", "gov", "rep", "sen", "pres", "hon",
        ]))

    def process(self, text: str, **kwargs) -> dict:
        return {
            "sentences": self.parse(text),
            "sentence_count": 0,
            "boundaries": self.find_boundaries(text),
        }

    def parse(self, text: str) -> list[str]:
        if not text or not text.strip():
            return []
        text = text.strip()
        sentences = []
        buffer = []
        tokens = re.split(r'(\s+)', text)
        i = 0
        while i < len(tokens):
            token = tokens[i]
            buffer.append(token)
            if re.search(r'[.!?]$', token.strip()):
                candidate = "".join(buffer).strip()
                lower = token.strip().lower().rstrip(".!?")
                if lower in self._abbreviations:
                    continue
                if i + 2 < len(tokens):
                    next_word = tokens[i + 2] if i + 2 < len(tokens) else ""
                    if next_word and next_word[0].islower():
                        continue
                sentences.append(candidate)
                buffer = []
            i += 1
        remainder = "".join(buffer).strip()
        if remainder:
            sentences.append(remainder)
        return sentences

    def find_boundaries(self, text: str) -> list[tuple[int, int]]:
        sentences = self.parse(text)
        boundaries = []
        pos = 0
        for sent in sentences:
            start = text.find(sent, pos)
            if start >= 0:
                end = start + len(sent)
                boundaries.append((start, end))
                pos = end
        return boundaries

    def is_sentence_boundary(self, text: str, position: int) -> bool:
        if position <= 0 or position >= len(text):
            return False
        char = text[position - 1]
        return char in ".!?"

import re
from typing import Optional


class DependencyParse:
    def __init__(self, head: str, dep: str, relation: str, head_idx: int, dep_idx: int):
        self.head = head
        self.dep = dep
        self.relation = relation
        self.head_idx = head_idx
        self.dep_idx = dep_idx

    def to_dict(self) -> dict:
        return {
            "head": self.head,
            "dep": self.dep,
            "relation": self.relation,
            "head_idx": self.head_idx,
            "dep_idx": self.dep_idx,
        }

    def __repr__(self) -> str:
        return f"DependencyParse({self.head} --{self.relation}--> {self.dep})"


class DependencyParser:
    _PATTERNS: list[tuple[str, str, str, str]] = [
        (r"\b(is|are|was|were|be|been|being|am)\s+\w+ing\b", "aux", "progressive", "root"),
        (r"\b(have|has|had)\s+\w+ed\b", "aux", "perfect", "root"),
        (r"\b(will|shall|would|should|can|could|may|might|must)\s+(\w+)", "aux", "modal", "root"),
        (r"\b(\w+)\s+(is|are|was|were|am)\s+(\w+ed|\w+ing)\b", "nsubj", "cop", "root"),
        (r"\b(\w+)\s+(\w+ed|ate|ought|ound|ent|\w+ing)\s+(\w+)\b", "nsubj", "root", "dobj"),
        (r"\b(\w+)\s+(\w+)\s+(in|on|at|by|with|from|to|for|of|about)\s+(\w+)", "nsubj", "root", "pobj"),
    ]

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        tokens = text.split()
        deps = self.parse(tokens)
        return {
            "dependencies": [d.to_dict() for d in deps],
            "tokens": tokens,
            "tree": self._build_tree(deps),
        }

    def parse(self, tokens: list[str]) -> list[DependencyParse]:
        deps: list[DependencyParse] = []
        sent = " ".join(tokens)
        for pattern, rel_head, rel_dep, _ in self._PATTERNS:
            for match in re.finditer(pattern, sent, re.IGNORECASE):
                groups = match.groups()
                if len(groups) >= 2:
                    g = list(groups)
                    deps.append(DependencyParse(
                        head=g[0], dep=g[1], relation=f"{rel_head}:{rel_dep}",
                        head_idx=self._find_index(tokens, g[0]),
                        dep_idx=self._find_index(tokens, g[1]),
                    ))
                    if len(g) >= 3:
                        deps.append(DependencyParse(
                            head=g[1], dep=g[2], relation="dobj",
                            head_idx=self._find_index(tokens, g[1]),
                            dep_idx=self._find_index(tokens, g[2]),
                        ))
        for i in range(len(tokens) - 1):
            if not any(d.dep_idx == i + 1 for d in deps):
                deps.append(DependencyParse(
                    head=tokens[i], dep=tokens[i + 1], relation="flat",
                    head_idx=i, dep_idx=i + 1,
                ))
        return deps

    @staticmethod
    def _find_index(tokens: list[str], word: str) -> int:
        try:
            return tokens.index(word)
        except ValueError:
            for i, t in enumerate(tokens):
                if t.lower() == word.lower():
                    return i
            return -1

    def _build_tree(self, deps: list[DependencyParse]) -> dict:
        root: dict[str, dict] = {}
        for d in deps:
            if d.head not in root:
                root[d.head] = {"dependents": []}
            root[d.head]["dependents"].append({
                "word": d.dep,
                "relation": d.relation,
            })
        return root

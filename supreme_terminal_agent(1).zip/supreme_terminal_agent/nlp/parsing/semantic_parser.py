import re
from typing import Any, Optional


class SemanticRole:
    def __init__(self, predicate: str, role: str, argument: str):
        self.predicate = predicate
        self.role = role
        self.argument = argument

    def to_dict(self) -> dict:
        return {"predicate": self.predicate, "role": self.role, "argument": self.argument}


class SemanticParser:
    _VERB_PATTERN = re.compile(r'\b(\w+)\b')
    _ROLE_PATTERNS: list[tuple[str, str, str]] = [
        (r"(\w+) (killed|hit|punched|kissed|helped|saw|called|asked|told) (\w+)", "agent", "patient"),
        (r"(\w+) (gave|sent|handed|showed|bought|sold|offered) (\w+) (\w+)", "agent", "recipient"),
        (r"(\w+) (gave|sent|handed|showed|bought|sold|offered) (\w+) to (\w+)", "agent", "recipient"),
        (r"(\w+) (is|was|are|were) (\w+)", "theme", "attribute"),
        (r"(\w+) (has|have|had) (\w+)", "possessor", "possessed"),
        (r"(\w+) (likes|hates|loves|knows|believes|thinks|wants|needs) (\w+)", "experiencer", "stimulus"),
        (r"(\w+) (walked|ran|went|came|arrived|left|traveled|moved)\s*(to|from|into|out of)?\s*(\w*)", "agent", "location"),
    ]

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return {
            "roles": [r.to_dict() for r in self.extract_roles(text)],
            "predicates": self._find_predicates(text),
            "arguments": self._find_arguments(text),
        }

    def extract_roles(self, text: str) -> list[SemanticRole]:
        roles: list[SemanticRole] = []
        for pattern, role1, role2 in self._ROLE_PATTERNS:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                groups = match.groups()
                if len(groups) >= 2:
                    roles.append(SemanticRole(
                        predicate=groups[1],
                        role="agent",
                        argument=groups[0],
                    ))
                    roles.append(SemanticRole(
                        predicate=groups[1],
                        role=role2,
                        argument=groups[-1],
                    ))
                    if "recipient" in (role1, role2) and len(groups) >= 4:
                        roles.append(SemanticRole(
                            predicate=groups[1],
                            role="patient",
                            argument=groups[2],
                        ))
        return roles

    def _find_predicates(self, text: str) -> list[str]:
        verbs = ["is", "are", "was", "were", "has", "have", "had", "do", "does", "did",
                 "will", "would", "can", "could", "shall", "should", "may", "might",
                 "go", "get", "make", "take", "give", "find", "see", "know", "think",
                 "say", "tell", "ask", "want", "need", "like", "love", "hate", "try",
                 "use", "work", "help", "keep", "start", "become", "show", "leave",
                 "put", "set", "bring", "run", "move", "stand", "sit", "let", "begin"]
        found = []
        tokens = text.lower().split()
        for token in tokens:
            if token in verbs and token not in found:
                found.append(token)
        return found

    def _find_arguments(self, text: str) -> list[str]:
        stop_words = {"the", "a", "an", "is", "are", "was", "were", "has", "have", "had",
                      "do", "does", "did", "will", "would", "can", "could", "shall", "should",
                      "may", "might", "must", "of", "in", "on", "at", "by", "with", "from",
                      "to", "for", "and", "or", "but", "not", "no", "so", "if", "as"}
        tokens = text.split()
        return [t for t in tokens if t.lower() not in stop_words and t.isalpha()]

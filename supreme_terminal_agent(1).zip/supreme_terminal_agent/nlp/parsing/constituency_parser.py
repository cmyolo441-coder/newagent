import re
from typing import Any, Optional


class ConstituencyTree:
    def __init__(self, label: str, children: Optional[list[Any]] = None):
        self.label = label
        self.children: list[Any] = children or []

    def is_leaf(self) -> bool:
        return isinstance(self.children[0], str) if self.children else True

    def to_dict(self) -> Any:
        if self.is_leaf():
            return {self.label: self.children[0] if self.children else ""}
        return {self.label: [c.to_dict() if isinstance(c, ConstituencyTree) else c for c in self.children]}

    def __repr__(self) -> str:
        return f"ConstituencyTree({self.label})"


class ConstituencyParser:
    _GRAMMAR: list[tuple[str, str, list[type]]] = [
        ("S", r"(?P<NP>.*?)\s+(?P<VP>.*?)", [str, str]),
        ("NP", r"(?P<DT>the|a|an|this|that|these|those|my|your|his|her|its|our|their)\s+(?P<NN>\w+)", [str, str]),
        ("NP", r"(?P<NN>\w+)", [str]),
        ("VP", r"(?P<VB>\w+)\s+(?P<NP>.*)", [str, str]),
        ("VP", r"(?P<VB>\w+)", [str]),
        ("PP", r"(?P<P>in|on|at|by|with|from|to|for|of|about)\s+(?P<NP>\w+)", [str, str]),
        ("ADJP", r"(?P<JJ>\w+)", [str]),
        ("ADVP", r"(?P<RB>\w+)", [str]),
    ]

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        tree = self.parse(text)
        return {
            "tree": tree.to_dict() if tree else {},
            "phrases": self.extract_phrases(tree),
            "structure": self._flatten(tree) if tree else [],
        }

    def parse(self, text: str) -> ConstituencyTree:
        root = ConstituencyTree("ROOT", [])
        sentences = self._split(text)
        for sent in sentences:
            sent_tree = self._parse_sentence(sent.strip())
            root.children.append(sent_tree)
        return root

    def _split(self, text: str) -> list[str]:
        return [s.strip() for s in re.split(r'[.!?]+', text) if s.strip()]

    def _parse_sentence(self, sentence: str) -> ConstituencyTree:
        return ConstituencyTree("S", self._build(sentence))

    def _build(self, phrase: str) -> list[ConstituencyTree]:
        tokens = phrase.split()
        result: list[ConstituencyTree] = []
        for token in tokens:
            result.append(ConstituencyTree("NN" if token[0].islower() else "NNP", [token]))
        return result

    def extract_phrases(self, tree: ConstituencyTree) -> dict[str, list[str]]:
        phrases: dict[str, list[str]] = {}
        self._walk(tree, phrases)
        return phrases

    def _walk(self, node: ConstituencyTree, phrases: dict[str, list[str]]) -> None:
        if node.label in ("NP", "VP", "PP", "ADJP", "ADVP", "S"):
            phrase_text = self._text(node)
            phrases.setdefault(node.label, []).append(phrase_text)
        for child in node.children:
            if isinstance(child, ConstituencyTree):
                self._walk(child, phrases)

    @staticmethod
    def _text(node: ConstituencyTree) -> str:
        parts: list[str] = []
        for child in node.children:
            if isinstance(child, ConstituencyTree):
                parts.append(ConstituencyParser._text(child))
            else:
                parts.append(str(child))
        return " ".join(parts)

    def _flatten(self, tree: ConstituencyTree, depth: int = 0) -> list[dict]:
        result = [{"label": tree.label, "text": self._text(tree), "depth": depth}]
        for child in tree.children:
            if isinstance(child, ConstituencyTree):
                result.extend(self._flatten(child, depth + 1))
        return result

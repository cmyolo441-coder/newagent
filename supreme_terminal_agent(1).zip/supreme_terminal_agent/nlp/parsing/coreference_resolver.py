import re
from typing import Optional


class CoreferenceChain:
    def __init__(self, representative: str):
        self.representative = representative
        self.mentions: list[dict] = []

    def add_mention(self, text: str, position: tuple[int, int], role: str = "unknown") -> None:
        self.mentions.append({"text": text, "start": position[0], "end": position[1], "role": role})

    def to_dict(self) -> dict:
        return {
            "representative": self.representative,
            "mentions": self.mentions,
        }


class CoreferenceResolver:
    _PRONOUNS: dict[str, str] = {
        "he": "male", "him": "male", "his": "male", "himself": "male",
        "she": "female", "her": "female", "hers": "female", "herself": "female",
        "it": "neuter", "its": "neuter", "itself": "neuter",
        "they": "plural", "them": "plural", "their": "plural", "theirs": "plural",
        "themselves": "plural", "themself": "plural",
        "this": "demonstrative", "that": "demonstrative",
        "these": "demonstrative", "those": "demonstrative",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        chains = self.resolve(text)
        return {
            "chains": [c.to_dict() for c in chains],
            "pronouns_resolved": self._count_resolved(text, chains),
            "antecedents": self._find_antecedents(text),
        }

    def resolve(self, text: str) -> list[CoreferenceChain]:
        sentences = [s.strip() for s in re.split(r'[.!?]+', text) if s.strip()]
        chains: list[CoreferenceChain] = []
        resolved: dict[str, CoreferenceChain] = {}
        for sent in sentences:
            potential_antecedents = self._extract_nouns(sent)
            pronouns = self._extract_pronouns(sent)
            for pronoun in pronouns:
                antecedent = self._find_nearest_antecedent(
                    potential_antecedents, pronoun, sent
                )
                if antecedent:
                    chain = resolved.get(antecedent)
                    if not chain:
                        chain = CoreferenceChain(antecedent)
                        pos = text.find(antecedent)
                        if pos >= 0:
                            chain.add_mention(antecedent, (pos, pos + len(antecedent)), "antecedent")
                        resolved[antecedent] = chain
                        chains.append(chain)
                    pronoun_pos = text.find(pronoun, text.find(sent))
                    if pronoun_pos >= 0:
                        chain.add_mention(pronoun, (pronoun_pos, pronoun_pos + len(pronoun)), "anaphor")
        return chains

    def _extract_nouns(self, sentence: str) -> list[str]:
        nouns = re.findall(r'\b[A-Z][a-z]+\b', sentence)
        nouns += [w for w in re.findall(r'\b[a-z]+\b', sentence) if w not in self._PRONOUNS and len(w) > 3]
        return list(set(nouns))

    def _extract_pronouns(self, sentence: str) -> list[str]:
        return re.findall(r'\b(?:' + '|'.join(self._PRONOUNS.keys()) + r')\b', sentence, re.IGNORECASE)

    @staticmethod
    def _find_nearest_antecedent(antecedents: list[str], pronoun: str, sentence: str) -> str:
        pronoun_idx = sentence.lower().find(pronoun.lower())
        best: str | None = None
        best_dist = float("inf")
        for ant in antecedents:
            idx = sentence.lower().find(ant.lower())
            if 0 <= idx < pronoun_idx:
                dist = pronoun_idx - idx
                if dist < best_dist:
                    best_dist = dist
                    best = ant
        return best or (antecedents[0] if antecedents else "")

    def _count_resolved(self, text: str, chains: list[CoreferenceChain]) -> int:
        total = 0
        for chain in chains:
            resolved = [m for m in chain.mentions if m["role"] == "anaphor"]
            total += len(resolved)
        return total

    def _find_antecedents(self, text: str) -> list[str]:
        return list(set(re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text)))

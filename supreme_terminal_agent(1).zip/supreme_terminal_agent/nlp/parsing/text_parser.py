import re
from typing import Optional


class TextParser:
    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        self._preserve_case = self.config.get("preserve_case", False)

    def process(self, text: str, **kwargs) -> dict:
        preserve_case = kwargs.get("preserve_case", self._preserve_case)
        parsed = {
            "raw": text,
            "sentences": self.split_sentences(text),
            "paragraphs": self.split_paragraphs(text),
            "normalized": self.normalize(text, preserve_case),
            "metadata": self.extract_metadata(text),
        }
        return parsed

    def split_sentences(self, text: str) -> list[str]:
        text = text.strip()
        if not text:
            return []
        parts = re.split(r'(?<=[.!?])\s+', text)
        return [p.strip() for p in parts if p.strip()]

    def split_paragraphs(self, text: str) -> list[str]:
        text = text.strip()
        if not text:
            return []
        paragraphs = re.split(r'\n\s*\n', text)
        return [p.strip() for p in paragraphs if p.strip()]

    def normalize(self, text: str, preserve_case: bool = False) -> str:
        text = re.sub(r'\s+', ' ', text).strip()
        if not preserve_case:
            text = text.lower()
        return text

    def extract_metadata(self, text: str) -> dict:
        return {
            "char_count": len(text),
            "word_count": len(text.split()),
            "sentence_count": len(self.split_sentences(text)),
            "paragraph_count": len(self.split_paragraphs(text)),
            "has_code": bool(re.search(r'(def |class |import |function|var |let |const )', text)),
            "has_urls": bool(re.search(r'https?://\S+', text)),
            "has_email": bool(re.search(r'\S+@\S+\.\S+', text)),
            "has_numbers": bool(re.search(r'\d+', text)),
        }

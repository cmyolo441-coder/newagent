import re
from typing import Optional


class DiscourseRelation:
    def __init__(self, connective: str, relation: str, left: str, right: str):
        self.connective = connective
        self.relation = relation
        self.left = left
        self.right = right

    def to_dict(self) -> dict:
        return {
            "connective": self.connective,
            "relation": self.relation,
            "left": self.left,
            "right": self.right,
        }


class DiscourseParser:
    _CONNECTIVES: dict[str, str] = {
        "because": "cause",
        "since": "cause",
        "as": "cause",
        "due to": "cause",
        "therefore": "result",
        "thus": "result",
        "hence": "result",
        "so": "result",
        "consequently": "result",
        "as a result": "result",
        "if": "condition",
        "unless": "condition",
        "provided that": "condition",
        "although": "contrast",
        "though": "contrast",
        "even though": "contrast",
        "whereas": "contrast",
        "while": "contrast",
        "however": "contrast",
        "but": "contrast",
        "yet": "contrast",
        "nevertheless": "contrast",
        "nonetheless": "contrast",
        "and": "conjunction",
        "also": "conjunction",
        "furthermore": "conjunction",
        "moreover": "conjunction",
        "in addition": "conjunction",
        "first": "sequence",
        "second": "sequence",
        "third": "sequence",
        "then": "sequence",
        "next": "sequence",
        "finally": "sequence",
        "after": "sequence",
        "before": "sequence",
        "similarly": "comparison",
        "likewise": "comparison",
        "in contrast": "comparison",
        "on the other hand": "comparison",
        "for example": "elaboration",
        "for instance": "elaboration",
        "specifically": "elaboration",
        "in particular": "elaboration",
        "in other words": "elaboration",
        "that is": "elaboration",
    }

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}

    def process(self, text: str, **kwargs) -> dict:
        return {
            "relations": [r.to_dict() for r in self.extract_relations(text)],
            "discourse_graph": self._build_graph(text),
            "connectives_found": self._find_connectives(text),
        }

    def extract_relations(self, text: str) -> list[DiscourseRelation]:
        relations: list[DiscourseRelation] = []
        sorted_connectives = sorted(self._CONNECTIVES.keys(), key=len, reverse=True)
        for connective in sorted_connectives:
            pattern = re.compile(
                rf'(?:^|[.!?]\s*)?([^.!?]*?\b{re.escape(connective)}\b[^.!?]*)',
                re.IGNORECASE
            )
            for match in pattern.finditer(text):
                segment = match.group(1).strip()
                parts = re.split(rf'\b{re.escape(connective)}\b', segment, flags=re.IGNORECASE, maxsplit=1)
                if len(parts) == 2:
                    relations.append(DiscourseRelation(
                        connective=connective,
                        relation=self._CONNECTIVES[connective],
                        left=parts[0].strip().rstrip(","),
                        right=parts[1].strip().rstrip(","),
                    ))
        return relations

    def _find_connectives(self, text: str) -> dict[str, list[str]]:
        found: dict[str, list[str]] = {}
        for conn, rel in self._CONNECTIVES.items():
            if re.search(rf'\b{re.escape(conn)}\b', text, re.IGNORECASE):
                found.setdefault(rel, []).append(conn)
        return found

    def _build_graph(self, text: str) -> dict:
        relations = self.extract_relations(text)
        nodes: set[str] = set()
        edges: list[dict] = []
        for r in relations:
            nodes.add(r.left)
            nodes.add(r.right)
            edges.append({
                "source": r.left,
                "target": r.right,
                "label": r.relation,
                "connective": r.connective,
            })
        return {"nodes": list(nodes), "edges": edges}

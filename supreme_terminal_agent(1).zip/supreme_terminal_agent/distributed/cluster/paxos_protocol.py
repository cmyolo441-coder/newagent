"""Paxos Protocol - Paxos consensus algorithm."""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class PaxosProtocol:
    def __init__(self, node_id: str):
        self._node_id = node_id
        self._highest_promised: int = 0
        self._accepted_proposal: Optional[int] = None
        self._accepted_value: Any = None

    async def prepare(self, proposal_number: int) -> Dict[str, Any]:
        if proposal_number > self._highest_promised:
            self._highest_promised = proposal_number
            return {
                "promised": True,
                "last_accepted_proposal": self._accepted_proposal,
                "last_accepted_value": self._accepted_value,
            }
        return {"promised": False}

    async def accept(self, proposal_number: int, value: Any) -> Dict[str, Any]:
        if proposal_number >= self._highest_promised:
            self._highest_promised = proposal_number
            self._accepted_proposal = proposal_number
            self._accepted_value = value
            return {"accepted": True}
        return {"accepted": False}

    async def learn(self, value: Any) -> None:
        logger.debug(f"Paxos learned value: {value}")

    @property
    def accepted_value(self) -> Any:
        return self._accepted_value

    def __repr__(self) -> str:
        return f"<PaxosProtocol node='{self._node_id[:8]}' promised={self._highest_promised}>"

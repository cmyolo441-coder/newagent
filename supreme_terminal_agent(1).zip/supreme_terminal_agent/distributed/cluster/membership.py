"""Membership - Cluster membership management."""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class NodeMembership:
    def __init__(self, node_id: str, address: str = "", port: int = 0):
        self.node_id = node_id
        self.address = address
        self.port = port
        self.joined_at: float = time.time()
        self.last_seen: float = time.time()
        self.is_active: bool = True


class Membership:
    def __init__(self):
        self._local_id: Optional[str] = None
        self._members: Dict[str, NodeMembership] = {}
        self._suspicion_timeout: float = 30.0

    def set_local_id(self, node_id: str) -> None:
        self._local_id = node_id

    def add_node(self, node_id: str, address: str = "", port: int = 0) -> None:
        if node_id not in self._members:
            self._members[node_id] = NodeMembership(node_id, address, port)
            logger.info(f"Node joined: {node_id}")

    def remove_node(self, node_id: str) -> None:
        self._members.pop(node_id, None)
        logger.info(f"Node left: {node_id}")

    def mark_active(self, node_id: str) -> None:
        if node_id in self._members:
            self._members[node_id].is_active = True
            self._members[node_id].last_seen = time.time()

    def mark_inactive(self, node_id: str) -> None:
        if node_id in self._members:
            self._members[node_id].is_active = False

    def is_active(self, node_id: str) -> bool:
        member = self._members.get(node_id)
        if member is None:
            return False
        if not member.is_active:
            return False
        if time.time() - member.last_seen > self._suspicion_timeout:
            return False
        return True

    def get_active_nodes(self) -> List[str]:
        return [nid for nid in self._members if self.is_active(nid)]

    def get_all_nodes(self) -> List[str]:
        return list(self._members.keys())

    def get_member(self, node_id: str) -> Optional[NodeMembership]:
        return self._members.get(node_id)

    def clear(self) -> None:
        self._members.clear()

    @property
    def size(self) -> int:
        return len(self._members)

    def __repr__(self) -> str:
        return f"<Membership active={len(self.get_active_nodes())} total={self.size}>"

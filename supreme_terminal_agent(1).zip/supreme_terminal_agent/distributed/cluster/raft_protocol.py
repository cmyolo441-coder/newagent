"""Raft Protocol - Raft consensus algorithm implementation."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Callable, Dict, List, Optional

from distributed.cluster.leader_election import LeaderElection, LeaderState

logger = logging.getLogger(__name__)


class RaftProtocol:
    def __init__(self, node_id: str):
        self._node_id = node_id
        self._leader_election = LeaderElection(node_id)
        self._log: List[Dict[str, Any]] = []
        self._commit_index: int = -1
        self._last_applied: int = -1

    @property
    def leader_election(self) -> LeaderElection:
        return self._leader_election

    @property
    def is_leader(self) -> bool:
        return self._leader_election.is_leader

    async def request_vote(self, candidate_id: str, term: int, last_log_index: int, last_log_term: int) -> Dict[str, Any]:
        granted = self._leader_election.vote_for(candidate_id, term)
        return {"term": self._leader_election.term, "vote_granted": granted}

    async def append_entries(self, term: int, leader_id: str, entries: List[Dict[str, Any]]) -> Dict[str, Any]:
        if term >= self._leader_election.term:
            self._leader_election.become_follower(term, leader_id)
            self._log.extend(entries)
        return {"term": self._leader_election.term, "success": True}

    async def append_entry(self, entry: Dict[str, Any]) -> bool:
        if not self.is_leader:
            return False
        self._log.append(entry)
        return True

    @property
    def log(self) -> List[Dict[str, Any]]:
        return list(self._log)

    @property
    def last_log_index(self) -> int:
        return len(self._log) - 1

    @property
    def last_log_term(self) -> int:
        if self._log:
            return self._log[-1].get("term", 0)
        return 0

    def __repr__(self) -> str:
        return f"<RaftProtocol node='{self._node_id[:8]}' leader={self.is_leader} log={len(self._log)}>"

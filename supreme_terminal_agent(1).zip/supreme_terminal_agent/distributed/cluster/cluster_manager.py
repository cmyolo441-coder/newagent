"""Cluster Manager - Manages cluster of nodes."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from distributed.cluster.node_manager import NodeManager
from distributed.cluster.membership import Membership
from distributed.cluster.leader_election import LeaderElection

logger = logging.getLogger(__name__)


class ClusterManager:
    def __init__(self, node_id: str):
        self._node_id = node_id
        self._node_manager = NodeManager(node_id)
        self._membership = Membership()
        self._leader_election = LeaderElection(node_id)

    @property
    def node_manager(self) -> NodeManager:
        return self._node_manager

    @property
    def membership(self) -> Membership:
        return self._membership

    @property
    def leader_election(self) -> LeaderElection:
        return self._leader_election

    async def join(self, seed_nodes: List[str]) -> None:
        for seed in seed_nodes:
            self._membership.add_node(seed)
        self._membership.set_local_id(self._node_id)
        logger.info(f"Cluster joined: {self._node_id}")

    async def leave(self) -> None:
        logger.info(f"Cluster left: {self._node_id}")

    @property
    def is_leader(self) -> bool:
        return self._leader_election.is_leader

    def get_nodes(self) -> List[str]:
        return self._membership.get_active_nodes()

    def __repr__(self) -> str:
        return f"<ClusterManager node='{self._node_id[:8]}' leader={self.is_leader}>"

"""Gossip Protocol - Gossip-based communication protocol."""

from __future__ import annotations

import asyncio
import logging
import random
import time
import uuid
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class GossipProtocol:
    def __init__(self, node_id: str, fanout: int = 3, interval: float = 1.0):
        self._node_id = node_id
        self._fanout = fanout
        self._interval = interval
        self._peers: Set[str] = set()
        self._messages: List[Dict[str, Any]] = []
        self._seen: Set[str] = set()

    def add_peer(self, peer_id: str) -> None:
        self._peers.add(peer_id)

    def remove_peer(self, peer_id: str) -> None:
        self._peers.discard(peer_id)

    def gossip(self, message: Dict[str, Any]) -> None:
        msg_id = str(uuid.uuid4())
        message["_id"] = msg_id
        message["_source"] = self._node_id
        message["_timestamp"] = time.time()
        self._messages.append(message)
        self._seen.add(msg_id)

    def select_peers(self) -> List[str]:
        candidates = [p for p in self._peers if p != self._node_id]
        if len(candidates) <= self._fanout:
            return candidates
        return random.sample(candidates, self._fanout)

    def receive(self, message: Dict[str, Any]) -> None:
        msg_id = message.get("_id", "")
        if msg_id not in self._seen:
            self._seen.add(msg_id)
            self._messages.append(message)

    @property
    def peers(self) -> Set[str]:
        return set(self._peers)

    @property
    def message_count(self) -> int:
        return len(self._messages)

    def clear(self) -> None:
        self._messages.clear()
        self._seen.clear()

    def __repr__(self) -> str:
        return f"<GossipProtocol node='{self._node_id[:8]}' peers={len(self._peers)}>"

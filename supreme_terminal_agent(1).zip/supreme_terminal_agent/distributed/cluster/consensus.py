"""Consensus - Distributed consensus abstraction."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class Consensus:
    def __init__(self, node_id: str):
        self._node_id = node_id
        self._committed: List[Dict[str, Any]] = []

    async def propose(self, value: Any) -> bool:
        logger.debug(f"Consensus propose: {value}")
        return True

    async def commit(self, entry: Dict[str, Any]) -> None:
        self._committed.append(entry)
        logger.debug(f"Consensus commit: {entry}")

    def get_committed(self) -> List[Dict[str, Any]]:
        return list(self._committed)

    def get_last_committed(self) -> Optional[Dict[str, Any]]:
        return self._committed[-1] if self._committed else None

    def __repr__(self) -> str:
        return f"<Consensus committed={len(self._committed)}>"

"""Node Manager - Manages individual cluster node."""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class NodeInfo:
    def __init__(self, node_id: str):
        self.node_id = node_id
        self.address: Optional[str] = None
        self.port: int = 0
        self.status: str = "unknown"
        self.last_heartbeat: float = time.time()
        self.tags: List[str] = []


class NodeManager:
    def __init__(self, node_id: str):
        self._node_id = node_id
        self._local_info = NodeInfo(node_id)

    @property
    def node_id(self) -> str:
        return self._node_id

    @property
    def local_info(self) -> NodeInfo:
        return self._local_info

    def set_address(self, address: str, port: int) -> None:
        self._local_info.address = address
        self._local_info.port = port

    def heartbeat(self) -> None:
        self._local_info.last_heartbeat = time.time()

    @property
    def is_alive(self) -> bool:
        return time.time() - self._local_info.last_heartbeat < 30

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self._node_id,
            "address": self._local_info.address,
            "port": self._local_info.port,
            "status": self._local_info.status,
            "last_heartbeat": self._local_info.last_heartbeat,
        }

    def __repr__(self) -> str:
        return f"<NodeManager id='{self._node_id[:8]}'>"

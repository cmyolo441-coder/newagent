"""Leader Election - Elects a leader among cluster nodes."""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class LeaderState(Enum):
    FOLLOWER = "follower"
    CANDIDATE = "candidate"
    LEADER = "leader"


class LeaderElection:
    def __init__(self, node_id: str):
        self._node_id = node_id
        self._state = LeaderState.FOLLOWER
        self._leader_id: Optional[str] = None
        self._term: int = 0
        self._votes_received: int = 0

    @property
    def state(self) -> LeaderState:
        return self._state

    @property
    def is_leader(self) -> bool:
        return self._state == LeaderState.LEADER

    @property
    def leader_id(self) -> Optional[str]:
        return self._leader_id

    @property
    def term(self) -> int:
        return self._term

    def become_follower(self, term: int, leader_id: Optional[str] = None) -> None:
        self._state = LeaderState.FOLLOWER
        self._term = term
        self._leader_id = leader_id
        self._votes_received = 0

    def become_candidate(self) -> None:
        self._state = LeaderState.CANDIDATE
        self._term += 1
        self._leader_id = None
        self._votes_received = 1

    def become_leader(self) -> None:
        self._state = LeaderState.LEADER
        self._leader_id = self._node_id

    def vote_for(self, candidate_id: str, term: int) -> bool:
        if term > self._term:
            self.become_follower(term)
            return True
        return False

    def receive_vote(self) -> int:
        self._votes_received += 1
        return self._votes_received

    @property
    def votes_received(self) -> int:
        return self._votes_received

    def __repr__(self) -> str:
        return f"<LeaderElection state={self._state.value} term={self._term}>"

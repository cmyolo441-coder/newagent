"""Distributed Counter - Distributed atomic counter."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class DistributedCounter:
    def __init__(self, name: str, initial: int = 0):
        self._name = name
        self._value = initial

    async def increment(self, amount: int = 1) -> int:
        self._value += amount
        return self._value

    async def decrement(self, amount: int = 1) -> int:
        self._value -= amount
        return self._value

    async def get(self) -> int:
        return self._value

    async def reset(self, value: int = 0) -> None:
        self._value = value

    @property
    def name(self) -> str:
        return self._name

    @property
    def value(self) -> int:
        return self._value

    def __repr__(self) -> str:
        return f"<DistributedCounter name='{self._name}' value={self._value}>"

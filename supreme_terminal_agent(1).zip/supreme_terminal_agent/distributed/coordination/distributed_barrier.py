"""Distributed Barrier - Distributed barrier synchronization."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, List, Optional, Set

logger = logging.getLogger(__name__)


class DistributedBarrier:
    def __init__(self, name: str, parties: int, timeout: float = 30.0):
        self._name = name
        self._parties = parties
        self._timeout = timeout
        self._waiting: Set[str] = set()

    async def wait(self, participant_id: str) -> bool:
        self._waiting.add(participant_id)
        deadline = time.time() + self._timeout
        while time.time() < deadline:
            if len(self._waiting) >= self._parties:
                self._waiting.clear()
                return True
            await asyncio.sleep(0.1)
        self._waiting.discard(participant_id)
        return False

    @property
    def name(self) -> str:
        return self._name

    @property
    def parties(self) -> int:
        return self._parties

    @property
    def waiting(self) -> int:
        return len(self._waiting)

    def reset(self) -> None:
        self._waiting.clear()

    def __repr__(self) -> str:
        return f"<DistributedBarrier name='{self._name}' waiting={self.waiting}/{self._parties}>"

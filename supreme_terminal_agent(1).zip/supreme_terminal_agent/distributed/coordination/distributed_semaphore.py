"""Distributed Semaphore - Distributed semaphore."""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class DistributedSemaphore:
    def __init__(self, name: str, max_count: int = 5):
        self._name = name
        self._max_count = max_count
        self._count = max_count
        self._holders: Dict[str, float] = {}

    async def acquire(self, timeout: float = 10.0) -> bool:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._count > 0:
                holder_id = str(uuid.uuid4())
                self._holders[holder_id] = time.time() + 30
                self._count -= 1
                return True
            await asyncio.sleep(0.1)
        return False

    async def release(self, holder_id: str) -> None:
        if holder_id in self._holders:
            del self._holders[holder_id]
            self._count += 1

    @property
    def name(self) -> str:
        return self._name

    @property
    def available(self) -> int:
        return self._count

    @property
    def max_count(self) -> int:
        return self._max_count

    def __repr__(self) -> str:
        return f"<DistributedSemaphore name='{self._name}' available={self.available}/{self._max_count}>"

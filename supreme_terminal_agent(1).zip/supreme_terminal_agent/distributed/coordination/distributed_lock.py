"""Distributed Lock - Distributed lock implementation."""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class DistributedLock:
    def __init__(self, name: str, timeout: float = 30.0):
        self._name = name
        self._timeout = timeout
        self._owner: Optional[str] = None
        self._expires_at: float = 0.0

    async def acquire(self, blocking: bool = True) -> bool:
        if self._owner is not None and time.time() < self._expires_at:
            if not blocking:
                return False
            while self._owner is not None and time.time() < self._expires_at:
                await asyncio.sleep(0.1)
        self._owner = str(uuid.uuid4())
        self._expires_at = time.time() + self._timeout
        return True

    async def release(self) -> None:
        self._owner = None
        self._expires_at = 0.0

    @property
    def name(self) -> str:
        return self._name

    @property
    def locked(self) -> bool:
        return self._owner is not None and time.time() < self._expires_at

    @property
    def owner(self) -> Optional[str]:
        return self._owner

    async def __aenter__(self):
        await self.acquire()
        return self

    async def __aexit__(self, *args) -> None:
        await self.release()

    def __repr__(self) -> str:
        return f"<DistributedLock name='{self._name}' locked={self.locked}>"

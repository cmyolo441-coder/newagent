"""Service Registry - Registry for distributed services."""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ServiceInstance:
    def __init__(self, service_id: str, address: str, port: int):
        self.service_id = service_id
        self.address = address
        self.port = port
        self.healthy: bool = True
        self.last_heartbeat: float = time.time()
        self.metadata: Dict[str, Any] = {}


class ServiceRegistry:
    def __init__(self):
        self._services: Dict[str, List[ServiceInstance]] = {}

    def register(self, service_name: str, instance: ServiceInstance) -> None:
        if service_name not in self._services:
            self._services[service_name] = []
        self._services[service_name].append(instance)
        logger.info(f"Registered {service_name} instance {instance.service_id}")

    def unregister(self, service_name: str, instance_id: str) -> None:
        if service_name in self._services:
            self._services[service_name] = [
                i for i in self._services[service_name]
                if i.service_id != instance_id
            ]

    def discover(self, service_name: str) -> List[ServiceInstance]:
        instances = self._services.get(service_name, [])
        return [i for i in instances if i.healthy]

    def get_all_services(self) -> Dict[str, List[ServiceInstance]]:
        return dict(self._services)

    def heartbeat(self, service_name: str, instance_id: str) -> bool:
        instances = self._services.get(service_name, [])
        for inst in instances:
            if inst.service_id == instance_id:
                inst.last_heartbeat = time.time()
                inst.healthy = True
                return True
        return False

    def check_health(self, timeout: float = 30.0) -> None:
        now = time.time()
        for instances in self._services.values():
            for inst in instances:
                if now - inst.last_heartbeat > timeout:
                    inst.healthy = False

    def clear(self) -> None:
        self._services.clear()

    def __repr__(self) -> str:
        return f"<ServiceRegistry services={len(self._services)}>"

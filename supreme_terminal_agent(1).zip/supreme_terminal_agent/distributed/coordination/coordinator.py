"""Coordinator - Distributed coordinator."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class Coordinator:
    def __init__(self, coordinator_id: str):
        self._coordinator_id = coordinator_id
        self._participants: Dict[str, Any] = {}
        self._running = False

    async def start(self) -> None:
        self._running = True
        logger.info(f"Coordinator '{self._coordinator_id}' started")

    async def stop(self) -> None:
        self._running = False
        logger.info(f"Coordinator '{self._coordinator_id}' stopped")

    def register_participant(self, participant_id: str, participant: Any) -> None:
        self._participants[participant_id] = participant

    def unregister_participant(self, participant_id: str) -> None:
        self._participants.pop(participant_id, None)

    async def coordinate(self, action: str, *args, **kwargs) -> Dict[str, Any]:
        results = {}
        for pid, participant in self._participants.items():
            try:
                fn = getattr(participant, action, None)
                if fn:
                    result = fn(*args, **kwargs)
                    if hasattr(result, "__await__"):
                        result = await result
                    results[pid] = result
            except Exception as e:
                results[pid] = {"error": str(e)}
        return results

    def get_participants(self) -> List[str]:
        return list(self._participants.keys())

    def __repr__(self) -> str:
        return f"<Coordinator id='{self._coordinator_id[:8]}' participants={len(self._participants)}>"

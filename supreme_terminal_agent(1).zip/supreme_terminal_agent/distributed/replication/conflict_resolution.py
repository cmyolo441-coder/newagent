"""Conflict Resolution - Resolves conflicts in replicated data."""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class ConflictResolution:
    def __init__(self):
        self._resolvers: Dict[str, Any] = {}

    def register_resolver(self, key: str, resolver: Any) -> None:
        self._resolvers[key] = resolver

    def unregister_resolver(self, key: str) -> None:
        self._resolvers.pop(key, None)

    def last_write_wins(self, versions: List[Tuple[Any, float]]) -> Any:
        return max(versions, key=lambda v: v[1])[0]

    def merge(self, key: str, values: List[Any]) -> Any:
        resolver = self._resolvers.get(key)
        if resolver:
            return resolver(values)
        return values[-1] if values else None

    def detect_conflict(self, versions: Dict[str, Tuple[Any, float]]) -> bool:
        if len(versions) < 2:
            return False
        values = set(str(v[0]) for v in versions.values())
        return len(values) > 1

    @staticmethod
    def timestamp_compare(a: Tuple[Any, float], b: Tuple[Any, float]) -> int:
        if a[1] > b[1]:
            return 1
        elif a[1] < b[1]:
            return -1
        return 0

    def __repr__(self) -> str:
        return f"<ConflictResolution resolvers={len(self._resolvers)}>"

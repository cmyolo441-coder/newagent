"""Chain Replication - Chain-based replication protocol."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ChainReplication:
    def __init__(self, node_id: str):
        self._node_id = node_id
        self._chain: List[str] = []
        self._data: Dict[str, Any] = {}

    def set_chain(self, chain: List[str]) -> None:
        self._chain = list(chain)

    def get_position(self) -> Optional[int]:
        if self._node_id in self._chain:
            return self._chain.index(self._node_id)
        return None

    @property
    def is_head(self) -> bool:
        return self.get_position() == 0

    @property
    def is_tail(self) -> bool:
        return self.get_position() == len(self._chain) - 1

    async def write(self, key: str, value: Any) -> bool:
        if not self.is_head:
            return False
        self._data[key] = value
        return True

    async def read(self, key: str) -> Any:
        if not self.is_tail:
            return None
        return self._data.get(key)

    async def propagate(self, key: str, value: Any) -> None:
        self._data[key] = value

    @property
    def chain(self) -> List[str]:
        return list(self._chain)

    def __repr__(self) -> str:
        pos = self.get_position()
        return f"<ChainReplication node='{self._node_id[:8]}' pos={pos}>"

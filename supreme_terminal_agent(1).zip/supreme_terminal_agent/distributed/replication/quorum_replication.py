"""Quorum Replication - Quorum-based replication."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class QuorumReplication:
    def __init__(self, node_id: str, total_nodes: int = 3):
        self._node_id = node_id
        self._total_nodes = total_nodes
        self._write_quorum = total_nodes // 2 + 1
        self._read_quorum = total_nodes // 2 + 1
        self._data: Dict[str, Any] = {}

    @property
    def write_quorum(self) -> int:
        return self._write_quorum

    @property
    def read_quorum(self) -> int:
        return self._read_quorum

    async def write(self, key: str, value: Any) -> bool:
        self._data[key] = value
        return True

    async def read(self, key: str) -> Any:
        return self._data.get(key)

    def has_data(self, key: str) -> bool:
        return key in self._data

    def __repr__(self) -> str:
        return f"<QuorumReplication node='{self._node_id[:8]}' write_q={self._write_quorum} read_q={self._read_quorum}>"

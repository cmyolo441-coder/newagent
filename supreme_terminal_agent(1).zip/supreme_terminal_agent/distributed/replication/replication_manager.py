"""Replication Manager - Manages data replication."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class ReplicationManager:
    def __init__(self, node_id: str):
        self._node_id = node_id
        self._replicas: Dict[str, Any] = {}
        self._sync_interval: float = 1.0
        self._running = False

    def add_replica(self, replica_id: str, replica: Any) -> None:
        self._replicas[replica_id] = replica

    def remove_replica(self, replica_id: str) -> None:
        self._replicas.pop(replica_id, None)

    async def replicate(self, data: Any) -> Dict[str, Any]:
        results = {}
        for rid, replica in self._replicas.items():
            try:
                result = replica.replicate(data)
                if hasattr(result, "__await__"):
                    result = await result
                results[rid] = result
            except Exception as e:
                results[rid] = {"error": str(e)}
        return results

    async def start_sync(self) -> None:
        self._running = True
        logger.info("Replication sync started")

    async def stop_sync(self) -> None:
        self._running = False
        logger.info("Replication sync stopped")

    def get_replicas(self) -> List[str]:
        return list(self._replicas.keys())

    def __repr__(self) -> str:
        return f"<ReplicationManager replicas={len(self._replicas)}>"

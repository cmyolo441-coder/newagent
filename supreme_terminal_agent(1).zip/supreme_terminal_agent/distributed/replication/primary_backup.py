"""Primary-Backup replication protocol."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class PrimaryBackup:
    def __init__(self, node_id: str, is_primary: bool = False):
        self._node_id = node_id
        self._is_primary = is_primary
        self._backups: List[str] = []
        self._data: Dict[str, Any] = {}

    def set_primary(self, is_primary: bool) -> None:
        self._is_primary = is_primary

    def add_backup(self, backup_id: str) -> None:
        if backup_id not in self._backups:
            self._backups.append(backup_id)

    def remove_backup(self, backup_id: str) -> None:
        if backup_id in self._backups:
            self._backups.remove(backup_id)

    async def write(self, key: str, value: Any) -> bool:
        if not self._is_primary:
            return False
        self._data[key] = value
        return True

    async def read(self, key: str) -> Any:
        return self._data.get(key)

    async def replicate(self, data: Dict[str, Any]) -> None:
        self._data.update(data)

    async def failover(self) -> Optional[str]:
        if self._backups:
            new_primary = self._backups[0]
            logger.info(f"Failing over to {new_primary}")
            return new_primary
        return None

    @property
    def is_primary(self) -> bool:
        return self._is_primary

    @property
    def backups(self) -> List[str]:
        return list(self._backups)

    def __repr__(self) -> str:
        return f"<PrimaryBackup node='{self._node_id[:8]}' primary={self._is_primary}>"

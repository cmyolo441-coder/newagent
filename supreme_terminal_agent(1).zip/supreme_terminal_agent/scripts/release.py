"""
Release script - tags a new version and publishes to PyPI.
"""
import sys
import subprocess
import argparse
import re
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _read_version():
    version_file = PROJECT_ROOT / "version.py"
    match = re.search(r"VERSION\s*=\s*['\"]([^'\"]+)['\"]", version_file.read_text())
    return match.group(1) if match else "0.0.0"


def _write_version(new_version: str):
    version_file = PROJECT_ROOT / "version.py"
    content = version_file.read_text()
    content = re.sub(r"VERSION\s*=\s*['\"][^'\"]+['\"]", f"VERSION = '{new_version}'", content)
    version_file.write_text(content)


def release(version: str | None = None, bump: str | None = None,
            dry_run: bool = False, push: bool = True):
    current = _read_version()

    if bump:
        parts = [int(x) for x in current.split(".")]
        if bump == "major":
            parts = [parts[0] + 1, 0, 0]
        elif bump == "minor":
            parts = [parts[0], parts[1] + 1, 0]
        elif bump == "patch":
            parts = [parts[0], parts[1], parts[2] + 1]
        version = ".".join(str(p) for p in parts)

    if not version:
        print(f"Current version: {current}. Use --bump or --version.")
        sys.exit(1)

    if dry_run:
        print(f"Would release version {version} (current: {current})")
        return

    _write_version(version)
    subprocess.check_call(["git", "add", "version.py"], cwd=str(PROJECT_ROOT))
    subprocess.check_call(["git", "commit", "-m", f"Release v{version}"], cwd=str(PROJECT_ROOT))
    subprocess.check_call(["git", "tag", "-a", f"v{version}", "-m", f"Release v{version}"],
                          cwd=str(PROJECT_ROOT))
    if push:
        subprocess.check_call(["git", "push", "origin", "main", "--tags"], cwd=str(PROJECT_ROOT))
    print(f"Released version {version}")


def main():
    parser = argparse.ArgumentParser(description="Create a new release")
    parser.add_argument("--version", help="Explicit version string")
    parser.add_argument("--bump", choices=["major", "minor", "patch"], help="Bump component")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be done")
    parser.add_argument("--no-push", action="store_false", dest="push", help="Skip git push")
    args = parser.parse_args()
    release(version=args.version, bump=args.bump, dry_run=args.dry_run, push=args.push)


if __name__ == "__main__":
    main()

"""
Package script - creates a deployable package tarball/zip with all assets.
"""
import sys
import tarfile
import argparse
import zipfile
from pathlib import Path
from datetime import datetime


PROJECT_ROOT = Path(__file__).resolve().parents[2]
VERSION_FILE = PROJECT_ROOT / "version.py"


def _get_version():
    ns = {}
    exec(VERSION_FILE.read_text(), ns)
    return ns.get("VERSION", "0.0.0")


def package(format: str = "tar.gz", output: str | None = None, include_data: bool = False):
    version = _get_version()
    dist_dir = PROJECT_ROOT / "dist"
    dist_dir.mkdir(parents=True, exist_ok=True)

    stem = output or f"supreme-terminal-agent-{version}"
    includes = ["supreme_terminal_agent", "main.py", "bootstrap.py", "launcher.py",
                "daemon.py", "config.py", "settings.py", "constants.py", "version.py",
                "setup.py", "pyproject.toml", "requirements.txt", "Makefile",
                "Dockerfile", "docker-compose.yml", ".env.example"]
    if include_data:
        includes.append("data")

    if format == "zip":
        path = dist_dir / f"{stem}.zip"
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            for name in includes:
                p = PROJECT_ROOT / name
                if p.exists():
                    if p.is_dir():
                        for f in p.rglob("*"):
                            zf.write(f, f.relative_to(PROJECT_ROOT))
                    else:
                        zf.write(p, name)
    else:
        path = dist_dir / f"{stem}.tar.gz"
        with tarfile.open(path, "w:gz") as tf:
            for name in includes:
                p = PROJECT_ROOT / name
                if p.exists():
                    tf.add(p, arcname=name)

    print(f"Package created: {path}")


def main():
    parser = argparse.ArgumentParser(description="Package Supreme Terminal Agent")
    parser.add_argument("--format", choices=["tar.gz", "zip"], default="tar.gz", help="Archive format")
    parser.add_argument("--output", help="Output filename stem (without extension)")
    parser.add_argument("--include-data", action="store_true", help="Include data directory")
    args = parser.parse_args()
    package(format=args.format, output=args.output, include_data=args.include_data)


if __name__ == "__main__":
    main()

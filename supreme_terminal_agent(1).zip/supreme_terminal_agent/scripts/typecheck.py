"""
Type check script - runs mypy static type checker.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def typecheck(strict: bool = False, path: str | None = None, ignore_missing: bool = False):
    cmd = [sys.executable, "-m", "mypy"]
    if strict:
        cmd.append("--strict")
    if ignore_missing:
        cmd.append("--ignore-missing-imports")
    target = path or str(PROJECT_ROOT / "supreme_terminal_agent")
    cmd.append(target)
    result = subprocess.run(cmd)
    sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description="Run type checker")
    parser.add_argument("--strict", action="store_true", help="Enable strict mode")
    parser.add_argument("--path", help="Specific path to check")
    parser.add_argument("--ignore-missing-imports", action="store_true", help="Ignore missing imports")
    args = parser.parse_args()
    typecheck(strict=args.strict, path=args.path, ignore_missing=args.ignore_missing_imports)


if __name__ == "__main__":
    main()

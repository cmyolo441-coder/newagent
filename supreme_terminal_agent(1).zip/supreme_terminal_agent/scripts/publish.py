"""
Publish script - uploads the package to PyPI.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def publish(repository: str = "pypi", token: str | None = None, dry_run: bool = False):
    dist_dir = PROJECT_ROOT / "dist"
    if not list(dist_dir.glob("*.whl")) and not list(dist_dir.glob("*.tar.gz")):
        print("No distributions found in dist/. Run build.py first.")
        sys.exit(1)

    cmd = [sys.executable, "-m", "twine", "upload"]
    if repository != "pypi":
        cmd.extend(["--repository", repository])
    if token:
        cmd.extend(["-p", token])
    if dry_run:
        cmd.append("--skip-existing")
        print(f"Would run: {' '.join(cmd)} {str(dist_dir)}/*")
        return
    cmd.append(str(dist_dir / "*"))
    subprocess.check_call(cmd)
    print("Publication complete.")


def main():
    parser = argparse.ArgumentParser(description="Publish to PyPI")
    parser.add_argument("--repository", default="pypi", help="PyPI repository (pypi, testpypi, etc.)")
    parser.add_argument("--token", help="PyPI API token")
    parser.add_argument("--dry-run", action="store_true", help="Simulate without uploading")
    args = parser.parse_args()
    publish(repository=args.repository, token=args.token, dry_run=args.dry_run)


if __name__ == "__main__":
    main()

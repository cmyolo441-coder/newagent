"""
Uninstall script - removes the Supreme Terminal Agent package.
"""
import sys
import subprocess
import argparse


def uninstall(confirm: bool = True, purge: bool = False):
    package = "supreme-terminal-agent"
    if confirm:
        response = input(f"Uninstall {package}? [y/N]: ")
        if response.lower() != "y":
            print("Aborted.")
            return
    subprocess.check_call([sys.executable, "-m", "pip", "uninstall", package, "-y"])
    if purge:
        import shutil
        from pathlib import Path
        data_dir = Path.home() / ".supreme-terminal-agent"
        if data_dir.exists():
            shutil.rmtree(data_dir)
            print(f"Removed {data_dir}")
    print("Uninstall complete.")


def main():
    parser = argparse.ArgumentParser(description="Uninstall Supreme Terminal Agent")
    parser.add_argument("-y", "--yes", action="store_true", help="Skip confirmation prompt")
    parser.add_argument("--purge", action="store_true", help="Remove all data and config files")
    args = parser.parse_args()
    uninstall(confirm=not args.yes, purge=args.purge)


if __name__ == "__main__":
    main()

"""
Cleanup script - removes temporary files, caches, and build artifacts.
"""
import sys
import shutil
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


_CLEANUP_PATTERNS = [
    "__pycache__",
    ".pyc",
    ".pyo",
    ".egg-info",
    ".eggs",
    "build",
    "dist",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "*.so",
    ".coverage",
]


def cleanup(dry_run: bool = False, aggressive: bool = False):
    removed_count = 0
    removed_size = 0

    for pattern in _CLEANUP_PATTERNS:
        for p in PROJECT_ROOT.rglob(pattern):
            if p.is_dir() and pattern in ("__pycache__", ".eggs", "build", "dist",
                                           ".mypy_cache", ".pytest_cache", ".ruff_cache"):
                size = sum(f.stat().st_size for f in p.rglob("*") if f.is_file()) if not dry_run else 0
                if dry_run:
                    print(f"Would remove {p.relative_to(PROJECT_ROOT)}")
                else:
                    shutil.rmtree(p)
                    print(f"Removed {p.relative_to(PROJECT_ROOT)}")
                removed_count += 1
                removed_size += size
            elif p.is_file() and p.suffix in (".pyc", ".pyo", ".so"):
                size = p.stat().st_size if not dry_run else 0
                if dry_run:
                    print(f"Would remove {p.relative_to(PROJECT_ROOT)}")
                else:
                    p.unlink()
                    print(f"Removed {p.relative_to(PROJECT_ROOT)}")
                removed_count += 1
                removed_size += size

    if aggressive and not dry_run:
        cache_dir = PROJECT_ROOT / "supreme_terminal_agent" / "cache"
        if cache_dir.exists():
            shutil.rmtree(cache_dir)
            cache_dir.mkdir(parents=True, exist_ok=True)
            print("Cleared cache directory")

    if dry_run:
        print(f"Would remove {removed_count} items")
    else:
        print(f"Removed {removed_count} items ({removed_size / 1024:.1f} KB freed)")


def main():
    parser = argparse.ArgumentParser(description="Clean up temporary files")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be removed")
    parser.add_argument("--aggressive", action="store_true", help="Also clear cache directory")
    args = parser.parse_args()
    cleanup(dry_run=args.dry_run, aggressive=args.aggressive)


if __name__ == "__main__":
    main()

"""
Rotate encryption keys - generates new keys and re-encrypts data.
"""
import sys
import json
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
KEYS_DIR = PROJECT_ROOT / "supreme_terminal_agent" / "security" / "keys"


def rotate_keys(output_dir: str | None = None, algorithm: str = "Fernet"):
    key_dir = Path(output_dir) if output_dir else KEYS_DIR
    key_dir.mkdir(parents=True, exist_ok=True)

    if algorithm == "Fernet":
        from cryptography.fernet import Fernet
        new_key = Fernet.generate_key()
        ext = ".key"
    elif algorithm == "AES":
        import os
        new_key = os.urandom(32)
        ext = ".aes"
    else:
        print(f"Unsupported algorithm: {algorithm}")
        sys.exit(1)

    key_file = key_dir / f"encryption_key{ext}"
    with open(key_file, "wb") as f:
        f.write(new_key)

    metadata = {"algorithm": algorithm, "rotated_at": str(__import__("datetime").datetime.utcnow()),
                "key_file": str(key_file)}
    meta_file = key_dir / "key_metadata.json"
    with open(meta_file, "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"New key generated: {key_file}")
    print(f"Metadata: {meta_file}")

    old_keys = sorted(key_dir.glob("*.key*"), key=lambda p: p.stat().st_mtime, reverse=True)
    if len(old_keys) > 3:
        print(f"Keeping last 3 keys, removing {len(old_keys) - 3} old ones...")


def main():
    parser = argparse.ArgumentParser(description="Rotate encryption keys")
    parser.add_argument("--output-dir", help="Output directory for keys")
    parser.add_argument("--algorithm", choices=["Fernet", "AES"], default="Fernet",
                        help="Encryption algorithm")
    args = parser.parse_args()
    rotate_keys(output_dir=args.output_dir, algorithm=args.algorithm)


if __name__ == "__main__":
    main()

"""
Initialize the database - creates tables and indexes.
"""
import sys
import asyncio
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


async def init_db(db_url: str | None = None, force: bool = False, seed: bool = False):
    from database.connection import DatabaseConnection
    from database.migrations import run_migrations

    db = DatabaseConnection(db_url or "sqlite+aiosqlite:///data/agent.db")
    await db.connect()

    if force:
        await db.execute("DROP TABLE IF EXISTS migrations CASCADE")
        print("Dropped existing tables (force mode)")

    await run_migrations(db)
    print("Database migrations applied.")

    if seed:
        from database.seeds import run_seeds
        await run_seeds(db)
        print("Seed data inserted.")

    await db.disconnect()
    print("Database initialization complete.")


def init_db_sync(db_url: str | None = None, force: bool = False, seed: bool = False):
    asyncio.run(init_db(db_url=db_url, force=force, seed=seed))


def main():
    parser = argparse.ArgumentParser(description="Initialize database")
    parser.add_argument("--db-url", help="Database connection URL")
    parser.add_argument("--force", action="store_true", help="Drop existing tables first")
    parser.add_argument("--seed", action="store_true", help="Insert seed data")
    args = parser.parse_args()
    init_db_sync(db_url=args.db_url, force=args.force, seed=args.seed)


if __name__ == "__main__":
    main()

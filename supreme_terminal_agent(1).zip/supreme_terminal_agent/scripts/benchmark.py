"""
Benchmark script - runs performance benchmarks.
"""
import sys
import subprocess
import argparse
import json
from pathlib import Path
from datetime import datetime


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def benchmark(output: str | None = None, suite: str | None = None, iterations: int = 5):
    benchmarks_dir = PROJECT_ROOT / "supreme_terminal_agent" / "benchmarks"
    results = {}

    suites = [suite] if suite else [d.name for d in benchmarks_dir.iterdir()
                                     if d.is_dir() and not d.name.startswith("_")]
    for s in suites:
        suite_file = benchmarks_dir / s / "benchmark.py"
        if not suite_file.exists():
            print(f"Benchmark suite not found: {s}")
            continue
        print(f"Running benchmark suite: {s}")
        result = subprocess.run(
            [sys.executable, str(suite_file), "--iterations", str(iterations)],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT)
        )
        results[s] = {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}

    if output:
        output_path = Path(output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(results, indent=2))
        print(f"Results written to {output_path}")
    else:
        for suite, data in results.items():
            print(f"\n=== {suite} ===")
            print(data["stdout"])


def main():
    parser = argparse.ArgumentParser(description="Run benchmarks")
    parser.add_argument("--suite", help="Specific benchmark suite to run")
    parser.add_argument("--iterations", type=int, default=5, help="Number of iterations")
    parser.add_argument("--output", help="JSON output file for results")
    args = parser.parse_args()
    benchmark(output=args.output, suite=args.suite, iterations=args.iterations)


if __name__ == "__main__":
    main()

"""
Test runner - runs the project test suite.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def run_tests(coverage: bool = False, verbose: bool = False, match: str | None = None,
              num_processes: int | None = None, markers: str | None = None):
    cmd = [sys.executable, "-m", "pytest"]
    if verbose:
        cmd.append("-v")
    if coverage:
        cmd.extend(["--cov=supreme_terminal_agent", "--cov-report=term-missing"])
    if match:
        cmd.extend(["-k", match])
    if num_processes:
        cmd.extend(["-n", str(num_processes)])
    if markers:
        cmd.extend(["-m", markers])
    cmd.append(str(PROJECT_ROOT / "tests"))
    result = subprocess.run(cmd)
    sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description="Run tests")
    parser.add_argument("--coverage", action="store_true", help="Run with coverage report")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    parser.add_argument("-k", "--match", help="Only run tests matching the given expression")
    parser.add_argument("-n", "--num-processes", type=int, help="Number of parallel processes")
    parser.add_argument("-m", "--markers", help="Only run tests with given markers")
    args = parser.parse_args()
    run_tests(coverage=args.coverage, verbose=args.verbose, match=args.match,
              num_processes=args.num_processes, markers=args.markers)


if __name__ == "__main__":
    main()

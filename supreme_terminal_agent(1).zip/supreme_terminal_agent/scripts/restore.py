"""
Restore script - restores data from a previously created backup.
"""
import sys
import tarfile
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
BACKUP_DIR = PROJECT_ROOT / "data" / "backups"


def restore(backup_file: str, force: bool = False):
    path = Path(backup_file)
    if not path.exists():
        path = BACKUP_DIR / backup_file
    if not path.exists():
        print(f"Backup file not found: {backup_file}")
        sys.exit(1)

    if not force:
        response = input(f"Restore from {path}? This will overwrite existing data. [y/N]: ")
        if response.lower() != "y":
            print("Aborted.")
            return

    with tarfile.open(path, "r:*") as tf:
        members = tf.getmembers()
        for member in members:
            target = PROJECT_ROOT / member.name
            if target.exists() and not force:
                print(f"Overwriting {target}")
        tf.extractall(path=PROJECT_ROOT)
    print(f"Restored from {path}")


def list_backups():
    backups = sorted(BACKUP_DIR.glob("backup_*"))
    if not backups:
        print("No backups found.")
        return
    print("Available backups:")
    for b in backups:
        size = b.stat().st_size / 1024
        print(f"  {b.name} ({size:.1f} KB)")


def main():
    parser = argparse.ArgumentParser(description="Restore from a backup")
    parser.add_argument("backup_file", nargs="?", help="Backup file name or path")
    parser.add_argument("--list", action="store_true", help="List available backups")
    parser.add_argument("--force", action="store_true", help="Skip confirmation prompt")
    args = parser.parse_args()

    if args.list:
        list_backups()
        return

    if not args.backup_file:
        parser.print_help()
        sys.exit(1)

    restore(backup_file=args.backup_file, force=args.force)


if __name__ == "__main__":
    main()

"""
Profile script - profiles the agent using cProfile and generates reports.
"""
import sys
import cProfile
import pstats
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROFILE_DIR = PROJECT_ROOT / "data" / "profiles"


def profile(sort: str = "cumtime", lines: int = 30, function: str = "main.main"):
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    output_file = PROFILE_DIR / "profile.prof"

    profiler = cProfile.Profile()
    profiler.enable()

    mod_name, func_name = function.rsplit(".", 1)
    __import__(mod_name)
    mod = sys.modules[mod_name]
    getattr(mod, func_name)()

    profiler.disable()
    profiler.dump_stats(str(output_file))

    stats = pstats.Stats(profiler)
    stats.sort_stats(sort)
    stats.print_stats(lines)
    print(f"\nProfile saved to {output_file}")


def main():
    parser = argparse.ArgumentParser(description="Profile the agent")
    parser.add_argument("--sort", default="cumtime", help="Sort key (cumtime, tottime, calls, etc.)")
    parser.add_argument("--lines", type=int, default=30, help="Number of lines to display")
    parser.add_argument("--function", default="main.main", help="Function to profile (module.function)")
    args = parser.parse_args()
    profile(sort=args.sort, lines=args.lines, function=args.function)


if __name__ == "__main__":
    main()

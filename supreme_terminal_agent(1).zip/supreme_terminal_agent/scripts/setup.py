"""
Setup script - installs dependencies and prepares the environment.
"""
import sys
import subprocess
import argparse
from pathlib import Path


REQUIREMENTS = Path(__file__).resolve().parents[2] / "requirements.txt"
PROJECT_ROOT = Path(__file__).resolve().parents[2]


def setup(venv: bool = False, dev: bool = False, force: bool = False):
    if venv:
        venv_path = PROJECT_ROOT / ".venv"
        if not venv_path.exists() or force:
            subprocess.check_call([sys.executable, "-m", "venv", str(venv_path)])
        python = str(venv_path / ("bin/python" if sys.platform != "win32" else "Scripts\\python.exe"))
    else:
        python = sys.executable

    subprocess.check_call([python, "-m", "pip", "install", "--upgrade", "pip"])
    subprocess.check_call([python, "-m", "pip", "install", "-r", str(REQUIREMENTS)])

    if dev:
        subprocess.check_call([python, "-m", "pip", "install", "pytest", "mypy", "ruff"])

    (PROJECT_ROOT / "data").mkdir(parents=True, exist_ok=True)
    (PROJECT_ROOT / "data" / "logs").mkdir(parents=True, exist_ok=True)
    (PROJECT_ROOT / "data" / "config").mkdir(parents=True, exist_ok=True)

    print("Setup complete.")


def main():
    parser = argparse.ArgumentParser(description="Setup the Supreme Terminal Agent")
    parser.add_argument("--venv", action="store_true", help="Create and use a virtual environment")
    parser.add_argument("--dev", action="store_true", help="Install development dependencies")
    parser.add_argument("--force", action="store_true", help="Force re-creation of venv")
    args = parser.parse_args()
    setup(venv=args.venv, dev=args.dev, force=args.force)


if __name__ == "__main__":
    main()

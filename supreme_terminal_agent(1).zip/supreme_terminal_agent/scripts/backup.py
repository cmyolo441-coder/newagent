"""
Backup script - creates a compressed backup of data and configuration.
"""
import sys
import tarfile
import argparse
import shutil
from pathlib import Path
from datetime import datetime


PROJECT_ROOT = Path(__file__).resolve().parents[2]
BACKUP_DIR = PROJECT_ROOT / "data" / "backups"
DATA_DIRS = [
    PROJECT_ROOT / "data",
    PROJECT_ROOT / "supreme_terminal_agent" / "config",
    PROJECT_ROOT / "supreme_terminal_agent" / "database",
    PROJECT_ROOT / "supreme_terminal_agent" / "cache",
]


def backup(output: str | None = None, compress: bool = True, include_logs: bool = False):
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    stem = output or f"backup_{timestamp}"
    ext = ".tar.gz" if compress else ".tar"
    path = BACKUP_DIR / f"{stem}{ext}"

    mode = "w:gz" if compress else "w"
    with tarfile.open(path, mode) as tf:
        for d in DATA_DIRS:
            if d.exists():
                arcname = d.relative_to(PROJECT_ROOT)
                tf.add(d, arcname=arcname)
        if include_logs:
            logs = PROJECT_ROOT / "data" / "logs"
            if logs.exists():
                tf.add(logs, arcname="logs")

    if not compress:
        import gzip
        with open(path, "rb") as f_in:
            with gzip.open(str(path) + ".gz", "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)
        path.unlink()
        path = Path(str(path) + ".gz")

    print(f"Backup created: {path} ({path.stat().st_size / 1024:.1f} KB)")


def main():
    parser = argparse.ArgumentParser(description="Create a backup")
    parser.add_argument("--output", help="Backup filename stem")
    parser.add_argument("--no-compress", action="store_false", dest="compress", help="Skip compression")
    parser.add_argument("--include-logs", action="store_true", help="Include log files")
    args = parser.parse_args()
    backup(output=args.output, compress=args.compress, include_logs=args.include_logs)


if __name__ == "__main__":
    main()

"""
Build documentation using Sphinx.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def docs_build(clean: bool = False, watch: bool = False):
    docs_dir = PROJECT_ROOT / "supreme_terminal_agent" / "docs"
    build_dir = docs_dir / "_build" / "html"

    if clean and build_dir.exists():
        import shutil
        shutil.rmtree(build_dir)

    if not (docs_dir / "conf.py").exists():
        subprocess.check_call([sys.executable, "-m", "sphinx", "quickstart", "-q", "--sep",
                               "-p", "Supreme Terminal Agent", "-a", "Supreme AI Systems",
                               "-v", "1.0.0", "--ext-autodoc", "--ext-viewcode", str(docs_dir)])

    cmd = [sys.executable, "-m", "sphinx", "-b", "html", str(docs_dir), str(build_dir)]
    subprocess.check_call(cmd)
    print(f"Documentation built at {build_dir}")


def main():
    parser = argparse.ArgumentParser(description="Build documentation")
    parser.add_argument("--clean", action="store_true", help="Clean build directory before building")
    parser.add_argument("--watch", action="store_true", help="Rebuild on changes (not yet supported)")
    args = parser.parse_args()
    docs_build(clean=args.clean, watch=args.watch)


if __name__ == "__main__":
    main()

"""
Generate self-signed TLS certificates for the agent.
"""
import sys
import argparse
import datetime
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CERTS_DIR = PROJECT_ROOT / "supreme_terminal_agent" / "security" / "certs"


def generate_certs(output_dir: str | None = None, days_valid: int = 365,
                   key_size: int = 2048, common_name: str = "localhost"):
    cert_dir = Path(output_dir) if output_dir else CERTS_DIR
    cert_dir.mkdir(parents=True, exist_ok=True)

    key_path = cert_dir / "key.pem"
    cert_path = cert_dir / "cert.pem"

    try:
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
    except ImportError:
        print("cryptography library is required. Install with: pip install cryptography")
        sys.exit(1)

    key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)

    with open(key_path, "wb") as f:
        f.write(key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        ))

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Supreme AI Systems"),
        x509.NameAttribute(NameOID.COMMON_NAME, common_name),
    ])

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.utcnow())
        .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=days_valid))
        .add_extension(
            x509.SubjectAlternativeName([x509.DNSName(common_name)]),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )

    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    print(f"Certificate generated: {cert_path}")
    print(f"Private key generated: {key_path}")


def main():
    parser = argparse.ArgumentParser(description="Generate TLS certificates")
    parser.add_argument("--output-dir", help="Output directory for certificates")
    parser.add_argument("--days", type=int, default=365, help="Certificate validity in days")
    parser.add_argument("--key-size", type=int, default=2048, help="RSA key size")
    parser.add_argument("--common-name", default="localhost", help="Certificate common name")
    args = parser.parse_args()
    generate_certs(output_dir=args.output_dir, days_valid=args.days,
                   key_size=args.key_size, common_name=args.common_name)


if __name__ == "__main__":
    main()

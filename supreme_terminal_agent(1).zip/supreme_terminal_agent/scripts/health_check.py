"""
Health check script - verifies all system components are operational.
"""
import sys
import json
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _check_directory(d: Path, name: str) -> tuple[str, str]:
    if d.exists() and d.is_dir():
        return (name, "ok")
    return (name, "missing")


def _check_file(f: Path, name: str) -> tuple[str, str]:
    if f.exists() and f.is_file():
        return (name, "ok")
    return (name, "missing")


def health_check(output: str | None = None, verbose: bool = False):
    results = {}
    all_ok = True

    for check_name, check_func, target in [
        ("project_root", _check_directory, PROJECT_ROOT),
        ("package_dir", _check_directory, PROJECT_ROOT / "supreme_terminal_agent"),
        ("core_dir", _check_directory, PROJECT_ROOT / "core"),
        ("version_file", _check_file, PROJECT_ROOT / "version.py"),
        ("config_file", _check_file, PROJECT_ROOT / "config.py"),
        ("main_entry", _check_file, PROJECT_ROOT / "main.py"),
        ("requirements", _check_file, PROJECT_ROOT / "requirements.txt"),
        ("setup_script", _check_file, PROJECT_ROOT / "setup.py"),
    ]:
        name, status = check_func(target, check_name)
        results[name] = status
        if status != "ok":
            all_ok = False

    for dep_name in ("supreme_terminal_agent", "core", "config", "version"):
        try:
            __import__(dep_name)
            results[f"import_{dep_name}"] = "ok"
        except ImportError:
            results[f"import_{dep_name}"] = "import_error"
            all_ok = False

    if verbose:
        for name, status in sorted(results.items()):
            icon = "✓" if status == "ok" else "✗"
            print(f"  {icon} {name}: {status}")

    if output:
        out_path = Path(output)
        out_path.write_text(json.dumps({"healthy": all_ok, "checks": results}, indent=2))
        print(f"Results written to {out_path}")

    sys.exit(0 if all_ok else 1)


def main():
    parser = argparse.ArgumentParser(description="Run health checks")
    parser.add_argument("--output", help="JSON output file")
    parser.add_argument("-v", "--verbose", action="store_true", help="Show all check results")
    args = parser.parse_args()
    health_check(output=args.output, verbose=args.verbose)


if __name__ == "__main__":
    main()

"""
Serve documentation locally via a simple HTTP server.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def docs_serve(port: int = 8000, host: str = "127.0.0.1", open_browser: bool = False):
    docs_build_dir = PROJECT_ROOT / "supreme_terminal_agent" / "docs" / "_build" / "html"
    if not docs_build_dir.exists():
        print("Documentation not built. Run docs_build.py first.")
        sys.exit(1)
    if open_browser:
        import webbrowser
        webbrowser.open(f"http://{host}:{port}")
    cmd = [sys.executable, "-m", "http.server", str(port), "--bind", host, "-d", str(docs_build_dir)]
    print(f"Serving docs at http://{host}:{port}")
    subprocess.check_call(cmd)


def main():
    parser = argparse.ArgumentParser(description="Serve documentation")
    parser.add_argument("--port", type=int, default=8000, help="Port to serve on")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--open", action="store_true", help="Open browser automatically")
    args = parser.parse_args()
    docs_serve(port=args.port, host=args.host, open_browser=args.open)


if __name__ == "__main__":
    main()

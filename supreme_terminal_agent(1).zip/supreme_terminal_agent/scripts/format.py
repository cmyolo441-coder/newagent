"""
Format script - auto-formats code using ruff.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def format_code(check: bool = False, path: str | None = None):
    cmd = [sys.executable, "-m", "ruff", "format"]
    if check:
        cmd.append("--check")
    target = path or str(PROJECT_ROOT / "supreme_terminal_agent")
    cmd.append(target)
    result = subprocess.run(cmd)
    sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description="Format code")
    parser.add_argument("--check", action="store_true", help="Check formatting without modifying")
    parser.add_argument("--path", help="Specific path to format")
    args = parser.parse_args()
    format_code(check=args.check, path=args.path)


if __name__ == "__main__":
    main()

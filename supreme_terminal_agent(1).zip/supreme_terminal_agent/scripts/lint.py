"""
Lint runner - runs ruff linter over the codebase.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def lint(fix: bool = False, path: str | None = None, format: str = "concise"):
    cmd = [sys.executable, "-m", "ruff", "check"]
    if fix:
        cmd.append("--fix")
    if format:
        cmd.extend(["--output-format", format])
    target = path or str(PROJECT_ROOT / "supreme_terminal_agent")
    cmd.append(target)
    result = subprocess.run(cmd)
    sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description="Run linter")
    parser.add_argument("--fix", action="store_true", help="Auto-fix issues")
    parser.add_argument("--path", help="Specific path to lint")
    parser.add_argument("--format", choices=["concise", "full", "github", "grouped"],
                        default="concise", help="Output format")
    args = parser.parse_args()
    lint(fix=args.fix, path=args.path, format=args.format)


if __name__ == "__main__":
    main()

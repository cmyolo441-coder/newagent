"""
Update script - upgrades the Supreme Terminal Agent to the latest version.
"""
import sys
import subprocess
import argparse


_UPDATE_SOURCES = {
    "pypi": ["pip", "install", "--upgrade", "supreme-terminal-agent"],
    "git": ["pip", "install", "--upgrade", "git+https://github.com/supreme/supreme-terminal-agent.git"],
    "local": ["pip", "install", "--upgrade", "."],
}


def update(source: str = "pypi", pre: bool = False):
    if source not in _UPDATE_SOURCES:
        print(f"Unknown source: {source}. Choose from: {', '.join(_UPDATE_SOURCES)}")
        sys.exit(1)
    cmd = [sys.executable] + _UPDATE_SOURCES[source]
    if pre:
        cmd.append("--pre")
    subprocess.check_call(cmd)
    print("Update complete.")


def main():
    parser = argparse.ArgumentParser(description="Update Supreme Terminal Agent")
    parser.add_argument("--source", choices=list(_UPDATE_SOURCES), default="pypi", help="Update source")
    parser.add_argument("--pre", action="store_true", help="Include pre-release versions")
    args = parser.parse_args()
    update(source=args.source, pre=args.pre)


if __name__ == "__main__":
    main()

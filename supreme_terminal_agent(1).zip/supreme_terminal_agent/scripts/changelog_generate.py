"""
Generate changelog from git commit history.
"""
import sys
import subprocess
import argparse
from pathlib import Path
from datetime import datetime


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def changelog(output: str | None = None, since: str | None = None, format: str = "markdown"):
    cmd = ["git", "log", "--oneline", "--no-decorate"]
    if since:
        cmd.extend([f"{since}..HEAD"])
    else:
        last_tag = subprocess.run(
            ["git", "describe", "--tags", "--abbrev=0"],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT)
        )
        if last_tag.returncode == 0:
            cmd.extend([f"{last_tag.stdout.strip()}..HEAD"])

    result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(PROJECT_ROOT))
    commits = result.stdout.strip().split("\n") if result.stdout.strip() else []

    markdown_lines = [f"# Changelog", f"## {datetime.now().strftime('%Y-%m-%d')}", ""]
    for commit in commits:
        parts = commit.split(" ", 1)
        if len(parts) == 2:
            markdown_lines.append(f"- {parts[1]} ({parts[0]})")

    changelog_text = "\n".join(markdown_lines)

    if output:
        out_path = Path(output)
        out_path.write_text(changelog_text)
        print(f"Changelog written to {out_path}")
    else:
        print(changelog_text)


def main():
    parser = argparse.ArgumentParser(description="Generate changelog from git history")
    parser.add_argument("--output", help="Output file path")
    parser.add_argument("--since", help="Starting ref (tag or commit)")
    parser.add_argument("--format", choices=["markdown"], default="markdown", help="Output format")
    args = parser.parse_args()
    changelog(output=args.output, since=args.since, format=args.format)


if __name__ == "__main__":
    main()

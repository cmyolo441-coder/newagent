"""
Build script - builds wheel and sdist distributions.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def build(clean: bool = False, wheel: bool = True, sdist: bool = True):
    dist_dir = PROJECT_ROOT / "dist"
    build_dir = PROJECT_ROOT / "build"

    if clean:
        for d in [dist_dir, build_dir]:
            if d.exists():
                import shutil
                shutil.rmtree(d)
                print(f"Removed {d}")

    dist_dir.mkdir(exist_ok=True)

    cmd = [sys.executable, "-m", "build", "--outdir", str(dist_dir)]
    if not wheel:
        cmd.append("--sdist")
    elif not sdist:
        cmd.append("--wheel")
    else:
        pass
    subprocess.check_call(cmd, cwd=str(PROJECT_ROOT))
    print("Build complete.")


def main():
    parser = argparse.ArgumentParser(description="Build Supreme Terminal Agent")
    parser.add_argument("--clean", action="store_true", help="Clean build artifacts before building")
    parser.add_argument("--wheel", action="store_true", default=True, help="Build wheel (default)")
    parser.add_argument("--sdist", action="store_true", default=True, help="Build source distribution")
    parser.add_argument("--no-wheel", action="store_false", dest="wheel", help="Skip wheel build")
    parser.add_argument("--no-sdist", action="store_false", dest="sdist", help="Skip sdist build")
    args = parser.parse_args()
    build(clean=args.clean, wheel=args.wheel, sdist=args.sdist)


if __name__ == "__main__":
    main()

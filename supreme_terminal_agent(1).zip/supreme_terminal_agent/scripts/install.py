"""
Install script - installs the package into the current Python environment.
"""
import sys
import subprocess
import argparse
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def install(editable: bool = False, user: bool = False):
    cmd = [sys.executable, "-m", "pip", "install"]
    if editable:
        cmd.append("-e")
    if user:
        cmd.append("--user")
    cmd.append(str(PROJECT_ROOT))
    subprocess.check_call(cmd)
    print("Installation complete.")


def main():
    parser = argparse.ArgumentParser(description="Install Supreme Terminal Agent")
    parser.add_argument("-e", "--editable", action="store_true", help="Install in editable mode")
    parser.add_argument("--user", action="store_true", help="Install to user site-packages")
    args = parser.parse_args()
    install(editable=args.editable, user=args.user)


if __name__ == "__main__":
    main()

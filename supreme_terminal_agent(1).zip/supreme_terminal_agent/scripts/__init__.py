"""
Supreme Terminal Agent scripts package.
"""

"""Shared Memory - Shared memory between processes."""

from __future__ import annotations

import logging
from multiprocessing import shared_memory
from typing import Any, Optional

logger = logging.getLogger(__name__)


class SharedMemory:
    def __init__(self, name: Optional[str] = None, size: int = 1024):
        self._name = name
        self._size = size
        self._shm: Optional[shared_memory.SharedMemory] = None

    def create(self) -> str:
        self._shm = shared_memory.SharedMemory(name=self._name, create=True, size=self._size)
        self._name = self._shm.name
        return self._name

    def attach(self, name: str) -> None:
        self._shm = shared_memory.SharedMemory(name=name)
        self._name = name

    def write(self, data: bytes, offset: int = 0) -> None:
        if self._shm:
            self._shm.buf[offset:offset + len(data)] = data

    def read(self, size: Optional[int] = None, offset: int = 0) -> bytes:
        if self._shm:
            if size is None:
                size = self._size - offset
            return bytes(self._shm.buf[offset:offset + size])
        return b""

    def close(self) -> None:
        if self._shm:
            self._shm.close()

    def unlink(self) -> None:
        if self._shm:
            self._shm.unlink()

    @property
    def name(self) -> Optional[str]:
        return self._name

    @property
    def size(self) -> int:
        return self._size

    def __repr__(self) -> str:
        return f"<SharedMemory name='{self._name}' size={self._size}>"

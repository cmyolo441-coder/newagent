"""Process Sync - Process synchronization primitives."""

from __future__ import annotations

import logging
from multiprocessing import Barrier as MPBarrier
from multiprocessing import BoundedSemaphore, Condition, Event, Lock, RLock, Semaphore
from typing import Optional

logger = logging.getLogger(__name__)


class ProcessSync:
    @staticmethod
    def Lock() -> Lock:
        return Lock()

    @staticmethod
    def RLock() -> RLock:
        return RLock()

    @staticmethod
    def Semaphore(value: int = 1) -> Semaphore:
        return Semaphore(value)

    @staticmethod
    def BoundedSemaphore(value: int = 1) -> BoundedSemaphore:
        return BoundedSemaphore(value)

    @staticmethod
    def Event() -> Event:
        return Event()

    @staticmethod
    def Condition(lock: Optional[Lock] = None) -> Condition:
        return Condition(lock)

    @staticmethod
    def Barrier(parties: int, timeout: Optional[float] = None) -> MPBarrier:
        return MPBarrier(parties, timeout=timeout)

    def __repr__(self) -> str:
        return "<ProcessSync>"

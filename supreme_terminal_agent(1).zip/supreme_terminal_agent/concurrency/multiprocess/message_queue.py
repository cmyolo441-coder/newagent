"""Message Queue - Process-safe message queue."""

from __future__ import annotations

import logging
from multiprocessing import Queue
from typing import Any, List, Optional

logger = logging.getLogger(__name__)


class MessageQueue:
    def __init__(self, maxsize: int = 0):
        self._queue = Queue(maxsize=maxsize)
        self._maxsize = maxsize

    def put(self, item: Any, block: bool = True, timeout: Optional[float] = None) -> None:
        self._queue.put(item, block=block, timeout=timeout)

    def get(self, block: bool = True, timeout: Optional[float] = None) -> Any:
        return self._queue.get(block=block, timeout=timeout)

    def put_nowait(self, item: Any) -> None:
        self._queue.put_nowait(item)

    def get_nowait(self) -> Any:
        return self._queue.get_nowait()

    @property
    def qsize(self) -> int:
        return self._queue.qsize()

    @property
    def empty(self) -> bool:
        return self._queue.empty()

    @property
    def full(self) -> bool:
        return self._queue.full()

    def close(self) -> None:
        self._queue.close()

    def __repr__(self) -> str:
        return f"<MessageQueue size={self.qsize}>"

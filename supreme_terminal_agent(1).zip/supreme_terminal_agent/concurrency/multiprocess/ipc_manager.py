"""IPC Manager - Inter-process communication management."""

from __future__ import annotations

import logging
from multiprocessing import connection
from typing import Any, List, Optional

logger = logging.getLogger(__name__)


class IPCManager:
    def __init__(self):
        self._listener: Optional[connection.Listener] = None
        self._connections: list = []

    def create_server(self, address: str, family: str = "AF_UNIX") -> None:
        self._listener = connection.Listener(address, family=family)
        logger.info(f"IPC server listening on {address}")

    def accept(self) -> Any:
        if self._listener:
            conn = self._listener.accept()
            self._connections.append(conn)
            return conn
        return None

    def connect(self, address: str, family: str = "AF_UNIX") -> Any:
        conn = connection.Client(address, family=family)
        self._connections.append(conn)
        return conn

    def send(self, conn: Any, message: Any) -> None:
        conn.send(message)

    def recv(self, conn: Any) -> Any:
        return conn.recv()

    def close_all(self) -> None:
        for conn in self._connections:
            conn.close()
        if self._listener:
            self._listener.close()
        self._connections.clear()

    def __repr__(self) -> str:
        return f"<IPCManager connections={len(self._connections)}>"

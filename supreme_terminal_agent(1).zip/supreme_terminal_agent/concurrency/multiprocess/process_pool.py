"""Process Pool - Manages a pool of worker processes."""

from __future__ import annotations

import logging
from concurrent.futures import Future, ProcessPoolExecutor
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)


class ProcessPool:
    def __init__(self, max_workers: int = 4):
        self._executor = ProcessPoolExecutor(max_workers=max_workers)
        self._max_workers = max_workers

    def submit(self, fn: Callable, *args, **kwargs) -> Future:
        return self._executor.submit(fn, *args, **kwargs)

    def map(self, fn: Callable, *iterables) -> Any:
        return self._executor.map(fn, *iterables)

    def shutdown(self, wait: bool = True) -> None:
        self._executor.shutdown(wait=wait)

    @property
    def max_workers(self) -> int:
        return self._max_workers

    def __repr__(self) -> str:
        return f"<ProcessPool workers={self._max_workers}>"

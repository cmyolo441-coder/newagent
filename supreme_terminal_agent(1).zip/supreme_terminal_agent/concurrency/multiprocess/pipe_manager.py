"""Pipe Manager - Pipe-based IPC."""

from __future__ import annotations

import logging
import os
from multiprocessing import Pipe
from typing import Any, Optional, Tuple

logger = logging.getLogger(__name__)


class PipeManager:
    def __init__(self):
        self._pipes: dict = {}

    def create_pipe(self, name: str, duplex: bool = True) -> Tuple[Any, Any]:
        parent, child = Pipe(duplex=duplex)
        self._pipes[name] = (parent, child)
        return parent, child

    def get_pipe(self, name: str) -> Optional[Tuple[Any, Any]]:
        return self._pipes.get(name)

    def send(self, conn: Any, message: Any) -> None:
        conn.send(message)

    def recv(self, conn: Any) -> Any:
        return conn.recv()

    def close_pipe(self, name: str) -> None:
        pipe = self._pipes.pop(name, None)
        if pipe:
            parent, child = pipe
            parent.close()
            child.close()

    def close_all(self) -> None:
        for name in list(self._pipes.keys()):
            self.close_pipe(name)

    def __repr__(self) -> str:
        return f"<PipeManager pipes={len(self._pipes)}>"

"""Future Manager - Manages future objects."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class FutureManager:
    def __init__(self):
        self._futures: Dict[str, asyncio.Future] = {}

    def create_future(self, name: str) -> asyncio.Future:
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        self._futures[name] = future
        return future

    def resolve(self, name: str, value: Any = None) -> bool:
        future = self._futures.get(name)
        if future and not future.done():
            future.set_result(value)
            return True
        return False

    def reject(self, name: str, exception: Exception) -> bool:
        future = self._futures.get(name)
        if future and not future.done():
            future.set_exception(exception)
            return True
        return False

    def get_future(self, name: str) -> Optional[asyncio.Future]:
        return self._futures.get(name)

    async def wait_for(self, name: str, timeout: Optional[float] = None) -> Any:
        future = self.get_future(name)
        if future is None:
            raise KeyError(f"Future '{name}' not found")
        return await asyncio.wait_for(future, timeout=timeout)

    def remove(self, name: str) -> None:
        self._futures.pop(name, None)

    def clear(self) -> None:
        self._futures.clear()

    def __repr__(self) -> str:
        return f"<FutureManager futures={len(self._futures)}>"

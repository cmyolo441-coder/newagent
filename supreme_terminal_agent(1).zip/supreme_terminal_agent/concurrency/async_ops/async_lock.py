"""Async Lock - Async-compatible lock."""

from __future__ import annotations

import asyncio
from typing import Optional


class AsyncLock:
    def __init__(self):
        self._lock = asyncio.Lock()

    async def acquire(self) -> bool:
        await self._lock.acquire()
        return True

    def release(self) -> None:
        self._lock.release()

    @property
    def locked(self) -> bool:
        return self._lock.locked()

    async def __aenter__(self):
        await self.acquire()
        return self

    async def __aexit__(self, *args) -> None:
        self.release()

    def __repr__(self) -> str:
        return f"<AsyncLock locked={self.locked}>"

"""Async Pool - Pool of reusable async workers."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)


class AsyncPool:
    def __init__(self, size: int = 10):
        self._size = size
        self._queue: asyncio.Queue = asyncio.Queue()
        self._workers: List[asyncio.Task] = []
        self._running = False

    async def start(self) -> None:
        self._running = True
        self._workers = [
            asyncio.create_task(self._worker(i)) for i in range(self._size)
        ]

    async def _worker(self, worker_id: int) -> None:
        while self._running:
            try:
                fn, args, kwargs, future = await self._queue.get()
                try:
                    result = fn(*args, **kwargs)
                    if hasattr(result, "__await__"):
                        result = await result
                    future.set_result(result)
                except Exception as e:
                    future.set_exception(e)
            except asyncio.CancelledError:
                break

    async def submit(self, fn: Callable, *args, **kwargs) -> Any:
        loop = asyncio.get_event_loop()
        future = loop.create_future()
        await self._queue.put((fn, args, kwargs, future))
        return await future

    async def stop(self) -> None:
        self._running = False
        for w in self._workers:
            w.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()

    def __repr__(self) -> str:
        return f"<AsyncPool size={self._size}>"

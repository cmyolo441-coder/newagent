"""Async Event - Async-compatible event."""

from __future__ import annotations

import asyncio
from typing import Optional


class AsyncEvent:
    def __init__(self):
        self._event = asyncio.Event()

    def set(self) -> None:
        self._event.set()

    def clear(self) -> None:
        self._event.clear()

    async def wait(self) -> bool:
        await self._event.wait()
        return True

    @property
    def is_set(self) -> bool:
        return self._event.is_set()

    def __repr__(self) -> str:
        return f"<AsyncEvent set={self.is_set}>"

"""Coroutine Manager - Manages coroutine lifecycle."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Coroutine, Dict, List, Optional

logger = logging.getLogger(__name__)


class CoroutineManager:
    def __init__(self):
        self._coroutines: Dict[str, asyncio.Task] = {}

    def create_task(self, name: str, coro: Coroutine) -> asyncio.Task:
        task = asyncio.create_task(coro)
        self._coroutines[name] = task
        task.add_done_callback(lambda _: self._coroutines.pop(name, None))
        return task

    def cancel(self, name: str) -> bool:
        task = self._coroutines.get(name)
        if task and not task.done():
            task.cancel()
            return True
        return False

    def is_running(self, name: str) -> bool:
        task = self._coroutines.get(name)
        return task is not None and not task.done()

    def get_task(self, name: str) -> Optional[asyncio.Task]:
        return self._coroutines.get(name)

    async def cancel_all(self) -> None:
        for name in list(self._coroutines.keys()):
            self.cancel(name)
        if self._coroutines:
            await asyncio.gather(*self._coroutines.values(), return_exceptions=True)
        self._coroutines.clear()

    @property
    def active_count(self) -> int:
        return sum(1 for t in self._coroutines.values() if not t.done())

    def __repr__(self) -> str:
        return f"<CoroutineManager active={self.active_count}>"

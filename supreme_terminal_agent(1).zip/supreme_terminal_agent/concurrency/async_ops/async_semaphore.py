"""Async Semaphore - Async-compatible semaphore."""

from __future__ import annotations

import asyncio
from typing import Optional


class AsyncSemaphore:
    def __init__(self, value: int = 1):
        self._sem = asyncio.Semaphore(value)
        self._value = value

    async def acquire(self) -> bool:
        await self._sem.acquire()
        return True

    def release(self) -> None:
        self._sem.release()

    @property
    def value(self) -> int:
        return self._value

    async def __aenter__(self):
        await self.acquire()
        return self

    async def __aexit__(self, *args) -> None:
        self.release()

    def __repr__(self) -> str:
        return f"<AsyncSemaphore value={self._value}>"

"""Event Loop - Wrapper around asyncio event loop."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


class EventLoop:
    def __init__(self):
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    @property
    def loop(self) -> asyncio.AbstractEventLoop:
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop

    def run(self, coro) -> Any:
        return self.loop.run_until_complete(coro)

    def run_in_background(self, coro) -> asyncio.Task:
        return self.loop.create_task(coro)

    def call_later(self, delay: float, callback: Callable, *args) -> asyncio.TimerHandle:
        return self.loop.call_later(delay, callback, *args)

    def stop(self) -> None:
        if self._loop and not self._loop.is_closed():
            self._loop.stop()

    def close(self) -> None:
        if self._loop and not self._loop.is_closed():
            self._loop.close()

    def __repr__(self) -> str:
        return f"<EventLoop running={self._loop.is_running() if self._loop else False}>"

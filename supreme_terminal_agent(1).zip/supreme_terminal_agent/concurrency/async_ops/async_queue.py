"""Async Queue - Async-compatible queue."""

from __future__ import annotations

import asyncio
from typing import Any, List, Optional


class AsyncQueue:
    def __init__(self, maxsize: int = 0):
        self._queue = asyncio.Queue(maxsize=maxsize)

    async def put(self, item: Any) -> None:
        await self._queue.put(item)

    async def get(self) -> Any:
        return await self._queue.get()

    def put_nowait(self, item: Any) -> None:
        self._queue.put_nowait(item)

    def get_nowait(self) -> Any:
        return self._queue.get_nowait()

    async def join(self) -> None:
        await self._queue.join()

    def task_done(self) -> None:
        self._queue.task_done()

    @property
    def qsize(self) -> int:
        return self._queue.qsize()

    @property
    def empty(self) -> bool:
        return self._queue.empty()

    @property
    def full(self) -> bool:
        return self._queue.full()

    @property
    def maxsize(self) -> int:
        return self._queue.maxsize

    def __repr__(self) -> str:
        return f"<AsyncQueue size={self.qsize}/{self.maxsize}>"

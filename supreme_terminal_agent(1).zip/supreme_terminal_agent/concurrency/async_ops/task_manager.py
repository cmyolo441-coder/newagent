"""Task Manager - Manages async tasks."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Coroutine, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class TaskManager:
    def __init__(self):
        self._tasks: Set[asyncio.Task] = set()

    def create_task(self, coro: Coroutine, name: Optional[str] = None) -> asyncio.Task:
        task = asyncio.create_task(coro, name=name)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return task

    async def cancel_all(self) -> None:
        for task in list(self._tasks):
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

    async def wait_all(self, timeout: Optional[float] = None) -> None:
        if self._tasks:
            await asyncio.wait(self._tasks, timeout=timeout)

    @property
    def count(self) -> int:
        return len(self._tasks)

    @property
    def pending(self) -> int:
        return sum(1 for t in self._tasks if not t.done())

    def __repr__(self) -> str:
        return f"<TaskManager pending={self.pending} total={self.count}>"

"""Async Executor - Executes coroutines with concurrency control."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Coroutine, List, Optional

logger = logging.getLogger(__name__)


class AsyncExecutor:
    def __init__(self, max_concurrency: int = 10):
        self._sem = asyncio.Semaphore(max_concurrency)
        self._max_concurrency = max_concurrency

    async def execute(self, coro: Coroutine) -> Any:
        async with self._sem:
            return await coro

    async def execute_many(self, coros: List[Coroutine]) -> List[Any]:
        sem = self._sem

        async def limited(c: Coroutine) -> Any:
            async with sem:
                return await c

        tasks = [limited(c) for c in coros]
        return await asyncio.gather(*tasks, return_exceptions=True)

    async def execute_fn(self, fn: Callable, *args, **kwargs) -> Any:
        async with self._sem:
            result = fn(*args, **kwargs)
            if hasattr(result, "__await__"):
                return await result
            return result

    def __repr__(self) -> str:
        return f"<AsyncExecutor max_concurrency={self._max_concurrency}>"

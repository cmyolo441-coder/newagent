"""Concurrency Manager - Central management for concurrency primitives."""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)


class ConcurrencyManager:
    def __init__(self):
        self._thread_pools: dict = {}
        self._async_pools: dict = {}
        self._process_pools: dict = {}

    def create_thread_pool(self, name: str, max_workers: int = 4) -> Any:
        from concurrent.futures import ThreadPoolExecutor
        pool = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix=name)
        self._thread_pools[name] = pool
        return pool

    def get_thread_pool(self, name: str) -> Any:
        return self._thread_pools.get(name)

    def run_in_thread(self, pool_name: str, fn: Callable, *args, **kwargs) -> Any:
        pool = self.get_thread_pool(pool_name)
        if pool is None:
            raise ValueError(f"Thread pool '{pool_name}' not found")
        return pool.submit(fn, *args, **kwargs)

    def create_async_pool(self, name: str, max_concurrency: int = 10) -> Any:
        sem = asyncio.Semaphore(max_concurrency)
        self._async_pools[name] = sem
        return sem

    def get_async_pool(self, name: str) -> Any:
        return self._async_pools.get(name)

    async def run_async(self, pool_name: str, coro) -> Any:
        sem = self.get_async_pool(pool_name)
        if sem is None:
            raise ValueError(f"Async pool '{pool_name}' not found")
        async with sem:
            return await coro

    def create_process_pool(self, name: str, max_workers: int = 4) -> Any:
        from concurrent.futures import ProcessPoolExecutor
        pool = ProcessPoolExecutor(max_workers=max_workers)
        self._process_pools[name] = pool
        return pool

    def get_process_pool(self, name: str) -> Any:
        return self._process_pools.get(name)

    def run_in_process(self, pool_name: str, fn: Callable, *args, **kwargs) -> Any:
        pool = self.get_process_pool(pool_name)
        if pool is None:
            raise ValueError(f"Process pool '{pool_name}' not found")
        return pool.submit(fn, *args, **kwargs)

    def shutdown_all(self) -> None:
        for pool in self._thread_pools.values():
            pool.shutdown(wait=False)
        for pool in self._process_pools.values():
            pool.shutdown(wait=False)
        self._thread_pools.clear()
        self._async_pools.clear()
        self._process_pools.clear()

    def __repr__(self) -> str:
        return f"<ConcurrencyManager threads={len(self._thread_pools)} async={len(self._async_pools)} processes={len(self._process_pools)}>"

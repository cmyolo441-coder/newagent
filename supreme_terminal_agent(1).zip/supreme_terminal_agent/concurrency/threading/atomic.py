"""Atomic - Thread-safe atomic operations."""

from __future__ import annotations

import threading
from typing import Any, Callable, TypeVar

T = TypeVar("T")


class Atomic:
    def __init__(self, value: T = 0):
        self._lock = threading.Lock()
        self._value: T = value

    def get(self) -> T:
        with self._lock:
            return self._value

    def set(self, value: T) -> None:
        with self._lock:
            self._value = value

    def add(self, amount: T) -> T:
        with self._lock:
            self._value += amount
            return self._value

    def sub(self, amount: T) -> T:
        with self._lock:
            self._value -= amount
            return self._value

    def inc(self) -> T:
        return self.add(1)

    def dec(self) -> T:
        return self.sub(1)

    def compare_and_set(self, expected: T, new_value: T) -> bool:
        with self._lock:
            if self._value == expected:
                self._value = new_value
                return True
            return False

    def update(self, fn: Callable[[T], T]) -> T:
        with self._lock:
            self._value = fn(self._value)
            return self._value

    @property
    def value(self) -> T:
        return self.get()

    def __repr__(self) -> str:
        return f"<Atomic value={self._value!r}>"

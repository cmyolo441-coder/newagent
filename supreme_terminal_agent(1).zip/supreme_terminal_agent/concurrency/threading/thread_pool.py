"""Thread Pool - Manages a pool of worker threads."""

from __future__ import annotations

import logging
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)


class ThreadPool:
    def __init__(self, max_workers: int = 4, name: str = "threadpool"):
        self._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix=name)
        self._max_workers = max_workers

    def submit(self, fn: Callable, *args, **kwargs) -> Future:
        return self._executor.submit(fn, *args, **kwargs)

    def map(self, fn: Callable, *iterables) -> Any:
        return self._executor.map(fn, *iterables)

    def shutdown(self, wait: bool = True) -> None:
        self._executor.shutdown(wait=wait)

    @property
    def max_workers(self) -> int:
        return self._max_workers

    def __repr__(self) -> str:
        return f"<ThreadPool workers={self._max_workers}>"

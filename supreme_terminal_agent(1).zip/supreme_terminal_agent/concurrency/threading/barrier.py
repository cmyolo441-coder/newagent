"""Barrier - Thread barrier synchronization primitive."""

from __future__ import annotations

import threading
from typing import Optional


class Barrier:
    def __init__(self, parties: int, timeout: Optional[float] = None):
        self._barrier = threading.Barrier(parties, timeout=timeout)
        self._parties = parties

    def wait(self, timeout: Optional[float] = None) -> int:
        return self._barrier.wait(timeout=timeout)

    def reset(self) -> None:
        self._barrier.reset()

    def abort(self) -> None:
        self._barrier.abort()

    @property
    def parties(self) -> int:
        return self._parties

    @property
    def n_waiting(self) -> int:
        return self._barrier.n_waiting

    @property
    def broken(self) -> bool:
        return self._barrier.broken

    def __repr__(self) -> str:
        return f"<Barrier parties={self._parties} waiting={self.n_waiting}>"

"""RW Lock - Read-Write lock implementation."""

from __future__ import annotations

import logging
import threading
from typing import Optional

logger = logging.getLogger(__name__)


class RWLock:
    def __init__(self):
        self._read_lock = threading.Lock()
        self._write_lock = threading.Lock()
        self._readers = 0

    def acquire_read(self) -> None:
        self._read_lock.acquire()
        self._readers += 1
        if self._readers == 1:
            self._write_lock.acquire()
        self._read_lock.release()

    def release_read(self) -> None:
        self._read_lock.acquire()
        self._readers -= 1
        if self._readers == 0:
            self._write_lock.release()
        self._read_lock.release()

    def acquire_write(self) -> None:
        self._write_lock.acquire()

    def release_write(self) -> None:
        self._write_lock.release()

    def __enter__(self):
        self.acquire_write()
        return self

    def __exit__(self, *args) -> None:
        self.release_write()

    def __repr__(self) -> str:
        return f"<RWLock readers={self._readers}>"

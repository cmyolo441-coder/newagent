"""Thread Safe - Thread-safe wrapper for objects."""

from __future__ import annotations

import threading
from typing import Any, Callable, TypeVar

T = TypeVar("T")


class ThreadSafe:
    def __init__(self, value: T = None):
        self._lock = threading.RLock()
        self._value: T = value

    @property
    def value(self) -> T:
        with self._lock:
            return self._value

    @value.setter
    def value(self, new_value: T) -> None:
        with self._lock:
            self._value = new_value

    def update(self, fn: Callable[[T], T]) -> T:
        with self._lock:
            self._value = fn(self._value)
            return self._value

    def __enter__(self) -> "ThreadSafe":
        self._lock.acquire()
        return self

    def __exit__(self, *args) -> None:
        self._lock.release()

    def __repr__(self) -> str:
        return f"<ThreadSafe value={self._value!r}>"

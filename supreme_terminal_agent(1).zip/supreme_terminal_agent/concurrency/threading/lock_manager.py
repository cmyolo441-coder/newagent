"""Lock Manager - Manages named locks for synchronization."""

from __future__ import annotations

import logging
import threading
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class LockManager:
    def __init__(self):
        self._locks: Dict[str, threading.Lock] = {}

    def get_lock(self, name: str) -> threading.Lock:
        if name not in self._locks:
            self._locks[name] = threading.Lock()
        return self._locks[name]

    def acquire(self, name: str, blocking: bool = True, timeout: float = -1) -> bool:
        lock = self.get_lock(name)
        return lock.acquire(blocking=blocking, timeout=timeout)

    def release(self, name: str) -> None:
        lock = self._locks.get(name)
        if lock and lock.locked():
            lock.release()

    def locked(self, name: str) -> bool:
        lock = self._locks.get(name)
        return lock is not None and lock.locked()

    def remove_lock(self, name: str) -> None:
        self._locks.pop(name, None)

    def clear(self) -> None:
        self._locks.clear()

    def __repr__(self) -> str:
        return f"<LockManager locks={len(self._locks)}>"

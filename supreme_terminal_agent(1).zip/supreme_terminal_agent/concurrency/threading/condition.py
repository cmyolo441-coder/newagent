"""Condition - Condition variable for thread synchronization."""

from __future__ import annotations

import threading
from typing import Any, Callable, Optional


class Condition:
    def __init__(self, lock: Optional[threading.Lock] = None):
        self._cond = threading.Condition(lock)

    def acquire(self, *args) -> bool:
        return self._cond.acquire(*args)

    def release(self) -> None:
        self._cond.release()

    def wait(self, timeout: Optional[float] = None) -> bool:
        return self._cond.wait(timeout=timeout)

    def notify(self, n: int = 1) -> None:
        self._cond.notify(n)

    def notify_all(self) -> None:
        self._cond.notify_all()

    def wait_for(self, predicate: Callable[[], bool], timeout: Optional[float] = None) -> bool:
        return self._cond.wait_for(predicate, timeout=timeout)

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *args) -> None:
        self.release()

    def __repr__(self) -> str:
        return "<Condition>"

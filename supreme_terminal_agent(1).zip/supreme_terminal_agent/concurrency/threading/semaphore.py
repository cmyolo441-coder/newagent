"""Semaphore - Counting semaphore for thread synchronization."""

from __future__ import annotations

import threading
from typing import Optional


class Semaphore:
    def __init__(self, value: int = 1):
        self._sem = threading.Semaphore(value)
        self._value = value

    def acquire(self, blocking: bool = True, timeout: Optional[float] = None) -> bool:
        return self._sem.acquire(blocking=blocking, timeout=timeout)

    def release(self) -> None:
        self._sem.release()

    @property
    def value(self) -> int:
        return self._value

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *args) -> None:
        self.release()

    def __repr__(self) -> str:
        return f"<Semaphore value={self._value}>"

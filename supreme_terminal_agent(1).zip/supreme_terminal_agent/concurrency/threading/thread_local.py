"""Thread Local - Thread-local storage."""

from __future__ import annotations

import threading
from typing import Any, Dict, Optional


class ThreadLocal:
    def __init__(self):
        self._local = threading.local()

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self._local, key, default)

    def set(self, key: str, value: Any) -> None:
        setattr(self._local, key, value)

    def delete(self, key: str) -> bool:
        if hasattr(self._local, key):
            delattr(self._local, key)
            return True
        return False

    def clear(self) -> None:
        self._local = threading.local()

    def __repr__(self) -> str:
        return "<ThreadLocal>"

"""Thread Manager - Manages individual threads."""

from __future__ import annotations

import logging
import threading
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)


class ThreadManager:
    def __init__(self):
        self._threads: Dict[str, threading.Thread] = {}

    def start_thread(self, name: str, target: Callable, daemon: bool = False, **kwargs) -> threading.Thread:
        thread = threading.Thread(target=target, name=name, daemon=daemon, **kwargs)
        thread.start()
        self._threads[name] = thread
        logger.debug(f"Started thread '{name}'")
        return thread

    def stop_thread(self, name: str, timeout: Optional[float] = None) -> None:
        thread = self._threads.get(name)
        if thread and thread.is_alive():
            logger.debug(f"Stopping thread '{name}'")
        self._threads.pop(name, None)

    def is_alive(self, name: str) -> bool:
        thread = self._threads.get(name)
        return thread is not None and thread.is_alive()

    def get_thread(self, name: str) -> Optional[threading.Thread]:
        return self._threads.get(name)

    @property
    def active_count(self) -> int:
        return sum(1 for t in self._threads.values() if t.is_alive())

    def stop_all(self, timeout: float = 1.0) -> None:
        for name in list(self._threads.keys()):
            self.stop_thread(name, timeout)

    def __repr__(self) -> str:
        return f"<ThreadManager threads={len(self._threads)}>"

"""SessionEvents - event system for session lifecycle events."""

import threading
from typing import Any, Callable, Dict, List, Optional


class SessionEvents:
    """Event system for subscribing to session lifecycle events."""

    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = {}
        self._lock = threading.RLock()

    def on(self, event: str, callback: Callable):
        """Register a listener for an event."""
        with self._lock:
            if event not in self._listeners:
                self._listeners[event] = []
            self._listeners[event].append(callback)

    def off(self, event: str, callback: Callable):
        """Remove a listener."""
        with self._lock:
            if event in self._listeners:
                self._listeners[event] = [
                    cb for cb in self._listeners[event] if cb != callback
                ]

    def emit(self, event: str, *args, **kwargs):
        """Emit an event to all registered listeners."""
        with self._lock:
            listeners = list(self._listeners.get(event, []))
        for callback in listeners:
            try:
                callback(*args, **kwargs)
            except Exception:
                pass

    def once(self, event: str, callback: Callable):
        """Register a one-shot listener."""
        def wrapper(*args, **kwargs):
            self.off(event, wrapper)
            callback(*args, **kwargs)
        self.on(event, wrapper)

    def listener_count(self, event: str) -> int:
        with self._lock:
            return len(self._listeners.get(event, []))

    def clear(self):
        with self._lock:
            self._listeners.clear()

    def list_events(self) -> List[str]:
        with self._lock:
            return list(self._listeners.keys())

"""SessionLock - provides locking mechanism for session operations."""

import os
import fcntl
import threading
import time
from typing import Optional


class SessionLock:
    """Provides locking for session operations to prevent concurrent access."""

    def __init__(self):
        self._lock = threading.RLock()
        self._locked = False
        self._owner: Optional[str] = None
        self._acquired_at: Optional[float] = None
        self._file_lock_path: Optional[str] = None
        self._file_lock_fd: Optional[int] = None

    def acquire(self, owner: str = "", blocking: bool = True, timeout: float = -1) -> bool:
        """Acquire the session lock."""
        start = time.time()
        while True:
            if self._lock.acquire(blocking=False):
                if not self._locked:
                    self._locked = True
                    self._owner = owner
                    self._acquired_at = time.time()
                    return True
                self._lock.release()
            if not blocking:
                return False
            if timeout >= 0 and (time.time() - start) >= timeout:
                return False
            time.sleep(0.01)

    def release(self):
        """Release the session lock."""
        with self._lock:
            self._locked = False
            self._owner = None
            self._acquired_at = None

    @property
    def is_locked(self) -> bool:
        with self._lock:
            return self._locked

    @property
    def owner(self) -> Optional[str]:
        with self._lock:
            return self._owner

    @property
    def held_seconds(self) -> float:
        with self._lock:
            if self._acquired_at:
                return time.time() - self._acquired_at
            return 0.0

    def acquire_file_lock(self, lock_path: str):
        """Acquire an OS-level file lock."""
        try:
            self._file_lock_fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o644)
            fcntl.flock(self._file_lock_fd, fcntl.LOCK_EX)
            self._file_lock_path = lock_path
        except OSError:
            pass

    def release_file_lock(self):
        """Release the OS-level file lock."""
        if self._file_lock_fd is not None:
            try:
                fcntl.flock(self._file_lock_fd, fcntl.LOCK_UN)
                os.close(self._file_lock_fd)
            except OSError:
                pass
            self._file_lock_fd = None
            self._file_lock_path = None

    def __enter__(self):
        self.acquire(blocking=True)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()

    def close(self):
        self.release()
        self.release_file_lock()

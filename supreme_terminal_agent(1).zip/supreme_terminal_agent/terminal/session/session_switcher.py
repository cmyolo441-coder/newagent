"""SessionSwitcher - handles switching between active sessions."""

import time
from typing import Dict, List, Optional

from terminal.session.session_controller import SessionController


class SessionSwitcher:
    """Manages switching focus between terminal sessions."""

    def __init__(self, manager):
        self._manager = manager
        self._current_session_id: Optional[str] = None
        self._switch_history: List[str] = []

    @property
    def current_session_id(self) -> Optional[str]:
        return self._current_session_id

    @property
    def current_session(self) -> Optional[SessionController]:
        if self._current_session_id:
            return self._manager.get_session(self._current_session_id)
        return None

    def switch(self, session_id: str) -> bool:
        """Switch focus to a session."""
        session = self._manager.get_session(session_id)
        if session is None:
            return False
        if self._current_session_id:
            prev = self._manager.get_session(self._current_session_id)
            if prev:
                prev.pause()
            self._switch_history.append(self._current_session_id)
        self._current_session_id = session_id
        session.resume()
        return True

    def switch_previous(self) -> bool:
        """Switch back to the previous session."""
        if not self._switch_history:
            return False
        prev_id = self._switch_history.pop()
        return self.switch(prev_id)

    def switch_next(self) -> bool:
        """Switch to the next session in the list."""
        session_ids = self._manager.list_sessions()
        if not session_ids:
            return False
        if self._current_session_id is None:
            return self.switch(session_ids[0])
        try:
            idx = session_ids.index(self._current_session_id)
            next_idx = (idx + 1) % len(session_ids)
            return self.switch(session_ids[next_idx])
        except ValueError:
            return self.switch(session_ids[0])

    def switch_prev(self) -> bool:
        """Switch to the previous session in the list."""
        session_ids = self._manager.list_sessions()
        if not session_ids:
            return False
        if self._current_session_id is None:
            return self.switch(session_ids[-1])
        try:
            idx = session_ids.index(self._current_session_id)
            prev_idx = (idx - 1) % len(session_ids)
            return self.switch(session_ids[prev_idx])
        except ValueError:
            return self.switch(session_ids[-1])

    def switch_by_index(self, index: int) -> bool:
        """Switch to session at given index."""
        session_ids = self._manager.list_sessions()
        if 0 <= index < len(session_ids):
            return self.switch(session_ids[index])
        return False

    def switch_by_name(self, name: str) -> bool:
        """Switch to a session by its metadata name."""
        for session_id in self._manager.list_sessions():
            session = self._manager.get_session(session_id)
            if session and session.metadata.get('name') == name:
                return self.switch(session_id)
        return False

    def get_history(self) -> List[str]:
        return list(self._switch_history)

    def clear_history(self):
        self._switch_history.clear()

    @property
    def session_index(self) -> int:
        """Get the index of the current session in the session list."""
        if self._current_session_id is None:
            return -1
        try:
            return self._manager.list_sessions().index(self._current_session_id)
        except ValueError:
            return -1

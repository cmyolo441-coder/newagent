"""SessionHistory - records input/output history for a terminal session."""

import time
import threading
from typing import Dict, List, Optional, Tuple


class SessionHistory:
    """Records input and output history for a terminal session."""

    def __init__(self, max_entries: int = 10000):
        self.max_entries = max_entries
        self._inputs: List[Tuple[float, bytes]] = []
        self._outputs: List[Tuple[float, bytes]] = []
        self._lock = threading.RLock()

    def add_input(self, data: bytes):
        with self._lock:
            self._inputs.append((time.time(), bytes(data)))
            self._trim()

    def add_output(self, data: bytes):
        with self._lock:
            self._outputs.append((time.time(), bytes(data)))
            self._trim()

    def _trim(self):
        total = len(self._inputs) + len(self._outputs)
        if total > self.max_entries:
            excess = total - self.max_entries
            remove_inputs = min(excess, len(self._inputs))
            self._inputs = self._inputs[remove_inputs:]
            excess -= remove_inputs
            if excess > 0:
                self._outputs = self._outputs[excess:]

    def get_inputs(self, limit: int = -1) -> List[Tuple[float, bytes]]:
        with self._lock:
            if limit < 0:
                return list(self._inputs)
            return self._inputs[-limit:]

    def get_outputs(self, limit: int = -1) -> List[Tuple[float, bytes]]:
        with self._lock:
            if limit < 0:
                return list(self._outputs)
            return self._outputs[-limit:]

    def get_all(self) -> Dict[str, list]:
        with self._lock:
            return {
                'inputs': list(self._inputs),
                'outputs': list(self._outputs),
            }

    def clear(self):
        with self._lock:
            self._inputs.clear()
            self._outputs.clear()

    @property
    def input_count(self) -> int:
        with self._lock:
            return len(self._inputs)

    @property
    def output_count(self) -> int:
        with self._lock:
            return len(self._outputs)

    def to_dict(self) -> dict:
        with self._lock:
            return {
                'inputs': [(t, d.hex()) for t, d in self._inputs],
                'outputs': [(t, d.hex()) for t, d in self._outputs],
            }

    def load_from(self, data: dict):
        with self._lock:
            self._inputs = [(t, bytes.fromhex(d)) for t, d in data.get('inputs', [])]
            self._outputs = [(t, bytes.fromhex(d)) for t, d in data.get('outputs', [])]

    def search(self, query: str, case_sensitive: bool = False) -> List[dict]:
        results = []
        with self._lock:
            if not case_sensitive:
                query = query.lower()
            for ts, data in self._outputs:
                text = data.decode('utf-8', errors='replace')
                match = text if case_sensitive else text.lower()
                if query in match:
                    results.append({
                        'timestamp': ts,
                        'data': text,
                        'type': 'output',
                    })
            for ts, data in self._inputs:
                text = data.decode('utf-8', errors='replace')
                match = text if case_sensitive else text.lower()
                if query in match:
                    results.append({
                        'timestamp': ts,
                        'data': text,
                        'type': 'input',
                    })
        return results

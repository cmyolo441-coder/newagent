"""SessionDestroyer - handles graceful and forced session termination."""

import os
import signal
import time
import threading
from typing import Optional

from terminal.session.session_controller import SessionController


class SessionDestroyer:
    """Handles session destruction with graceful shutdown and cleanup."""

    def __init__(self, manager):
        self._manager = manager

    def destroy(self, session: SessionController, force: bool = False):
        """Destroy a session, optionally forcing termination."""
        if force:
            self._force_destroy(session)
        else:
            self._graceful_destroy(session)

    def _graceful_destroy(self, session: SessionController):
        """Gracefully terminate a session."""
        child_pid = session.state.get('child_pid')
        if child_pid:
            try:
                os.kill(child_pid, signal.SIGTERM)
                for _ in range(50):
                    pid, status = os.waitpid(child_pid, os.WNOHANG)
                    if pid == child_pid:
                        break
                    time.sleep(0.1)
                else:
                    os.kill(child_pid, signal.SIGKILL)
                    os.waitpid(child_pid, 0)
            except (OSError, ChildProcessError):
                pass
        session.close()

    def _force_destroy(self, session: SessionController):
        """Forcefully terminate a session."""
        child_pid = session.state.get('child_pid')
        if child_pid:
            try:
                os.kill(child_pid, signal.SIGKILL)
                os.waitpid(child_pid, os.WNOHANG)
            except (OSError, ChildProcessError):
                pass
        session.close()

    def destroy_by_pid(self, pid: int):
        """Destroy the session containing the given child PID."""
        for session_id in self._manager.list_sessions():
            session = self._manager.get_session(session_id)
            if session and session.state.get('child_pid') == pid:
                self._manager.destroy_session(session_id)
                return True
        return False

    def destroy_idle_sessions(self, max_idle_seconds: float = 300.0):
        """Destroy sessions idle for longer than max_idle_seconds."""
        now = time.time()
        for session_id in self._manager.list_sessions():
            session = self._manager.get_session(session_id)
            if session and (now - session._created_at) > max_idle_seconds:
                if not session.is_active:
                    self._manager.destroy_session(session_id)

    def destroy_all(self):
        """Destroy all sessions."""
        for session_id in self._manager.list_sessions():
            self._manager.destroy_session(session_id)

    def cleanup_zombies(self):
        """Clean up zombie child processes from sessions."""
        for session_id in self._manager.list_sessions():
            session = self._manager.get_session(session_id)
            if session:
                child_pid = session.state.get('child_pid')
                if child_pid:
                    try:
                        os.waitpid(child_pid, os.WNOHANG)
                    except (OSError, ChildProcessError):
                        pass

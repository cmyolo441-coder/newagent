"""SessionRestore - restores sessions from persisted state."""

import os
import time
from typing import Dict, List, Optional

from terminal.session.session_controller import SessionController
from terminal.session.session_persistence import SessionPersistence


class SessionRestore:
    """Handles restoration of terminal sessions from saved state."""

    def __init__(self, manager):
        self._manager = manager
        self.persistence = SessionPersistence()

    def restore(self, session_id: str) -> Optional[SessionController]:
        """Restore a single session by ID."""
        state = self.persistence.load(session_id)
        if state is None:
            return None
        session = SessionController()
        session.load_state(state)
        child_pid = session.state.get('child_pid')
        if child_pid:
            try:
                os.kill(child_pid, 0)
            except OSError:
                return None
        return session

    def restore_all(self) -> List[SessionController]:
        """Restore all saved sessions."""
        sessions = []
        for session_id in self.persistence.list_saved():
            session = self.restore(session_id)
            if session:
                sessions.append(session)
        return sessions

    def restore_latest(self) -> Optional[SessionController]:
        """Restore the most recently saved session."""
        saved = self.persistence.list_saved()
        if not saved:
            return None
        latest_id = max(
            saved,
            key=lambda sid: os.path.getmtime(self.persistence._session_path(sid))
        )
        return self.restore(latest_id)

    def get_restorable(self) -> List[dict]:
        """Get metadata for all restorable sessions."""
        result = []
        for session_id in self.persistence.list_saved():
            state = self.persistence.load(session_id)
            if state:
                result.append({
                    'session_id': session_id,
                    'saved_at': state.get('_saved_at', 0),
                    'type': state.get('metadata', {}).get('type', 'unknown'),
                })
        return sorted(result, key=lambda x: x['saved_at'], reverse=True)

    def delete_restored(self, session_id: str):
        """Delete a persisted session after restoration."""
        self.persistence.delete(session_id)

    def cleanup_failed(self):
        """Clean up persisted sessions that fail to restore."""
        for session_id in self.persistence.list_saved():
            if self.restore(session_id) is None:
                self.persistence.delete(session_id)

    def restore_all_to_manager(self) -> int:
        """Restore all sessions and add them to the manager. Returns count."""
        sessions = self.restore_all()
        for session in sessions:
            pass
        return len(sessions)

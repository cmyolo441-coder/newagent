"""SessionManager - central manager for all terminal sessions."""

import time
import uuid
import threading
from typing import Dict, List, Optional, Callable

from terminal.session.session_controller import SessionController
from terminal.session.session_creator import SessionCreator
from terminal.session.session_destroyer import SessionDestroyer
from terminal.session.session_persistence import SessionPersistence
from terminal.session.session_events import SessionEvents


class SessionManager:
    """Central manager that coordinates all terminal session operations."""

    def __init__(self):
        self._sessions: Dict[str, SessionController] = {}
        self._lock = threading.RLock()
        self.creator = SessionCreator(self)
        self.destroyer = SessionDestroyer(self)
        self.persistence = SessionPersistence()
        self.events = SessionEvents()
        self._on_create: List[Callable] = []
        self._on_destroy: List[Callable] = []

    def create_session(self, session_type: str = "shell", **kwargs) -> SessionController:
        """Create a new terminal session."""
        session = self.creator.create(session_type, **kwargs)
        with self._lock:
            self._sessions[session.session_id] = session
        self.events.emit('session_created', session.session_id)
        for cb in self._on_create:
            cb(session)
        return session

    def destroy_session(self, session_id: str):
        """Destroy a terminal session."""
        with self._lock:
            session = self._sessions.pop(session_id, None)
        if session:
            self.destroyer.destroy(session)
            self.events.emit('session_destroyed', session_id)
            for cb in self._on_destroy:
                cb(session_id)

    def get_session(self, session_id: str) -> Optional[SessionController]:
        with self._lock:
            return self._sessions.get(session_id)

    def list_sessions(self) -> List[str]:
        with self._lock:
            return list(self._sessions.keys())

    def list_active_sessions(self) -> List[SessionController]:
        with self._lock:
            return [s for s in self._sessions.values() if s.is_active]

    def get_session_count(self) -> int:
        with self._lock:
            return len(self._sessions)

    def on_create(self, callback: Callable):
        self._on_create.append(callback)

    def on_destroy(self, callback: Callable):
        self._on_destroy.append(callback)

    def save_all(self):
        """Persist all active sessions."""
        with self._lock:
            for session_id, session in self._sessions.items():
                self.persistence.save(session_id, session.get_state())

    def restore_all(self):
        """Restore all persisted sessions."""
        states = self.persistence.restore_all()
        for state in states:
            try:
                session = self.creator.restore(state)
                with self._lock:
                    self._sessions[session.session_id] = session
            except (ValueError, RuntimeError):
                pass

    def destroy_all(self):
        """Destroy all sessions."""
        with self._lock:
            session_ids = list(self._sessions.keys())
        for sid in session_ids:
            self.destroy_session(sid)

    def broadcast(self, data: bytes, exclude: Optional[List[str]] = None):
        """Broadcast data to all sessions."""
        exclude = exclude or []
        with self._lock:
            for session_id, session in self._sessions.items():
                if session_id not in exclude:
                    try:
                        session.write(data)
                    except (RuntimeError, OSError):
                        pass

    def close(self):
        """Clean up all sessions and resources."""
        self.destroy_all()
        self.persistence.close()

"""SessionSharing - manages sharing terminal sessions between users."""

import time
import uuid
import threading
from typing import Dict, List, Optional, Set, Callable

from terminal.session.session_controller import SessionController


class SessionSharing:
    """Manages sharing of terminal sessions between multiple users/consumers."""

    def __init__(self):
        self._shared_sessions: Dict[str, Set[str]] = {}
        self._share_tokens: Dict[str, str] = {}
        self._on_join: List[Callable] = []
        self._on_leave: List[Callable] = []
        self._lock = threading.RLock()

    def share(self, session_id: str, user_id: str, permission: str = "read") -> str:
        """Share a session with a user. Returns a share token."""
        token = str(uuid.uuid4())
        with self._lock:
            if session_id not in self._shared_sessions:
                self._shared_sessions[session_id] = set()
            self._shared_sessions[session_id].add(user_id)
            self._share_tokens[token] = session_id
        return token

    def unshare(self, session_id: str, user_id: str):
        """Remove a user's access to a shared session."""
        with self._lock:
            if session_id in self._shared_sessions:
                self._shared_sessions[session_id].discard(user_id)
                if not self._shared_sessions[session_id]:
                    del self._shared_sessions[session_id]
            tokens_to_remove = [
                t for t, s in self._share_tokens.items()
                if s == session_id
            ]
            for t in tokens_to_remove:
                del self._share_tokens[t]

    def join(self, token: str, user_id: str) -> Optional[str]:
        """Join a shared session using a token."""
        with self._lock:
            session_id = self._share_tokens.get(token)
            if session_id is None:
                return None
            if session_id not in self._shared_sessions:
                return None
            self._shared_sessions[session_id].add(user_id)
            for cb in self._on_join:
                cb(session_id, user_id)
            return session_id

    def leave(self, session_id: str, user_id: str):
        """Leave a shared session."""
        self.unshare(session_id, user_id)
        for cb in self._on_leave:
            cb(session_id, user_id)

    def get_shared_users(self, session_id: str) -> List[str]:
        with self._lock:
            return list(self._shared_sessions.get(session_id, set()))

    def get_shared_sessions(self) -> List[str]:
        with self._lock:
            return list(self._shared_sessions.keys())

    def is_shared(self, session_id: str) -> bool:
        with self._lock:
            return session_id in self._shared_sessions

    def get_share_count(self, session_id: str) -> int:
        with self._lock:
            return len(self._shared_sessions.get(session_id, set()))

    def revoke_token(self, token: str):
        with self._lock:
            self._share_tokens.pop(token, None)

    def generate_token(self) -> str:
        return str(uuid.uuid4())

    def on_join(self, callback: Callable):
        self._on_join.append(callback)

    def on_leave(self, callback: Callable):
        self._on_leave.append(callback)

    def broadcast_to_session(self, session_id: str, data: bytes, exclude: Optional[List[str]] = None):
        """Broadcast data to all users sharing a session."""
        pass

    def close(self):
        self._shared_sessions.clear()
        self._share_tokens.clear()

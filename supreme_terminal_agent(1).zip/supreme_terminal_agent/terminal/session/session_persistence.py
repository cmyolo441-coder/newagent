"""SessionPersistence - saves and loads session state to/from disk."""

import json
import os
import time
import threading
from typing import Dict, List, Optional


class SessionPersistence:
    """Persists terminal session state to disk for later restoration."""

    DEFAULT_DIR = os.path.expanduser("~/.config/supreme-terminal/sessions")

    def __init__(self, storage_dir: Optional[str] = None):
        self.storage_dir = storage_dir or self.DEFAULT_DIR
        self._lock = threading.Lock()
        os.makedirs(self.storage_dir, exist_ok=True)

    def _session_path(self, session_id: str) -> str:
        return os.path.join(self.storage_dir, f"{session_id}.json")

    def save(self, session_id: str, state: dict):
        """Save session state to disk."""
        with self._lock:
            path = self._session_path(session_id)
            state['_saved_at'] = time.time()
            with open(path, 'w') as f:
                json.dump(state, f, indent=2, default=str)

    def load(self, session_id: str) -> Optional[dict]:
        """Load session state from disk."""
        with self._lock:
            path = self._session_path(session_id)
            if not os.path.exists(path):
                return None
            try:
                with open(path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                return None

    def delete(self, session_id: str):
        """Delete a saved session file."""
        with self._lock:
            path = self._session_path(session_id)
            try:
                if os.path.exists(path):
                    os.remove(path)
            except OSError:
                pass

    def list_saved(self) -> List[str]:
        """List all saved session IDs."""
        with self._lock:
            sessions = []
            for fname in os.listdir(self.storage_dir):
                if fname.endswith('.json'):
                    sessions.append(fname[:-5])
            return sessions

    def restore_all(self) -> List[dict]:
        """Restore all saved sessions."""
        states = []
        for session_id in self.list_saved():
            state = self.load(session_id)
            if state:
                states.append(state)
        return states

    def save_all(self, sessions: Dict[str, dict]):
        """Save multiple sessions at once."""
        for session_id, state in sessions.items():
            self.save(session_id, state)

    def get_saved_count(self) -> int:
        return len(self.list_saved())

    def get_storage_size(self) -> int:
        """Get total size of session storage in bytes."""
        total = 0
        with self._lock:
            for fname in os.listdir(self.storage_dir):
                path = os.path.join(self.storage_dir, fname)
                if os.path.isfile(path):
                    total += os.path.getsize(path)
        return total

    def cleanup_old(self, max_age_seconds: float = 86400 * 30):
        """Remove session files older than max_age_seconds."""
        now = time.time()
        for session_id in self.list_saved():
            path = self._session_path(session_id)
            try:
                age = now - os.path.getmtime(path)
                if age > max_age_seconds:
                    os.remove(path)
            except OSError:
                pass

    def close(self):
        pass

"""SessionIsolation - provides isolation between terminal sessions."""

import os
import tempfile
import threading
from typing import Dict, List, Optional


class SessionIsolation:
    """Provides filesystem and process isolation for terminal sessions."""

    def __init__(self):
        self._isolated_dirs: Dict[str, str] = {}
        self._lock = threading.Lock()

    def create_isolated_env(self, session_id: str) -> str:
        """Create an isolated temporary directory for a session."""
        tmpdir = tempfile.mkdtemp(prefix=f"session_{session_id[:8]}_")
        with self._lock:
            self._isolated_dirs[session_id] = tmpdir
        return tmpdir

    def remove_isolated_env(self, session_id: str):
        """Remove the isolated environment for a session."""
        with self._lock:
            tmpdir = self._isolated_dirs.pop(session_id, None)
            if tmpdir and os.path.exists(tmpdir):
                import shutil
                shutil.rmtree(tmpdir, ignore_errors=True)

    def get_isolated_dir(self, session_id: str) -> Optional[str]:
        with self._lock:
            return self._isolated_dirs.get(session_id)

    def get_isolated_env_vars(self, session_id: str) -> Dict[str, str]:
        """Get environment variables for an isolated session."""
        tmpdir = self.get_isolated_dir(session_id)
        if tmpdir is None:
            return {}
        return {
            'HOME': tmpdir,
            'TMPDIR': tmpdir,
            'PWD': tmpdir,
            'USER': f"session_{session_id[:8]}",
        }

    def is_isolated(self, session_id: str) -> bool:
        with self._lock:
            return session_id in self._isolated_dirs

    def cleanup_all(self):
        """Clean up all isolated environments."""
        with self._lock:
            for session_id in list(self._isolated_dirs.keys()):
                self.remove_isolated_env(session_id)

    def get_isolated_count(self) -> int:
        with self._lock:
            return len(self._isolated_dirs)

    def close(self):
        self.cleanup_all()

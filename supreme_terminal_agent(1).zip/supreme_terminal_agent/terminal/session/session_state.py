"""SessionState - manages the runtime state of a terminal session."""

import os
import threading
from typing import Any, Dict, Optional


class SessionState:
    """Manages mutable runtime state for a terminal session."""

    def __init__(self):
        self._state: Dict[str, Any] = {
            'rows': 24,
            'cols': 80,
            'cwd': os.getcwd(),
            'child_pid': None,
            'shell': '/bin/bash',
            'env': {},
            'exit_code': None,
        }
        self._lock = threading.RLock()

    def set(self, key: str, value: Any):
        with self._lock:
            self._state[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._state.get(key, default)

    def update(self, data: Dict[str, Any]):
        with self._lock:
            self._state.update(data)

    @property
    def rows(self) -> int:
        return self.get('rows', 24)

    @rows.setter
    def rows(self, value: int):
        self.set('rows', value)

    @property
    def cols(self) -> int:
        return self.get('cols', 80)

    @cols.setter
    def cols(self, value: int):
        self.set('cols', value)

    @property
    def cwd(self) -> str:
        return self.get('cwd', os.getcwd())

    @cwd.setter
    def cwd(self, value: str):
        self.set('cwd', value)

    @property
    def child_pid(self) -> Optional[int]:
        return self.get('child_pid')

    @child_pid.setter
    def child_pid(self, value: Optional[int]):
        self.set('child_pid', value)

    def to_dict(self) -> dict:
        with self._lock:
            return dict(self._state)

    def load_from(self, data: dict):
        with self._lock:
            self._state.update(data)

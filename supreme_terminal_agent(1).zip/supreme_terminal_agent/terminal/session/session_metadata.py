"""SessionMetadata - stores metadata about a terminal session."""

import time
import threading
from typing import Any, Dict, Optional


class SessionMetadata:
    """Stores descriptive metadata about a terminal session."""

    def __init__(self):
        self._data: Dict[str, Any] = {
            'name': '',
            'type': 'shell',
            'description': '',
            'tags': [],
            'created_at': time.time(),
            'last_active': time.time(),
            'icon': '',
            'color': '',
        }
        self._lock = threading.RLock()

    def set(self, key: str, value: Any):
        with self._lock:
            self._data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._data.get(key, default)

    def update(self, data: Dict[str, Any]):
        with self._lock:
            self._data.update(data)

    def add_tag(self, tag: str):
        with self._lock:
            if tag not in self._data.get('tags', []):
                self._data.setdefault('tags', []).append(tag)

    def remove_tag(self, tag: str):
        with self._lock:
            tags = self._data.get('tags', [])
            if tag in tags:
                tags.remove(tag)

    @property
    def name(self) -> str:
        return self.get('name', '')

    @name.setter
    def name(self, value: str):
        self.set('name', value)

    @property
    def type(self) -> str:
        return self.get('type', 'shell')

    @type.setter
    def type(self, value: str):
        self.set('type', value)

    @property
    def tags(self) -> list:
        return self.get('tags', [])

    def to_dict(self) -> dict:
        with self._lock:
            return dict(self._data)

    def load_from(self, data: dict):
        with self._lock:
            self._data.update(data)

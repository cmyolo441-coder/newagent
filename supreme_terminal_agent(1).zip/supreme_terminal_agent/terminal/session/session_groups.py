"""SessionGroups - manages groups of related terminal sessions."""

import time
import uuid
import threading
from typing import Dict, List, Optional, Set, Callable


class SessionGroup:
    """Represents a group of related sessions."""

    def __init__(self, name: str, group_id: Optional[str] = None):
        self.group_id = group_id or str(uuid.uuid4())
        self.name = name
        self.session_ids: Set[str] = set()
        self.metadata: Dict[str, object] = {}
        self.created_at = time.time()

    def add_session(self, session_id: str):
        self.session_ids.add(session_id)

    def remove_session(self, session_id: str):
        self.session_ids.discard(session_id)

    def has_session(self, session_id: str) -> bool:
        return session_id in self.session_ids

    @property
    def session_count(self) -> int:
        return len(self.session_ids)

    def to_dict(self) -> dict:
        return {
            'group_id': self.group_id,
            'name': self.name,
            'session_ids': list(self.session_ids),
            'metadata': self.metadata,
            'created_at': self.created_at,
        }


class SessionGroups:
    """Manages grouping of terminal sessions."""

    def __init__(self):
        self._groups: Dict[str, SessionGroup] = {}
        self._session_to_groups: Dict[str, Set[str]] = {}
        self._lock = threading.RLock()

    def create_group(self, name: str) -> SessionGroup:
        group = SessionGroup(name)
        with self._lock:
            self._groups[group.group_id] = group
        return group

    def delete_group(self, group_id: str):
        with self._lock:
            group = self._groups.pop(group_id, None)
            if group:
                for sid in group.session_ids:
                    if sid in self._session_to_groups:
                        self._session_to_groups[sid].discard(group_id)

    def add_to_group(self, session_id: str, group_id: str) -> bool:
        with self._lock:
            group = self._groups.get(group_id)
            if group is None:
                return False
            group.add_session(session_id)
            if session_id not in self._session_to_groups:
                self._session_to_groups[session_id] = set()
            self._session_to_groups[session_id].add(group_id)
            return True

    def remove_from_group(self, session_id: str, group_id: str):
        with self._lock:
            group = self._groups.get(group_id)
            if group:
                group.remove_session(session_id)
            if session_id in self._session_to_groups:
                self._session_to_groups[session_id].discard(group_id)

    def get_group(self, group_id: str) -> Optional[SessionGroup]:
        with self._lock:
            return self._groups.get(group_id)

    def get_groups_for_session(self, session_id: str) -> List[SessionGroup]:
        with self._lock:
            group_ids = self._session_to_groups.get(session_id, set())
            return [self._groups[gid] for gid in group_ids if gid in self._groups]

    def get_sessions_in_group(self, group_id: str) -> List[str]:
        with self._lock:
            group = self._groups.get(group_id)
            return list(group.session_ids) if group else []

    def list_groups(self) -> List[SessionGroup]:
        with self._lock:
            return list(self._groups.values())

    def broadcast_to_group(self, group_id: str, data: bytes):
        """Broadcast data to all sessions in a group."""
        with self._lock:
            group = self._groups.get(group_id)
            if group is None:
                return
            session_ids = list(group.session_ids)
        for sid in session_ids:
            pass

    @property
    def group_count(self) -> int:
        with self._lock:
            return len(self._groups)

    def clear(self):
        with self._lock:
            self._groups.clear()
            self._session_to_groups.clear()

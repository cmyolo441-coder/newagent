"""Session management module for terminal sessions."""

from terminal.session.session_manager import SessionManager
from terminal.session.session_controller import SessionController
from terminal.session.session_creator import SessionCreator
from terminal.session.session_destroyer import SessionDestroyer
from terminal.session.session_switcher import SessionSwitcher
from terminal.session.session_persistence import SessionPersistence
from terminal.session.session_restore import SessionRestore
from terminal.session.session_snapshot import SessionSnapshot
from terminal.session.session_sharing import SessionSharing
from terminal.session.session_isolation import SessionIsolation
from terminal.session.session_groups import SessionGroups
from terminal.session.session_history import SessionHistory
from terminal.session.session_metadata import SessionMetadata
from terminal.session.session_state import SessionState
from terminal.session.session_lock import SessionLock
from terminal.session.session_events import SessionEvents

__all__ = [
    'SessionManager', 'SessionController', 'SessionCreator',
    'SessionDestroyer', 'SessionSwitcher', 'SessionPersistence',
    'SessionRestore', 'SessionSnapshot', 'SessionSharing',
    'SessionIsolation', 'SessionGroups', 'SessionHistory',
    'SessionMetadata', 'SessionState', 'SessionLock', 'SessionEvents',
]

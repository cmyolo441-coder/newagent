"""SessionCreator - factory for creating new terminal sessions."""

import os
import pty
import uuid
import threading
from typing import Any, Dict, Optional

from terminal.session.session_controller import SessionController


class SessionCreator:
    """Factory for creating and configuring new terminal sessions."""

    def __init__(self, manager):
        self._manager = manager

    def create(self, session_type: str = "shell", **kwargs) -> SessionController:
        """Create a new session based on type."""
        creators = {
            'shell': self._create_shell_session,
            'command': self._create_command_session,
            'capture': self._create_capture_session,
        }
        creator = creators.get(session_type, self._create_shell_session)
        return creator(**kwargs)

    def _create_shell_session(self, **kwargs) -> SessionController:
        session = SessionController()
        rows = kwargs.get('rows', 24)
        cols = kwargs.get('cols', 80)
        shell = kwargs.get('shell', os.environ.get('SHELL', '/bin/bash'))
        session.metadata.set('type', 'shell')
        session.metadata.set('shell', shell)
        session.metadata.set('created_by', kwargs.get('created_by', 'system'))
        session.initialize(rows=rows, cols=cols, shell=shell)
        return session

    def _create_command_session(self, **kwargs) -> SessionController:
        session = SessionController()
        command = kwargs.get('command', '')
        rows = kwargs.get('rows', 24)
        cols = kwargs.get('cols', 80)
        shell = kwargs.get('shell', '/bin/bash')
        session.metadata.set('type', 'command')
        session.metadata.set('command', command)
        session.initialize(rows=rows, cols=cols, shell=shell)
        if command:
            session.writeline(command)
        return session

    def _create_capture_session(self, **kwargs) -> SessionController:
        session = self._create_shell_session(**kwargs)
        session.metadata.set('type', 'capture')
        session.metadata.set('capture_output', True)
        return session

    def restore(self, state: dict) -> SessionController:
        """Restore a session from saved state."""
        session = SessionController()
        session.load_state(state)
        return session

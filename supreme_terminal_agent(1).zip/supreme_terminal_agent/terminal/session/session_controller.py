"""SessionController - controls an individual terminal session."""

import os
import time
import uuid
import threading
from enum import Enum
from typing import Any, Dict, Optional, Callable

from terminal.pty.pty_master import PtyMaster
from terminal.session.session_state import SessionState
from terminal.session.session_metadata import SessionMetadata
from terminal.session.session_lock import SessionLock
from terminal.session.session_history import SessionHistory


class SessionStatus(Enum):
    CREATED = "created"
    INITIALIZING = "initializing"
    ACTIVE = "active"
    PAUSED = "paused"
    CLOSED = "closed"
    ERROR = "error"


class SessionController:
    """Controls a single terminal session's lifecycle and I/O."""

    def __init__(self, session_id: Optional[str] = None):
        self.session_id = session_id or str(uuid.uuid4())
        self.state = SessionState()
        self.metadata = SessionMetadata()
        self.lock = SessionLock()
        self.history = SessionHistory()
        self.pty: Optional[PtyMaster] = None
        self._status = SessionStatus.CREATED
        self._created_at = time.time()
        self._lock = threading.RLock()
        self._on_data: List[Callable] = []

    @property
    def is_active(self) -> bool:
        return self._status == SessionStatus.ACTIVE

    @property
    def status(self) -> SessionStatus:
        return self._status

    @status.setter
    def status(self, value: SessionStatus):
        with self._lock:
            self._status = value

    def initialize(self, rows: int = 24, cols: int = 80, shell: str = "/bin/bash"):
        """Initialize the session with a PTY."""
        with self._lock:
            status = SessionStatus.INITIALIZING
            self.pty = PtyMaster()
            self.pty.open()
            self.state.set('rows', rows)
            self.state.set('cols', cols)
            self.state.set('shell', shell)
            self.state.set('cwd', os.getcwd())
            self._spawn_shell(shell, rows, cols)
            self._status = SessionStatus.ACTIVE

    def _spawn_shell(self, shell: str, rows: int, cols: int):
        """Spawn a shell process in the PTY."""
        import pty
        pid = os.fork()
        if pid == 0:
            try:
                os.setsid()
                os.dup2(self.pty.slave_fd, 0)
                os.dup2(self.pty.slave_fd, 1)
                os.dup2(self.pty.slave_fd, 2)
                if self.pty.slave_fd > 2:
                    os.close(self.pty.slave_fd)
                os.execve(shell, [shell], os.environ.copy())
            except OSError:
                os._exit(1)
        else:
            self.state.set('child_pid', pid)

    def read(self, size: int = 4096) -> bytes:
        if self.pty is None:
            return b''
        data = self.pty.read(size)
        if data:
            self.history.add_output(data)
        return data

    def write(self, data: bytes) -> int:
        if self.pty is None:
            raise RuntimeError("Session not initialized")
        result = self.pty.write(data)
        self.history.add_input(data)
        return result

    def writeline(self, text: str):
        self.write((text + '\n').encode('utf-8', errors='replace'))

    def resize(self, rows: int, cols: int):
        if self.pty is not None:
            self.pty.resize(rows, cols)
            self.state.set('rows', rows)
            self.state.set('cols', cols)

    def pause(self):
        with self._lock:
            self._status = SessionStatus.PAUSED

    def resume(self):
        with self._lock:
            if self._status == SessionStatus.PAUSED:
                self._status = SessionStatus.ACTIVE

    def close(self):
        with self._lock:
            self._status = SessionStatus.CLOSED
            if self.pty:
                self.pty.close()
                self.pty = None

    def get_state(self) -> dict:
        with self._lock:
            return {
                'session_id': self.session_id,
                'status': self._status.value,
                'state': self.state.to_dict(),
                'metadata': self.metadata.to_dict(),
                'history': self.history.to_dict(),
                'created_at': self._created_at,
            }

    def load_state(self, state: dict):
        with self._lock:
            self.session_id = state.get('session_id', self.session_id)
            self.state.load_from(state.get('state', {}))
            self.metadata.load_from(state.get('metadata', {}))
            self.history.load_from(state.get('history', {}))
            self._status = SessionStatus(state.get('status', 'created'))

    def on_data(self, callback: Callable):
        self._on_data.append(callback)

    @property
    def uptime(self) -> float:
        return time.time() - self._created_at

    def fileno(self) -> int:
        if self.pty is None or self.pty.master_fd is None:
            raise RuntimeError("Session PTY not available")
        return self.pty.master_fd

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

"""SessionSnapshot - creates and manages point-in-time session snapshots."""

import time
import json
import os
import threading
import uuid
from typing import Dict, List, Optional

from terminal.session.session_controller import SessionController


class SessionSnapshot:
    """Creates and manages point-in-time snapshots of terminal sessions."""

    def __init__(self, storage_dir: Optional[str] = None):
        self.storage_dir = storage_dir or os.path.expanduser(
            "~/.config/supreme-terminal/snapshots"
        )
        self._lock = threading.Lock()
        os.makedirs(self.storage_dir, exist_ok=True)

    def take(self, session: SessionController, name: Optional[str] = None) -> str:
        """Take a snapshot of the current session state."""
        snapshot_id = str(uuid.uuid4())
        snapshot = {
            'snapshot_id': snapshot_id,
            'name': name or f"snapshot_{snapshot_id[:8]}",
            'timestamp': time.time(),
            'session_id': session.session_id,
            'state': session.get_state(),
        }
        path = os.path.join(self.storage_dir, f"{snapshot_id}.json")
        with self._lock:
            with open(path, 'w') as f:
                json.dump(snapshot, f, indent=2, default=str)
        return snapshot_id

    def load(self, snapshot_id: str) -> Optional[dict]:
        """Load a snapshot by ID."""
        path = os.path.join(self.storage_dir, f"{snapshot_id}.json")
        if not os.path.exists(path):
            return None
        with self._lock:
            try:
                with open(path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                return None

    def delete(self, snapshot_id: str):
        """Delete a snapshot."""
        path = os.path.join(self.storage_dir, f"{snapshot_id}.json")
        with self._lock:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except OSError:
                pass

    def list_snapshots(self) -> List[dict]:
        """List all available snapshots."""
        snapshots = []
        with self._lock:
            for fname in os.listdir(self.storage_dir):
                if fname.endswith('.json'):
                    try:
                        with open(os.path.join(self.storage_dir, fname), 'r') as f:
                            snap = json.load(f)
                            snapshots.append({
                                'snapshot_id': snap.get('snapshot_id', fname[:-5]),
                                'name': snap.get('name', ''),
                                'timestamp': snap.get('timestamp', 0),
                                'session_id': snap.get('session_id', ''),
                            })
                    except (json.JSONDecodeError, OSError):
                        pass
        return sorted(snapshots, key=lambda s: s['timestamp'], reverse=True)

    def list_for_session(self, session_id: str) -> List[dict]:
        """List snapshots for a specific session."""
        return [s for s in self.list_snapshots() if s['session_id'] == session_id]

    def get_latest(self, session_id: str) -> Optional[dict]:
        """Get the latest snapshot for a session."""
        snapshots = self.list_for_session(session_id)
        if snapshots:
            return snapshots[0]
        return None

    def restore(self, snapshot_id: str, session: SessionController) -> bool:
        """Restore a session from a snapshot."""
        snapshot = self.load(snapshot_id)
        if snapshot is None:
            return False
        session.load_state(snapshot.get('state', {}))
        return True

    def cleanup_old(self, max_count: int = 100):
        """Remove oldest snapshots exceeding max_count."""
        snapshots = self.list_snapshots()
        if len(snapshots) <= max_count:
            return
        to_delete = snapshots[max_count:]
        for snap in to_delete:
            self.delete(snap['snapshot_id'])

    def get_count(self) -> int:
        return len(self.list_snapshots())

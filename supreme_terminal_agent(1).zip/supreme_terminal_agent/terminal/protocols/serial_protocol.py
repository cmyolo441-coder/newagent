"""SerialProtocol - serial port connection protocol."""

import os
import termios
import tty
from typing import Any, Dict, Optional

from terminal.protocols.base_protocol import BaseProtocol


class SerialProtocol(BaseProtocol):
    """Serial port connection via termios."""

    def __init__(self, device: str = "/dev/ttyUSB0",
                 baudrate: int = 115200, rows: int = 24, cols: int = 80,
                 **kwargs: Any):
        super().__init__(**kwargs)
        self._device = device
        self._baudrate = baudrate
        self._rows = rows
        self._cols = cols

    def get_type(self) -> str:
        return "serial"

    def _baud_to_rate(self) -> int:
        table = {
            50: termios.B50, 75: termios.B75, 110: termios.B110,
            134: termios.B134, 150: termios.B150, 200: termios.B200,
            300: termios.B300, 600: termios.B600, 1200: termios.B1200,
            1800: termios.B1800, 2400: termios.B2400,
            4800: termios.B4800, 9600: termios.B9600,
            19200: termios.B19200, 38400: termios.B38400,
            57600: termios.B57600, 115200: termios.B115200,
            230400: termios.B230400,
        }
        return table.get(self._baudrate, termios.B115200)

    def connect(self) -> int:
        fd = os.open(self._device, os.O_RDWR | os.O_NOCTTY)
        attrs = termios.tcgetattr(fd)
        rate = self._baud_to_rate()
        attrs[0] = 0
        attrs[1] = 0
        attrs[2] = termios.HUPCL | termios.CREAD | termios.CLOCAL
        attrs[3] = termios.ICANON | termios.ISIG | termios.ECHO
        attrs[4] = rate
        attrs[5] = rate
        attrs[6][termios.VMIN] = 1
        attrs[6][termios.VTIME] = 0
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
        self._fd = fd
        self._connected = True
        return fd

    def disconnect(self):
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
        self._connected = False
        self._fd = None

    def read(self, size: int = 4096) -> bytes:
        if self._fd is None:
            return b""
        try:
            return os.read(self._fd, size)
        except OSError:
            return b""

    def write(self, data: bytes) -> int:
        if self._fd is None:
            return 0
        try:
            return os.write(self._fd, data)
        except OSError:
            return 0

    def resize(self, rows: int, cols: int) -> bool:
        self._rows = rows
        self._cols = cols
        return True

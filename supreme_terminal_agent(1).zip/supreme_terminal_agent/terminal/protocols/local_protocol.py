"""LocalProtocol - local PTY-based protocol."""

import os
import pty
import tty
from typing import Any, Dict, Optional

from terminal.protocols.base_protocol import BaseProtocol


class LocalProtocol(BaseProtocol):
    """Local terminal connection via fork/exec with PTY."""

    def __init__(self, shell: str = "/bin/bash", rows: int = 24,
                 cols: int = 80, **kwargs: Any):
        super().__init__(**kwargs)
        self._shell = shell
        self._rows = rows
        self._cols = cols
        self._child_pid: Optional[int] = None

    def get_type(self) -> str:
        return "local"

    def connect(self) -> int:
        pid, fd = pty.fork()
        if pid == 0:
            os.environ["TERM"] = "xterm-256color"
            os.environ["SHELL"] = self._shell
            if self._rows and self._cols:
                import struct
                import fcntl
                import termios as t
                winsize = struct.pack("HHHH", self._rows, self._cols, 0, 0)
                fcntl.ioctl(0, t.TIOCSWINSZ, winsize)
            os.execvp(self._shell, [self._shell, "-i"])
        else:
            self._child_pid = pid
            self._fd = fd
            self._connected = True
            return fd

    def disconnect(self):
        if self._child_pid:
            try:
                os.kill(self._child_pid, 15)
                os.waitpid(self._child_pid, 0)
            except OSError:
                pass
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
        self._connected = False
        self._child_pid = None
        self._fd = None

    def read(self, size: int = 4096) -> bytes:
        if self._fd is None:
            return b""
        try:
            return os.read(self._fd, size)
        except OSError:
            return b""

    def write(self, data: bytes) -> int:
        if self._fd is None:
            return 0
        try:
            return os.write(self._fd, data)
        except OSError:
            return 0

    def resize(self, rows: int, cols: int) -> bool:
        if self._fd is None:
            return False
        import struct
        import fcntl
        import termios as t
        try:
            winsize = struct.pack("HHHH", rows, cols, 0, 0)
            fcntl.ioctl(self._fd, t.TIOCSWINSZ, winsize)
            self._rows = rows
            self._cols = cols
            return True
        except OSError:
            return False

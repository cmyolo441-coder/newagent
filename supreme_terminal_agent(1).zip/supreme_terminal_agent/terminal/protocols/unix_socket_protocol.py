"""UnixSocketProtocol - Unix domain socket connection protocol."""

import os
import socket
from typing import Any, Dict, Optional

from terminal.protocols.base_protocol import BaseProtocol


class UnixSocketProtocol(BaseProtocol):
    """Unix domain socket (AF_UNIX) connection."""

    def __init__(self, path: str = "/tmp/terminal.sock",
                 rows: int = 24, cols: int = 80, **kwargs: Any):
        super().__init__(**kwargs)
        self._path = path
        self._rows = rows
        self._cols = cols
        self._sock: Optional[socket.socket] = None

    def get_type(self) -> str:
        return "unix_socket"

    def connect(self) -> int:
        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._sock.settimeout(30)
        self._sock.connect(self._path)
        self._sock.settimeout(None)
        fd = self._sock.fileno()
        self._fd = fd
        self._connected = True
        return fd

    def disconnect(self):
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass
        self._connected = False
        self._sock = None
        self._fd = None

    def read(self, size: int = 4096) -> bytes:
        if self._sock is None:
            return b""
        try:
            return self._sock.recv(size)
        except (OSError, ConnectionError):
            return b""

    def write(self, data: bytes) -> int:
        if self._sock is None:
            return 0
        try:
            return self._sock.send(data)
        except (OSError, ConnectionError):
            return 0

    def resize(self, rows: int, cols: int) -> bool:
        self._rows = rows
        self._cols = cols
        return True

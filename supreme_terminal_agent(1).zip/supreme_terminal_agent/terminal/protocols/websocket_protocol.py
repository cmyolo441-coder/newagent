"""WebSocketProtocol - WebSocket connection protocol."""

import os
import pty
import subprocess
from typing import Any, Dict, Optional

from terminal.protocols.base_protocol import BaseProtocol


class WebSocketProtocol(BaseProtocol):
    """WebSocket connection via subprocess tunnel."""

    def __init__(self, url: str = "", rows: int = 24, cols: int = 80,
                 **kwargs: Any):
        super().__init__(**kwargs)
        self._url = url
        self._rows = rows
        self._cols = cols
        self._proc: Optional[subprocess.Popen] = None

    def get_type(self) -> str:
        return "websocket"

    def connect(self) -> int:
        master_fd, slave_fd = pty.openpty()
        args = ["websocat", self._url]
        self._proc = subprocess.Popen(
            args, stdin=slave_fd, stdout=slave_fd,
            stderr=slave_fd, close_fds=True,
        )
        os.close(slave_fd)
        self._fd = master_fd
        self._connected = True
        self.resize(self._rows, self._cols)
        return master_fd

    def disconnect(self):
        if self._proc:
            try:
                self._proc.terminate()
                self._proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                self._proc.wait()
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
        self._connected = False
        self._proc = None
        self._fd = None

    def read(self, size: int = 4096) -> bytes:
        if self._fd is None:
            return b""
        try:
            return os.read(self._fd, size)
        except OSError:
            return b""

    def write(self, data: bytes) -> int:
        if self._fd is None:
            return 0
        try:
            return os.write(self._fd, data)
        except OSError:
            return 0

    def resize(self, rows: int, cols: int) -> bool:
        if self._fd is None:
            return False
        import struct
        import fcntl
        import termios as t
        try:
            winsize = struct.pack("HHHH", rows, cols, 0, 0)
            fcntl.ioctl(self._fd, t.TIOCSWINSZ, winsize)
            self._rows = rows
            self._cols = cols
            return True
        except OSError:
            return False

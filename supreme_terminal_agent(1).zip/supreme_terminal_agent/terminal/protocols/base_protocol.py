"""BaseProtocol - abstract base for all connection protocols."""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class BaseProtocol(ABC):
    """Abstract base class for terminal connection protocols."""

    def __init__(self, **kwargs: Any):
        self._config: Dict[str, Any] = kwargs
        self._connected = False
        self._fd: Optional[int] = None

    @abstractmethod
    def connect(self) -> int:
        ...

    @abstractmethod
    def disconnect(self):
        ...

    def is_connected(self) -> bool:
        return self._connected

    def get_fd(self) -> Optional[int]:
        return self._fd

    def get_config(self) -> Dict[str, Any]:
        return dict(self._config)

    @abstractmethod
    def read(self, size: int = 4096) -> bytes:
        ...

    @abstractmethod
    def write(self, data: bytes) -> int:
        ...

    @abstractmethod
    def resize(self, rows: int, cols: int) -> bool:
        ...

    @abstractmethod
    def get_type(self) -> str:
        ...

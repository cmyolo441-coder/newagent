"""ProtocolManager - factory and registry for connection protocols."""

from typing import Any, Dict, Optional, Type

from terminal.protocols.base_protocol import BaseProtocol


class ProtocolManager:
    """Manages protocol registration and instantiation."""

    def __init__(self):
        self._registry: Dict[str, Type[BaseProtocol]] = {}

    def register(self, name: str, cls: Type[BaseProtocol]):
        self._registry[name] = cls

    def unregister(self, name: str):
        self._registry.pop(name, None)

    def create(self, name: str, **kwargs: Any) -> Optional[BaseProtocol]:
        cls = self._registry.get(name)
        if cls is None:
            return None
        return cls(**kwargs)

    def list_protocols(self) -> Dict[str, Type[BaseProtocol]]:
        return dict(self._registry)

    def supports(self, name: str) -> bool:
        return name in self._registry

"""SshProtocol - SSH connection protocol."""

import os
import pty
import subprocess
from typing import Any, Dict, List, Optional

from terminal.protocols.base_protocol import BaseProtocol


class SshProtocol(BaseProtocol):
    """SSH connection via subprocess with PTY."""

    def __init__(self, host: str = "", port: int = 22,
                 user: str = "", identity_file: str = "",
                 rows: int = 24, cols: int = 80, **kwargs: Any):
        super().__init__(**kwargs)
        self._host = host
        self._port = port
        self._user = user
        self._identity_file = identity_file
        self._rows = rows
        self._cols = cols
        self._proc: Optional[subprocess.Popen] = None

    def get_type(self) -> str:
        return "ssh"

    def _build_args(self) -> List[str]:
        args = ["ssh", "-tt"]
        if self._port and self._port != 22:
            args.extend(["-p", str(self._port)])
        if self._user:
            args.extend(["-l", self._user])
        if self._identity_file:
            args.extend(["-i", self._identity_file])
        args.extend(["-o", "StrictHostKeyChecking=no"])
        args.append(self._host)
        return args

    def connect(self) -> int:
        master_fd, slave_fd = pty.openpty()
        args = self._build_args()
        self._proc = subprocess.Popen(
            args, stdin=slave_fd, stdout=slave_fd,
            stderr=slave_fd, close_fds=True,
        )
        os.close(slave_fd)
        self._fd = master_fd
        self._connected = True
        self.resize(self._rows, self._cols)
        return master_fd

    def disconnect(self):
        if self._proc:
            try:
                self._proc.terminate()
                self._proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                self._proc.wait()
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
        self._connected = False
        self._proc = None
        self._fd = None

    def read(self, size: int = 4096) -> bytes:
        if self._fd is None:
            return b""
        try:
            return os.read(self._fd, size)
        except OSError:
            return b""

    def write(self, data: bytes) -> int:
        if self._fd is None:
            return 0
        try:
            return os.write(self._fd, data)
        except OSError:
            return 0

    def resize(self, rows: int, cols: int) -> bool:
        if self._fd is None:
            return False
        import struct
        import fcntl
        import termios as t
        try:
            winsize = struct.pack("HHHH", rows, cols, 0, 0)
            fcntl.ioctl(self._fd, t.TIOCSWINSZ, winsize)
            self._rows = rows
            self._cols = cols
            return True
        except OSError:
            return False

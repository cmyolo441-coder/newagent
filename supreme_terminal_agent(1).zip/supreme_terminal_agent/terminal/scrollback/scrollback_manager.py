"""ScrollbackManager - manages the scrollback buffer for terminal sessions."""

import threading
from typing import List, Optional, Callable

from terminal.scrollback.scrollback_buffer import ScrollbackBuffer
from terminal.scrollback.scrollback_search import ScrollbackSearch
from terminal.scrollback.scrollback_persistence import ScrollbackPersistence
from terminal.scrollback.scrollback_compression import ScrollbackCompression
from terminal.scrollback.scrollback_indexer import ScrollbackIndexer
from terminal.scrollback.scrollback_export import ScrollbackExport


class ScrollbackManager:
    """Manages scrollback history for terminal sessions."""

    def __init__(self, max_lines: int = 100000):
        self.buffer = ScrollbackBuffer(max_lines)
        self.search = ScrollbackSearch(self.buffer)
        self.persistence = ScrollbackPersistence()
        self.compression = ScrollbackCompression()
        self.indexer = ScrollbackIndexer()
        self.exporter = ScrollbackExport()
        self._lock = threading.RLock()

    def write(self, data: bytes):
        self.buffer.write(data)
        self.indexer.index(data)

    def get_lines(self, start: int = 0, end: Optional[int] = None) -> List[str]:
        return self.buffer.get_lines(start, end)

    def get_all_lines(self) -> List[str]:
        return self.buffer.get_all_lines()

    def get_line_count(self) -> int:
        return self.buffer.line_count

    def clear(self):
        self.buffer.clear()
        self.indexer.clear()

    def search_text(self, query: str, **kwargs) -> List[dict]:
        return self.search.search(query, **kwargs)

    def save_to_file(self, filepath: str):
        self.persistence.save(self.buffer, filepath)

    def load_from_file(self, filepath: str):
        self.persistence.load(self.buffer, filepath)

    def export_text(self, filepath: str):
        self.exporter.export_text(self.buffer, filepath)

    def export_html(self, filepath: str):
        self.exporter.export_html(self.buffer, filepath)

    def export_json(self, filepath: str):
        self.exporter.export_json(self.buffer, filepath)

    def compress(self):
        self.compression.compress(self.buffer)

    def decompress(self):
        self.compression.decompress(self.buffer)

    def resize(self, max_lines: int):
        self.buffer.resize(max_lines)

    def close(self):
        self.buffer.clear()
        self.indexer.clear()

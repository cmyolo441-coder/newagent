"""ScrollbackExport - exports scrollback content to various formats."""

import json
import html
from typing import List, Optional

from terminal.scrollback.scrollback_buffer import ScrollbackBuffer


class ScrollbackExport:
    """Exports scrollback buffer content to various formats."""

    def export_text(self, buffer: ScrollbackBuffer, filepath: str):
        with open(filepath, 'w') as f:
            for line in buffer.get_all_lines():
                f.write(line + '\n')

    def export_html(self, buffer: ScrollbackBuffer, filepath: str, dark_bg: bool = True):
        bg = "#1a1a2e" if dark_bg else "#ffffff"
        fg = "#e0e0e0" if dark_bg else "#000000"
        lines_html = []
        for line in buffer.get_all_lines():
            escaped = html.escape(line)
            lines_html.append(f'<div>{escaped}</div>')
        content = '\n'.join(lines_html)
        html_output = f'''<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Terminal Output</title>
<style>
  body {{ background: {bg}; color: {fg}; font-family: 'Courier New', monospace; font-size: 13px; padding: 16px; }}
  div {{ white-space: pre; line-height: 1.3; }}
</style>
</head>
<body>{content}</body></html>'''
        with open(filepath, 'w') as f:
            f.write(html_output)

    def export_json(self, buffer: ScrollbackBuffer, filepath: str):
        data = {
            'line_count': buffer.line_count,
            'max_lines': buffer.max_lines,
            'lines': buffer.get_all_lines(),
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

    def export_range(self, buffer: ScrollbackBuffer, start: int, end: int, filepath: str):
        lines = buffer.get_lines(start, end)
        with open(filepath, 'w') as f:
            for line in lines:
                f.write(line + '\n')

    def to_text(self, buffer: ScrollbackBuffer) -> str:
        return '\n'.join(buffer.get_all_lines())

    def to_html(self, buffer: ScrollbackBuffer, dark_bg: bool = True) -> str:
        bg = "#1a1a2e" if dark_bg else "#ffffff"
        fg = "#e0e0e0" if dark_bg else "#000000"
        lines = [f'<div>{html.escape(line)}</div>' for line in buffer.get_all_lines()]
        content = '\n'.join(lines)
        return f'''<div style="background:{bg};color:{fg};font-family:monospace;padding:16px">{content}</div>'''

    def to_json(self, buffer: ScrollbackBuffer) -> str:
        data = {
            'line_count': buffer.line_count,
            'max_lines': buffer.max_lines,
            'lines': buffer.get_all_lines(),
        }
        return json.dumps(data, indent=2)

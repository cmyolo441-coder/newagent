"""ScrollbackSearch - searches scrollback buffer content."""

import re
from typing import List, Optional

from terminal.scrollback.scrollback_buffer import ScrollbackBuffer


class ScrollbackSearch:
    """Searches through scrollback buffer content."""

    def __init__(self, buffer: ScrollbackBuffer):
        self.buffer = buffer

    def search(self, query: str, case_sensitive: bool = False, regex: bool = False, max_results: int = 100) -> List[dict]:
        results = []
        if regex:
            try:
                pattern = re.compile(query, 0 if case_sensitive else re.IGNORECASE)
            except re.error:
                return results
        else:
            pattern = re.compile(re.escape(query), 0 if case_sensitive else re.IGNORECASE)
        for i, line in enumerate(self.buffer.get_all_lines()):
            if len(results) >= max_results:
                break
            for match in pattern.finditer(line):
                results.append({
                    'line': i,
                    'start': match.start(),
                    'end': match.end(),
                    'text': match.group(),
                    'context': line[max(0, match.start() - 20):match.end() + 20],
                })
        return results

    def search_forward(self, query: str, start_line: int = 0, **kwargs) -> Optional[dict]:
        results = self.search(query, **kwargs)
        for r in results:
            if r['line'] >= start_line:
                return r
        return None

    def search_backward(self, query: str, start_line: int, **kwargs) -> Optional[dict]:
        results = self.search(query, **kwargs)
        for r in reversed(results):
            if r['line'] <= start_line:
                return r
        return None

    def search_all(self, query: str, **kwargs) -> List[int]:
        results = self.search(query, **kwargs)
        return list(set(r['line'] for r in results))

    def count_matches(self, query: str, **kwargs) -> int:
        return len(self.search(query, **kwargs))

    def has_match(self, query: str, **kwargs) -> bool:
        return len(self.search(query, max_results=1, **kwargs)) > 0

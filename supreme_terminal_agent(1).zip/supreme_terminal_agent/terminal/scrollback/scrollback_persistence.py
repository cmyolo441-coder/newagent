"""ScrollbackPersistence - saves/loads scrollback data to/from disk."""

import json
import os
from typing import Optional

from terminal.scrollback.scrollback_buffer import ScrollbackBuffer


class ScrollbackPersistence:
    """Persists scrollback buffer to and from disk."""

    def save(self, buffer: ScrollbackBuffer, filepath: str):
        lines = buffer.get_all_lines()
        data = {
            'max_lines': buffer.max_lines,
            'line_count': len(lines),
            'lines': lines,
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

    def load(self, buffer: ScrollbackBuffer, filepath: str) -> bool:
        if not os.path.exists(filepath):
            return False
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            buffer.clear()
            buffer.max_lines = data.get('max_lines', buffer.max_lines)
            for line in data.get('lines', []):
                buffer.add_line(line)
            return True
        except (json.JSONDecodeError, OSError):
            return False

    def save_text(self, buffer: ScrollbackBuffer, filepath: str):
        with open(filepath, 'w') as f:
            for line in buffer.get_all_lines():
                f.write(line + '\n')

    def load_text(self, buffer: ScrollbackBuffer, filepath: str) -> bool:
        if not os.path.exists(filepath):
            return False
        try:
            with open(filepath, 'r') as f:
                buffer.clear()
                for line in f:
                    buffer.add_line(line.rstrip('\n'))
            return True
        except OSError:
            return False

    def get_file_size(self, filepath: str) -> int:
        try:
            return os.path.getsize(filepath)
        except OSError:
            return 0

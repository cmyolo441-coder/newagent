"""ScrollbackCompression - compresses scrollback data."""

import gzip
import io
import zlib
from typing import Optional

from terminal.scrollback.scrollback_buffer import ScrollbackBuffer


class ScrollbackCompression:
    """Provides compression for scrollback buffer data."""

    def compress(self, buffer: ScrollbackBuffer) -> bytes:
        data = '\n'.join(buffer.get_all_lines()).encode('utf-8')
        return gzip.compress(data)

    def decompress_into(self, buffer: ScrollbackBuffer, compressed: bytes):
        data = gzip.decompress(compressed).decode('utf-8', errors='replace')
        buffer.clear()
        for line in data.split('\n'):
            buffer.add_line(line)

    def compress_buffer(self, buffer: ScrollbackBuffer, level: int = 6) -> bytes:
        lines = buffer.get_all_lines()
        return zlib.compress('\n'.join(lines).encode('utf-8'), level)

    def decompress_buffer(self, data: bytes) -> str:
        return zlib.decompress(data).decode('utf-8', errors='replace')

    def compress_stream(self, data: bytes) -> bytes:
        buf = io.BytesIO()
        with gzip.GzipFile(fileobj=buf, mode='wb') as f:
            f.write(data)
        return buf.getvalue()

    def decompress_stream(self, data: bytes) -> bytes:
        buf = io.BytesIO(data)
        with gzip.GzipFile(fileobj=buf, mode='rb') as f:
            return f.read()

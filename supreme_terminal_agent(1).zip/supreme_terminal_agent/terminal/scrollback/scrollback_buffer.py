"""ScrollbackBuffer - ring buffer for scrollback history."""

import threading
from typing import List, Optional


class ScrollbackBuffer:
    """Ring buffer for storing terminal scrollback history."""

    def __init__(self, max_lines: int = 100000):
        self.max_lines = max_lines
        self._lines: List[str] = []
        self._lock = threading.RLock()

    def write(self, data: bytes):
        text = data.decode('utf-8', errors='replace')
        with self._lock:
            for ch in text:
                if ch == '\n':
                    self._lines.append('')
                elif ch == '\r':
                    pass
                else:
                    if not self._lines:
                        self._lines.append('')
                    self._lines[-1] += ch
            while len(self._lines) > self.max_lines:
                self._lines.pop(0)

    def add_line(self, line: str):
        with self._lock:
            self._lines.append(line)
            while len(self._lines) > self.max_lines:
                self._lines.pop(0)

    def get_lines(self, start: int = 0, end: Optional[int] = None) -> List[str]:
        with self._lock:
            if end is None or end > len(self._lines):
                end = len(self._lines)
            return list(self._lines[start:end])

    def get_line(self, index: int) -> Optional[str]:
        with self._lock:
            if 0 <= index < len(self._lines):
                return self._lines[index]
            return None

    def get_all_lines(self) -> List[str]:
        with self._lock:
            return list(self._lines)

    def get_last_lines(self, count: int) -> List[str]:
        with self._lock:
            return list(self._lines[-count:])

    def clear(self):
        with self._lock:
            self._lines.clear()

    def resize(self, max_lines: int):
        with self._lock:
            self.max_lines = max_lines
            while len(self._lines) > max_lines:
                self._lines.pop(0)

    @property
    def line_count(self) -> int:
        with self._lock:
            return len(self._lines)

    def __len__(self) -> int:
        return self.line_count

    def __getitem__(self, index: int) -> str:
        return self.get_line(index)

    def __iter__(self):
        with self._lock:
            return iter(list(self._lines))

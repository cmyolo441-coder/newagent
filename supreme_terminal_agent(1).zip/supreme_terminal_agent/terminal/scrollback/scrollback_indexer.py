"""ScrollbackIndexer - indexes scrollback content for fast search."""

import re
import threading
from typing import Dict, List, Optional, Set


class ScrollbackIndexer:
    """Builds and maintains a search index over scrollback content."""

    def __init__(self):
        self._word_index: Dict[str, Set[int]] = {}
        self._lock = threading.RLock()
        self._line_count = 0

    def index(self, data: bytes):
        text = data.decode('utf-8', errors='replace')
        with self._lock:
            for line in text.splitlines():
                words = re.findall(r'\w+', line.lower())
                for word in words:
                    if word not in self._word_index:
                        self._word_index[word] = set()
                    self._word_index[word].add(self._line_count)
                self._line_count += 1

    def index_line(self, line: str):
        with self._lock:
            words = re.findall(r'\w+', line.lower())
            for word in words:
                if word not in self._word_index:
                    self._word_index[word] = set()
                self._word_index[word].add(self._line_count)
            self._line_count += 1

    def search(self, word: str) -> List[int]:
        with self._lock:
            lines = self._word_index.get(word.lower(), set())
            return sorted(lines)

    def search_phrase(self, phrase: str) -> List[int]:
        words = re.findall(r'\w+', phrase.lower())
        if not words:
            return []
        with self._lock:
            result = self._word_index.get(words[0], set())
            for word in words[1:]:
                result &= self._word_index.get(word, set())
            return sorted(result)

    def clear(self):
        with self._lock:
            self._word_index.clear()
            self._line_count = 0

    @property
    def word_count(self) -> int:
        with self._lock:
            return len(self._word_index)

    @property
    def indexed_lines(self) -> int:
        with self._lock:
            return self._line_count

    def remove_line(self, line_number: int):
        with self._lock:
            for word, lines in self._word_index.items():
                lines.discard(line_number)

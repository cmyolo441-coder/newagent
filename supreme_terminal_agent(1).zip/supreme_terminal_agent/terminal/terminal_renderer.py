"""TerminalRenderer - renders terminal buffer content with full ANSI support."""

import re
import threading
from typing import Any, Dict, List, Optional, Tuple

from terminal.terminal_state import CursorStyle, TerminalState
from terminal.terminal_capabilities import ColorCapability, TerminalCapabilities, TerminalFeature
from terminal.screen.screen_buffer import ScreenBuffer
from terminal.output.ansi_stripper import AnsiStripper
from terminal.escape.sgr_parser import SgrParser


_CSI_RE = re.compile(r"\x1b\[[\d;]*[a-zA-Z]")
_OSC_RE = re.compile(r"\x1b\][\d;].*?(?:\x1b\\|\x07)")
_SGR_RE = re.compile(r"\x1b\[([\d;]*)m")


class RenderedLine:
    """A single rendered line with styling metadata."""

    def __init__(self, text: str, styles: Optional[List[Dict[str, Any]]] = None):
        self.text = text
        self.styles = styles or []

    def to_dict(self) -> dict:
        return {"text": self.text, "styles": self.styles}

    def __repr__(self) -> str:
        return f"RenderedLine(text={self.text!r})"


class RenderedFrame:
    """A complete rendered frame of terminal output."""

    def __init__(
        self,
        lines: List[RenderedLine],
        cursor_x: int = 0,
        cursor_y: int = 0,
        cursor_visible: bool = True,
        cursor_style: CursorStyle = CursorStyle.BLINKING_BLOCK,
        title: str = "",
        scroll_top: int = 0,
    ):
        self.lines = lines
        self.cursor_x = cursor_x
        self.cursor_y = cursor_y
        self.cursor_visible = cursor_visible
        self.cursor_style = cursor_style
        self.title = title
        self.scroll_top = scroll_top

    @property
    def rows(self) -> int:
        return len(self.lines)

    def to_plain_text(self) -> str:
        return "\n".join(line.text for line in self.lines)

    def to_dict(self) -> dict:
        return {
            "lines": [l.to_dict() for l in self.lines],
            "cursor_x": self.cursor_x,
            "cursor_y": self.cursor_y,
            "cursor_visible": self.cursor_visible,
            "title": self.title,
            "rows": self.rows,
        }

    def __repr__(self) -> str:
        return f"RenderedFrame(rows={self.rows}, cursor=({self.cursor_x},{self.cursor_y}))"


def _parse_sgr_params(params: str) -> Dict[str, Any]:
    """Parse SGR parameter string into a style dictionary."""
    style: Dict[str, Any] = {
        "bold": False,
        "dim": False,
        "italic": False,
        "underline": False,
        "blink": False,
        "reverse": False,
        "strikethrough": False,
        "fg_color": None,
        "bg_color": None,
    }

    if not params:
        return style

    codes = [int(p) if p else 0 for p in params.split(";")]
    i = 0
    while i < len(codes):
        code = codes[i]
        if code == 0:
            for k in style:
                if isinstance(style[k], bool):
                    style[k] = False
                else:
                    style[k] = None
        elif code == 1:
            style["bold"] = True
        elif code == 2:
            style["dim"] = True
        elif code == 3:
            style["italic"] = True
        elif code == 4:
            style["underline"] = True
        elif code == 5 or code == 6:
            style["blink"] = True
        elif code == 7:
            style["reverse"] = True
        elif code == 9:
            style["strikethrough"] = True
        elif code == 22:
            style["bold"] = False
            style["dim"] = False
        elif code == 23:
            style["italic"] = False
        elif code == 24:
            style["underline"] = False
        elif code == 25:
            style["blink"] = False
        elif code == 27:
            style["reverse"] = False
        elif code == 29:
            style["strikethrough"] = False
        elif 30 <= code <= 37:
            style["fg_color"] = code - 30
        elif code == 38:
            if i + 1 < len(codes):
                if codes[i + 1] == 5 and i + 2 < len(codes):
                    style["fg_color"] = ("256", codes[i + 2])
                    i += 2
                elif codes[i + 1] == 2 and i + 4 < len(codes):
                    style["fg_color"] = ("truecolor", codes[i + 2], codes[i + 3], codes[i + 4])
                    i += 4
        elif code == 39:
            style["fg_color"] = None
        elif 40 <= code <= 47:
            style["bg_color"] = code - 40
        elif code == 48:
            if i + 1 < len(codes):
                if codes[i + 1] == 5 and i + 2 < len(codes):
                    style["bg_color"] = ("256", codes[i + 2])
                    i += 2
                elif codes[i + 1] == 2 and i + 4 < len(codes):
                    style["bg_color"] = ("truecolor", codes[i + 2], codes[i + 3], codes[i + 4])
                    i += 4
        elif code == 49:
            style["bg_color"] = None
        elif 90 <= code <= 97:
            style["fg_color"] = code - 90 + 8
        elif 100 <= code <= 107:
            style["bg_color"] = code - 100 + 8
        i += 1

    return style


def _sgr_to_ansi_escape(params: str) -> str:
    """Convert SGR parameters back to a full ANSI escape sequence."""
    return f"\x1b[{params}m" if params else "\x1b[m"


class TerminalRenderer:
    """Renders terminal screen buffer content to styled output."""

    def __init__(
        self,
        capabilities: Optional[TerminalCapabilities] = None,
        state: Optional[TerminalState] = None,
    ):
        self._capabilities = capabilities or TerminalCapabilities()
        self._state = state
        self._stripper = AnsiStripper()
        self._lock = threading.RLock()
        self._current_style: Dict[str, Any] = _parse_sgr_params("")

    @property
    def state(self) -> Optional[TerminalState]:
        return self._state

    @state.setter
    def state(self, value: TerminalState):
        self._state = value

    def render_frame(
        self,
        buffer: ScreenBuffer,
        scroll_offset: int = 0,
        render_cursor: bool = True,
    ) -> RenderedFrame:
        """Render a full frame from a screen buffer."""
        state = self._state
        if state is None:
            return RenderedFrame(lines=[])

        rows = state.rows
        cols = state.cols
        lines: List[RenderedLine] = []

        for row in range(rows):
            line_text = buffer.get_line(row) if hasattr(buffer, "get_line") else ""
            if len(line_text) < cols:
                line_text = line_text.ljust(cols)
            else:
                line_text = line_text[:cols]
            lines.append(RenderedLine(line_text))

        cursor_x = state.cursor_x
        cursor_y = state.cursor_y
        cursor_visible = state.cursor_visible and render_cursor
        cursor_style = state.cursor_style
        title = getattr(state, "_title", "")

        return RenderedFrame(
            lines=lines,
            cursor_x=cursor_x,
            cursor_y=cursor_y,
            cursor_visible=cursor_visible,
            cursor_style=cursor_style,
            title=title,
        )

    def render_to_ansi(
        self,
        lines: List[str],
        cursor_line: Optional[int] = None,
    ) -> bytes:
        """Render lines with ANSI cursor positioning to stdout-ready bytes."""
        with self._lock:
            state = self._state
            if state is None:
                return b""

            output = bytearray()

            if cursor_line is not None:
                output.extend(f"\x1b[{cursor_line + 1};1H".encode())

            for i, line in enumerate(lines):
                if i > 0:
                    output.extend(b"\r\n")
                stripped = self._stripper.strip(line.encode("latin-1"))
                output.extend(stripped if stripped else b" ")

            return bytes(output)

    def render_plain_text(
        self,
        buffer: ScreenBuffer,
        start_row: int = 0,
        end_row: Optional[int] = None,
    ) -> str:
        """Extract plain text content from a screen buffer without styling."""
        state = self._state
        if state is None:
            return ""

        rows = state.rows
        cols = state.cols
        end = end_row if end_row is not None else rows
        text_parts: List[str] = []

        for row in range(max(0, start_row), min(end, rows)):
            line = buffer.get_line(row) if hasattr(buffer, "get_line") else ""
            text_parts.append(line.rstrip())

        return "\n".join(text_parts).rstrip("\n")

    def render_diff(
        self,
        old_lines: List[RenderedLine],
        new_buffer: ScreenBuffer,
    ) -> bytes:
        """Render only the changed lines between two frames as ANSI diff."""
        state = self._state
        if state is None:
            return b""

        output = bytearray()
        rows = state.rows
        old_count = len(old_lines)

        for row in range(rows):
            new_line = new_buffer.get_line(row) if hasattr(new_buffer, "get_line") else ""
            if row < old_count:
                old_line = old_lines[row].text
            else:
                old_line = ""

            if new_line != old_line:
                output.extend(f"\x1b[{row + 1};1H".encode())
                output.extend(new_line.encode("latin-1", errors="replace"))

        return bytes(output)

    def render_cursor(self, state: TerminalState) -> bytes:
        """Render cursor positioning as ANSI escape sequences."""
        return f"\x1b[{state.cursor_y + 1};{state.cursor_x + 1}H".encode()

    def render_cursor_style(self, style: CursorStyle) -> bytes:
        """Render cursor style as a DECSCUSR sequence."""
        return f"\x1b[{style.value} q".encode()

    def render_cursor_visibility(self, visible: bool) -> bytes:
        """Render cursor visibility as DECTCEM sequences."""
        if visible:
            return b"\x1b[?25h"
        return b"\x1b[?25l"

    def render_title(self, title: str) -> bytes:
        """Render window title as an OSC sequence."""
        return f"\x1b]0;{title}\x07".encode()

    def render_reset(self) -> bytes:
        """Render full terminal reset sequence."""
        return b"\x1bc"

    def render_soft_reset(self) -> bytes:
        """Render soft terminal reset sequence."""
        return b"\x1b[!p"

    def render_alternate_screen(self, enable: bool) -> bytes:
        """Render alternate screen buffer switch sequences."""
        if enable:
            return b"\x1b[?1049h"
        return b"\x1b[?1049l"

    def render_bracketed_paste(self, enable: bool) -> bytes:
        """Render bracketed paste mode sequences."""
        if enable:
            return b"\x1b[?2004h"
        return b"\x1b[?2004l"

    def render_mouse_mode(self, mode: int) -> bytes:
        """Render mouse tracking mode sequences."""
        if mode == 0:
            return b"\x1b[?1000l\x1b[?1002l\x1b[?1003l"
        if mode == 1:
            return b"\x1b[?1000h"
        if mode == 2:
            return b"\x1b[?1002h"
        if mode == 3:
            return b"\x1b[?1003h"
        return b""

    def render_clear_screen(self) -> bytes:
        """Render clear screen sequence."""
        return b"\x1b[2J\x1b[H"

    def render_clear_line(self) -> bytes:
        """Render clear line sequence."""
        return b"\x1b[2K\r"

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "capabilities": self._capabilities.term,
            }

    def __repr__(self) -> str:
        return f"TerminalRenderer(capabilities={self._capabilities.term!r})"

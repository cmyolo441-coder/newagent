"""KeyParser - parses raw bytes into key events."""

from typing import Dict, Optional, Tuple


class KeyParser:
    """Parses raw escape sequences and bytes into key event structures."""

    CSI_KEY_MAP = {
        'A': 'up', 'B': 'down', 'C': 'right', 'D': 'left',
        'H': 'home', 'F': 'end',
        '1~': 'home', '2~': 'insert', '3~': 'delete',
        '4~': 'end', '5~': 'page_up', '6~': 'page_down',
        '7~': 'home', '8~': 'end',
    }

    SIMPLE_ESCAPE_MAP = {
        'a': 'c-a', 'b': 'c-b', 'c': 'c-c', 'd': 'c-d',
        'e': 'c-e', 'f': 'c-f', 'g': 'c-g', 'h': 'c-h',
        'i': 'c-i', 'j': 'c-j', 'k': 'c-k', 'l': 'c-l',
        'm': 'c-m', 'n': 'c-n', 'o': 'c-o', 'p': 'c-p',
        'q': 'c-q', 'r': 'c-r', 's': 'c-s', 't': 'c-t',
        'u': 'c-u', 'v': 'c-v', 'w': 'c-w', 'x': 'c-x',
        'y': 'c-y', 'z': 'c-z',
    }

    def parse_csi(self, seq: bytes) -> Optional[dict]:
        text = seq.decode('utf-8', errors='replace')
        if not text.startswith('\x1b['):
            return None
        inner = text[2:]
        terminator = inner[-1]
        param_part = inner[:-1]
        if param_part:
            csi_key = param_part + terminator
        else:
            csi_key = terminator
        mapped = self.CSI_KEY_MAP.get(csi_key) or self.CSI_KEY_MAP.get(terminator)
        if mapped:
            return {'type': 'key', 'key': mapped}
        if param_part:
            modifiers = self._parse_modifiers(param_part)
            base_key = self.CSI_KEY_MAP.get(terminator, terminator)
            return {'type': 'key', 'key': base_key, 'modifiers': modifiers}
        return {'type': 'key', 'key': f'csi-{terminator}'}

    def parse_ss3(self, data: bytes, start: int) -> Optional[dict]:
        if start + 2 < len(data) and data[start + 2] in (0x50, 0x51, 0x52, 0x53):
            mapping = {0x50: 'f1', 0x51: 'f2', 0x52: 'f3', 0x53: 'f4'}
            return {'type': 'key', 'key': mapping.get(data[start + 2], 'unknown')}
        return None

    def parse_simple_escape(self, data: bytes, start: int) -> Optional[str]:
        if start + 1 < len(data):
            byte = data[start + 1]
            if 0x41 <= byte <= 0x5a:
                return self.SIMPLE_ESCAPE_MAP.get(chr(byte).lower())
        return None

    def _parse_modifiers(self, param: str) -> dict:
        modifiers = {'shift': False, 'alt': False, 'ctrl': False, 'meta': False}
        try:
            num = int(param.rstrip(';~'))
            if num > 1:
                modifiers['shift'] = bool(num & 1)
                modifiers['alt'] = bool(num & 2)
                modifiers['ctrl'] = bool(num & 4)
                modifiers['meta'] = bool(num & 8)
        except ValueError:
            pass
        return modifiers

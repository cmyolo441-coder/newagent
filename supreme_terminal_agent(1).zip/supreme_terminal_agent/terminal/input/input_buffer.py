"""InputBuffer - manages editable input line buffer."""

import threading
from typing import Optional


class InputBuffer:
    """Manages an editable line buffer for terminal input."""

    def __init__(self):
        self._buffer = bytearray()
        self._cursor = 0
        self._lock = threading.RLock()

    def write(self, data: bytes):
        with self._lock:
            self._buffer[self._cursor:self._cursor] = data
            self._cursor += len(data)

    def insert(self, text: str):
        self.write(text.encode('utf-8', errors='replace'))

    def insert_char(self, char: str):
        self.write(char.encode('utf-8'))

    def delete(self, n: int = 1):
        with self._lock:
            if self._cursor > 0 and n > 0:
                del_count = min(n, self._cursor)
                del self._buffer[self._cursor - del_count:self._cursor]
                self._cursor -= del_count

    def delete_forward(self, n: int = 1):
        with self._lock:
            del_count = min(n, len(self._buffer) - self._cursor)
            del self._buffer[self._cursor:self._cursor + del_count]

    def delete_to_end(self):
        with self._lock:
            del self._buffer[self._cursor:]

    def delete_word(self):
        with self._lock:
            pos = self._cursor - 1
            while pos >= 0 and self._buffer[pos] == 32:
                pos -= 1
            while pos >= 0 and self._buffer[pos] != 32:
                pos -= 1
            del self._buffer[pos + 1:self._cursor]
            self._cursor = pos + 1

    def clear(self):
        with self._lock:
            self._buffer = bytearray()
            self._cursor = 0

    def set_text(self, text: str):
        with self._lock:
            self._buffer = bytearray(text.encode('utf-8'))
            self._cursor = len(self._buffer)

    def set_cursor(self, pos: int):
        with self._lock:
            self._cursor = max(0, min(pos, len(self._buffer)))

    def move_cursor_left(self, n: int = 1):
        with self._lock:
            self._cursor = max(0, self._cursor - n)

    def move_cursor_right(self, n: int = 1):
        with self._lock:
            self._cursor = min(len(self._buffer), self._cursor + n)

    def move_cursor_home(self):
        with self._lock:
            self._cursor = 0

    def move_cursor_end(self):
        with self._lock:
            self._cursor = len(self._buffer)

    @property
    def cursor(self) -> int:
        with self._lock:
            return self._cursor

    def get_value(self) -> str:
        with self._lock:
            return self._buffer.decode('utf-8', errors='replace')

    @property
    def length(self) -> int:
        with self._lock:
            return len(self._buffer)

    def to_bytes(self) -> bytes:
        with self._lock:
            return bytes(self._buffer)

    def __len__(self) -> int:
        return self.length

    def __str__(self) -> str:
        return self.get_value()

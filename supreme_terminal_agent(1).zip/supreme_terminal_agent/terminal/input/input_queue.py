"""InputQueue - queues input events for processing."""

import sys
if 'queue' in sys.modules and sys.modules['queue'].__file__.startswith('/content/'):
    del sys.modules['queue']
import queue as stdlib_queue
import threading
from typing import Any, List, Optional


class InputQueue:
    """Thread-safe queue for input events."""

    def __init__(self, maxsize: int = 0):
        self._queue: stdlib_queue.Queue = stdlib_queue.Queue(maxsize=maxsize)
        self._lock = threading.RLock()

    def put(self, event: Any, block: bool = True, timeout: Optional[float] = None):
        self._queue.put(event, block=block, timeout=timeout)

    def get(self, block: bool = True, timeout: Optional[float] = None) -> Any:
        try:
            return self._queue.get(block=block, timeout=timeout)
        except stdlib_queue.Empty:
            return None

    def get_nowait(self) -> Any:
        try:
            return self._queue.get_nowait()
        except stdlib_queue.Empty:
            return None

    def put_nowait(self, event: Any):
        try:
            self._queue.put_nowait(event)
        except stdlib_queue.Full:
            pass

    def clear(self):
        with self._lock:
            while not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except stdlib_queue.Empty:
                    break

    def drain(self) -> List[Any]:
        events = []
        while True:
            event = self.get_nowait()
            if event is None:
                break
            events.append(event)
        return events

    @property
    def size(self) -> int:
        return self._queue.qsize()

    @property
    def is_empty(self) -> bool:
        return self._queue.empty()

    @property
    def is_full(self) -> bool:
        return self._queue.full()

    def close(self):
        self.clear()

"""KeyChord - manages multi-key chord sequences."""

import time
from typing import Dict, List, Optional, Tuple


class KeyChord:
    """Manages multi-key chord sequences (e.g., C-x C-s)."""

    def __init__(self, timeout: float = 1.0):
        self.timeout = timeout
        self._chords: Dict[str, str] = {}
        self._prefix = ""
        self._last_key_time = 0.0

    def define_chord(self, sequence: str, action: str):
        self._chords[sequence] = action

    def feed(self, key: str) -> Optional[str]:
        now = time.time()
        if self._prefix and (now - self._last_key_time) > self.timeout:
            self._prefix = ""
            return None
        self._last_key_time = now
        candidate = self._prefix + key if self._prefix else key
        if candidate in self._chords:
            self._prefix = ""
            return self._chords[candidate]
        for chord in self._chords:
            if chord.startswith(candidate) and chord != candidate:
                self._prefix = candidate
                return None
        self._prefix = ""
        return None

    @property
    def is_active(self) -> bool:
        return bool(self._prefix)

    def cancel(self):
        self._prefix = ""

    @property
    def current_prefix(self) -> str:
        return self._prefix

    def clear(self):
        self._chords.clear()
        self._prefix = ""

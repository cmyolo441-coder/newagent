"""MouseMode - manages mouse reporting modes."""

from typing import Dict, Optional


class MouseMode:
    """Manages mouse reporting mode (X10, normal, SGR, etc)."""

    MODES = {
        'x10': b'\x1b[?9h',
        'normal': b'\x1b[?1000h',
        'button': b'\x1b[?1002h',
        'any': b'\x1b[?1003h',
        'sgr': b'\x1b[?1006h',
        'utf8': b'\x1b[?1005h',
        'urxvt': b'\x1b[?1015h',
    }

    DISABLE = {
        'x10': b'\x1b[?9l',
        'normal': b'\x1b[?1000l',
        'button': b'\x1b[?1002l',
        'any': b'\x1b[?1003l',
        'sgr': b'\x1b[?1006l',
        'utf8': b'\x1b[?1005l',
        'urxvt': b'\x1b[?1015l',
    }

    def __init__(self):
        self._current: str = 'none'
        self._enabled: bool = False

    def set(self, mode: str):
        self._current = mode
        self._enabled = mode != 'none'

    def enable(self):
        if self._current != 'none':
            self._enabled = True

    def disable(self):
        self._enabled = False

    @property
    def current(self) -> str:
        return self._current

    @property
    def enabled(self) -> bool:
        return self._enabled

    def to_ansi(self, mode: str = 'normal') -> bytes:
        return self.MODES.get(mode, b'')

    def to_disable_ansi(self, mode: str = 'normal') -> bytes:
        return self.DISABLE.get(mode, b'')

    def enable_all(self) -> bytes:
        result = bytearray()
        for mode in ('normal', 'button', 'sgr'):
            result.extend(self.MODES.get(mode, b''))
        self._current = 'sgr'
        self._enabled = True
        return bytes(result)

    def disable_all(self) -> bytes:
        result = bytearray()
        for mode in ('sgr', 'button', 'any', 'normal', 'x10'):
            result.extend(self.DISABLE.get(mode, b''))
        self._enabled = False
        return bytes(result)

"""InputReader - reads raw input from a file descriptor."""

import os
import select
import sys
import threading
from typing import Callable, Optional

from terminal.input.input_buffer import InputBuffer


class InputReader:
    """Reads raw bytes from a file descriptor (typically stdin)."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd or sys.stdin.fileno()
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._on_data: Optional[Callable[[bytes], None]] = None
        self.buffer = InputBuffer()
        self._lock = threading.Lock()

    def set_callback(self, callback: Callable[[bytes], None]):
        self._on_data = callback

    def read(self, size: int = 4096) -> bytes:
        try:
            return os.read(self.fd, size)
        except (OSError, ValueError):
            return b''

    def read_line(self, timeout: Optional[float] = None) -> bytes:
        result = bytearray()
        deadline = None
        if timeout is not None:
            deadline = __import__('time').time() + timeout
        while True:
            if timeout is not None and __import__('time').time() > deadline:
                break
            try:
                r, _, _ = select.select([self.fd], [], [], 0.1)
                if r:
                    data = os.read(self.fd, 1)
                    if data:
                        result.extend(data)
                        if data == b'\n':
                            break
            except (OSError, ValueError):
                break
        return bytes(result)

    def read_available(self) -> bytes:
        result = bytearray()
        while True:
            try:
                r, _, _ = select.select([self.fd], [], [], 0.0)
                if r:
                    data = os.read(self.fd, 4096)
                    if data:
                        result.extend(data)
                    else:
                        break
                else:
                    break
            except (OSError, ValueError):
                break
        return bytes(result)

    def start(self, fd: Optional[int] = None):
        if fd is not None:
            self.fd = fd
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None

    def _read_loop(self):
        while self._running:
            try:
                r, _, _ = select.select([self.fd], [], [], 0.1)
                if r:
                    data = os.read(self.fd, 4096)
                    if data:
                        if self._on_data:
                            self._on_data(data)
                        else:
                            self.buffer.write(data)
                    else:
                        break
            except (OSError, ValueError):
                break

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def has_data(self) -> bool:
        try:
            r, _, _ = select.select([self.fd], [], [], 0.0)
            return len(r) > 0
        except (ValueError, OSError):
            return False

    def close(self):
        self.stop()
        self.buffer.clear()

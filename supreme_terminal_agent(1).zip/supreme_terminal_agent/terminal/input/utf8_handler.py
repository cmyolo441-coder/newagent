"""Utf8Handler - handles UTF-8 encoding/decoding."""

from typing import Optional, Tuple


class Utf8Handler:
    """Handles UTF-8 encoding and decoding of input bytes."""

    def decode(self, data: bytes, start: int) -> Tuple[Optional[str], int]:
        if start >= len(data):
            return (None, 0)
        byte = data[start]
        if byte < 0x80:
            return (chr(byte), 1)
        elif byte < 0xc0:
            return (None, 0)
        elif byte < 0xe0:
            if start + 1 < len(data) and 0x80 <= data[start + 1] < 0xc0:
                cp = ((byte & 0x1f) << 6) | (data[start + 1] & 0x3f)
                return (chr(cp), 2)
            return (None, 1)
        elif byte < 0xf0:
            if (start + 2 < len(data) and 0x80 <= data[start + 1] < 0xc0
                    and 0x80 <= data[start + 2] < 0xc0):
                cp = ((byte & 0x0f) << 12) | ((data[start + 1] & 0x3f) << 6) | (data[start + 2] & 0x3f)
                return (chr(cp), 3)
            return (None, 1)
        elif byte < 0xf8:
            if (start + 3 < len(data) and 0x80 <= data[start + 1] < 0xc0
                    and 0x80 <= data[start + 2] < 0xc0
                    and 0x80 <= data[start + 3] < 0xc0):
                cp = ((byte & 0x07) << 18) | ((data[start + 1] & 0x3f) << 12) | ((data[start + 2] & 0x3f) << 6) | (data[start + 3] & 0x3f)
                return (chr(cp), 4)
            return (None, 1)
        return (None, 1)

    def encode(self, char: str) -> bytes:
        return char.encode('utf-8')

    def validate(self, data: bytes) -> bool:
        i = 0
        while i < len(data):
            _, width = self.decode(data, i)
            if width == 0:
                return False
            i += max(width, 1)
        return True

    def replace_invalid(self, data: bytes, replacement: str = '\ufffd') -> str:
        result = []
        i = 0
        while i < len(data):
            char, width = self.decode(data, i)
            if char:
                result.append(char)
                i += width
            else:
                result.append(replacement)
                i += 1
        return ''.join(result)

"""MouseHandler - processes mouse events."""

from typing import Callable, List, Optional

from terminal.input.mouse_parser import MouseParser
from terminal.input.mouse_mode import MouseMode


class MouseHandler:
    """Handles mouse input events."""

    def __init__(self):
        self.parser = MouseParser()
        self.mode = MouseMode()
        self._on_click: List[Callable] = []
        self._on_move: List[Callable] = []
        self._on_scroll: List[Callable] = []

    def process(self, data: bytes) -> Optional[dict]:
        if not self.mode.enabled:
            return None
        event = self.parser.parse(data, 0)
        if event is None:
            event = self.parser.parse_csi(data)
        if event:
            self._dispatch(event)
        return event

    def _dispatch(self, event: dict):
        btn = event.get('button', -1)
        if btn in (0, 1, 2):
            for cb in self._on_click:
                cb(event)
        elif btn == 32:
            for cb in self._on_move:
                cb(event)
        elif btn in (64, 65):
            for cb in self._on_scroll:
                cb(event)

    def on_click(self, callback: Callable):
        self._on_click.append(callback)

    def on_move(self, callback: Callable):
        self._on_move.append(callback)

    def on_scroll(self, callback: Callable):
        self._on_scroll.append(callback)

    def set_mode(self, mode: str):
        self.mode.set(mode)

    def enable(self):
        self.mode.enable()

    def disable(self):
        self.mode.disable()

    def to_ansi(self) -> bytes:
        return self.mode.to_ansi(self.mode.current)

    def clear(self):
        self._on_click.clear()
        self._on_move.clear()
        self._on_scroll.clear()

"""MouseParser - parses raw mouse event bytes."""

from typing import Dict, Optional, Tuple


class MouseParser:
    """Parses mouse event sequences (SGR, X10, normal tracking)."""

    def parse(self, data: bytes, start: int) -> Optional[dict]:
        if len(data) - start < 6:
            return None
        if data[start] != 0x1b or data[start + 1] != 0x4d:
            return None
        cb = data[start + 2]
        cx = data[start + 3] - 32
        cy = data[start + 4] - 32
        button = cb & 3
        action = 'press' if not (cb & 32) else 'release'
        if cb & 64:
            button = 'scroll_up' if button == 0 else 'scroll_down'
            action = 'scroll'
        modifiers = {
            'shift': bool(cb & 4),
            'meta': bool(cb & 8),
            'ctrl': bool(cb & 16),
        }
        return {
            'type': 'mouse',
            'button': button,
            'action': action,
            'x': cx,
            'y': cy,
            'modifiers': modifiers,
        }

    def parse_csi(self, seq: bytes) -> Optional[dict]:
        text = seq.decode('utf-8', errors='replace')
        if not text.startswith('\x1b[') or not text.endswith('M'):
            return None
        inner = text[2:-1]
        parts = inner.split(';')
        if len(parts) != 3:
            return None
        try:
            cb = int(parts[0])
            cx = int(parts[1]) - 1
            cy = int(parts[2]) - 1
            button = cb & 3
            action = 'press' if not (cb & 32) else 'release'
            if cb & 64:
                button = 'scroll_up' if button == 0 else 'scroll_down'
                action = 'scroll'
            modifiers = {
                'shift': bool(cb & 4),
                'meta': bool(cb & 8),
                'ctrl': bool(cb & 16),
            }
            return {
                'type': 'mouse',
                'button': button,
                'action': action,
                'x': cx,
                'y': cy,
                'modifiers': modifiers,
            }
        except (ValueError, IndexError):
            return None

"""InputValidator - validates input events."""

from typing import Any, Dict, List, Optional


class InputValidator:
    """Validates input events for correctness."""

    VALID_TYPES = {'char', 'key', 'mouse', 'paste', 'string', 'focus'}

    def validate(self, event: dict) -> bool:
        if not isinstance(event, dict):
            return False
        event_type = event.get('type', '')
        if event_type not in self.VALID_TYPES:
            return False
        if event_type == 'char':
            return 'char' in event and isinstance(event['char'], str) and len(event['char']) > 0
        if event_type == 'key':
            return 'key' in event and isinstance(event['key'], str)
        if event_type == 'mouse':
            return all(k in event for k in ('button', 'x', 'y'))
        if event_type == 'paste':
            return 'data' in event
        return True

    def validate_char(self, char: str) -> bool:
        return isinstance(char, str) and len(char) > 0

    def validate_key(self, key: str) -> bool:
        return isinstance(key, str) and len(key) > 0

    def sanitize(self, event: dict) -> Optional[dict]:
        if not self.validate(event):
            return None
        return event

    def is_printable(self, char: str) -> bool:
        if len(char) != 1:
            return False
        cp = ord(char)
        return 0x20 <= cp <= 0x7e or cp >= 0xa0

    def is_control(self, char: str) -> bool:
        if len(char) != 1:
            return False
        cp = ord(char)
        return cp < 0x20 or cp == 0x7f

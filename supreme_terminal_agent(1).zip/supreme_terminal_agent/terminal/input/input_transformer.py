"""InputTransformer - transforms input events into output bytes."""

from typing import Dict, Optional


class InputTransformer:
    """Transforms validated input events into output byte sequences."""

    def __init__(self):
        self._key_map: Dict[str, str] = {
            'enter': '\n',
            'tab': '\t',
            'backspace': '\x7f',
            'escape': '\x1b',
            'ctrl-c': '\x03',
            'ctrl-d': '\x04',
            'ctrl-z': '\x1a',
            'ctrl-a': '\x01',
            'ctrl-b': '\x02',
            'ctrl-e': '\x05',
            'ctrl-f': '\x06',
            'ctrl-g': '\x07',
            'ctrl-h': '\x08',
            'ctrl-i': '\x09',
            'ctrl-j': '\x0a',
            'ctrl-k': '\x0b',
            'ctrl-l': '\x0c',
            'ctrl-n': '\x0e',
            'ctrl-o': '\x0f',
            'ctrl-p': '\x10',
            'ctrl-q': '\x11',
            'ctrl-r': '\x12',
            'ctrl-s': '\x13',
            'ctrl-t': '\x14',
            'ctrl-u': '\x15',
            'ctrl-v': '\x16',
            'ctrl-w': '\x17',
            'ctrl-x': '\x18',
            'ctrl-y': '\x19',
        }

    def transform_char(self, char: str) -> bytes:
        return char.encode('utf-8', errors='replace')

    def transform_key(self, key: str) -> bytes:
        mapped = self._key_map.get(key)
        if mapped:
            return mapped.encode('utf-8')
        if key.startswith('c-') and len(key) == 3:
            ctrl_code = ord(key[2]) - ord('a') + 1
            if 1 <= ctrl_code <= 26:
                return bytes([ctrl_code])
        if key.startswith('f') and len(key) > 1:
            try:
                n = int(key[1:])
                return f'\x1b[{n}~'.encode()
            except ValueError:
                pass
        arrow_map = {
            'up': '\x1b[A',
            'down': '\x1b[B',
            'right': '\x1b[C',
            'left': '\x1b[D',
            'home': '\x1b[H',
            'end': '\x1b[F',
            'page_up': '\x1b[5~',
            'page_down': '\x1b[6~',
            'insert': '\x1b[2~',
            'delete': '\x1b[3~',
        }
        mapped_arrow = arrow_map.get(key)
        if mapped_arrow:
            return mapped_arrow.encode('utf-8')
        return key.encode('utf-8', errors='replace')

    def register_mapping(self, key: str, sequence: str):
        self._key_map[key] = sequence

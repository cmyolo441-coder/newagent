"""KeyboardHandler - processes keyboard input events."""

from typing import Callable, Dict, List, Optional

from terminal.input.key_parser import KeyParser
from terminal.input.key_mapper import KeyMapper
from terminal.input.key_binding import KeyBinding
from terminal.input.key_chord import KeyChord
from terminal.input.key_macro import KeyMacro


class KeyboardHandler:
    """Handles keyboard input processing including key parsing, mapping, bindings, chords, and macros."""

    def __init__(self):
        self.parser = KeyParser()
        self.mapper = KeyMapper()
        self.binding = KeyBinding()
        self.chord = KeyChord()
        self.macro = KeyMacro()
        self._on_key: List[Callable] = []

    def process_key(self, key_event: dict) -> Optional[str]:
        key = key_event.get('key', '')
        mapped = self.mapper.map(key)
        if mapped:
            key = mapped
        if self.chord.is_active:
            result = self.chord.feed(key)
            if result:
                return result
            return None
        if self.binding.has_binding(key):
            action = self.binding.get_action(key)
            self._execute_action(action)
            return None
        if self.macro.is_recording:
            self.macro.record(key)
            return None
        if self.macro.is_playing:
            return None
        return key

    def _execute_action(self, action: str):
        for cb in self._on_key:
            cb({'type': 'action', 'action': action})

    def on_key(self, callback: Callable):
        self._on_key.append(callback)

    def start_macro_recording(self):
        self.macro.start_recording()

    def stop_macro_recording(self):
        self.macro.stop_recording()

    def play_macro(self):
        self.macro.play()

    def clear(self):
        self.mapper.clear()
        self.binding.clear()
        self.chord.clear()
        self.macro.clear()

"""KeyMapper - maps key names to different key names or actions."""

from typing import Dict, Optional


class KeyMapper:
    """Maps input key names to different key names or actions."""

    def __init__(self):
        self._mappings: Dict[str, str] = {}

    def map(self, key: str) -> Optional[str]:
        return self._mappings.get(key)

    def register_mapping(self, from_key: str, to_key: str):
        self._mappings[from_key] = to_key

    def remove_mapping(self, key: str):
        self._mappings.pop(key, None)

    def load_preset(self, preset: str):
        presets = {
            'vim': {
                'j': 'down',
                'k': 'up',
                'h': 'left',
                'l': 'right',
            },
            'emacs': {
                'c-f': 'right',
                'c-b': 'left',
                'c-p': 'up',
                'c-n': 'down',
            },
        }
        mappings = presets.get(preset, {})
        self._mappings.update(mappings)

    def clear(self):
        self._mappings.clear()

    def to_dict(self) -> dict:
        return dict(self._mappings)

    def load_from(self, data: dict):
        self._mappings.update(data)

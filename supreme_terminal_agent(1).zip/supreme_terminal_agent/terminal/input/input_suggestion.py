"""InputSuggestion - provides inline suggestions for input."""

from typing import Callable, List, Optional


class InputSuggestion:
    """Provides inline suggestions as the user types."""

    def __init__(self):
        self._suggester: Optional[Callable[[str], Optional[str]]] = None
        self._current_suggestion: Optional[str] = None

    def set_suggester(self, suggester: Callable[[str], Optional[str]]):
        self._suggester = suggester

    def suggest(self, text: str) -> Optional[str]:
        if self._suggester:
            self._current_suggestion = self._suggester(text)
        else:
            self._current_suggestion = None
        return self._current_suggestion

    def accept_suggestion(self) -> Optional[str]:
        suggestion = self._current_suggestion
        self._current_suggestion = None
        return suggestion

    def reject_suggestion(self):
        self._current_suggestion = None

    @property
    def current(self) -> Optional[str]:
        return self._current_suggestion

    @property
    def has_suggestion(self) -> bool:
        return self._current_suggestion is not None

    def clear(self):
        self._current_suggestion = None

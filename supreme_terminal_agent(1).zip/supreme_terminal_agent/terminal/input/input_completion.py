"""InputCompletion - provides tab completion for input."""

from typing import Callable, List, Optional


class InputCompletion:
    """Provides tab-completion for terminal input."""

    def __init__(self):
        self._completions: List[str] = []
        self._index = -1
        self._prefix = ""
        self._completer: Optional[Callable[[str], List[str]]] = None

    def set_completer(self, completer: Callable[[str], List[str]]):
        self._completer = completer

    def complete(self, text: str) -> Optional[str]:
        if not self._completions:
            self._prefix = text
            if self._completer:
                self._completions = self._completer(text)
            else:
                self._completions = self._default_complete(text)
            if not self._completions:
                return None
            self._index = 0
            return self._completions[0]
        self._index = (self._index + 1) % len(self._completions)
        return self._completions[self._index]

    def reset(self):
        self._completions = []
        self._index = -1
        self._prefix = ""

    def _default_complete(self, text: str) -> List[str]:
        import glob
        matches = glob.glob(text + '*')
        matches.sort()
        return matches

    @property
    def has_completions(self) -> bool:
        return len(self._completions) > 0

    @property
    def completion_count(self) -> int:
        return len(self._completions)

    def get_all_completions(self) -> List[str]:
        return list(self._completions)

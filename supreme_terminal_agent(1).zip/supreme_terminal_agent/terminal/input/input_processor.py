"""InputProcessor - processes parsed input events."""

from typing import Any, Dict, List, Optional, Callable

from terminal.input.input_validator import InputValidator
from terminal.input.input_transformer import InputTransformer


class InputProcessor:
    """Processes parsed input events through validation and transformation."""

    def __init__(self):
        self.validator = InputValidator()
        self.transformer = InputTransformer()
        self._handlers: Dict[str, Callable] = {}

    def register_handler(self, event_type: str, handler: Callable):
        self._handlers[event_type] = handler

    def process(self, events: List[dict]) -> bytes:
        result = bytearray()
        for event in events:
            if not self.validator.validate(event):
                continue
            processed = self._process_event(event)
            result.extend(processed)
            handler = self._handlers.get(event.get('type', ''))
            if handler:
                handler(event)
        return bytes(result)

    def _process_event(self, event: dict) -> bytes:
        event_type = event.get('type', '')
        if event_type == 'char':
            char = event.get('char', '')
            return self.transformer.transform_char(char)
        elif event_type == 'key':
            key = event.get('key', '')
            return self.transformer.transform_key(key)
        elif event_type == 'mouse':
            return self._process_mouse(event)
        elif event_type == 'paste':
            return event.get('data', b'')
        elif event_type == 'string':
            return event.get('data', b'')
        return b''

    def _process_mouse(self, event: dict) -> bytes:
        return b''

    def process_event(self, event: dict) -> bytes:
        return self._process_event(event)

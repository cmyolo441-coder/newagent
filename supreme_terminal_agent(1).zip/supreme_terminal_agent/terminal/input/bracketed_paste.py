"""BracketedPaste - handles bracketed paste mode."""

from typing import Optional


class BracketedPaste:
    """Handles bracketed paste mode (CSI 200~ ... CSI 201~)."""

    START_SEQ = b'\x1b[200~'
    END_SEQ = b'\x1b[201~'

    def __init__(self):
        self._enabled: bool = False
        self._buffer = bytearray()
        self._in_paste = False

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool):
        self._enabled = value
        if not value:
            self._buffer = bytearray()
            self._in_paste = False

    def process(self, data: bytes) -> Optional[str]:
        if not self._enabled:
            return None
        self._buffer.extend(data)
        if not self._in_paste:
            idx = self._buffer.find(self.START_SEQ)
            if idx >= 0:
                self._in_paste = True
                self._buffer = self._buffer[idx + len(self.START_SEQ):]
        if self._in_paste:
            idx = self._buffer.find(self.END_SEQ)
            if idx >= 0:
                pasted = bytes(self._buffer[:idx])
                self._buffer = self._buffer[idx + len(self.END_SEQ):]
                self._in_paste = False
                return pasted.decode('utf-8', errors='replace')
        return None

    def wrap(self, text: str) -> bytes:
        if self._enabled:
            return self.START_SEQ + text.encode('utf-8') + self.END_SEQ
        return text.encode('utf-8')

    def reset(self):
        self._buffer = bytearray()
        self._in_paste = False

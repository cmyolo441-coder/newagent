"""KeyBinding - manages key-to-action bindings."""

from typing import Callable, Dict, List, Optional


class KeyBinding:
    """Binds key sequences to actions or commands."""

    def __init__(self):
        self._bindings: Dict[str, str] = {}
        self._action_handlers: Dict[str, List[Callable]] = {}

    def bind(self, key: str, action: str):
        self._bindings[key] = action

    def unbind(self, key: str):
        self._bindings.pop(key, None)

    def has_binding(self, key: str) -> bool:
        return key in self._bindings

    def get_action(self, key: str) -> Optional[str]:
        return self._bindings.get(key)

    def on_action(self, action: str, handler: Callable):
        if action not in self._action_handlers:
            self._action_handlers[action] = []
        self._action_handlers[action].append(handler)

    def execute_action(self, action: str):
        handlers = self._action_handlers.get(action, [])
        for handler in handlers:
            handler()

    def load_defaults(self):
        defaults = {
            'c-c': 'interrupt',
            'c-d': 'eof',
            'c-z': 'suspend',
            'c-l': 'clear_screen',
            'c-u': 'clear_line',
            'c-w': 'delete_word',
            'c-a': 'home',
            'c-e': 'end',
            'c-r': 'search_history',
            'c-p': 'history_prev',
            'c-n': 'history_next',
            'tab': 'complete',
            'enter': 'accept_line',
            'backspace': 'delete_back',
            'escape': 'cancel',
        }
        self._bindings.update(defaults)

    def clear(self):
        self._bindings.clear()
        self._action_handlers.clear()

    def to_dict(self) -> dict:
        return dict(self._bindings)

    def load_from(self, data: dict):
        self._bindings.update(data)

"""PasteHandler - handles paste events."""

from typing import Callable, List, Optional

from terminal.input.bracketed_paste import BracketedPaste


class PasteHandler:
    """Handles paste operations (regular and bracketed)."""

    def __init__(self):
        self.bracketed = BracketedPaste()
        self._on_paste: List[Callable] = []

    def process(self, data: bytes) -> Optional[str]:
        if self.bracketed.enabled:
            result = self.bracketed.process(data)
            if result:
                for cb in self._on_paste:
                    cb(result)
                return result
        return None

    def on_paste(self, callback: Callable[[str], None]):
        self._on_paste.append(callback)

    def paste(self, text: str) -> bytes:
        if self.bracketed.enabled:
            return self.bracketed.wrap(text)
        return text.encode('utf-8')

    @property
    def bracketed_mode(self) -> bool:
        return self.bracketed.enabled

    @bracketed_mode.setter
    def bracketed_mode(self, value: bool):
        self.bracketed.enabled = value

    def clear(self):
        self._on_paste.clear()
        self.bracketed.reset()

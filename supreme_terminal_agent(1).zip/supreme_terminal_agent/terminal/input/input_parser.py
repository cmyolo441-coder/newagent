"""InputParser - parses raw input bytes into structured input events."""

from typing import Dict, List, Optional, Tuple

from terminal.input.key_parser import KeyParser
from terminal.input.mouse_parser import MouseParser
from terminal.input.utf8_handler import Utf8Handler


class InputParser:
    """Parses raw input bytes into structured events (keys, mouse, paste, etc)."""

    def __init__(self):
        self.key_parser = KeyParser()
        self.mouse_parser = MouseParser()
        self.utf8 = Utf8Handler()

    def parse(self, data: bytes) -> List[dict]:
        """Parse bytes into a list of input events."""
        events = []
        i = 0
        while i < len(data):
            byte = data[i]
            if byte == 0x1b:
                end, event = self._parse_escape(data, i)
                if event:
                    events.append(event)
                i = end if end > i else i + 1
            elif byte & 0x80:
                char, width = self.utf8.decode(data, i)
                if char:
                    events.append({'type': 'char', 'char': char})
                i += width if width > 0 else 1
            elif byte == 0x7f:
                events.append({'type': 'key', 'key': 'backspace'})
                i += 1
            elif byte == 0x09:
                events.append({'type': 'key', 'key': 'tab'})
                i += 1
            elif byte == 0x0d:
                events.append({'type': 'key', 'key': 'enter'})
                i += 1
            elif byte == 0x03:
                events.append({'type': 'key', 'key': 'ctrl-c'})
                i += 1
            elif byte == 0x04:
                events.append({'type': 'key', 'key': 'ctrl-d'})
                i += 1
            elif byte == 0x1a:
                events.append({'type': 'key', 'key': 'ctrl-z'})
                i += 1
            elif 0x20 <= byte <= 0x7e:
                events.append({'type': 'char', 'char': chr(byte)})
                i += 1
            else:
                events.append({'type': 'key', 'key': f'c-{chr(byte + 0x60)}'})
                i += 1
        return events

    def _parse_escape(self, data: bytes, start: int) -> Tuple[int, Optional[dict]]:
        if start + 1 >= len(data):
            return start + 1, {'type': 'key', 'key': 'escape'}
        next_byte = data[start + 1]
        if next_byte == 0x5b:
            return self._parse_csi(data, start)
        elif next_byte == 0x4f:
            return self._parse_ss3(data, start)
        elif next_byte == 0x4d:
            return self._parse_mouse(data, start)
        elif next_byte == 0x50 or next_byte == 0x5f or next_byte == 0x5e or next_byte == 0x58:
            return self._parse_string_sequence(data, start)
        else:
            key = self.key_parser.parse_simple_escape(data, start)
            if key:
                return start + 2, {'type': 'key', 'key': key}
            return start + 2, {'type': 'key', 'key': f'escape-0x{next_byte:02x}'}

    def _parse_csi(self, data: bytes, start: int) -> Tuple[int, Optional[dict]]:
        idx = start + 2
        while idx < len(data) and not (0x40 <= data[idx] <= 0x7e):
            idx += 1
        if idx >= len(data):
            return start + 2, None
        terminator = data[idx]
        seq = data[start:idx + 1]
        if terminator == 0x4d and len(seq) >= 6:
            return self._parse_csi_mouse(seq)
        key_event = self.key_parser.parse_csi(seq)
        if key_event:
            return idx + 1, key_event
        return idx + 1, {'type': 'key', 'key': 'unknown-csi'}

    def _parse_ss3(self, data: bytes, start: int) -> Tuple[int, Optional[dict]]:
        if start + 2 < len(data):
            key_event = self.key_parser.parse_ss3(data, start)
            if key_event:
                return start + 3, key_event
        return start + 2, {'type': 'key', 'key': 'unknown-ss3'}

    def _parse_mouse(self, data: bytes, start: int) -> Tuple[int, Optional[dict]]:
        event = self.mouse_parser.parse(data, start)
        if event:
            return start + 6, event
        return start + 3, None

    def _parse_csi_mouse(self, seq: bytes) -> Tuple[int, Optional[dict]]:
        event = self.mouse_parser.parse_csi(seq)
        if event:
            return 0, event
        return 0, None

    def _parse_string_sequence(self, data: bytes, start: int) -> Tuple[int, Optional[dict]]:
        idx = start + 2
        while idx < len(data) and data[idx] not in (0x07, 0x9c) and not (
            data[idx] == 0x5c and idx > start + 2 and data[idx - 1] == 0x1b
        ):
            idx += 1
        if idx < len(data):
            idx += 1
        return idx, {'type': 'string', 'data': data[start:idx]}

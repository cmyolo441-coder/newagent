"""InputController - high-level controller for terminal input."""

import sys
import os
from typing import Callable, List, Optional

from terminal.input.input_reader import InputReader
from terminal.input.input_parser import InputParser
from terminal.input.input_processor import InputProcessor
from terminal.input.input_buffer import InputBuffer
from terminal.input.input_queue import InputQueue
from terminal.input.input_history import InputHistory
from terminal.input.keyboard_handler import KeyboardHandler
from terminal.input.mouse_handler import MouseHandler
from terminal.input.paste_handler import PasteHandler


class InputController:
    """High-level controller for all terminal input."""

    def __init__(self):
        self.reader = InputReader()
        self.parser = InputParser()
        self.processor = InputProcessor()
        self.buffer = InputBuffer()
        self.queue = InputQueue()
        self.history = InputHistory()
        self.keyboard = KeyboardHandler()
        self.mouse = MouseHandler()
        self.paste = PasteHandler()
        self._on_input: List[Callable] = []

    def start_reading(self, fd: Optional[int] = None):
        self.reader.start(fd)

    def stop_reading(self):
        self.reader.stop()

    def read_line(self, prompt: str = "", timeout: Optional[float] = None) -> str:
        if prompt:
            sys.stdout.write(prompt)
            sys.stdout.flush()
        data = self.reader.read_line(timeout=timeout)
        text = data.decode('utf-8', errors='replace').rstrip('\n\r')
        if text:
            self.history.add(text)
        return text

    def process(self, data: bytes):
        parsed = self.parser.parse(data)
        processed = self.processor.process(parsed)
        self.buffer.write(processed)
        for cb in self._on_input:
            cb(data)

    def process_character(self, char: str):
        self.process(char.encode('utf-8'))

    def on_input(self, callback: Callable):
        self._on_input.append(callback)

    def get_line_buffer(self) -> str:
        return self.buffer.get_value()

    def clear_buffer(self):
        self.buffer.clear()

    def get_history(self) -> List[str]:
        return self.history.get_all()

    def set_mouse_mode(self, mode: str):
        self.mouse.set_mode(mode)

    def set_bracketed_paste(self, enabled: bool):
        self.paste.bracketed = enabled

    def close(self):
        self.stop_reading()
        self.reader.close()
        self.buffer.clear()
        self.queue.clear()

"""InputHistory - manages input history."""

import os
import threading
from typing import Iterator, List, Optional


class InputHistory:
    """Manages a history of past inputs."""

    def __init__(self, max_entries: int = 1000):
        self.max_entries = max_entries
        self._entries: List[str] = []
        self._index = -1
        self._lock = threading.RLock()

    def add(self, text: str):
        if not text:
            return
        with self._lock:
            if self._entries and self._entries[-1] == text:
                return
            self._entries.append(text)
            if len(self._entries) > self.max_entries:
                self._entries.pop(0)
            self._index = len(self._entries)

    def get_previous(self) -> Optional[str]:
        with self._lock:
            if self._index > 0:
                self._index -= 1
                return self._entries[self._index]
            return None

    def get_next(self) -> Optional[str]:
        with self._lock:
            if self._index < len(self._entries) - 1:
                self._index += 1
                return self._entries[self._index]
            else:
                self._index = len(self._entries)
                return None

    def search(self, query: str) -> List[str]:
        with self._lock:
            return [e for e in self._entries if query in e]

    def get_all(self) -> List[str]:
        with self._lock:
            return list(self._entries)

    def get_last(self, n: int = 1) -> Optional[str]:
        with self._lock:
            if not self._entries:
                return None
            return self._entries[-min(n, len(self._entries))]

    def clear(self):
        with self._lock:
            self._entries.clear()
            self._index = -1

    @property
    def count(self) -> int:
        with self._lock:
            return len(self._entries)

    def save_to_file(self, filepath: str):
        with self._lock:
            with open(filepath, 'w') as f:
                for entry in self._entries:
                    f.write(entry + '\n')

    def load_from_file(self, filepath: str):
        if not os.path.exists(filepath):
            return
        with self._lock:
            with open(filepath, 'r') as f:
                self._entries = [line.rstrip('\n') for line in f][-self.max_entries:]
            self._index = len(self._entries)

    def __iter__(self) -> Iterator[str]:
        with self._lock:
            return iter(list(self._entries))

    def __len__(self) -> int:
        return self.count

"""KeyMacro - records and plays back key macros."""

import time
import threading
from typing import List, Optional, Callable


class KeyMacro:
    """Records and plays back sequences of key events."""

    def __init__(self):
        self._keys: List[str] = []
        self._recording = False
        self._playing = False
        self._on_play: Optional[Callable[[str], None]] = None
        self._thread: Optional[threading.Thread] = None

    def start_recording(self):
        self._keys = []
        self._recording = True

    def stop_recording(self) -> List[str]:
        self._recording = False
        return list(self._keys)

    def record(self, key: str):
        if self._recording:
            self._keys.append(key)

    def play(self, callback: Optional[Callable[[str], None]] = None, speed: float = 0.05):
        if self._playing or not self._keys:
            return
        self._playing = True
        self._on_play = callback
        self._thread = threading.Thread(target=self._play_loop, args=(speed,), daemon=True)
        self._thread.start()

    def _play_loop(self, speed: float):
        for key in self._keys:
            if not self._playing:
                break
            if self._on_play:
                self._on_play(key)
            time.sleep(speed)
        self._playing = False

    def stop_playback(self):
        self._playing = False
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None

    def clear(self):
        self._keys = []
        self._recording = False
        self._playing = False

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def is_playing(self) -> bool:
        return self._playing

    @property
    def key_count(self) -> int:
        return len(self._keys)

    def get_keys(self) -> List[str]:
        return list(self._keys)

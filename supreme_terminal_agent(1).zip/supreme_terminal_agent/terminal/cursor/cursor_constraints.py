"""CursorConstraints - manages cursor boundary constraints."""

from typing import Optional, Tuple


class CursorConstraints:
    """Enforces cursor position constraints (bounds)."""

    def __init__(self, max_rows: int = 24, max_cols: int = 80):
        self._max_rows = max_rows
        self._max_cols = max_cols
        self._min_row = 0
        self._min_col = 0
        self._margin_top = 0
        self._margin_bottom = 0
        self._margin_left = 0
        self._margin_right = 0

    def set_bounds(self, rows: int, cols: int):
        self._max_rows = rows
        self._max_cols = cols

    def set_margins(self, top: int, bottom: int, left: int, right: int):
        self._margin_top = top
        self._margin_bottom = bottom
        self._margin_left = left
        self._margin_right = right

    def constrain(self, x: int, y: int) -> Tuple[int, int]:
        cx = max(self._margin_left, min(x, self._max_cols - 1 - self._margin_right))
        cy = max(self._margin_top, min(y, self._max_rows - 1 - self._margin_bottom))
        return (cx, cy)

    def is_valid(self, x: int, y: int) -> bool:
        mx, my = self.constrain(x, y)
        return mx == x and my == y

    @property
    def max_rows(self) -> int:
        return self._max_rows

    @property
    def max_cols(self) -> int:
        return self._max_cols

    def to_dict(self) -> dict:
        return {
            'max_rows': self._max_rows,
            'max_cols': self._max_cols,
            'margin_top': self._margin_top,
            'margin_bottom': self._margin_bottom,
            'margin_left': self._margin_left,
            'margin_right': self._margin_right,
        }

    def load_from(self, data: dict):
        self._max_rows = data.get('max_rows', 24)
        self._max_cols = data.get('max_cols', 80)
        self._margin_top = data.get('margin_top', 0)
        self._margin_bottom = data.get('margin_bottom', 0)
        self._margin_left = data.get('margin_left', 0)
        self._margin_right = data.get('margin_right', 0)

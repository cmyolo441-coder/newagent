"""CursorStyle - manages cursor style settings."""

from typing import Optional


class CursorStyle:
    """Manages cursor style (shape, blink, color)."""

    def __init__(self):
        self._shape: str = "block"
        self._blink: bool = False
        self._color: str = "default"

    def set_shape(self, shape: str):
        valid = ("block", "underline", "bar", "beam")
        if shape in valid:
            self._shape = shape

    def set_blink(self, blink: bool):
        self._blink = blink

    def set_color(self, color: str):
        self._color = color

    @property
    def shape(self) -> str:
        return self._shape

    @property
    def blink(self) -> bool:
        return self._blink

    @property
    def color(self) -> str:
        return self._color

    def to_ansi(self) -> str:
        """Generate ANSI escape sequence for cursor style."""
        shape_map = {
            "block": "\x1b[1 q",
            "underline": "\x1b[4 q",
            "bar": "\x1b[5 q",
            "beam": "\x1b[6 q",
        }
        return shape_map.get(self._shape, "\x1b[1 q")

    def to_dict(self) -> dict:
        return {
            'shape': self._shape,
            'blink': self._blink,
            'color': self._color,
        }

    def load_from(self, data: dict):
        self._shape = data.get('shape', 'block')
        self._blink = data.get('blink', False)
        self._color = data.get('color', 'default')

    def reset(self):
        self._shape = "block"
        self._blink = False
        self._color = "default"

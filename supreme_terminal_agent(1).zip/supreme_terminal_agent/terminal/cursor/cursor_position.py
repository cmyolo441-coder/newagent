"""CursorPosition - tracks the cursor position."""

from typing import Tuple


class CursorPosition:
    """Tracks the current cursor position (x=column, y=row, 0-indexed)."""

    def __init__(self, rows: int = 24, cols: int = 80):
        self._x = 0
        self._y = 0
        self._max_rows = rows
        self._max_cols = cols

    @property
    def x(self) -> int:
        return self._x

    @x.setter
    def x(self, value: int):
        self._x = max(0, min(value, self._max_cols - 1))

    @property
    def y(self) -> int:
        return self._y

    @y.setter
    def y(self, value: int):
        self._y = max(0, min(value, self._max_rows - 1))

    def set(self, x: int, y: int):
        self.x = x
        self.y = y

    def set_max(self, rows: int, cols: int):
        self._max_rows = rows
        self._max_cols = cols

    def constrain(self, rows: int, cols: int):
        self._max_rows = rows
        self._max_cols = cols
        self._x = min(self._x, cols - 1)
        self._y = min(self._y, rows - 1)

    @property
    def position(self) -> Tuple[int, int]:
        return (self._x, self._y)

    @property
    def max_rows(self) -> int:
        return self._max_rows

    @property
    def max_cols(self) -> int:
        return self._max_cols

    def is_at(self, x: int, y: int) -> bool:
        return self._x == x and self._y == y

    def to_origin(self):
        self._x = 0
        self._y = 0

    def to_dict(self) -> dict:
        return {'x': self._x, 'y': self._y}

    def load_from(self, data: dict):
        self._x = data.get('x', 0)
        self._y = data.get('y', 0)

    def __repr__(self) -> str:
        return f"CursorPosition(x={self._x}, y={self._y})"

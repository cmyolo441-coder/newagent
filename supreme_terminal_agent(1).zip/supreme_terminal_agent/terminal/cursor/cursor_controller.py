"""CursorController - controls all cursor operations."""

from typing import Optional, Tuple

from terminal.cursor.cursor_position import CursorPosition
from terminal.cursor.cursor_movement import CursorMovement
from terminal.cursor.cursor_style import CursorStyle
from terminal.cursor.cursor_visibility import CursorVisibility
from terminal.cursor.cursor_blink import CursorBlink
from terminal.cursor.cursor_shape import CursorShape
from terminal.cursor.cursor_color import CursorColor
from terminal.cursor.cursor_save_restore import CursorSaveRestore
from terminal.cursor.cursor_constraints import CursorConstraints


class CursorController:
    """High-level controller for all cursor operations."""

    def __init__(self, rows: int = 24, cols: int = 80):
        self.position = CursorPosition(rows, cols)
        self.movement = CursorMovement(self.position)
        self.style = CursorStyle()
        self.visibility = CursorVisibility()
        self.blink = CursorBlink()
        self.shape = CursorShape()
        self.color = CursorColor()
        self.save_restore = CursorSaveRestore()
        self.constraints = CursorConstraints(rows, cols)

    def set_position(self, x: int, y: int):
        self.position.set(x, y)

    def move_up(self, n: int = 1):
        self.movement.up(n)

    def move_down(self, n: int = 1):
        self.movement.down(n)

    def move_left(self, n: int = 1):
        self.movement.left(n)

    def move_right(self, n: int = 1):
        self.movement.right(n)

    def move_to_column(self, col: int):
        self.movement.to_column(col)

    def move_to_row(self, row: int):
        self.movement.to_row(row)

    def move_home(self):
        self.movement.home()

    def save(self):
        self.save_restore.save(self.position.x, self.position.y)

    def restore(self):
        saved = self.save_restore.restore()
        if saved:
            self.position.set(*saved)

    def show(self):
        self.visibility.show()

    def hide(self):
        self.visibility.hide()

    def enable_blink(self):
        self.blink.enable()

    def disable_blink(self):
        self.blink.disable()

    def set_shape(self, shape: str):
        self.shape.set(shape)

    def set_color(self, color: str):
        self.color.set(color)

    def get_state(self) -> dict:
        return {
            'position': (self.position.x, self.position.y),
            'visible': self.visibility.visible,
            'blink': self.blink.enabled,
            'shape': self.shape.current,
            'color': self.color.current,
        }

    def reset(self):
        self.position.set(0, 0)
        self.visibility.show()
        self.shape.set('block')
        self.color.set('default')
        self.blink.disable()

    def constrain(self, rows: int, cols: int):
        self.constraints.set_bounds(rows, cols)
        self.position.constrain(rows, cols)

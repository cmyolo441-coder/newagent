"""CursorShape - manages cursor shape."""


class CursorShape:
    """Manages the cursor shape (block, underline, bar/beam)."""

    VALID_SHAPES = ("block", "underline", "bar", "beam", "default")

    def __init__(self):
        self._shape: str = "block"

    def set(self, shape: str):
        if shape in self.VALID_SHAPES:
            self._shape = shape

    def set_block(self):
        self._shape = "block"

    def set_underline(self):
        self._shape = "underline"

    def set_bar(self):
        self._shape = "bar"

    def set_beam(self):
        self._shape = "beam"

    @property
    def current(self) -> str:
        return self._shape

    @property
    def is_block(self) -> bool:
        return self._shape == "block"

    @property
    def is_underline(self) -> bool:
        return self._shape == "underline"

    @property
    def is_bar(self) -> bool:
        return self._shape == "bar"

    @property
    def is_beam(self) -> bool:
        return self._shape == "beam"

    def to_ansi(self) -> str:
        mapping = {
            "block": "\x1b[2 q",
            "underline": "\x1b[4 q",
            "bar": "\x1b[6 q",
            "beam": "\x1b[6 q",
        }
        return mapping.get(self._shape, "\x1b[2 q")

    def to_dict(self) -> dict:
        return {'shape': self._shape}

    def load_from(self, data: dict):
        shape = data.get('shape', 'block')
        self.set(shape)

    def reset(self):
        self._shape = "block"

"""CursorSaveRestore - saves and restores cursor positions."""

from typing import List, Optional, Tuple


class CursorSaveRestore:
    """Saves and restores cursor positions (DECSC/DECRC)."""

    def __init__(self):
        self._saved_positions: List[Tuple[int, int]] = []
        self._max_saves: int = 100

    def save(self, x: int, y: int):
        """Save the current cursor position."""
        self._saved_positions.append((x, y))
        if len(self._saved_positions) > self._max_saves:
            self._saved_positions.pop(0)

    def restore(self) -> Optional[Tuple[int, int]]:
        """Restore the most recently saved cursor position."""
        if self._saved_positions:
            return self._saved_positions.pop()
        return None

    def peek(self) -> Optional[Tuple[int, int]]:
        """View the most recently saved position without removing it."""
        if self._saved_positions:
            return self._saved_positions[-1]
        return None

    def clear(self):
        self._saved_positions.clear()

    @property
    def count(self) -> int:
        return len(self._saved_positions)

    def to_dict(self) -> dict:
        return {'saved_positions': list(self._saved_positions)}

    def load_from(self, data: dict):
        self._saved_positions = [tuple(p) for p in data.get('saved_positions', [])]

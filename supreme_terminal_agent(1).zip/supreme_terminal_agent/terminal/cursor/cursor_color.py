"""CursorColor - manages cursor color."""


class CursorColor:
    """Manages the cursor color."""

    def __init__(self):
        self._color: str = "default"

    def set(self, color: str):
        self._color = color

    def set_default(self):
        self._color = "default"

    def set_rgb(self, r: int, g: int, b: int):
        self._color = f"#{r:02x}{g:02x}{b:02x}"

    @property
    def current(self) -> str:
        return self._color

    @property
    def is_default(self) -> bool:
        return self._color == "default"

    def to_ansi(self) -> str:
        if self._color == "default":
            return ""
        if self._color.startswith('#'):
            try:
                hex_val = self._color[1:]
                r = int(hex_val[0:2], 16)
                g = int(hex_val[2:4], 16)
                b = int(hex_val[4:6], 16)
                return f"\x1b]12;rgb:{r:02x}/{g:02x}/{b:02x}\x1b\\"
            except (ValueError, IndexError):
                return ""
        return f"\x1b]12;{self._color}\x1b\\"

    def to_dict(self) -> dict:
        return {'color': self._color}

    def load_from(self, data: dict):
        self._color = data.get('color', 'default')

    def reset(self):
        self._color = "default"

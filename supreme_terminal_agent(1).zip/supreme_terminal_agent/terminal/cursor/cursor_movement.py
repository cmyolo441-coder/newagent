"""CursorMovement - controls cursor movement operations."""

from terminal.cursor.cursor_position import CursorPosition


class CursorMovement:
    """Handles cursor movement commands."""

    def __init__(self, position: CursorPosition):
        self.position = position

    def up(self, n: int = 1):
        self.position.y = self.position.y - n

    def down(self, n: int = 1):
        self.position.y = self.position.y + n

    def left(self, n: int = 1):
        self.position.x = self.position.x - n

    def right(self, n: int = 1):
        self.position.x = self.position.x + n

    def to_column(self, col: int):
        self.position.x = col

    def to_row(self, row: int):
        self.position.y = row

    def to_position(self, x: int, y: int):
        self.position.set(x, y)

    def home(self):
        self.position.to_origin()

    def next_line(self):
        self.position.y += 1
        self.position.x = 0

    def prev_line(self):
        self.position.y -= 1
        self.position.x = 0

    def tab_forward(self, tab_stops: int = 8):
        self.position.x = ((self.position.x // tab_stops) + 1) * tab_stops

    def tab_backward(self, tab_stops: int = 8):
        self.position.x = max(0, ((self.position.x - 1) // tab_stops) * tab_stops)

    def carriage_return(self):
        self.position.x = 0

    def line_feed(self):
        self.position.y += 1

    def reverse_line_feed(self):
        self.position.y -= 1

    def to_bottom(self):
        self.position.y = self.position.max_rows - 1

    def to_top(self):
        self.position.y = 0

    def to_right_edge(self):
        self.position.x = self.position.max_cols - 1

    def to_left_edge(self):
        self.position.x = 0

    def to_home(self):
        """Move cursor to top-left."""
        self.to_top()
        self.to_left_edge()

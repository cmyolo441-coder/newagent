"""CursorVisibility - manages cursor visibility."""


class CursorVisibility:
    """Manages whether the cursor is visible or hidden."""

    def __init__(self):
        self._visible: bool = True

    def show(self):
        self._visible = True

    def hide(self):
        self._visible = False

    @property
    def visible(self) -> bool:
        return self._visible

    @visible.setter
    def visible(self, value: bool):
        self._visible = value

    def toggle(self):
        self._visible = not self._visible

    def to_ansi(self) -> str:
        if self._visible:
            return "\x1b[?25h"
        else:
            return "\x1b[?25l"

    def to_dict(self) -> dict:
        return {'visible': self._visible}

    def load_from(self, data: dict):
        self._visible = data.get('visible', True)

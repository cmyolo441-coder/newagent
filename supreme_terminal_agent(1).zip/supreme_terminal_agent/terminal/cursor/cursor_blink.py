"""CursorBlink - manages cursor blink state."""


class CursorBlink:
    """Manages whether the cursor blinks."""

    def __init__(self):
        self._enabled: bool = False

    def enable(self):
        self._enabled = True

    def disable(self):
        self._enabled = False

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool):
        self._enabled = value

    def toggle(self):
        self._enabled = not self._enabled

    def to_ansi(self) -> str:
        if self._enabled:
            return "\x1b[?12h"
        else:
            return "\x1b[?12l"

    def to_dict(self) -> dict:
        return {'enabled': self._enabled}

    def load_from(self, data: dict):
        self._enabled = data.get('enabled', False)

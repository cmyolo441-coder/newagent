"""TerminalState - manages the runtime state of a terminal instance."""

import copy
import threading
from enum import Enum
from typing import Any, Dict, List, Optional


class TerminalMode(Enum):
    ASCII = "ascii"
    UTF8 = "utf8"
    SBCS = "sbcs"
    DBCS = "dbcs"


class CursorStyle(Enum):
    BLINKING_BLOCK = 1
    STEADY_BLOCK = 2
    BLINKING_UNDERLINE = 3
    STEADY_UNDERLINE = 4
    BLINKING_BAR = 5
    STEADY_BAR = 6


class TerminalState:
    """Holds the complete runtime state for a terminal emulator session."""

    def __init__(self, rows: int = 24, cols: int = 80):
        self._lock = threading.RLock()
        self._rows = rows
        self._cols = cols
        self._scroll_top: int = 0
        self._scroll_bottom: int = rows - 1
        self._cursor_x: int = 0
        self._cursor_y: int = 0
        self._cursor_visible: bool = True
        self._cursor_style: CursorStyle = CursorStyle.BLINKING_BLOCK
        self._autowrap: bool = True
        self._insert_mode: bool = False
        self._origin_mode: bool = False
        self._application_keypad: bool = False
        self._application_cursor: bool = False
        self._bracketed_paste: bool = False
        self._mouse_mode: int = 0
        self._mouse_encoding: int = 0
        self._mode: TerminalMode = TerminalMode.UTF8
        self._fg_color: Optional[str] = None
        self._bg_color: Optional[str] = None
        self._bold: bool = False
        self._dim: bool = False
        self._italic: bool = False
        self._underline: bool = False
        self._blink: bool = False
        self._reverse: bool = False
        self._strikethrough: bool = False
        self._protected: bool = False
        self._title: str = ""
        self._icon_name: str = ""
        self._tab_stops: List[int] = []
        self._custom: Dict[str, Any] = {}

    @property
    def rows(self) -> int:
        return self._rows

    @rows.setter
    def rows(self, value: int):
        with self._lock:
            self._rows = value
            self._scroll_bottom = value - 1

    @property
    def cols(self) -> int:
        return self._cols

    @cols.setter
    def cols(self, value: int):
        with self._lock:
            self._cols = value

    @property
    def cursor_x(self) -> int:
        return self._cursor_x

    @cursor_x.setter
    def cursor_x(self, value: int):
        with self._lock:
            self._cursor_x = max(0, min(value, self._cols - 1))

    @property
    def cursor_y(self) -> int:
        return self._cursor_y

    @cursor_y.setter
    def cursor_y(self, value: int):
        with self._lock:
            self._cursor_y = max(0, min(value, self._rows - 1))

    @property
    def cursor_visible(self) -> bool:
        return self._cursor_visible

    @cursor_visible.setter
    def cursor_visible(self, value: bool):
        with self._lock:
            self._cursor_visible = value

    @property
    def cursor_style(self) -> CursorStyle:
        return self._cursor_style

    @cursor_style.setter
    def cursor_style(self, value: CursorStyle):
        with self._lock:
            self._cursor_style = value

    @property
    def scrolled(self) -> int:
        return self._scroll_top

    @property
    def scroll_region(self) -> tuple:
        with self._lock:
            return (self._scroll_top, self._scroll_bottom)

    def set_scroll_region(self, top: int, bottom: int):
        with self._lock:
            self._scroll_top = max(0, top)
            self._scroll_bottom = min(self._rows - 1, bottom)

    def reset_scroll_region(self):
        with self._lock:
            self._scroll_top = 0
            self._scroll_bottom = self._rows - 1

    def set_cursor(self, x: int, y: int):
        with self._lock:
            if self._origin_mode:
                y += self._scroll_top
            self._cursor_x = max(0, min(x, self._cols - 1))
            self._cursor_y = max(0, min(y, self._rows - 1))

    def move_cursor_up(self, n: int = 1):
        with self._lock:
            self._cursor_y = max(self._scroll_top, self._cursor_y - n)

    def move_cursor_down(self, n: int = 1):
        with self._lock:
            self._cursor_y = min(self._scroll_bottom, self._cursor_y + n)

    def move_cursor_left(self, n: int = 1):
        with self._lock:
            self._cursor_x = max(0, self._cursor_x - n)

    def move_cursor_right(self, n: int = 1):
        with self._lock:
            self._cursor_x = min(self._cols - 1, self._cursor_x + n)

    def carriage_return(self):
        with self._lock:
            self._cursor_x = 0

    def linefeed(self):
        with self._lock:
            if self._cursor_y == self._scroll_bottom:
                self._cursor_y = self._scroll_bottom
            else:
                self._cursor_y += 1

    def reverse_index(self):
        with self._lock:
            if self._cursor_y == self._scroll_top:
                pass
            else:
                self._cursor_y -= 1

    def tab_forward(self, tab_width: int = 8):
        with self._lock:
            new_x = ((self._cursor_x + tab_width) // tab_width) * tab_width
            self._cursor_x = min(new_x, self._cols - 1)

    def tab_backward(self, tab_width: int = 8):
        with self._lock:
            self._cursor_x = max(0, self._cursor_x - tab_width)

    def set_tab_stop(self):
        with self._lock:
            if self._cursor_x not in self._tab_stops:
                self._tab_stops.append(self._cursor_x)

    def clear_tab_stop(self):
        with self._lock:
            self._tab_stops = [t for t in self._tab_stops if t != self._cursor_x]

    def clear_all_tab_stops(self):
        with self._lock:
            self._tab_stops.clear()

    def reset(self):
        with self._lock:
            self._cursor_x = 0
            self._cursor_y = 0
            self._cursor_visible = True
            self._cursor_style = CursorStyle.BLINKING_BLOCK
            self._autowrap = True
            self._insert_mode = False
            self._origin_mode = False
            self._application_keypad = False
            self._application_cursor = False
            self._bracketed_paste = False
            self._mouse_mode = 0
            self._mouse_encoding = 0
            self._mode = TerminalMode.UTF8
            self._fg_color = None
            self._bg_color = None
            self._bold = False
            self._dim = False
            self._italic = False
            self._underline = False
            self._blink = False
            self._reverse = False
            self._strikethrough = False
            self._protected = False
            self._title = ""
            self._icon_name = ""
            self._tab_stops.clear()

    def save_cursor(self) -> tuple:
        with self._lock:
            return (self._cursor_x, self._cursor_y)

    def restore_cursor(self, pos: tuple):
        with self._lock:
            self._cursor_x, self._cursor_y = pos

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "rows": self._rows,
                "cols": self._cols,
                "cursor_x": self._cursor_x,
                "cursor_y": self._cursor_y,
                "cursor_visible": self._cursor_visible,
                "cursor_style": self._cursor_style.value,
                "scroll_top": self._scroll_top,
                "scroll_bottom": self._scroll_bottom,
                "autowrap": self._autowrap,
                "insert_mode": self._insert_mode,
                "origin_mode": self._origin_mode,
                "application_keypad": self._application_keypad,
                "application_cursor": self._application_cursor,
                "bracketed_paste": self._bracketed_paste,
                "mouse_mode": self._mouse_mode,
                "mouse_encoding": self._mouse_encoding,
                "mode": self._mode.value,
                "title": self._title,
                "icon_name": self._icon_name,
            }

    def load_from(self, data: Dict[str, Any]):
        with self._lock:
            self._rows = data.get("rows", self._rows)
            self._cols = data.get("cols", self._cols)
            self._cursor_x = data.get("cursor_x", 0)
            self._cursor_y = data.get("cursor_y", 0)
            self._cursor_visible = data.get("cursor_visible", True)
            self._scroll_top = data.get("scroll_top", 0)
            self._scroll_bottom = data.get("scroll_bottom", self._rows - 1)
            self._autowrap = data.get("autowrap", True)
            self._insert_mode = data.get("insert_mode", False)
            self._origin_mode = data.get("origin_mode", False)
            self._title = data.get("title", "")
            self._icon_name = data.get("icon_name", "")

    def __repr__(self) -> str:
        with self._lock:
            return (
                f"TerminalState(rows={self._rows}, cols={self._cols}, "
                f"cursor=({self._cursor_x},{self._cursor_y}))"
            )

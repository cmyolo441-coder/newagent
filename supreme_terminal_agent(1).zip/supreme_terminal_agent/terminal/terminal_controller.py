"""TerminalController - manages terminal instance lifecycle and I/O operations."""

import os
import pty
import time
import errno
import fcntl
import signal
import struct
import termios
import logging
import threading
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

from terminal.terminal_state import TerminalState
from terminal.terminal_emulator import TerminalEmulator
from terminal.terminal_renderer import RenderedFrame, TerminalRenderer
from terminal.terminal_capabilities import TerminalCapabilities
from terminal.terminal_negotiation import NegotiationResult, TerminalNegotiation
from terminal.screen.screen_manager import ScreenManager
from terminal.session.session_metadata import SessionMetadata

logger = logging.getLogger(__name__)


class TerminalStatus(Enum):
    CREATED = "created"
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    CLOSED = "closed"
    ERROR = "error"


class TerminalController:
    """Controls the full lifecycle of a terminal instance.

    Owns the PTY process, emulator, renderer, and manages I/O between
    the underlying OS terminal and the emulation layer.
    """

    def __init__(
        self,
        rows: int = 24,
        cols: int = 80,
        terminal_id: Optional[str] = None,
    ):
        self.terminal_id = terminal_id or f"term_{id(self)}"
        self._rows = rows
        self._cols = cols
        self._status = TerminalStatus.CREATED
        self._capabilities = TerminalCapabilities()
        self._state = TerminalState(rows, cols)
        self._emulator = TerminalEmulator(rows, cols, self._capabilities)
        self._renderer = TerminalRenderer(self._capabilities, self._state)
        self._negotiation = TerminalNegotiation(self._capabilities)
        self._metadata = SessionMetadata()

        self._master_fd: Optional[int] = None
        self._slave_fd: Optional[int] = None
        self._child_pid: Optional[int] = None
        self._shell: str = "/bin/bash"
        self._lock = threading.RLock()
        self._created_at = time.time()
        self._last_activity = time.time()
        self._on_data_callbacks: List[Callable[[bytes], None]] = []
        self._on_status_change: List[Callable[[TerminalStatus], None]] = []
        self._on_error: List[Callable[[Exception], None]] = []

    @property
    def status(self) -> TerminalStatus:
        return self._status

    @property
    def is_active(self) -> bool:
        return self._status == TerminalStatus.RUNNING

    @property
    def is_paused(self) -> bool:
        return self._status == TerminalStatus.PAUSED

    @property
    def rows(self) -> int:
        return self._rows

    @property
    def cols(self) -> int:
        return self._cols

    @property
    def state(self) -> TerminalState:
        return self._state

    @property
    def emulator(self) -> TerminalEmulator:
        return self._emulator

    @property
    def renderer(self) -> TerminalRenderer:
        return self._renderer

    @property
    def capabilities(self) -> TerminalCapabilities:
        return self._capabilities

    @property
    def negotiation(self) -> TerminalNegotiation:
        return self._negotiation

    @property
    def metadata(self) -> SessionMetadata:
        return self._metadata

    @property
    def master_fd(self) -> Optional[int]:
        return self._master_fd

    @property
    def uptime(self) -> float:
        return time.time() - self._created_at

    @property
    def last_activity(self) -> float:
        return self._last_activity

    @property
    def idle_time(self) -> float:
        return time.time() - self._last_activity

    def initialize(
        self,
        shell: str = "/bin/bash",
        env: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        term: str = "xterm-256color",
    ):
        """Initialize the terminal with a PTY and shell process."""
        with self._lock:
            if self._status != TerminalStatus.CREATED:
                raise RuntimeError(f"Cannot initialize terminal in state: {self._status}")

            self._status = TerminalStatus.INITIALIZING
            self._shell = shell
            self._notify_status()

            try:
                self._master_fd, self._slave_fd = pty.openpty()
                self._configure_pty()

                pid = os.fork()
                if pid == 0:
                    self._child_process(env, cwd, term)
                else:
                    self._parent_process(pid)

                self._status = TerminalStatus.RUNNING
                self._emulator.start()
                self._notify_status()

            except OSError as e:
                self._status = TerminalStatus.ERROR
                self._notify_error(e)
                raise

    def _configure_pty(self):
        """Configure PTY attributes."""
        if self._master_fd is None:
            return
        import fcntl
        fl = fcntl.fcntl(self._master_fd, fcntl.F_GETFL)
        fcntl.fcntl(self._master_fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)

        self._set_winsize(self._rows, self._cols)

        attrs = termios.tcgetattr(self._master_fd)
        attrs[0] = attrs[0] & ~(termios.IGNBRK | termios.BRKINT | termios.PARMRK
                                 | termios.ISTRIP | termios.INLCR | termios.IGNCR
                                 | termios.ICRNL | termios.IXON)
        attrs[1] = attrs[1] & ~termios.OPOST
        attrs[2] = attrs[2] & ~(termios.CSIZE | termios.PARENB)
        attrs[2] = attrs[2] | termios.CS8
        attrs[3] = attrs[3] & ~(termios.ECHO | termios.ICANON | termios.ISIG
                                 | termios.IEXTEN)
        attrs[3] = attrs[3] | termios.TTYDEF_IFLAG
        termios.tcsetattr(self._master_fd, termios.TCSANOW, attrs)

    def _child_process(self, env: Optional[Dict[str, str]], cwd: Optional[str], term: str):
        """Child process: set up slave PTY and exec shell."""
        try:
            os.setsid()
            os.dup2(self._slave_fd, 0)
            os.dup2(self._slave_fd, 1)
            os.dup2(self._slave_fd, 2)

            for fd in range(3, 1024):
                try:
                    os.close(fd)
                except OSError:
                    pass

            if cwd:
                try:
                    os.chdir(cwd)
                except OSError:
                    pass

            proc_env = os.environ.copy()
            if env:
                proc_env.update(env)
            proc_env["TERM"] = term

            os.execve(self._shell, [self._shell, "--login"], proc_env)
        except OSError:
            os._exit(1)

    def _parent_process(self, pid: int):
        """Parent process: close slave fd and track child."""
        if self._slave_fd is not None:
            try:
                os.close(self._slave_fd)
            except OSError:
                pass
            self._slave_fd = None
        self._child_pid = pid

    def _set_winsize(self, rows: int, cols: int):
        """Set terminal window size via ioctl."""
        if self._master_fd is None:
            return
        try:
            buf = struct.pack("HHHH", rows, cols, 0, 0)
            fcntl.ioctl(self._master_fd, termios.TIOCSWINSZ, buf)
        except OSError:
            pass

    def read(self, size: int = 4096) -> bytes:
        """Read raw data from the PTY master."""
        if self._master_fd is None:
            return b""
        try:
            data = os.read(self._master_fd, size)
            if data:
                self._last_activity = time.time()
                self._emulator.feed(data)
            return data
        except OSError as e:
            if e.errno == errno.EAGAIN:
                return b""
            if e.errno == errno.EIO:
                self.close()
            return b""

    def write(self, data: bytes) -> int:
        """Write raw data to the PTY master."""
        if self._master_fd is None:
            raise RuntimeError("Terminal not initialized")
        try:
            written = os.write(self._master_fd, data)
            self._last_activity = time.time()
            self._emulator.write_input(data)
            for cb in self._on_data_callbacks:
                try:
                    cb(data)
                except Exception:
                    pass
            return written
        except OSError:
            return 0

    def writeline(self, text: str) -> int:
        """Write a line of text to the terminal."""
        return self.write((text + "\n").encode("utf-8", errors="replace"))

    def resize(self, rows: int, cols: int):
        """Resize the terminal PTY and emulator."""
        with self._lock:
            self._rows = rows
            self._cols = cols
            self._set_winsize(rows, cols)
            self._emulator.resize(rows, cols)
            self._state.rows = rows
            self._state.cols = cols
            if self._child_pid:
                try:
                    os.kill(self._child_pid, signal.SIGWINCH)
                except OSError:
                    pass

    def render(self) -> RenderedFrame:
        """Render the current terminal state."""
        return self._emulator.render()

    def get_plain_text(self) -> str:
        """Get visible terminal content as plain text."""
        return self._emulator.get_plain_text()

    def pause(self):
        """Pause the terminal (stops processing)."""
        with self._lock:
            self._status = TerminalStatus.PAUSED
            self._emulator.stop()
            self._notify_status()

    def resume(self):
        """Resume a paused terminal."""
        with self._lock:
            if self._status == TerminalStatus.PAUSED:
                self._status = TerminalStatus.RUNNING
                self._emulator.start()
                self._notify_status()

    def reset(self, hard: bool = False):
        """Reset the terminal state."""
        self._emulator.reset(hard)
        self._state.reset()
        if hard:
            self._negotiation = TerminalNegotiation(self._capabilities)

    def close(self):
        """Close the terminal and release all resources."""
        with self._lock:
            old_status = self._status
            self._status = TerminalStatus.CLOSED
            self._emulator.close()

            if self._child_pid:
                try:
                    os.kill(self._child_pid, signal.SIGHUP)
                    os.kill(self._child_pid, signal.SIGTERM)
                    _, status = os.waitpid(self._child_pid, os.WNOHANG)
                    if not status:
                        import time
                        time.sleep(0.1)
                        try:
                            os.kill(self._child_pid, signal.SIGKILL)
                            os.waitpid(self._child_pid, 0)
                        except OSError:
                            pass
                except OSError:
                    pass
                self._child_pid = None

            if self._master_fd is not None:
                try:
                    os.close(self._master_fd)
                except OSError:
                    pass
                self._master_fd = None

            self._notify_status()

    def get_state(self) -> Dict[str, Any]:
        """Get serializable terminal state."""
        with self._lock:
            return {
                "terminal_id": self.terminal_id,
                "status": self._status.value,
                "rows": self._rows,
                "cols": self._cols,
                "shell": self._shell,
                "state": self._state.to_dict(),
                "metadata": self._metadata.to_dict() if hasattr(self._metadata, "to_dict") else {},
                "created_at": self._created_at,
                "last_activity": self._last_activity,
                "uptime": self.uptime,
                "idle_time": self.idle_time,
                "child_pid": self._child_pid,
            }

    def load_state(self, data: Dict[str, Any]):
        """Restore terminal state from a dictionary."""
        with self._lock:
            self.terminal_id = data.get("terminal_id", self.terminal_id)
            self._rows = data.get("rows", self._rows)
            self._cols = data.get("cols", self._cols)
            self._shell = data.get("shell", self._shell)
            self._state.load_from(data.get("state", {}))
            state_data = data.get("metadata", {})
            if state_data and hasattr(self._metadata, "load_from"):
                self._metadata.load_from(state_data)
            self._created_at = data.get("created_at", time.time())
            self._last_activity = data.get("last_activity", time.time())

    def on_data(self, callback: Callable[[bytes], None]):
        """Register a callback for incoming data."""
        self._on_data_callbacks.append(callback)

    def on_status_change(self, callback: Callable[[TerminalStatus], None]):
        """Register a callback for status changes."""
        self._on_status_change.append(callback)

    def on_error(self, callback: Callable[[Exception], None]):
        """Register a callback for errors."""
        self._on_error.append(callback)

    def fileno(self) -> int:
        """Return the master fd for use in select/poll loops."""
        if self._master_fd is None:
            raise RuntimeError("Terminal not initialized")
        return self._master_fd

    def _notify_status(self):
        """Notify status change callbacks."""
        for cb in self._on_status_change:
            try:
                cb(self._status)
            except Exception:
                pass

    def _notify_error(self, error: Exception):
        """Notify error callbacks."""
        for cb in self._on_error:
            try:
                cb(error)
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __repr__(self) -> str:
        return (
            f"TerminalController(id={self.terminal_id!r}, "
            f"status={self._status.value}, "
            f"size={self._rows}x{self._cols})"
        )

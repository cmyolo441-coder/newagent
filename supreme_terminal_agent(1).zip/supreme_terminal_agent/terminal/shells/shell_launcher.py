"""ShellLauncher - launches shell processes in PTY sessions."""

import os
import pty
import signal
import struct
import fcntl
import termios
from typing import Optional

from terminal.shells.shell_controller import ShellController


class ShellLauncher:
    """Launches shell processes in pseudo-terminal sessions."""

    def __init__(self, manager):
        self._manager = manager

    def launch(self, shell_path: Optional[str] = None, rows: int = 24, cols: int = 80,
               env: Optional[dict] = None) -> ShellController:
        shell = shell_path or os.environ.get('SHELL', '/bin/bash')
        controller = ShellController()

        controller.master_fd, controller.slave_fd = pty.openpty()
        self._set_winsize(controller.master_fd, rows, cols)

        env_dict = (env or os.environ.copy())
        env_dict['TERM'] = env_dict.get('TERM', 'xterm-256color')
        env_dict['COLUMNS'] = str(cols)
        env_dict['LINES'] = str(rows)

        pid = os.fork()
        if pid == 0:
            try:
                os.close(controller.master_fd)
                os.setsid()
                os.dup2(controller.slave_fd, 0)
                os.dup2(controller.slave_fd, 1)
                os.dup2(controller.slave_fd, 2)
                if controller.slave_fd > 2:
                    os.close(controller.slave_fd)
                os.execve(shell, [shell], env_dict)
            except OSError:
                os._exit(1)
        else:
            controller.child_pid = pid
            controller.shell_path = shell
            controller.shell_type = self._detect_type(shell)
            os.close(controller.slave_fd)
            controller.slave_fd = None

        return controller

    def _set_winsize(self, fd: int, rows: int, cols: int):
        buf = struct.pack('HHHH', rows, cols, 0, 0)
        try:
            fcntl.ioctl(fd, termios.TIOCSWINSZ, buf)
        except OSError:
            pass

    def _detect_type(self, shell_path: str) -> str:
        name = os.path.basename(shell_path).lower()
        if 'bash' in name:
            return 'bash'
        elif 'zsh' in name:
            return 'zsh'
        elif 'fish' in name:
            return 'fish'
        return name

    def launch_interactive(self, shell_path: Optional[str] = None, **kwargs) -> ShellController:
        return self.launch(shell_path, **kwargs)

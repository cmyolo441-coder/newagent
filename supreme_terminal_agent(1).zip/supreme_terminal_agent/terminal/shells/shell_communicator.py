"""ShellCommunicator - communicates with shell processes."""

import os
import select
import time
import re
from typing import Optional

from terminal.shells.shell_controller import ShellController


class ShellCommunicator:
    """Handles sending commands to shells and receiving output."""

    def __init__(self):
        self._output_timeout = 10.0
        self._read_size = 4096

    def communicate(self, shell: ShellController, command: str, timeout: float = 10.0) -> str:
        shell.writeline(command)
        output = self._read_all_output(shell, timeout)
        return output

    def send_and_wait(self, shell: ShellController, command: str,
                      wait_for: str = '', timeout: float = 10.0) -> str:
        shell.writeline(command)
        return self._read_until(shell, wait_for, timeout)

    def send(self, shell: ShellController, data: bytes):
        shell.write(data)

    def send_line(self, shell: ShellController, text: str):
        shell.writeline(text)

    def read_output(self, shell: ShellController, timeout: float = 1.0) -> bytes:
        result = bytearray()
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                r, _, _ = select.select([shell.master_fd], [], [], 0.1)
                if r:
                    data = os.read(shell.master_fd, self._read_size)
                    if data:
                        result.extend(data)
                    else:
                        break
                else:
                    break
            except OSError:
                break
        return bytes(result)

    def read_line(self, shell: ShellController, timeout: float = 5.0) -> str:
        result = bytearray()
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                r, _, _ = select.select([shell.master_fd], [], [], 0.1)
                if r:
                    data = os.read(shell.master_fd, 1)
                    if data:
                        result.extend(data)
                        if data == b'\n':
                            break
                    else:
                        break
                else:
                    break
            except OSError:
                break
        return result.decode('utf-8', errors='replace').rstrip('\n\r')

    def _read_all_output(self, shell: ShellController, timeout: float) -> str:
        result = bytearray()
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                r, _, _ = select.select([shell.master_fd], [], [], 0.1)
                if r:
                    data = os.read(shell.master_fd, self._read_size)
                    if data:
                        result.extend(data)
                    else:
                        break
                else:
                    break
            except OSError:
                break
        return result.decode('utf-8', errors='replace')

    def _read_until(self, shell: ShellController, marker: str, timeout: float) -> str:
        result = bytearray()
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                r, _, _ = select.select([shell.master_fd], [], [], 0.05)
                if r:
                    data = os.read(shell.master_fd, self._read_size)
                    if data:
                        result.extend(data)
                        if marker and marker.encode() in result:
                            break
                    else:
                        break
                else:
                    break
            except OSError:
                break
        return result.decode('utf-8', errors='replace')

    def wait_for_output(self, shell: ShellController, timeout: float = 1.0) -> bool:
        try:
            r, _, _ = select.select([shell.master_fd], [], [], timeout)
            return len(r) > 0
        except (ValueError, OSError):
            return False

"""ShellDetector - detects available shells on the system."""

import os
import subprocess
from typing import Dict, List, Optional


class ShellDetector:
    """Detects available shells on the system."""

    COMMON_SHELLS = [
        '/bin/bash', '/bin/zsh', '/bin/fish', '/bin/dash',
        '/bin/ash', '/bin/sh', '/bin/ksh', '/bin/tcsh',
        '/bin/csh', '/usr/bin/pwsh', '/usr/bin/powershell',
        '/bin/nu', '/usr/bin/xonsh', '/usr/bin/elvish',
        '/usr/bin/oil',
    ]

    def detect_default(self) -> str:
        return os.environ.get('SHELL', '/bin/bash')

    def detect_available(self) -> Dict[str, str]:
        available = {}
        for shell in self.COMMON_SHELLS:
            if os.path.isfile(shell) and os.access(shell, os.X_OK):
                name = os.path.basename(shell)
                available[name] = shell
        try:
            with open('/etc/shells', 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        if os.path.isfile(line) and os.access(line, os.X_OK):
                            name = os.path.basename(line)
                            if name not in available:
                                available[name] = line
        except OSError:
            pass
        return available

    def detect_shell_type(self, shell_path: str) -> str:
        name = os.path.basename(shell_path).lower()
        if 'bash' in name:
            return 'bash'
        elif 'zsh' in name:
            return 'zsh'
        elif 'fish' in name:
            return 'fish'
        elif 'dash' in name:
            return 'dash'
        elif 'ash' in name:
            return 'ash'
        elif 'ksh' in name:
            return 'ksh'
        elif 'tcsh' in name:
            return 'tcsh'
        elif 'csh' in name:
            return 'csh'
        elif 'pwsh' in name or 'powershell' in name:
            return 'powershell'
        elif 'nu' in name or 'nushell' in name:
            return 'nushell'
        elif 'xonsh' in name:
            return 'xonsh'
        elif 'elvish' in name:
            return 'elvish'
        elif 'oil' in name:
            return 'oil'
        return 'sh'

    def is_valid_shell(self, shell_path: str) -> bool:
        return os.path.isfile(shell_path) and os.access(shell_path, os.X_OK)

    def get_shell_version(self, shell_path: str) -> Optional[str]:
        try:
            result = subprocess.run(
                [shell_path, '--version'],
                capture_output=True, text=True, timeout=5
            )
            return result.stdout.strip() or result.stderr.strip()
        except (subprocess.TimeoutExpired, OSError):
            return None

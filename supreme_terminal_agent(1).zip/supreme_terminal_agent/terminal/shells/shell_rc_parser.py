"""ShellRcParser - parses shell rc files for configuration."""

import re
from typing import Dict, List, Optional, Tuple


class ShellRcParser:
    """Parses shell rc files to extract aliases, exports, and other configs."""

    ALIAS_RE = re.compile(r'^alias\s+(\w+)\s*=\s*[\'"]?(.*?)[\'"]?\s*$')
    EXPORT_RE = re.compile(r'^export\s+(\w+)\s*=\s*[\'"]?(.*?)[\'"]?\s*$')
    PATH_RE = re.compile(r'^export\s+PATH\s*=\s*[\'"]?(.*?)[\'"]?\s*$')
    SOURCE_RE = re.compile(r'^source\s+(.+)$')
    FUNCTION_RE = re.compile(r'^function\s+(\w+)\s*\(\)')

    def parse(self, content: str) -> dict:
        aliases = {}
        exports = {}
        sources = []
        functions = []
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            alias_m = self.ALIAS_RE.match(line)
            if alias_m:
                aliases[alias_m.group(1)] = alias_m.group(2)
                continue
            export_m = self.EXPORT_RE.match(line)
            if export_m:
                exports[export_m.group(1)] = export_m.group(2)
                continue
            source_m = self.SOURCE_RE.match(line)
            if source_m:
                sources.append(source_m.group(1))
                continue
            fn_m = self.FUNCTION_RE.match(line)
            if fn_m:
                functions.append(fn_m.group(1))
        return {
            'aliases': aliases,
            'exports': exports,
            'sources': sources,
            'functions': functions,
        }

    def parse_file(self, filepath: str) -> Optional[dict]:
        try:
            with open(filepath, 'r') as f:
                return self.parse(f.read())
        except OSError:
            return None

    def extract_aliases(self, content: str) -> Dict[str, str]:
        result = {}
        for line in content.splitlines():
            m = self.ALIAS_RE.match(line.strip())
            if m:
                result[m.group(1)] = m.group(2)
        return result

    def extract_exports(self, content: str) -> Dict[str, str]:
        result = {}
        for line in content.splitlines():
            m = self.EXPORT_RE.match(line.strip())
            if m:
                result[m.group(1)] = m.group(2)
        return result

    def extract_paths(self, content: str) -> List[str]:
        for line in content.splitlines():
            m = self.PATH_RE.match(line.strip())
            if m:
                return m.group(1).split(':')
        return []

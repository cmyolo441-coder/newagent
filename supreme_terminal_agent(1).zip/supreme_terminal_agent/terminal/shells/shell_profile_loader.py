"""ShellProfileLoader - loads shell profile/rc files."""

import os
from typing import Dict, List, Optional


class ShellProfileLoader:
    """Loads and parses shell profile and rc files."""

    RC_FILES = {
        'bash': ['.bashrc', '.bash_profile', '.bash_login', '.profile'],
        'zsh': ['.zshrc', '.zshenv', '.zprofile'],
        'fish': ['.config/fish/config.fish'],
        'sh': ['.profile'],
        'ksh': ['.kshrc', '.profile'],
    }

    def __init__(self):
        self._home = os.path.expanduser('~')

    def load(self, shell_path: str) -> dict:
        shell_type = self._detect_type(shell_path)
        rc_files = self.RC_FILES.get(shell_type, ['.profile'])
        result = {}
        for rc_file in rc_files:
            path = os.path.join(self._home, rc_file)
            if os.path.exists(path):
                content = self._read_file(path)
                if content:
                    result[rc_file] = content
        return {'shell_type': shell_type, 'rc_files': result}

    def load_rc(self, shell_path: str) -> dict:
        return self.load(shell_path)

    def get_rc_paths(self, shell_type: str) -> List[str]:
        rc_files = self.RC_FILES.get(shell_type, ['.profile'])
        return [os.path.join(self._home, f) for f in rc_files]

    def _detect_type(self, shell_path: str) -> str:
        name = os.path.basename(shell_path).lower()
        for st in ('bash', 'zsh', 'fish', 'ksh'):
            if st in name:
                return st
        return 'sh'

    def _read_file(self, path: str) -> Optional[str]:
        try:
            with open(path, 'r') as f:
                return f.read()
        except (OSError, UnicodeDecodeError):
            return None

    def exists(self, shell_path: str) -> bool:
        for rc_path in self.get_rc_paths(self._detect_type(shell_path)):
            if os.path.exists(rc_path):
                return True
        return False

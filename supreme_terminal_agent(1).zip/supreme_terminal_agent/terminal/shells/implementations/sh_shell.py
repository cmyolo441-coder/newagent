"""ShShell - POSIX sh (Bourne shell) implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class ShShell(BaseShell):
    def __init__(self, shell_path: str = "/bin/sh"):
        super().__init__(shell_path)
        self.name = "sh"

    def get_name(self) -> str:
        return "sh"

    def get_type(self) -> str:
        return "sh"

    def get_default_rc(self) -> List[str]:
        return [
            "export TERM=xterm",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'heredoc', 'job_control',
        }
        return feature in features

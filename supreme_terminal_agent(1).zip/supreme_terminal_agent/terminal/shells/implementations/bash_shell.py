"""BashShell - Bash shell implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class BashShell(BaseShell):
    def __init__(self, shell_path: str = "/bin/bash"):
        super().__init__(shell_path)
        self.name = "bash"

    def get_name(self) -> str:
        return "bash"

    def get_type(self) -> str:
        return "bash"

    def get_default_rc(self) -> List[str]:
        return [
            "export TERM=xterm-256color",
            "export HISTFILE=/dev/null",
            "shopt -s histappend",
            "shopt -s checkwinsize",
            "set -o emacs",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'prompt_escapes', 'color_support', 'associative_arrays',
            'process_substitution', 'heredoc', 'arithmetic',
            'string_manipulation', 'printf',
        }
        return feature in features

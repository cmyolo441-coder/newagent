"""PowershellShell - Windows PowerShell implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class PowershellShell(BaseShell):
    def __init__(self, shell_path: str = "/usr/bin/powershell"):
        super().__init__(shell_path)
        self.name = "powershell"

    def get_name(self) -> str:
        return "powershell"

    def get_type(self) -> str:
        return "powershell"

    def get_default_rc(self) -> List[str]:
        return [
            "$env:TERM = 'xterm-256color'",
            "$OutputEncoding = [console]::OutputEncoding",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'color_support', 'object_pipeline', 'modules',
            'remoting', 'classes', 'exception_handling',
        }
        return feature in features

"""CmdShell - Windows cmd.exe implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class CmdShell(BaseShell):
    def __init__(self, shell_path: str = "cmd.exe"):
        super().__init__(shell_path)
        self.name = "cmd"

    def get_name(self) -> str:
        return "cmd"

    def get_type(self) -> str:
        return "cmd"

    def get_default_rc(self) -> List[str]:
        return []

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'history', 'batch_scripts',
            'environment_variables', 'error_level',
        }
        return feature in features

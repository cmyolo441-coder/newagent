"""PwshShell - PowerShell Core (pwsh) implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class PwshShell(BaseShell):
    def __init__(self, shell_path: str = "/usr/bin/pwsh"):
        super().__init__(shell_path)
        self.name = "pwsh"

    def get_name(self) -> str:
        return "pwsh"

    def get_type(self) -> str:
        return "pwsh"

    def get_default_rc(self) -> List[str]:
        return [
            "$env:TERM = 'xterm-256color'",
            "$PSDefaultParameterValues['*:Encoding'] = 'utf8'",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'color_support', 'object_pipeline', 'modules',
            'remoting', 'classes', 'exception_handling',
            'cross_platform', 'parallel_foreach',
        }
        return feature in features

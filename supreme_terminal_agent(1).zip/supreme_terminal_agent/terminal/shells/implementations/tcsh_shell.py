"""TcshShell - Tcsh (tenex csh) shell implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class TcshShell(BaseShell):
    def __init__(self, shell_path: str = "/bin/tcsh"):
        super().__init__(shell_path)
        self.name = "tcsh"

    def get_name(self) -> str:
        return "tcsh"

    def get_type(self) -> str:
        return "tcsh"

    def get_default_rc(self) -> List[str]:
        return [
            "set term = xterm-256color",
            "set prompt = '%{%%} '",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'prompt_escapes', 'color_support',
        }
        return feature in features

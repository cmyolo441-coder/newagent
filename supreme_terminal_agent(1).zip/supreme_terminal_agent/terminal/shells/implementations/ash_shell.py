"""AshShell - Ash (BusyBox Almquist shell) implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class AshShell(BaseShell):
    def __init__(self, shell_path: str = "/bin/ash"):
        super().__init__(shell_path)
        self.name = "ash"

    def get_name(self) -> str:
        return "ash"

    def get_type(self) -> str:
        return "ash"

    def get_default_rc(self) -> List[str]:
        return [
            "export TERM=linux",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'history', 'job_control', 'heredoc',
        }
        return feature in features

"""OilShell - Oil shell implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class OilShell(BaseShell):
    def __init__(self, shell_path: str = "/usr/bin/oil"):
        super().__init__(shell_path)
        self.name = "oil"

    def get_name(self) -> str:
        return "oil"

    def get_type(self) -> str:
        return "oil"

    def get_default_rc(self) -> List[str]:
        return [
            "export TERM=xterm-256color",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'prompt_escapes', 'color_support',
            'python_like', 'shell_compat',
        }
        return feature in features

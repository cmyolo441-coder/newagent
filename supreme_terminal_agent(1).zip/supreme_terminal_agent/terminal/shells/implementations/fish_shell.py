"""FishShell - Fish shell implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class FishShell(BaseShell):
    def __init__(self, shell_path: str = "/usr/bin/fish"):
        super().__init__(shell_path)
        self.name = "fish"

    def get_name(self) -> str:
        return "fish"

    def get_type(self) -> str:
        return "fish"

    def get_default_rc(self) -> List[str]:
        return [
            "set -g fish_emoji_width 2",
            "set -g theme_display_date no",
            "set -g theme_display_cmd_duration no",
            "set -U fish_color_normal normal",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'prompt_escapes', 'color_support', 'abbreviations',
            'syntax_highlighting', 'autosuggestions',
            'web_config', 'man_page_completions',
        }
        return feature in features

"""Shell implementations for various shell types."""

from terminal.shells.implementations.base_shell import BaseShell
from terminal.shells.implementations.bash_shell import BashShell
from terminal.shells.implementations.zsh_shell import ZshShell
from terminal.shells.implementations.fish_shell import FishShell
from terminal.shells.implementations.dash_shell import DashShell
from terminal.shells.implementations.ash_shell import AshShell
from terminal.shells.implementations.sh_shell import ShShell
from terminal.shells.implementations.ksh_shell import KshShell
from terminal.shells.implementations.tcsh_shell import TcshShell
from terminal.shells.implementations.csh_shell import CshShell
from terminal.shells.implementations.powershell_shell import PowershellShell
from terminal.shells.implementations.pwsh_shell import PwshShell
from terminal.shells.implementations.cmd_shell import CmdShell
from terminal.shells.implementations.nushell_shell import NushellShell
from terminal.shells.implementations.xonsh_shell import XonshShell
from terminal.shells.implementations.elvish_shell import ElvishShell
from terminal.shells.implementations.oil_shell import OilShell

__all__ = [
    'BaseShell', 'BashShell', 'ZshShell', 'FishShell',
    'DashShell', 'AshShell', 'ShShell', 'KshShell',
    'TcshShell', 'CshShell', 'PowershellShell', 'PwshShell',
    'CmdShell', 'NushellShell', 'XonshShell', 'ElvishShell', 'OilShell',
]

"""ZshShell - Zsh shell implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class ZshShell(BaseShell):
    def __init__(self, shell_path: str = "/bin/zsh"):
        super().__init__(shell_path)
        self.name = "zsh"

    def get_name(self) -> str:
        return "zsh"

    def get_type(self) -> str:
        return "zsh"

    def get_default_rc(self) -> List[str]:
        return [
            "export TERM=xterm-256color",
            "setopt AUTO_CD",
            "setopt EXTENDED_HISTORY",
            "setopt NOTIFY",
            "HISTSIZE=100000",
            "SAVEHIST=100000",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'prompt_escapes', 'color_support', 'associative_arrays',
            'process_substitution', 'heredoc', 'arithmetic',
            'string_manipulation', 'printf', 'vcs_info',
            'hook_functions', 'module_loading',
        }
        return feature in features

"""BaseShell - base class for all shell implementations."""

import os
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from terminal.shells.shell_controller import ShellController


class BaseShell(ABC):
    """Abstract base class for shell implementations."""

    def __init__(self, shell_path: str = ""):
        self.shell_path = shell_path
        self.name = ""
        self._controller: Optional[ShellController] = None

    @abstractmethod
    def get_name(self) -> str:
        ...

    @abstractmethod
    def get_default_rc(self) -> List[str]:
        ...

    def set_controller(self, controller: ShellController):
        self._controller = controller

    def get_controller(self) -> Optional[ShellController]:
        return self._controller

    def configure(self):
        if self._controller is None:
            return
        for line in self.get_default_rc():
            self._controller.writeline(line)

    def setup_prompt(self, prompt: str = ""):
        if self._controller is None:
            return
        if prompt:
            self._controller.writeline(prompt)

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'prompt_escapes', 'color_support',
        }
        return feature in features

    def get_version(self) -> Optional[str]:
        import subprocess
        try:
            result = subprocess.run(
                [self.shell_path, '--version'],
                capture_output=True, text=True, timeout=5
            )
            return (result.stdout or result.stderr).strip()
        except (OSError, subprocess.TimeoutExpired):
            return None

    @abstractmethod
    def get_type(self) -> str:
        ...

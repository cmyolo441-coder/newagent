"""CshShell - C shell (csh) implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class CshShell(BaseShell):
    def __init__(self, shell_path: str = "/bin/csh"):
        super().__init__(shell_path)
        self.name = "csh"

    def get_name(self) -> str:
        return "csh"

    def get_type(self) -> str:
        return "csh"

    def get_default_rc(self) -> List[str]:
        return [
            "set term=xterm",
            "set prompt='%# '",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'history', 'job_control', 'prompt_escapes',
        }
        return feature in features

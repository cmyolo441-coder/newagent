"""XonshShell - Xonsh (Python shell) implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class XonshShell(BaseShell):
    def __init__(self, shell_path: str = "/usr/bin/xonsh"):
        super().__init__(shell_path)
        self.name = "xonsh"

    def get_name(self) -> str:
        return "xonsh"

    def get_type(self) -> str:
        return "xonsh"

    def get_default_rc(self) -> List[str]:
        return [
            "$TERM = 'xterm-256color'",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'color_support', 'python_integration',
            'virtualenv', 'tab_completion',
        }
        return feature in features

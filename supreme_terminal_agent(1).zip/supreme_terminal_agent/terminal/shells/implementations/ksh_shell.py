"""KshShell - KornShell (ksh) implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class KshShell(BaseShell):
    def __init__(self, shell_path: str = "/bin/ksh"):
        super().__init__(shell_path)
        self.name = "ksh"

    def get_name(self) -> str:
        return "ksh"

    def get_type(self) -> str:
        return "ksh"

    def get_default_rc(self) -> List[str]:
        return [
            "export TERM=xterm-256color",
            "set -o emacs",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'job_control',
            'prompt_escapes', 'color_support', 'associative_arrays',
            'arithmetic', 'string_manipulation', 'printf',
            'coprocesses', 'floating_point',
        }
        return feature in features

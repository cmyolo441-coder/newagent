"""NushellShell - Nushell (nu) implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class NushellShell(BaseShell):
    def __init__(self, shell_path: str = "/usr/bin/nu"):
        super().__init__(shell_path)
        self.name = "nushell"

    def get_name(self) -> str:
        return "nushell"

    def get_type(self) -> str:
        return "nushell"

    def get_default_rc(self) -> List[str]:
        return [
            "$env.TERM = 'xterm-256color'",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'pipeline',
            'structured_data', 'color_support', 'plugins',
        }
        return feature in features

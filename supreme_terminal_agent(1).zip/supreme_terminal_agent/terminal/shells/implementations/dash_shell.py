"""DashShell - Dash (Debian Almquist shell) implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class DashShell(BaseShell):
    def __init__(self, shell_path: str = "/bin/dash"):
        super().__init__(shell_path)
        self.name = "dash"

    def get_name(self) -> str:
        return "dash"

    def get_type(self) -> str:
        return "dash"

    def get_default_rc(self) -> List[str]:
        return [
            "export TERM=xterm-256color",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'history', 'job_control', 'heredoc',
        }
        return feature in features

"""ElvishShell - Elvish shell implementation."""

from typing import List

from terminal.shells.implementations.base_shell import BaseShell


class ElvishShell(BaseShell):
    def __init__(self, shell_path: str = "/usr/bin/elvish"):
        super().__init__(shell_path)
        self.name = "elvish"

    def get_name(self) -> str:
        return "elvish"

    def get_type(self) -> str:
        return "elvish"

    def get_default_rc(self) -> List[str]:
        return [
            "set E:TERM = 'xterm-256color'",
        ]

    def has_feature(self, feature: str) -> bool:
        features = {
            'alias', 'completion', 'history', 'pipeline',
            'color_support', 'structured_data',
            'exception_handling', 'modules',
        }
        return feature in features

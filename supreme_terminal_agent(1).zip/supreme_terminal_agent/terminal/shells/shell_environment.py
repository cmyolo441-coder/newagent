"""ShellEnvironment - manages shell environment variables."""

import os
from typing import Dict, List, Optional

from terminal.shells.shell_controller import ShellController


class ShellEnvironment:
    """Gets and sets environment variables in shell sessions."""

    def get_env(self, shell: ShellController) -> Dict[str, str]:
        shell.writeline("env")
        output = self._read_output(shell)
        env = {}
        for line in output.splitlines():
            if '=' in line:
                key, value = line.split('=', 1)
                env[key.strip()] = value.strip()
        return env

    def set_env(self, shell: ShellController, key: str, value: str):
        shell.writeline(f"export {key}='{value}'")

    def unset_env(self, shell: ShellController, key: str):
        shell.writeline(f"unset {key}")

    def get_var(self, shell: ShellController, key: str) -> Optional[str]:
        shell.writeline(f"echo ${key}")
        output = self._read_output(shell)
        return output.strip() if output.strip() else None

    def get_path(self, shell: ShellController) -> List[str]:
        path_str = self.get_var(shell, 'PATH')
        if path_str:
            return path_str.split(':')
        return []

    def add_to_path(self, shell: ShellController, directory: str):
        shell.writeline(f"export PATH={directory}:$PATH")

    def _read_output(self, shell: ShellController) -> str:
        import select
        import time
        result = bytearray()
        deadline = time.time() + 2.0
        while time.time() < deadline:
            try:
                r, _, _ = select.select([shell.master_fd], [], [], 0.1)
                if r:
                    data = os.read(shell.master_fd, 4096)
                    if data:
                        result.extend(data)
                    else:
                        break
                else:
                    break
            except (OSError, ValueError):
                break
        return result.decode('utf-8', errors='replace')

    def get_shell_env(self, shell: ShellController) -> Dict[str, str]:
        return self.get_env(shell)

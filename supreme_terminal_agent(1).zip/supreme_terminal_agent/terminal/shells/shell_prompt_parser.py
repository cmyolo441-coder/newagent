"""ShellPromptParser - parses shell prompts from output."""

import re
from typing import Dict, List, Optional


class ShellPromptParser:
    """Parses shell prompts to extract useful information (user, host, cwd, etc)."""

    PROMPT_PATTERNS = [
        re.compile(r'(?:^|\n)([\w@]+):\s*(/[^\s]*)\s*[\$\#>]\s*$'),
        re.compile(r'(?:^|\n)([\w.-]+)@([\w.-]+):(/[^\s]*)\s*[\$\#>]\s*'),
        re.compile(r'(?:^|\n)(/[^\s]*)\s*[\$\#>]\s*$'),
    ]

    def parse(self, data: bytes) -> Optional[dict]:
        text = data.decode('utf-8', errors='replace')
        for pattern in self.PROMPT_PATTERNS:
            match = pattern.search(text)
            if match:
                groups = match.groups()
                result = {'type': 'shell_prompt'}
                if len(groups) == 2:
                    result['user_host'] = groups[0]
                    result['cwd'] = groups[1]
                elif len(groups) == 3:
                    result['user'] = groups[0]
                    result['host'] = groups[1]
                    result['cwd'] = groups[2]
                elif len(groups) == 1:
                    result['cwd'] = groups[0]
                return result
        return None

    def extract_cwd(self, data: bytes) -> Optional[str]:
        result = self.parse(data)
        if result and 'cwd' in result:
            return result['cwd']
        return None

    def extract_user(self, data: bytes) -> Optional[str]:
        result = self.parse(data)
        if result and 'user' in result:
            return result['user']
        return None

    def extract_host(self, data: bytes) -> Optional[str]:
        result = self.parse(data)
        if result and 'host' in result:
            return result['host']
        return None

    def is_root(self, prompt_char: str) -> bool:
        return prompt_char == '#'

    def detect_prompt_char(self, data: bytes) -> Optional[str]:
        text = data.decode('utf-8', errors='replace').rstrip()
        if text.endswith('#'):
            return '#'
        if text.endswith('$'):
            return '$'
        if text.endswith('>'):
            return '>'
        return None

    def has_prompt(self, data: bytes) -> bool:
        return self.parse(data) is not None

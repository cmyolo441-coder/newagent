"""Shells module for shell management and interaction."""

from terminal.shells.shell_manager import ShellManager
from terminal.shells.shell_detector import ShellDetector
from terminal.shells.shell_launcher import ShellLauncher
from terminal.shells.shell_controller import ShellController
from terminal.shells.shell_communicator import ShellCommunicator
from terminal.shells.shell_configurator import ShellConfigurator
from terminal.shells.shell_profile_loader import ShellProfileLoader
from terminal.shells.shell_rc_parser import ShellRcParser
from terminal.shells.shell_environment import ShellEnvironment
from terminal.shells.shell_integration import ShellIntegration
from terminal.shells.shell_prompt_parser import ShellPromptParser

__all__ = [
    'ShellManager', 'ShellDetector', 'ShellLauncher',
    'ShellController', 'ShellCommunicator', 'ShellConfigurator',
    'ShellProfileLoader', 'ShellRcParser', 'ShellEnvironment',
    'ShellIntegration', 'ShellPromptParser',
]

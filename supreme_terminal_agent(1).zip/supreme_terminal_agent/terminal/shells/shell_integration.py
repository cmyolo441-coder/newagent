"""ShellIntegration - integrates with shell features like prompt marks."""

import os
from typing import Optional

from terminal.shells.shell_controller import ShellController


class ShellIntegration:
    """Provides shell integration features (prompt marks, current dir tracking, etc)."""

    def enable_integration(self, shell: ShellController):
        shell_type = shell.shell_type
        if shell_type == 'bash':
            self._enable_bash_integration(shell)
        elif shell_type == 'zsh':
            self._enable_zsh_integration(shell)
        elif shell_type == 'fish':
            self._enable_fish_integration(shell)

    def _enable_bash_integration(self, shell: ShellController):
        shell.writeline("""__ps1() { printf "\\e]0;%s@%s:%s\\a" "${USER}" "${HOSTNAME%%.*}" "${PWD/#$HOME/~}"; }""")
        shell.writeline("""PROMPT_COMMAND='__ps1'""")
        shell.writeline("""PS1='\\[\\e]133;A\\e\\\\\\]\\[\\e]1337;CurrentDir=$PWD\\e\\\\\\]\\$ '""")

    def _enable_zsh_integration(self, shell: ShellController):
        shell.writeline("""precmd() { print -Pn "\\e]0;%n@%m:%~\\a"; }""")
        shell.writeline("""PROMPT='%{\\e]133;A\\e\\%}%{\\e]1337;CurrentDir=%d\\e\\%}%# '""")

    def _enable_fish_integration(self, shell: ShellController):
        shell.writeline("""function __set_prompt --on-event fish_prompt; echo -ne "\\e]0;$USER@$hostname:$PWD\\a"; end""")

    def disable_integration(self, shell: ShellController):
        shell_type = shell.shell_type
        if shell_type == 'bash':
            shell.writeline("unset PROMPT_COMMAND")
            shell.writeline("PS1='\\$ '")
        elif shell_type == 'zsh':
            shell.writeline("PROMPT='%# '")

    def set_current_dir(self, shell: ShellController, path: str):
        shell.writeline(f"\\e]1337;CurrentDir={path}\\e\\\\")

    def inject_mark(self, shell: ShellController, mark_type: str = 'A'):
        shell.writeline(f"\\e]133;{mark_type}\\e\\\\")

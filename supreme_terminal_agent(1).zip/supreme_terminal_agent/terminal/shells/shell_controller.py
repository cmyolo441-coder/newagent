"""ShellController - controls a shell process running in a PTY."""

import os
import signal
import select
import time
import threading
import uuid
from typing import Optional, Callable


class ShellController:
    """Controls a shell process running inside a pseudo-terminal."""

    def __init__(self):
        self.session_id = str(uuid.uuid4())
        self.master_fd: Optional[int] = None
        self.slave_fd: Optional[int] = None
        self.child_pid: Optional[int] = None
        self.shell_path: str = ''
        self.shell_type: str = ''
        self._on_output: Optional[Callable[[bytes], None]] = None
        self._lock = threading.RLock()
        self._running = False

    def write(self, data: bytes) -> int:
        if self.master_fd is None:
            raise RuntimeError("Shell not launched")
        try:
            return os.write(self.master_fd, data)
        except OSError as e:
            raise RuntimeError(f"Write error: {e}") from e

    def writeline(self, command: str):
        self.write((command + '\n').encode('utf-8', errors='replace'))

    def read(self, size: int = 4096) -> bytes:
        if self.master_fd is None:
            return b''
        try:
            return os.read(self.master_fd, size)
        except OSError:
            return b''

    def read_available(self, timeout: float = 0.1) -> bytes:
        result = bytearray()
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.master_fd is None:
                break
            try:
                r, _, _ = select.select([self.master_fd], [], [], 0.05)
                if r:
                    data = os.read(self.master_fd, 4096)
                    if data:
                        result.extend(data)
                    else:
                        break
                else:
                    break
            except OSError:
                break
        return bytes(result)

    def resize(self, rows: int, cols: int):
        if self.master_fd is not None:
            import struct
            import fcntl
            import termios
            buf = struct.pack('HHHH', rows, cols, 0, 0)
            try:
                fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, buf)
            except OSError:
                pass
            if self.child_pid:
                try:
                    os.kill(self.child_pid, signal.SIGWINCH)
                except OSError:
                    pass

    def is_alive(self) -> bool:
        if self.child_pid is None:
            return False
        try:
            pid, status = os.waitpid(self.child_pid, os.WNOHANG)
            if pid == self.child_pid:
                self.child_pid = None
                return False
            return True
        except ChildProcessError:
            return False

    def terminate(self):
        if self.child_pid is not None:
            try:
                os.kill(self.child_pid, signal.SIGTERM)
            except OSError:
                pass

    def kill(self):
        if self.child_pid is not None:
            try:
                os.kill(self.child_pid, signal.SIGKILL)
            except OSError:
                pass

    def wait(self) -> int:
        if self.child_pid is None:
            return -1
        _, status = os.waitpid(self.child_pid, 0)
        self.child_pid = None
        return status

    def close(self):
        self.terminate()
        if self.child_pid:
            try:
                os.waitpid(self.child_pid, os.WNOHANG)
            except (OSError, ChildProcessError):
                pass
            self.child_pid = None
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None
        if self.slave_fd is not None:
            try:
                os.close(self.slave_fd)
            except OSError:
                pass
            self.slave_fd = None

    def fileno(self) -> int:
        if self.master_fd is None:
            raise RuntimeError("Shell not launched")
        return self.master_fd

    def on_output(self, callback: Callable[[bytes], None]):
        self._on_output = callback

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

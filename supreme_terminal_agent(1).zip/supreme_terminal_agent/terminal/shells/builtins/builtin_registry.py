"""BuiltinRegistry - registry of all builtin command handlers."""

from typing import Dict, List, Optional, Type

from terminal.shells.builtins.base_handler import BaseHandler


class BuiltinRegistry:
    """Registry mapping command names to handler classes."""

    def __init__(self):
        self._handlers: Dict[str, BaseHandler] = {}

    def register(self, handler: BaseHandler):
        for name in handler.get_aliases():
            self._handlers[name] = handler

    def unregister(self, name: str):
        self._handlers.pop(name, None)

    def get(self, name: str) -> Optional[BaseHandler]:
        return self._handlers.get(name)

    def has(self, name: str) -> bool:
        return name in self._handlers

    def list_commands(self) -> List[str]:
        return list(self._handlers.keys())

    def get_all(self) -> List[BaseHandler]:
        return list(set(self._handlers.values()))

    def get_handler(self, name: str) -> Optional[BaseHandler]:
        return self._handlers.get(name)

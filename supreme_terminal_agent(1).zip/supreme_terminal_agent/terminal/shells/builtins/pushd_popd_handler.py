"""PushdPopdHandler - builtin pushd/popd/dirs commands."""

import os
from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class PushdPopdHandler(BaseHandler):
    def __init__(self):
        self._dir_stack: List[str] = []

    def get_name(self) -> str:
        return "pushd"

    def get_aliases(self) -> List[str]:
        return ["pushd", "popd", "dirs"]

    def get_help(self) -> str:
        return "pushd [dir] / popd / dirs - directory stack operations"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        name = kwargs.get("command", "dirs")

        if name == "dirs":
            return {"exit_code": 0, "output": " ".join(self._dir_stack) if self._dir_stack else os.getcwd()}

        if name == "pushd":
            if not args:
                if len(self._dir_stack) < 2:
                    return {"exit_code": 1, "error": "pushd: no other directory"}
                self._dir_stack.append(os.getcwd())
                target = self._dir_stack.pop(0)
                os.chdir(target)
            else:
                self._dir_stack.append(os.getcwd())
                target = args[0]
                os.chdir(target)
            return {"exit_code": 0, "dir_stack": list(self._dir_stack), "cwd": os.getcwd()}

        if name == "popd":
            if not self._dir_stack:
                return {"exit_code": 1, "error": "popd: directory stack empty"}
            target = self._dir_stack.pop()
            os.chdir(target)
            return {"exit_code": 0, "dir_stack": list(self._dir_stack), "cwd": os.getcwd()}

        return {"exit_code": 1, "error": f"unknown command: {name}"}

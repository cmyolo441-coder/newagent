"""ExportHandler - builtin export command."""

import os
from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class ExportHandler(BaseHandler):
    def get_name(self) -> str:
        return "export"

    def get_help(self) -> str:
        return "export [name[=value] ...] - set environment variables"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        if not args:
            return {"exit_code": 0, "output": "\n".join(
                f"{k}={v}" for k, v in os.environ.items()
            )}
        result_env: Dict[str, str] = {}
        for arg in args:
            if "=" in arg:
                name, _, value = arg.partition("=")
                os.environ[name] = value
                result_env[name] = value
            else:
                if arg in os.environ:
                    result_env[arg] = os.environ[arg]
        return {"exit_code": 0, "env": result_env}

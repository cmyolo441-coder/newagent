"""JobsHandler - builtin jobs command."""

from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class JobsHandler(BaseHandler):
    def __init__(self):
        self._jobs: Dict[int, Dict[str, Any]] = {}

    def get_name(self) -> str:
        return "jobs"

    def get_help(self) -> str:
        return "jobs [-l] - list active jobs"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        if not self._jobs:
            return {"exit_code": 0, "output": ""}

        lines = []
        for jid, job in self._jobs.items():
            status = job.get("status", "running")
            cmd = job.get("command", "")
            pid = job.get("pid", 0)
            lines.append(f"[{jid}] {status} {pid}\t{cmd}")

        return {"exit_code": 0, "output": "\n".join(lines), "jobs": dict(self._jobs)}

    def add_job(self, jid: int, pid: int, command: str):
        self._jobs[jid] = {"pid": pid, "command": command, "status": "running"}

    def remove_job(self, jid: int):
        self._jobs.pop(jid, None)

    def update_status(self, jid: int, status: str):
        if jid in self._jobs:
            self._jobs[jid]["status"] = status

    def list_jobs(self) -> Dict[int, Dict[str, Any]]:
        return dict(self._jobs)

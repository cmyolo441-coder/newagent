"""AliasHandler - builtin alias command."""

from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class AliasHandler(BaseHandler):
    def __init__(self):
        self._aliases: Dict[str, str] = {}

    def get_name(self) -> str:
        return "alias"

    def get_help(self) -> str:
        return "alias [name[=value] ...] - define or display aliases"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        if not args:
            output = "\n".join(
                f"{k}='{v}'" for k, v in self._aliases.items()
            )
            return {"exit_code": 0, "output": output}

        for arg in args:
            if "=" in arg:
                name, _, value = arg.partition("=")
                self._aliases[name] = value
            else:
                pass

        return {"exit_code": 0, "aliases": dict(self._aliases)}

    def set_alias(self, name: str, value: str):
        self._aliases[name] = value

    def get_alias(self, name: str) -> Optional[str]:
        return self._aliases.get(name)

    def remove_alias(self, name: str):
        self._aliases.pop(name, None)

    def list_aliases(self) -> Dict[str, str]:
        return dict(self._aliases)

"""FgBgHandler - builtin fg/bg commands."""

import os
import signal
from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class FgBgHandler(BaseHandler):
    def get_name(self) -> str:
        return "fg"

    def get_aliases(self) -> List[str]:
        return ["fg", "bg"]

    def get_help(self) -> str:
        return "fg [job] / bg [job] - bring job to foreground/background"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        command = args[0] if args else "fg"
        name = self.get_name() if not args else args[0]

        sig = signal.SIGCONT
        is_fg = name == "fg"

        # In a real implementation pid would come from job table
        return {
            "exit_code": 0,
            "action": "foreground" if is_fg else "background",
            "signal": sig,
        }

"""UnsetHandler - builtin unset command."""

import os
from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class UnsetHandler(BaseHandler):
    def get_name(self) -> str:
        return "unset"

    def get_help(self) -> str:
        return "unset [-fv] name ... - unset shell variable or function"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        if not args:
            return {"exit_code": 1, "error": "unset: not enough arguments"}
        unset_vars: List[str] = []
        for arg in args:
            if arg in ("-f", "-v"):
                continue
            os.environ.pop(arg, None)
            unset_vars.append(arg)
        return {"exit_code": 0, "unset": unset_vars}

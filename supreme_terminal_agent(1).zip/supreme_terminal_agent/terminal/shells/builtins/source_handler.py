"""SourceHandler - builtin source (.) command."""

from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class SourceHandler(BaseHandler):
    def get_name(self) -> str:
        return "source"

    def get_aliases(self) -> List[str]:
        return ["source", "."]

    def get_help(self) -> str:
        return "source file [args] - execute commands from a file"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        if not args:
            return {"exit_code": 1, "error": "source: no file specified"}
        filepath = args[0]
        try:
            with open(filepath) as f:
                content = f.read()
            return {"exit_code": 0, "file": filepath, "content": content}
        except FileNotFoundError:
            return {"exit_code": 1, "error": f"source: {filepath}: No such file"}
        except PermissionError:
            return {"exit_code": 1, "error": f"source: {filepath}: Permission denied"}
        except Exception as exc:
            return {"exit_code": 1, "error": str(exc)}

"""HistoryHandler - builtin history command."""

from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class HistoryHandler(BaseHandler):
    def __init__(self):
        self._history: List[str] = []

    def get_name(self) -> str:
        return "history"

    def get_help(self) -> str:
        return "history [-c] [n] - display or clear command history"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        if not args:
            lines = "\n".join(
                f"  {i+1}  {cmd}"
                for i, cmd in enumerate(self._history)
            )
            return {"exit_code": 0, "output": lines, "history": list(self._history)}

        if args[0] == "-c":
            self._history.clear()
            return {"exit_code": 0}

        try:
            n = int(args[0])
            return {"exit_code": 0, "history": list(self._history[-n:])}
        except (ValueError, IndexError):
            return {"exit_code": 1, "error": "history: invalid argument"}

    def append(self, command: str):
        if command and (not self._history or self._history[-1] != command):
            self._history.append(command)

    def clear(self):
        self._history.clear()

    def get_all(self) -> List[str]:
        return list(self._history)

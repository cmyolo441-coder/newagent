"""CdHandler - builtin cd command."""

import os
from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class CdHandler(BaseHandler):
    def get_name(self) -> str:
        return "cd"

    def get_aliases(self) -> List[str]:
        return ["cd", "chdir"]

    def get_help(self) -> str:
        return "cd [dir] - change current directory"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        target = args[0] if args else (os.environ.get("HOME") or "/")
        try:
            os.chdir(target)
            return {"exit_code": 0, "cwd": os.getcwd()}
        except FileNotFoundError:
            return {"exit_code": 1, "error": f"cd: {target}: No such directory"}
        except PermissionError:
            return {"exit_code": 1, "error": f"cd: {target}: Permission denied"}
        except Exception as exc:
            return {"exit_code": 1, "error": str(exc)}

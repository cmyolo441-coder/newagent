"""PwdHandler - builtin pwd command."""

import os
from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class PwdHandler(BaseHandler):
    def get_name(self) -> str:
        return "pwd"

    def get_help(self) -> str:
        return "pwd - print working directory"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        try:
            cwd = os.getcwd()
            return {"exit_code": 0, "output": cwd, "cwd": cwd}
        except Exception as exc:
            return {"exit_code": 1, "error": str(exc)}

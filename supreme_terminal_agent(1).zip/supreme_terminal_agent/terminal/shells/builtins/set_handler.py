"""SetHandler - builtin set command."""

import os
from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class SetHandler(BaseHandler):
    def get_name(self) -> str:
        return "set"

    def get_help(self) -> str:
        return "set [-aefnuvx] [name[=value] ...] - set/unset shell options"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        if not args:
            return {"exit_code": 0, "output": "\n".join(
                f"{k}={v}" for k, v in sorted(os.environ.items())
            )}
        result: Dict[str, str] = {}
        for arg in args:
            if "=" in arg:
                name, _, value = arg.partition("=")
                os.environ[name] = value
                result[name] = value
            elif arg.startswith("+"):
                result[arg[1:]] = "off"
            elif arg.startswith("-"):
                options: Dict[str, str] = {"a": "allexport", "e": "errexit",
                    "f": "noglob", "u": "nounset", "n": "noexec",
                    "v": "verbose", "x": "xtrace"}
                for flag in arg[1:]:
                    name = options.get(flag, flag)
                    result[name] = "on"
        return {"exit_code": 0, "options": result}

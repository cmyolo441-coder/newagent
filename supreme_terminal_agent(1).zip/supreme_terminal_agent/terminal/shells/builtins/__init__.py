"""Builtin command handlers for shell simulation."""

from terminal.shells.builtins.cd_handler import CdHandler
from terminal.shells.builtins.pwd_handler import PwdHandler
from terminal.shells.builtins.export_handler import ExportHandler
from terminal.shells.builtins.alias_handler import AliasHandler
from terminal.shells.builtins.history_handler import HistoryHandler
from terminal.shells.builtins.source_handler import SourceHandler
from terminal.shells.builtins.exit_handler import ExitHandler
from terminal.shells.builtins.jobs_handler import JobsHandler
from terminal.shells.builtins.fg_bg_handler import FgBgHandler
from terminal.shells.builtins.pushd_popd_handler import PushdPopdHandler
from terminal.shells.builtins.set_handler import SetHandler
from terminal.shells.builtins.unset_handler import UnsetHandler
from terminal.shells.builtins.builtin_registry import BuiltinRegistry

__all__ = [
    'CdHandler', 'PwdHandler', 'ExportHandler', 'AliasHandler',
    'HistoryHandler', 'SourceHandler', 'ExitHandler', 'JobsHandler',
    'FgBgHandler', 'PushdPopdHandler', 'SetHandler', 'UnsetHandler',
    'BuiltinRegistry',
]

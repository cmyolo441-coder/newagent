"""BaseHandler - abstract base for builtin command handlers."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class BaseHandler(ABC):
    """Abstract base class for builtin command handlers."""

    @abstractmethod
    def get_name(self) -> str:
        ...

    def get_aliases(self) -> List[str]:
        return [self.get_name()]

    def get_help(self) -> str:
        return ""

    @abstractmethod
    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        ...

    def is_safe(self) -> bool:
        return True

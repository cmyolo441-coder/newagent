"""ExitHandler - builtin exit command."""

from typing import Any, Dict, List, Optional

from terminal.shells.builtins.base_handler import BaseHandler


class ExitHandler(BaseHandler):
    def get_name(self) -> str:
        return "exit"

    def get_help(self) -> str:
        return "exit [n] - exit the shell with status n"

    def execute(self, args: List[str], env: Optional[Dict[str, str]] = None,
                **kwargs: Any) -> Dict[str, Any]:
        code = 0
        if args:
            try:
                code = int(args[0])
            except ValueError:
                return {"exit_code": 1, "error": "exit: numeric argument required"}
        return {"exit_code": code, "exit": True}

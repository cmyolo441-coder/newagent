"""ShellManager - manages shell instances and operations."""

import os
import signal
import threading
from typing import Dict, List, Optional, Callable

from terminal.shells.shell_detector import ShellDetector
from terminal.shells.shell_launcher import ShellLauncher
from terminal.shells.shell_controller import ShellController
from terminal.shells.shell_communicator import ShellCommunicator
from terminal.shells.shell_configurator import ShellConfigurator
from terminal.shells.shell_profile_loader import ShellProfileLoader
from terminal.shells.shell_environment import ShellEnvironment
from terminal.shells.shell_integration import ShellIntegration
from terminal.shells.shell_prompt_parser import ShellPromptParser


class ShellManager:
    """Central manager for shell instances."""

    def __init__(self):
        self.detector = ShellDetector()
        self.launcher = ShellLauncher(self)
        self.communicator = ShellCommunicator()
        self.configurator = ShellConfigurator()
        self.profile_loader = ShellProfileLoader()
        self.environment = ShellEnvironment()
        self.integration = ShellIntegration()
        self.prompt_parser = ShellPromptParser()
        self._shells: Dict[str, ShellController] = {}
        self._lock = threading.RLock()

    def detect_default_shell(self) -> str:
        return self.detector.detect_default()

    def launch_shell(self, shell_path: Optional[str] = None, **kwargs) -> ShellController:
        shell = self.launcher.launch(shell_path, **kwargs)
        with self._lock:
            self._shells[shell.session_id] = shell
        return shell

    def get_shell(self, session_id: str) -> Optional[ShellController]:
        with self._lock:
            return self._shells.get(session_id)

    def list_shells(self) -> List[str]:
        with self._lock:
            return list(self._shells.keys())

    def close_shell(self, session_id: str):
        with self._lock:
            shell = self._shells.pop(session_id, None)
            if shell:
                shell.close()

    def close_all(self):
        with self._lock:
            for shell in list(self._shells.values()):
                shell.close()
            self._shells.clear()

    def communicate(self, session_id: str, command: str, timeout: float = 10.0) -> str:
        shell = self.get_shell(session_id)
        if shell is None:
            raise RuntimeError(f"Shell {session_id} not found")
        return self.communicator.communicate(shell, command, timeout)

    def execute(self, command: str, shell_path: Optional[str] = None, timeout: float = 30.0) -> str:
        shell = self.launch_shell(shell_path)
        try:
            return self.communicator.communicate(shell, command, timeout)
        finally:
            shell.close()

    def configure(self, session_id: str, config: dict):
        shell = self.get_shell(session_id)
        if shell:
            self.configurator.configure(shell, config)

    def load_profile(self, shell_path: str) -> dict:
        return self.profile_loader.load(shell_path)

    def get_environment(self, session_id: str) -> dict:
        shell = self.get_shell(session_id)
        if shell:
            return self.environment.get_env(shell)
        return {}

    def parse_prompt(self, data: bytes) -> Optional[dict]:
        return self.prompt_parser.parse(data)

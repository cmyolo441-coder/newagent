"""ShellConfigurator - configures shell environments."""

import os
from typing import Dict, List, Optional

from terminal.shells.shell_controller import ShellController


class ShellConfigurator:
    """Configures shell startup files, aliases, and settings."""

    def configure(self, shell: ShellController, config: dict):
        if 'aliases' in config:
            self.set_aliases(shell, config['aliases'])
        if 'env_vars' in config:
            self.set_env_vars(shell, config['env_vars'])
        if 'prompt' in config:
            self.set_prompt(shell, config['prompt'])
        if 'path' in config:
            self.set_path(shell, config['path'])

    def set_aliases(self, shell: ShellController, aliases: Dict[str, str]):
        for name, value in aliases.items():
            shell.writeline(f"alias {name}='{value}'")

    def set_env_vars(self, shell: ShellController, env_vars: Dict[str, str]):
        for key, value in env_vars.items():
            shell.writeline(f"export {key}='{value}'")

    def set_prompt(self, shell: ShellController, prompt: str):
        shell_type = shell.shell_type
        if shell_type == 'bash':
            shell.writeline(f"PS1='{prompt}'")
        elif shell_type == 'zsh':
            shell.writeline(f"PROMPT='{prompt}'")
        elif shell_type == 'fish':
            shell.writeline(f"set -g fish_prompt_pwd_dir_length 0")
            shell.writeline(f"function fish_prompt; echo '{prompt}'; end")
        else:
            shell.writeline(f"PS1='{prompt}'")

    def set_path(self, shell: ShellController, path_list: List[str]):
        path_str = ':'.join(path_list)
        shell.writeline(f"export PATH={path_str}:$PATH")

    def apply_rc_file(self, shell: ShellController, rc_path: str):
        if os.path.exists(rc_path):
            data = self._get_rc_content(rc_path, shell.shell_type)
            for line in data:
                if line.strip() and not line.strip().startswith('#'):
                    shell.writeline(line)

    def _get_rc_content(self, rc_path: str, shell_type: str) -> List[str]:
        try:
            with open(rc_path, 'r') as f:
                return f.readlines()
        except OSError:
            return []

    def configure_default(self, shell: ShellController):
        shell.writeline("export TERM=xterm-256color")
        shell.writeline("export EDITOR=vi")

    def set_hostname(self, shell: ShellController, hostname: str):
        shell.writeline(f"export HOSTNAME={hostname}")

    def set_terminal_type(self, shell: ShellController, term_type: str):
        shell.writeline(f"export TERM={term_type}")

"""ApcParser - parses Application Program Command escape sequences."""

import re
from typing import Optional


class ApcParser:
    """Parses APC (Application Program Command) escape sequences."""

    APC_REGEX = re.compile(r'\x1b_(.*?)(?:\x1b\\|\x07|$)')

    def parse(self, data: bytes) -> Optional[dict]:
        """Parse an APC sequence."""
        text = data.decode('utf-8', errors='replace')
        match = self.APC_REGEX.match(text)
        if not match:
            return None
        return {
            'raw': text,
            'content': match.group(1),
        }

"""KittyExtensions - handles Kitty-specific escape sequences."""

import re
from typing import Dict, Optional


class KittyExtensions:
    """Handles Kitty terminal-specific escape sequences."""

    KEYBOARD_PROTOCOL = re.compile(r'\x1b\[=(\d+)([uU])')
    GRAPHICS = re.compile(r'\x1b_G(.*?);(.*?)(?:\x1b\\|$)')
    PLACEHOLDER = re.compile(r'\x1b_](.*?)\x1b\\')
    COLOR_PALETTE = re.compile(r'\x1b\](\d+);(.*?)(?:\x1b\\|\x07|$)')

    def parse_keyboard_protocol(self, data: bytes) -> Optional[dict]:
        text = data.decode('utf-8', errors='replace')
        match = self.KEYBOARD_PROTOCOL.match(text)
        if match:
            return {
                'flags': int(match.group(1)),
                'mode': match.group(2),
            }
        return None

    def parse_graphics(self, data: bytes) -> Optional[dict]:
        text = data.decode('utf-8', errors='replace')
        match = self.GRAPHICS.match(text)
        if match:
            return {
                'params': match.group(1),
                'data': match.group(2),
            }
        return None

    def generate_keyboard_protocol(self, flags: int, mode: str = 'u') -> bytes:
        return f'\x1b[={flags}{mode}'.encode()

    def generate_graphics(self, params: str, data: str) -> bytes:
        return f'\x1b_G{params};{data}\x1b\\'.encode()

    def generate_placeholder(self, content: str) -> bytes:
        return f'\x1b_]{content}\x1b\\'.encode()

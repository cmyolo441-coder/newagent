"""EscapeParser - parses terminal escape sequences from raw byte streams."""

import re
from enum import Enum
from typing import Callable, Dict, List, Optional, Tuple

from terminal.escape.csi_parser import CsiParser
from terminal.escape.osc_parser import OscParser
from terminal.escape.dcs_parser import DcsParser
from terminal.escape.apc_parser import ApcParser
from terminal.escape.pm_parser import PmParser
from terminal.escape.sos_parser import SosParser
from terminal.escape.c0_codes import C0Codes
from terminal.escape.c1_codes import C1Codes
from terminal.escape.sgr_parser import SgrParser


class ParserState(Enum):
    GROUND = "ground"
    ESCAPE = "escape"
    CSI = "csi"
    OSC = "osc"
    DCS = "dcs"
    APC = "apc"
    PM = "pm"
    SOS = "sos"
    STRING_TERM = "string_term"


class EscapeParser:
    """State-machine parser for terminal escape sequences."""

    ESCAPE = b'\x1b'
    CSI_TERMINATORS = b'ABCDEFGHJKSTfmnsu`'
    OSC_TERMINATOR = b'\x1b\\'
    STRING_TERMINATORS = {b'\x1b\\', b'\x07'}

    def __init__(self):
        self.state = ParserState.GROUND
        self._buffer = bytearray()
        self._params: List[int] = []
        self._collected: bytearray = bytearray()
        self.csi_parser = CsiParser()
        self.osc_parser = OscParser()
        self.dcs_parser = DcsParser()
        self.apc_parser = ApcParser()
        self.pm_parser = PmParser()
        self.sos_parser = SosParser()
        self.sgr_parser = SgrParser()
        self.c0 = C0Codes()
        self.c1 = C1Codes()
        self._csi_handler: Optional[Callable] = None
        self._osc_handler: Optional[Callable] = None
        self._sgr_handler: Optional[Callable] = None
        self._text_handler: Optional[Callable[[str], None]] = None

    def set_csi_handler(self, handler: Callable):
        self._csi_handler = handler

    def set_osc_handler(self, handler: Callable):
        self._osc_handler = handler

    def set_sgr_handler(self, handler: Callable):
        self._sgr_handler = handler

    def set_text_handler(self, handler: Callable[[str], None]):
        self._text_handler = handler

    def feed(self, data: bytes):
        """Feed bytes into the parser."""
        for byte in data:
            self._feed_byte(byte)

    def _feed_byte(self, byte: int):
        b = bytes([byte])
        if self.state == ParserState.GROUND:
            if byte == 0x1b:
                self.state = ParserState.ESCAPE
                self._buffer = bytearray(b)
                self._params = []
                self._collected = bytearray()
            elif byte in (0x00, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d):
                self._handle_c0(byte)
            elif byte >= 0x20:
                if self._text_handler:
                    self._text_handler(chr(byte))
        elif self.state == ParserState.ESCAPE:
            self._buffer.append(byte)
            if byte == 0x5b:
                self.state = ParserState.CSI
            elif byte == 0x5d:
                self.state = ParserState.OSC
            elif byte == 0x50:
                self.state = ParserState.DCS
            elif byte == 0x5f:
                self.state = ParserState.APC
            elif byte == 0x5e:
                self.state = ParserState.PM
            elif byte == 0x58:
                self.state = ParserState.SOS
            elif byte in (0x4d, 0x44, 0x45, 0x48, 0x46, 0x37, 0x38, 0x63, 0x36, 0x4e):
                self._handle_escape_sequence(b)
                self.state = ParserState.GROUND
            else:
                self.state = ParserState.GROUND
        elif self.state == ParserState.CSI:
            self._buffer.append(byte)
            if 0x40 <= byte <= 0x7e:
                self._handle_csi()
                self.state = ParserState.GROUND
            elif 0x30 <= byte <= 0x3f:
                self._collected.append(byte)
            elif 0x20 <= byte <= 0x2f:
                pass
        elif self.state == ParserState.OSC:
            self._buffer.append(byte)
            if byte == 0x07 or (byte == 0x5c and len(self._buffer) >= 2 and self._buffer[-2] == 0x1b):
                if self._buffer[-1] == 0x5c:
                    self._buffer = self._buffer[:-1]
                if self._osc_handler:
                    osc_text = self._buffer[1:].decode('utf-8', errors='replace')
                    self._osc_handler(osc_text)
                self.state = ParserState.GROUND
        elif self.state == ParserState.DCS:
            self._buffer.append(byte)
            if 0x40 <= byte <= 0x7e:
                self._handle_dcs()
                self.state = ParserState.GROUND
        elif self.state == ParserState.APC:
            self._buffer.append(byte)
            if byte == 0x07 or (byte == 0x5c and len(self._buffer) >= 2 and self._buffer[-2] == 0x1b):
                self.state = ParserState.GROUND
        elif self.state == ParserState.PM:
            self._buffer.append(byte)
            if byte == 0x07 or (byte == 0x5c and len(self._buffer) >= 2 and self._buffer[-2] == 0x1b):
                self.state = ParserState.GROUND
        elif self.state == ParserState.SOS:
            self._buffer.append(byte)
            if byte == 0x07 or (byte == 0x5c and len(self._buffer) >= 2 and self._buffer[-2] == 0x1b):
                self.state = ParserState.GROUND

    def _handle_c0(self, byte: int):
        handler = self.c0.get_handler(byte)
        if handler:
            handler(byte)

    def _handle_escape_sequence(self, seq: bytes):
        pass

    def _handle_csi(self):
        buf = bytes(self._buffer)
        self.csi_parser.parse(buf)
        if self._csi_handler:
            self._csi_handler(buf)
        if self._sgr_handler and buf.endswith(b'm'):
            self._sgr_handler(buf)

    def _handle_dcs(self):
        buf = bytes(self._buffer)
        self.dcs_parser.parse(buf)

    def reset(self):
        self.state = ParserState.GROUND
        self._buffer = bytearray()
        self._params = []
        self._collected = bytearray()

"""Iterm2Extensions - handles iTerm2-specific escape sequences."""

import re
from typing import Dict, Optional


class Iterm2Extensions:
    """Handles iTerm2-specific escape sequences."""

    PROMPT_MARK = re.compile(r'\x1b\]133;(.*?)(?:\x1b\\|\x07|$)')
    CURRENT_DIR = re.compile(r'\x1b\]1337;CurrentDir=(.*?)(?:\x1b\\|\x07|$)')
    SHELL_INTEGRATION = re.compile(r'\x1b\]133;(A|B|C|D|E|F|K|L)(?:;.*?)?(?:\x1b\\|\x07|$)')
    USER_DATA = re.compile(r'\x1b\]1337;File=([^:]+):(.*?)(?:\x1b\\|\x07|$)')
    COPROCESS = re.compile(r'\x1b\]1337;Coproc=(.*?)(?:\x1b\\|\x07|$)')
    STEAL_KEY = re.compile(r'\x1b\]1337;StealKey=(.*?)(?:\x1b\\|\x07|$)')
    CLEAR_SCROLLBACK = re.compile(r'\x1b\]1337;ClearScrollback(?:\x1b\\|\x07|$)')

    def parse_prompt_mark(self, text: str) -> Optional[dict]:
        match = self.PROMPT_MARK.search(text)
        if match:
            return {'content': match.group(1)}
        return None

    def parse_current_dir(self, text: str) -> Optional[str]:
        match = self.CURRENT_DIR.search(text)
        return match.group(1) if match else None

    def parse_shell_integration(self, text: str) -> Optional[str]:
        match = self.SHELL_INTEGRATION.search(text)
        return match.group(1) if match else None

    def generate_prompt_mark(self) -> bytes:
        return b'\x1b]133;A\x1b\\'

    def generate_current_dir(self, path: str) -> bytes:
        return f'\x1b]1337;CurrentDir={path}\x1b\\'.encode()

    def generate_steal_key(self, key: str) -> bytes:
        return f'\x1b]1337;StealKey={key}\x1b\\'.encode()

    def generate_clear_scrollback(self) -> bytes:
        return b'\x1b]1337;ClearScrollback\x1b\\'

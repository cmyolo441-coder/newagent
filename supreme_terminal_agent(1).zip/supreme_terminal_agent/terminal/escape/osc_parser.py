"""OscParser - parses Operating System Command escape sequences."""

import re
from typing import Dict, Optional, Tuple


class OscParser:
    """Parses OSC (Operating System Command) escape sequences."""

    OSC_REGEX = re.compile(r'\x1b\](\d+);(.*?)(?:\x1b\\|\x07|$)')

    def parse(self, text: str) -> Optional[dict]:
        """Parse an OSC sequence. Returns dict with number, content, etc."""
        match = self.OSC_REGEX.match(text)
        if not match:
            cleaned = text.lstrip('\x1b]')
            parts = cleaned.split(';', 1)
            if len(parts) == 2:
                try:
                    return {
                        'number': int(parts[0]),
                        'content': parts[1].rstrip('\x1b\\\x07'),
                        'raw': text,
                    }
                except ValueError:
                    pass
            return None
        return {
            'number': int(match.group(1)),
            'content': match.group(2),
            'raw': text,
        }

    def get_number(self, text: str) -> Optional[int]:
        result = self.parse(text)
        if result:
            return result.get('number')
        return None

    def get_content(self, text: str) -> Optional[str]:
        result = self.parse(text)
        if result:
            return result.get('content')
        return None

"""DecPrivate - handles DEC private mode escape sequences."""

import re
from typing import Dict, Optional


class DecPrivate:
    """Parses and handles DEC private mode sequences (CSI ? ... h/l)."""

    DEC_MODE_REGEX = re.compile(r'\x1b\[\?([\d;]*)([hl])')

    MODES = {
        1: 'CURSOR_KEYS', 2: 'ANSI_VT52', 3: 'COLUMN',
        4: 'SCROLL', 5: 'REVERSE_VIDEO', 6: 'ORIGIN',
        7: 'AUTO_WRAP', 8: 'AUTO_REPEAT', 9: 'INTERLACE',
        12: 'BLINK', 25: 'CURSOR', 40: 'ALLOW_80_132',
        1047: 'ALT_BUFFER', 1048: 'SAVE_CURSOR',
        1049: 'ALT_BUFFER_FULL',
    }

    def parse(self, data: bytes) -> Optional[dict]:
        """Parse a DEC private mode sequence."""
        text = data.decode('utf-8', errors='replace')
        match = self.DEC_MODE_REGEX.match(text)
        if not match:
            return None
        param_str = match.group(1)
        action = match.group(2)
        params = []
        if param_str:
            for p in param_str.split(';'):
                if p:
                    try:
                        params.append(int(p))
                    except ValueError:
                        params.append(0)
                else:
                    params.append(0)
        return {
            'raw': text,
            'params': params,
            'action': action,
            'set': action == 'h',
            'clear': action == 'l',
        }

    def get_mode_name(self, mode: int) -> str:
        return self.MODES.get(mode, f'UNKNOWN_{mode}')

    def is_set(self, data: bytes) -> Optional[bool]:
        result = self.parse(data)
        if result:
            return result.get('set')
        return None

    def get_modes(self, data: bytes) -> list:
        result = self.parse(data)
        if result:
            return result.get('params', [])
        return []

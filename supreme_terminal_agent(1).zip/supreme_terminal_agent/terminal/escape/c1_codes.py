"""C1Codes - handles C1 control codes (0x80-0x9F)."""

from typing import Callable, Dict, Optional


class C1Codes:
    """Handles C1 (0x80-0x9F) control code processing."""

    CODES = {
        0x84: 'IND', 0x85: 'NEL', 0x86: 'SSA', 0x87: 'ESA',
        0x88: 'HTS', 0x89: 'HTJ', 0x8a: 'VTS', 0x8b: 'PLD',
        0x8c: 'PLU', 0x8d: 'RI',  0x8e: 'SS2', 0x8f: 'SS3',
        0x90: 'DCS', 0x91: 'PU1', 0x92: 'PU2', 0x93: 'STS',
        0x94: 'CCH', 0x95: 'MW',  0x96: 'SPA', 0x97: 'EPA',
        0x98: 'SOS', 0x99: 'SGCI', 0x9a: 'SCI', 0x9b: 'CSI',
        0x9c: 'ST',  0x9d: 'OSC', 0x9e: 'PM',  0x9f: 'APC',
    }

    def __init__(self):
        self._handlers: Dict[int, Callable] = {}

    def register_handler(self, code: int, handler: Callable):
        self._handlers[code] = handler

    def get_handler(self, code: int) -> Optional[Callable]:
        return self._handlers.get(code)

    def get_name(self, code: int) -> str:
        return self.CODES.get(code, f'0x{code:02x}')

    def is_c1(self, byte: int) -> bool:
        return 0x80 <= byte <= 0x9f

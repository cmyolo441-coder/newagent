"""EscapeGenerator - generates terminal escape sequences."""

from typing import List, Optional


class EscapeGenerator:
    """Generates terminal escape sequence byte strings."""

    def csi(self, params: Optional[List[int]] = None, intermediate: str = "", final: str = "m") -> bytes:
        parts = []
        if params:
            parts.append(';'.join(str(p) for p in params))
        csi = '\x1b[' + ''.join(parts) + intermediate + final
        return csi.encode('utf-8')

    def sgr(self, params: List[int]) -> bytes:
        return self.csi(params, final='m')

    def osc(self, text: str) -> bytes:
        return f'\x1b]{text}\x1b\\'.encode('utf-8')

    def dcs(self, text: str) -> bytes:
        return f'\x1bP{text}\x1b\\'.encode('utf-8')

    def apc(self, text: str) -> bytes:
        return f'\x1b_{text}\x1b\\'.encode('utf-8')

    def pm(self, text: str) -> bytes:
        return f'\x1b^{text}\x1b\\'.encode('utf-8')

    def sos(self, text: str) -> bytes:
        return f'\x1bX{text}\x1b\\'.encode('utf-8')

    def cursor_up(self, n: int = 1) -> bytes:
        return f'\x1b[{n}A'.encode()

    def cursor_down(self, n: int = 1) -> bytes:
        return f'\x1b[{n}B'.encode()

    def cursor_forward(self, n: int = 1) -> bytes:
        return f'\x1b[{n}C'.encode()

    def cursor_back(self, n: int = 1) -> bytes:
        return f'\x1b[{n}D'.encode()

    def cursor_next_line(self, n: int = 1) -> bytes:
        return f'\x1b[{n}E'.encode()

    def cursor_prev_line(self, n: int = 1) -> bytes:
        return f'\x1b[{n}F'.encode()

    def cursor_horizontal_abs(self, col: int) -> bytes:
        return f'\x1b[{col}G'.encode()

    def cursor_position(self, row: int = 1, col: int = 1) -> bytes:
        return f'\x1b[{row};{col}H'.encode()

    def erase_display(self, mode: int = 0) -> bytes:
        return f'\x1b[{mode}J'.encode()

    def erase_line(self, mode: int = 0) -> bytes:
        return f'\x1b[{mode}K'.encode()

    def scroll_up(self, n: int = 1) -> bytes:
        return f'\x1b[{n}S'.encode()

    def scroll_down(self, n: int = 1) -> bytes:
        return f'\x1b[{n}T'.encode()

    def save_cursor(self) -> bytes:
        return b'\x1b7'

    def restore_cursor(self) -> bytes:
        return b'\x1b8'

    def hide_cursor(self) -> bytes:
        return b'\x1b[?25l'

    def show_cursor(self) -> bytes:
        return b'\x1b[?25h'

    def enable_alt_buffer(self) -> bytes:
        return b'\x1b[?1049h'

    def disable_alt_buffer(self) -> bytes:
        return b'\x1b[?1049l'

    def set_title(self, title: str) -> bytes:
        return self.osc(f'0;{title}')

    def set_icon_name(self, name: str) -> bytes:
        return self.osc(f'1;{name}')

    def set_window_title(self, title: str) -> bytes:
        return self.osc(f'2;{title}')

    def set_rgb_color(self, which: int, r: int, g: int, b: int) -> bytes:
        return self.csi([which, 2, r, g, b], final='m')

    def reset_attributes(self) -> bytes:
        return self.sgr([0])

    def bold(self) -> bytes:
        return self.sgr([1])

    def dim(self) -> bytes:
        return self.sgr([2])

    def italic(self) -> bytes:
        return self.sgr([3])

    def underline(self) -> bytes:
        return self.sgr([4])

    def blink(self) -> bytes:
        return self.sgr([5])

    def reverse(self) -> bytes:
        return self.sgr([7])

    def device_report(self, report_type: int = 5) -> bytes:
        return f'\x1b[{report_type}n'.encode()

    def request_cursor_position(self) -> bytes:
        return b'\x1b[6n'

"""CsiParser - parses Control Sequence Introducer escape sequences."""

import re
from typing import Dict, List, Optional


class CsiParser:
    """Parses CSI (Control Sequence Introducer) escape sequences."""

    CSI_REGEX = re.compile(r'\x1b\[([\d;]*)([@-~])')

    def parse(self, data: bytes) -> Optional[dict]:
        """Parse a CSI sequence. Returns dict with params, command, etc."""
        text = data.decode('utf-8', errors='replace')
        match = self.CSI_REGEX.match(text)
        if not match:
            return None
        param_str = match.group(1)
        command = match.group(2)
        params = []
        if param_str:
            for p in param_str.split(';'):
                if p:
                    try:
                        params.append(int(p))
                    except ValueError:
                        params.append(0)
                else:
                    params.append(0)
        return {
            'raw': text,
            'params': params,
            'command': command,
            'param_str': param_str,
        }

    def parse_params(self, data: bytes) -> List[int]:
        """Extract just the numeric parameters from a CSI sequence."""
        result = self.parse(data)
        if result:
            return result.get('params', [])
        return []

    def get_command(self, data: bytes) -> Optional[str]:
        result = self.parse(data)
        if result:
            return result.get('command')
        return None

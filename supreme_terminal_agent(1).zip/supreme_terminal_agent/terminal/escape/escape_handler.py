"""EscapeHandler - dispatches parsed escape sequences to appropriate handlers."""

from typing import Callable, Dict, Optional

from terminal.escape.escape_parser import EscapeParser
from terminal.escape.csi_parser import CsiParser
from terminal.escape.osc_parser import OscParser
from terminal.escape.sgr_parser import SgrParser


class EscapeHandler:
    """Dispatches parsed escape sequences to registered handlers."""

    def __init__(self):
        self._csi_handlers: Dict[str, Callable] = {}
        self._osc_handlers: Dict[int, Callable] = {}
        self._sgr_handlers: Dict[int, Callable] = {}
        self._escape_handlers: Dict[str, Callable] = {}

    def register_csi(self, command: str, handler: Callable):
        self._csi_handlers[command] = handler

    def register_osc(self, number: int, handler: Callable):
        self._osc_handlers[number] = handler

    def register_sgr(self, param: int, handler: Callable):
        self._sgr_handlers[param] = handler

    def register_escape(self, sequence: str, handler: Callable):
        self._escape_handlers[sequence] = handler

    def handle_csi(self, data: bytes):
        parser = CsiParser()
        result = parser.parse(data)
        if result:
            cmd = result.get('command', '')
            handler = self._csi_handlers.get(cmd)
            if handler:
                handler(result)

    def handle_osc(self, text: str):
        parser = OscParser()
        result = parser.parse(text)
        if result:
            num = result.get('number', 0)
            handler = self._osc_handlers.get(num)
            if handler:
                handler(result)

    def handle_sgr(self, data: bytes):
        parser = SgrParser()
        result = parser.parse(data)
        if result:
            for param in result.get('params', []):
                handler = self._sgr_handlers.get(param)
                if handler:
                    handler(result)

    def handle_escape(self, sequence: str):
        handler = self._escape_handlers.get(sequence)
        if handler:
            handler()

    def clear(self):
        self._csi_handlers.clear()
        self._osc_handlers.clear()
        self._sgr_handlers.clear()
        self._escape_handlers.clear()

"""SgrParser - parses Select Graphic Rendition (SGR) sequences."""

import re
from typing import Dict, List, Optional


class SgrParser:
    """Parses SGR (Select Graphic Rendition) escape sequences (CSI ... m)."""

    SGR_REGEX = re.compile(r'\x1b\[([\d;]*)m')

    def parse(self, data: bytes) -> Optional[dict]:
        """Parse an SGR sequence. Returns dict with params and attributes."""
        text = data.decode('utf-8', errors='replace')
        match = self.SGR_REGEX.match(text)
        if not match:
            return None
        param_str = match.group(1)
        params = []
        if param_str:
            for p in param_str.split(';'):
                if p:
                    try:
                        params.append(int(p))
                    except ValueError:
                        params.append(0)
                else:
                    params.append(0)
        else:
            params = [0]
        attrs = self._params_to_attrs(params)
        return {
            'raw': text,
            'params': params,
            'attributes': attrs,
        }

    def _params_to_attrs(self, params: List[int]) -> Dict[str, object]:
        attrs = {
            'bold': False, 'dim': False, 'italic': False,
            'underline': False, 'blink': False, 'reverse': False,
            'hidden': False, 'strikethrough': False,
            'fg_color': None, 'bg_color': None,
        }
        i = 0
        while i < len(params):
            p = params[i]
            if p == 0:
                for k in attrs:
                    if k not in ('fg_color', 'bg_color'):
                        attrs[k] = False
                attrs['fg_color'] = None
                attrs['bg_color'] = None
            elif p == 1:
                attrs['bold'] = True
            elif p == 2:
                attrs['dim'] = True
            elif p == 3:
                attrs['italic'] = True
            elif p == 4:
                attrs['underline'] = True
            elif p == 5 or p == 6:
                attrs['blink'] = True
            elif p == 7:
                attrs['reverse'] = True
            elif p == 8:
                attrs['hidden'] = True
            elif p == 9:
                attrs['strikethrough'] = True
            elif 30 <= p <= 37:
                attrs['fg_color'] = p - 30
            elif p == 38:
                if i + 2 < len(params) and params[i+1] == 5:
                    attrs['fg_color'] = params[i+2]
                    i += 2
                elif i + 4 < len(params) and params[i+1] == 2:
                    attrs['fg_color'] = (params[i+2], params[i+3], params[i+4])
                    i += 4
            elif p == 39:
                attrs['fg_color'] = None
            elif 40 <= p <= 47:
                attrs['bg_color'] = p - 40
            elif p == 48:
                if i + 2 < len(params) and params[i+1] == 5:
                    attrs['bg_color'] = params[i+2]
                    i += 2
                elif i + 4 < len(params) and params[i+1] == 2:
                    attrs['bg_color'] = (params[i+2], params[i+3], params[i+4])
                    i += 4
            elif p == 49:
                attrs['bg_color'] = None
            elif p == 90:
                attrs['fg_color'] = 8
            elif p == 97:
                attrs['fg_color'] = 15
            elif 100 <= p <= 107:
                attrs['bg_color'] = p - 92
            i += 1
        return attrs

    def get_params(self, data: bytes) -> List[int]:
        result = self.parse(data)
        if result:
            return result.get('params', [])
        return []

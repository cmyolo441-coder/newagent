"""XtermExtensions - handles xterm-specific escape sequences."""

import re
from typing import Dict, Optional


class XtermExtensions:
    """Handles xterm-specific escape sequence extensions."""

    TITLE_REGEX = re.compile(r'\x1b\]0;(.*?)(?:\x1b\\|\x07|$)')
    ICON_NAME_REGEX = re.compile(r'\x1b\]1;(.*?)(?:\x1b\\|\x07|$)')
    WINDOW_TITLE_REGEX = re.compile(r'\x1b\]2;(.*?)(?:\x1b\\|\x07|$)')
    COLOR_REGEX = re.compile(r'\x1b\]4;(\d+);(#[0-9a-fA-F]+)(?:\x1b\\|\x07|$)')
    FG_COLOR_REGEX = re.compile(r'\x1b\]10;(.*?)(?:\x1b\\|\x07|$)')
    BG_COLOR_REGEX = re.compile(r'\x1b\]11;(.*?)(?:\x1b\\|\x07|$)')
    CURSOR_COLOR_REGEX = re.compile(r'\x1b\]12;(.*?)(?:\x1b\\|\x07|$)')
    MOUSE_REGEX = re.compile(r'\x1b\[M(.)(.)(.)')

    def parse_title(self, text: str) -> Optional[str]:
        match = self.TITLE_REGEX.search(text)
        return match.group(1) if match else None

    def parse_window_title(self, text: str) -> Optional[str]:
        match = self.WINDOW_TITLE_REGEX.search(text)
        return match.group(1) if match else None

    def parse_icon_name(self, text: str) -> Optional[str]:
        match = self.ICON_NAME_REGEX.search(text)
        return match.group(1) if match else None

    def parse_color(self, text: str) -> Optional[dict]:
        match = self.COLOR_REGEX.search(text)
        if match:
            return {'index': int(match.group(1)), 'color': match.group(2)}
        return None

    def parse_fg_color(self, text: str) -> Optional[str]:
        match = self.FG_COLOR_REGEX.search(text)
        return match.group(1) if match else None

    def parse_bg_color(self, text: str) -> Optional[str]:
        match = self.BG_COLOR_REGEX.search(text)
        return match.group(1) if match else None

    def parse_cursor_color(self, text: str) -> Optional[str]:
        match = self.CURSOR_COLOR_REGEX.search(text)
        return match.group(1) if match else None

    def parse_mouse(self, data: bytes) -> Optional[dict]:
        match = self.MOUSE_REGEX.match(data)
        if match:
            cb = ord(match.group(1))
            cx = ord(match.group(2)) - 32
            cy = ord(match.group(3)) - 32
            return {'button': cb & 3, 'action': 'press' if not (cb & 32) else 'release',
                    'x': cx, 'y': cy, 'modifiers': (cb >> 2) & 3}
        return None

    def generate_set_title(self, title: str) -> bytes:
        return f'\x1b]0;{title}\x1b\\'.encode()

    def generate_set_window_title(self, title: str) -> bytes:
        return f'\x1b]2;{title}\x1b\\'.encode()

    def generate_set_color(self, index: int, color: str) -> bytes:
        return f'\x1b]4;{index};{color}\x1b\\'.encode()

"""PmParser - parses Privacy Message escape sequences."""

import re
from typing import Optional


class PmParser:
    """Parses PM (Privacy Message) escape sequences."""

    PM_REGEX = re.compile(r'\x1b\^(.*?)(?:\x1b\\|\x07|$)')

    def parse(self, data: bytes) -> Optional[dict]:
        """Parse a PM sequence."""
        text = data.decode('utf-8', errors='replace')
        match = self.PM_REGEX.match(text)
        if not match:
            return None
        return {
            'raw': text,
            'content': match.group(1),
        }

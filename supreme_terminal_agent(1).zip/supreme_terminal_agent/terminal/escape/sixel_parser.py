"""SixelParser - parses Sixel graphics escape sequences."""

import re
from typing import Dict, List, Optional


class SixelParser:
    """Parses Sixel graphics format escape sequences."""

    SIXEL_START = re.compile(r'\x1bPq')
    SIXEL_END = re.compile(r'\x1b\\')

    def __init__(self):
        self._data: bytearray = bytearray()
        self._parsing = False
        self._params: dict = {}
        self._sixels: List[List[int]] = []

    def feed(self, data: bytes):
        for byte in data:
            self._feed_byte(byte)

    def _feed_byte(self, byte: int):
        if not self._parsing:
            if byte == 0x1b:
                self._parsing = True
                self._data = bytearray(b'\x1b')
            return
        self._data.append(byte)
        if byte == 0x5c and len(self._data) >= 2 and self._data[-2] == 0x1b:
            self._finalize()
        elif byte == ord('q') and self._data == b'\x1bPq':
            pass

    def _finalize(self):
        data = bytes(self._data)
        self._parse_sixel(data)
        self._parsing = False
        self._data = bytearray()

    def _parse_sixel(self, data: bytes):
        text = data.decode('utf-8', errors='replace')
        without_dcs = text[2:-2] if text.endswith('\\') else text[2:]
        params_part = ''
        sixel_data = without_dcs
        idx = without_dcs.find('"')
        if idx >= 0:
            params_part = without_dcs[:idx]
            sixel_data = without_dcs[idx:]
        elif without_dcs and without_dcs[0].isdigit():
            parts = without_dcs.split(';', 1)
            if len(parts) == 2:
                params_part = parts[0]
                sixel_data = parts[1]
        self._params = {'raw_params': params_part, 'width': 0, 'height': 0}
        lines = []
        current_line = []
        for ch in sixel_data:
            if 63 <= ord(ch) <= 126:
                current_line.append(ch)
            elif ch == '-' or ch == '$':
                if current_line:
                    lines.append(current_line)
                    current_line = []
                if ch == '-':
                    pass
        if current_line:
            lines.append(current_line)
        self._sixels = lines

    def get_result(self) -> dict:
        return {
            'params': self._params,
            'sixels': self._sixels,
            'width': self._params.get('width', 0),
            'height': self._params.get('height', 0),
        }

    @property
    def width(self) -> int:
        return self._params.get('width', 0)

    @property
    def height(self) -> int:
        return self._params.get('height', 0)

    def reset(self):
        self._data = bytearray()
        self._parsing = False
        self._params = {}
        self._sixels = []

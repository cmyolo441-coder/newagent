"""SosParser - parses Start of String escape sequences."""

import re
from typing import Optional


class SosParser:
    """Parses SOS (Start of String) escape sequences."""

    SOS_REGEX = re.compile(r'\x1bX(.*?)(?:\x1b\\|\x07|$)')

    def parse(self, data: bytes) -> Optional[dict]:
        """Parse an SOS sequence."""
        text = data.decode('utf-8', errors='replace')
        match = self.SOS_REGEX.match(text)
        if not match:
            return None
        return {
            'raw': text,
            'content': match.group(1),
        }

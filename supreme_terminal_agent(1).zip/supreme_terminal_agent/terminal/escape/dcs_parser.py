"""DcsParser - parses Device Control String escape sequences."""

import re
from typing import Dict, Optional


class DcsParser:
    """Parses DCS (Device Control String) escape sequences."""

    DCS_REGEX = re.compile(r'\x1bP(.*?)(?:\x1b\\|$)')

    def parse(self, data: bytes) -> Optional[dict]:
        """Parse a DCS sequence."""
        text = data.decode('utf-8', errors='replace')
        match = self.DCS_REGEX.match(text)
        if not match:
            return None
        content = match.group(1)
        params = []
        data_str = content
        if ' ' in content:
            parts = content.split(' ', 1)
            param_part = parts[0]
            data_str = parts[1] if len(parts) > 1 else ''
            for ch in param_part:
                if ch.isdigit():
                    params.append(int(ch))
        return {
            'raw': text,
            'content': content,
            'params': params,
            'data': data_str,
        }

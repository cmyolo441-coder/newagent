"""OutputWriter - writes output to a file descriptor."""

import os
import sys
import threading
from typing import Optional


class OutputWriter:
    """Writes output data to a file descriptor (typically stdout)."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd or sys.stdout.fileno()
        self._lock = threading.Lock()

    def set_fd(self, fd: int):
        self.fd = fd

    def write(self, data: bytes) -> int:
        with self._lock:
            try:
                return os.write(self.fd, data)
            except OSError:
                return 0

    def write_text(self, text: str):
        self.write(text.encode('utf-8', errors='replace'))

    def writeline(self, text: str = ""):
        self.write_text(text + '\n')

    def flush(self):
        if self.fd == sys.stdout.fileno():
            sys.stdout.flush()

    def close(self):
        pass

"""AnsiStripper - removes ANSI escape sequences from output."""

import re
from typing import List, Optional


class AnsiStripper:
    """Strips ANSI escape sequences from terminal output."""

    ANSI_PATTERNS = [
        re.compile(r'\x1b\[[\d;]*[a-zA-Z]'),
        re.compile(r'\x1b\][\d;].*?(?:\x1b\\|\x07)'),
        re.compile(r'\x1b[\[\]()][\d;]*[a-zA-Z]'),
        re.compile(r'\x1bP.*?\x1b\\'),
        re.compile(r'\x1b_.*?\x1b\\'),
        re.compile(r'\x1b\^.*?\x1b\\'),
        re.compile(r'\x1bX.*?\x1b\\'),
    ]

    def strip(self, data: bytes) -> bytes:
        text = data.decode('utf-8', errors='replace')
        for pattern in self.ANSI_PATTERNS:
            text = pattern.sub('', text)
        return text.encode('utf-8', errors='replace')

    def strip_to_string(self, data: bytes) -> str:
        return self.strip(data).decode('utf-8', errors='replace')

    def preserve_escaped(self, data: bytes) -> bytes:
        text = data.decode('utf-8', errors='replace')
        for pattern in self.ANSI_PATTERNS[:-3]:
            text = pattern.sub('', text)
        return text.encode('utf-8', errors='replace')

    def strip_line(self, line: str) -> str:
        for pattern in self.ANSI_PATTERNS:
            line = pattern.sub('', line)
        return line

"""OutputFormatter - formats output data."""

from typing import Any, Dict, List, Optional


class OutputFormatter:
    """Formats terminal output data in various ways."""

    def format(self, fmt: str, *args) -> str:
        if fmt == 'json':
            return self.format_json(*args)
        elif fmt == 'table':
            return self.format_table(*args)
        elif fmt == 'list':
            return self.format_list(*args)
        elif fmt == 'csv':
            return self.format_csv(*args)
        return str(args[0]) if args else ''

    def format_json(self, data: Any, indent: int = 2) -> str:
        import json
        return json.dumps(data, indent=indent, default=str)

    def format_table(self, headers: List[str], rows: List[List[str]], padding: int = 2) -> str:
        if not headers or not rows:
            return ''
        col_widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                if i < len(col_widths):
                    col_widths[i] = max(col_widths[i], len(str(cell)))
        sep = '+'.join('-' * (w + padding) for w in col_widths)
        sep = '+' + sep + '+'
        lines = [sep]
        header_line = '|'
        for i, h in enumerate(headers):
            header_line += h.center(col_widths[i] + padding) + '|'
        lines.append(header_line)
        lines.append(sep)
        for row in rows:
            line = '|'
            for i, cell in enumerate(row):
                if i < len(col_widths):
                    line += str(cell).ljust(col_widths[i] + padding) + '|'
            lines.append(line)
        lines.append(sep)
        return '\n'.join(lines)

    def format_list(self, items: List[str], numbered: bool = False) -> str:
        if numbered:
            return '\n'.join(f"{i+1}. {item}" for i, item in enumerate(items))
        return '\n'.join(items)

    def format_csv(self, rows: List[List[str]], delimiter: str = ',') -> str:
        def escape_csv(val: str) -> str:
            if delimiter in val or '"' in val or '\n' in val:
                val = '"' + val.replace('"', '""') + '"'
            return val
        return '\n'.join(
            delimiter.join(escape_csv(str(cell)) for cell in row)
            for row in rows
        )

    def format_key_value(self, data: Dict[str, Any], separator: str = ': ') -> str:
        max_key_len = max(len(k) for k in data) if data else 0
        return '\n'.join(
            f"{k.ljust(max_key_len)}{separator}{v}"
            for k, v in data.items()
        )

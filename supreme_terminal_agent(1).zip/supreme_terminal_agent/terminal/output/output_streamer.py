"""OutputStreamer - streams output data through callbacks."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Callable, Generator, List, Optional

if TYPE_CHECKING:
    from terminal.output.output_controller import OutputController


class OutputStreamer:
    """Streams output data through callbacks or to an output controller."""

    def __init__(self):
        self._callbacks: List[Callable[[bytes], None]] = []

    def add_callback(self, callback: Callable[[bytes], None]):
        self._callbacks.append(callback)

    def remove_callback(self, callback: Callable[[bytes], None]):
        self._callbacks.remove(callback) if callback in self._callbacks else None

    def stream(self, data: bytes):
        for cb in self._callbacks:
            try:
                cb(data)
            except Exception:
                pass

    def stream_generator(self, generator: Generator[bytes, None, None], controller: OutputController):
        def _stream():
            for chunk in generator:
                controller.write(chunk)
        thread = threading.Thread(target=_stream, daemon=True)
        thread.start()
        return thread

    def stream_file(self, filepath: str, controller: OutputController, chunk_size: int = 4096):
        def _generate():
            with open(filepath, 'rb') as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    yield chunk
        return self.stream_generator(_generate(), controller)

    def broadcast(self, data: bytes):
        self.stream(data)

    def clear(self):
        self._callbacks.clear()

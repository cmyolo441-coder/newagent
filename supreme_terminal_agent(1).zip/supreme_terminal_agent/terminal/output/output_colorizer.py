"""OutputColorizer - colorizes terminal output with ANSI codes."""

from typing import Dict, Optional


class OutputColorizer:
    """Colorizes terminal output with ANSI escape sequences."""

    COLORS = {
        'black': 0, 'red': 1, 'green': 2, 'yellow': 3,
        'blue': 4, 'magenta': 5, 'cyan': 6, 'white': 7,
        'bright_black': 8, 'bright_red': 9, 'bright_green': 10,
        'bright_yellow': 11, 'bright_blue': 12, 'bright_magenta': 13,
        'bright_cyan': 14, 'bright_white': 15,
    }

    STYLES = {
        'bold': 1, 'dim': 2, 'italic': 3, 'underline': 4,
        'blink': 5, 'reverse': 7, 'hidden': 8, 'strikethrough': 9,
    }

    def colorize(self, text: str, fg: str = "", bg: str = "", styles: Optional[list] = None) -> str:
        parts = []
        if fg:
            fg_code = self.COLORS.get(fg)
            if fg_code is not None:
                if fg_code < 8:
                    parts.append(f'30{fg_code}')
                else:
                    parts.append(f'38;5;{fg_code}')
        if bg:
            bg_code = self.COLORS.get(bg)
            if bg_code is not None:
                if bg_code < 8:
                    parts.append(f'40{bg_code}')
                else:
                    parts.append(f'48;5;{bg_code}')
        if styles:
            for style in styles:
                code = self.STYLES.get(style)
                if code is not None:
                    parts.append(str(code))
        if parts:
            return f'\x1b[{";".join(parts)}m{text}\x1b[0m'
        return text

    def colorize_rgb(self, text: str, fg_rgb: Optional[tuple] = None, bg_rgb: Optional[tuple] = None) -> str:
        parts = []
        if fg_rgb and len(fg_rgb) == 3:
            parts.append(f'38;2;{fg_rgb[0]};{fg_rgb[1]};{fg_rgb[2]}')
        if bg_rgb and len(bg_rgb) == 3:
            parts.append(f'48;2;{bg_rgb[0]};{bg_rgb[1]};{bg_rgb[2]}')
        if parts:
            return f'\x1b[{";".join(parts)}m{text}\x1b[0m'
        return text

    def red(self, text: str) -> str:
        return self.colorize(text, fg='red')

    def green(self, text: str) -> str:
        return self.colorize(text, fg='green')

    def yellow(self, text: str) -> str:
        return self.colorize(text, fg='yellow')

    def blue(self, text: str) -> str:
        return self.colorize(text, fg='blue')

    def magenta(self, text: str) -> str:
        return self.colorize(text, fg='magenta')

    def cyan(self, text: str) -> str:
        return self.colorize(text, fg='cyan')

    def white(self, text: str) -> str:
        return self.colorize(text, fg='white')

    def bold(self, text: str) -> str:
        return self.colorize(text, styles=['bold'])

    def underline(self, text: str) -> str:
        return self.colorize(text, styles=['underline'])

    def dim(self, text: str) -> str:
        return self.colorize(text, styles=['dim'])

    def reset(self, text: str = "") -> str:
        return f'{text}\x1b[0m'

    def strip_ansi(self, text: str) -> str:
        import re
        return re.sub(r'\x1b\[[\d;]*[a-zA-Z]', '', text)

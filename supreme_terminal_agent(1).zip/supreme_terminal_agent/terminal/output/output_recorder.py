"""OutputRecorder - records terminal output for later analysis."""

import os
import time
import threading
from typing import List, Optional, Tuple


class OutputRecorder:
    """Records terminal output to a buffer or file."""

    def __init__(self, filepath: Optional[str] = None):
        self.filepath = filepath
        self._buffer: List[Tuple[float, bytes]] = []
        self._recording = False
        self._file: Optional[object] = None
        self._lock = threading.Lock()

    def start(self, filepath: Optional[str] = None):
        with self._lock:
            self._buffer = []
            self._recording = True
            if filepath:
                self.filepath = filepath
            if self.filepath:
                self._file = open(self.filepath, 'wb')

    def record(self, data: bytes):
        if not self._recording:
            return
        timestamp = time.time()
        with self._lock:
            self._buffer.append((timestamp, data))
            if self._file:
                self._file.write(data)
                self._file.flush()

    def stop(self) -> List[Tuple[float, bytes]]:
        with self._lock:
            self._recording = False
            if self._file:
                self._file.close()
                self._file = None
            return list(self._buffer)

    def get_buffer(self) -> List[Tuple[float, bytes]]:
        with self._lock:
            return list(self._buffer)

    def get_text(self) -> str:
        with self._lock:
            return b''.join(d for _, d in self._buffer).decode('utf-8', errors='replace')

    def clear(self):
        with self._lock:
            self._buffer.clear()

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._buffer)

    def close(self):
        if self._recording:
            self.stop()

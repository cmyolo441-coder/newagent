"""OutputPager - paginates terminal output for display."""

import os
import subprocess
import tempfile
from typing import Optional


class OutputPager:
    """Paginates output for display through a pager program."""

    def __init__(self, pager: Optional[str] = None):
        self.pager = pager or os.environ.get('PAGER', 'less')
        self._page_lines: int = 0
        self._page_size: int = 0

    def page(self, data: bytes, pager: Optional[str] = None):
        cmd = pager or self.pager
        try:
            proc = subprocess.Popen(
                cmd, shell=True, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            proc.stdin.write(data)
            proc.stdin.close()
            proc.wait()
        except OSError:
            pass

    def page_text(self, text: str, pager: Optional[str] = None):
        self.page(text.encode('utf-8'), pager)

    def page_file(self, filepath: str, pager: Optional[str] = None):
        cmd = pager or self.pager
        try:
            subprocess.run(f'{cmd} {filepath}', shell=True)
        except OSError:
            pass

    def page_temp(self, data: bytes, pager: Optional[str] = None):
        with tempfile.NamedTemporaryFile(mode='wb', delete=False) as f:
            f.write(data)
            tmppath = f.name
        try:
            self.page_file(tmppath, pager)
        finally:
            try:
                os.unlink(tmppath)
            except OSError:
                pass

    def set_pager(self, pager: str):
        self.pager = pager

    def is_pager_available(self) -> bool:
        pager = self.pager.split()[0] if self.pager else 'less'
        return self._command_exists(pager)

    def _command_exists(self, cmd: str) -> bool:
        path = os.environ.get('PATH', '')
        for dir_path in path.split(':'):
            full = os.path.join(dir_path, cmd)
            if os.path.isfile(full) and os.access(full, os.X_OK):
                return True
        return False

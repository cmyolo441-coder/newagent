"""OutputController - high-level controller for terminal output."""

import sys
import os
from typing import Callable, List, Optional

from terminal.output.output_buffer import OutputBuffer
from terminal.output.output_queue import OutputQueue
from terminal.output.output_writer import OutputWriter
from terminal.output.output_parser import OutputParser
from terminal.output.output_analyzer import OutputAnalyzer
from terminal.output.output_filter import OutputFilter
from terminal.output.output_transformer import OutputTransformer
from terminal.output.output_formatter import OutputFormatter
from terminal.output.output_colorizer import OutputColorizer
from terminal.output.output_pager import OutputPager
from terminal.output.output_recorder import OutputRecorder
from terminal.output.output_streamer import OutputStreamer


class OutputController:
    """High-level controller for all terminal output."""

    def __init__(self):
        self.buffer = OutputBuffer()
        self.queue = OutputQueue()
        self.writer = OutputWriter()
        self.parser = OutputParser()
        self.analyzer = OutputAnalyzer()
        self.filter = OutputFilter()
        self.transformer = OutputTransformer()
        self.formatter = OutputFormatter()
        self.colorizer = OutputColorizer()
        self.pager = OutputPager()
        self.recorder = OutputRecorder()
        self.streamer = OutputStreamer()
        self._on_output: List[Callable] = []

    def write(self, data: bytes):
        self.writer.write(data)
        for cb in self._on_output:
            cb(data)

    def write_text(self, text: str):
        self.write(text.encode('utf-8', errors='replace'))

    def writeline(self, text: str = ""):
        self.write_text(text + '\n')

    def write_buffered(self, data: bytes):
        self.buffer.write(data)

    def flush(self):
        data = self.buffer.read()
        if data:
            self.writer.write(data)

    def write_colored(self, text: str, fg: str = "", bg: str = ""):
        colored = self.colorizer.colorize(text, fg, bg)
        self.write_text(colored)

    def write_formatted(self, fmt: str, *args):
        text = self.formatter.format(fmt, *args)
        self.write_text(text)

    def stream(self, generator):
        self.streamer.stream(generator, self)

    def start_recording(self):
        self.recorder.start()

    def stop_recording(self):
        return self.recorder.stop()

    def on_output(self, callback: Callable):
        self._on_output.append(callback)

    def close(self):
        self.flush()
        self.writer.close()
        self.buffer.clear()
        self.queue.clear()

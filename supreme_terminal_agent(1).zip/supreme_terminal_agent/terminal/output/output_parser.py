"""OutputParser - parses output data for analysis."""

import re
from typing import Dict, List, Optional, Tuple


class OutputParser:
    """Parses terminal output for structure analysis."""

    ANSI_REGEX = re.compile(r'(\x1b\[[\d;]*[a-zA-Z])|(\x1b\][\d;].*?(?:\x1b\\|\x07))|(\x1b[\[\]()][\d;]*[a-zA-Z])')
    URL_REGEX = re.compile(r'https?://[^\s<>"\'()]+')
    EMAIL_REGEX = re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')
    PATH_REGEX = re.compile(r'(?:/[a-zA-Z0-9._-]+)+')
    PROMPT_REGEX = re.compile(r'[\$\#>] $')

    def parse(self, data: bytes) -> List[dict]:
        text = data.decode('utf-8', errors='replace')
        segments = []
        last_end = 0
        for match in self.ANSI_REGEX.finditer(text):
            if match.start() > last_end:
                segments.append({
                    'type': 'text',
                    'content': text[last_end:match.start()],
                })
            segments.append({
                'type': 'ansi',
                'content': match.group(0),
            })
            last_end = match.end()
        if last_end < len(text):
            segments.append({
                'type': 'text',
                'content': text[last_end:],
            })
        return segments

    def extract_text(self, data: bytes) -> str:
        return self.ANSI_REGEX.sub('', data.decode('utf-8', errors='replace'))

    def extract_urls(self, data: bytes) -> List[str]:
        text = self.extract_text(data)
        return self.URL_REGEX.findall(text)

    def extract_emails(self, data: bytes) -> List[str]:
        text = self.extract_text(data)
        return self.EMAIL_REGEX.findall(text)

    def extract_paths(self, data: bytes) -> List[str]:
        text = self.extract_text(data)
        return self.PATH_REGEX.findall(text)

    def is_prompt(self, data: bytes) -> bool:
        text = data.decode('utf-8', errors='replace').strip()
        return bool(self.PROMPT_REGEX.search(text))

    def count_lines(self, data: bytes) -> int:
        return data.count(b'\n')

    def get_line_count(self, data: bytes) -> int:
        return len(data.splitlines())

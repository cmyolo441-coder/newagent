"""OutputQueue - queues output data for deferred writing."""

import sys
if 'queue' in sys.modules and sys.modules['queue'].__file__.startswith('/content/'):
    del sys.modules['queue']
import queue as stdlib_queue
import threading
from typing import Any, List, Optional


class OutputQueue:
    """Thread-safe queue for output data."""

    def __init__(self, maxsize: int = 0):
        self._queue: stdlib_queue.Queue = stdlib_queue.Queue(maxsize=maxsize)

    def put(self, data: bytes, block: bool = True, timeout: Optional[float] = None):
        self._queue.put(data, block=block, timeout=timeout)

    def get(self, block: bool = True, timeout: Optional[float] = None) -> Optional[bytes]:
        try:
            return self._queue.get(block=block, timeout=timeout)
        except stdlib_queue.Empty:
            return None

    def get_nowait(self) -> Optional[bytes]:
        try:
            return self._queue.get_nowait()
        except stdlib_queue.Empty:
            return None

    def drain(self) -> List[bytes]:
        items = []
        while True:
            item = self.get_nowait()
            if item is None:
                break
            items.append(item)
        return items

    def clear(self):
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except stdlib_queue.Empty:
                break

    @property
    def size(self) -> int:
        return self._queue.qsize()

    @property
    def is_empty(self) -> bool:
        return self._queue.empty()

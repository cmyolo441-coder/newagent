"""OutputSplitter - splits output to multiple destinations."""

import os
from typing import List, Optional


class OutputSplitter:
    """Splits output to multiple destinations simultaneously."""

    def __init__(self):
        self._outputs: List[object] = []

    def add_writer(self, writer):
        self._outputs.append(writer)

    def add_fd(self, fd: int):
        class _FdWriter:
            def __init__(self, fd):
                self.fd = fd
            def write(self, data):
                try:
                    os.write(self.fd, data)
                except OSError:
                    pass
        self._outputs.append(_FdWriter(fd))

    def add_file(self, filepath: str, mode: str = 'ab'):
        f = open(filepath, mode)
        self._outputs.append(f)

    def write(self, data: bytes):
        for output in self._outputs:
            try:
                output.write(data)
            except (OSError, AttributeError):
                pass

    def remove(self, output):
        if output in self._outputs:
            self._outputs.remove(output)
            if hasattr(output, 'close'):
                try:
                    output.close()
                except (OSError, AttributeError):
                    pass

    def close_all(self):
        for output in self._outputs:
            if hasattr(output, 'close'):
                try:
                    output.close()
                except OSError:
                    pass
        self._outputs.clear()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close_all()

"""OutputTransformer - transforms output data."""

from typing import Callable, List, Optional


class OutputTransformer:
    """Transforms terminal output data through a chain of transformations."""

    def __init__(self):
        self._transformers: List[Callable[[bytes], bytes]] = []

    def add_transformer(self, transformer: Callable[[bytes], bytes]):
        self._transformers.append(transformer)

    def transform(self, data: bytes) -> bytes:
        result = data
        for transformer in self._transformers:
            result = transformer(result)
        return result

    def remove_ansi(self, data: bytes) -> bytes:
        import re
        text = data.decode('utf-8', errors='replace')
        cleaned = re.sub(r'\x1b\[[\d;]*[a-zA-Z]', '', text)
        cleaned = re.sub(r'\x1b\][\d;].*?(?:\x1b\\|\x07)', '', cleaned)
        return cleaned.encode('utf-8', errors='replace')

    def replace_tabs(self, data: bytes, spaces: int = 8) -> bytes:
        text = data.decode('utf-8', errors='replace')
        text = text.expandtabs(spaces)
        return text.encode('utf-8', errors='replace')

    def strip_empty_lines(self, data: bytes) -> bytes:
        text = data.decode('utf-8', errors='replace')
        lines = [l for l in text.splitlines(True) if l.strip()]
        return ''.join(lines).encode('utf-8', errors='replace')

    def truncate_lines(self, data: bytes, max_lines: int = 1000) -> bytes:
        text = data.decode('utf-8', errors='replace')
        lines = text.splitlines(True)
        if len(lines) > max_lines:
            lines = lines[:max_lines]
        return ''.join(lines).encode('utf-8', errors='replace')

    def truncate(self, data: bytes, max_bytes: int = 65536) -> bytes:
        if len(data) <= max_bytes:
            return data
        return data[:max_bytes]

    def clear(self):
        self._transformers.clear()

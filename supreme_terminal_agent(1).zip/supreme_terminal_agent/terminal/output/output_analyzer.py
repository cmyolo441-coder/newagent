"""OutputAnalyzer - analyzes terminal output content."""

import re
from typing import Dict, List, Optional


class OutputAnalyzer:
    """Analyzes terminal output for patterns, errors, and structure."""

    ERROR_PATTERNS = [
        r'error:', r'Error:', r'ERROR:', r'Traceback',
        r'failed', r'Failed', r'FAILED',
        r'exception', r'Exception', r'EXCEPTION',
        r'warning:', r'Warning:', r'WARNING:',
        r'undefined', r'Undefined',
        r'cannot', r'Cannot', r'CANNOT',
        r'not found', r'Not found', r'NOT FOUND',
        r'permission denied', r'Permission denied',
    ]

    def __init__(self):
        self._compiled = [re.compile(p) for p in self.ERROR_PATTERNS]

    def analyze(self, data: bytes) -> Dict[str, object]:
        text = data.decode('utf-8', errors='replace')
        lines = text.splitlines()
        return {
            'line_count': len(lines),
            'char_count': len(text),
            'has_errors': self.has_errors(data),
            'has_warnings': self.has_warnings(data),
            'error_lines': self.find_errors(data),
            'is_empty': len(text.strip()) == 0,
            'ends_with_newline': data.endswith(b'\n'),
        }

    def has_errors(self, data: bytes) -> bool:
        text = data.decode('utf-8', errors='replace')
        return any(p.search(text) for p in self._compiled[:6])

    def has_warnings(self, data: bytes) -> bool:
        text = data.decode('utf-8', errors='replace')
        return any(p.search(text) for p in self._compiled[6:9])

    def find_errors(self, data: bytes) -> List[Dict[str, object]]:
        text = data.decode('utf-8', errors='replace')
        results = []
        for i, line in enumerate(text.splitlines()):
            for pattern in self._compiled:
                if pattern.search(line):
                    results.append({
                        'line': i,
                        'text': line.strip(),
                        'pattern': pattern.pattern,
                    })
                    break
        return results

    def find_patterns(self, data: bytes, patterns: List[str]) -> List[Dict[str, object]]:
        text = data.decode('utf-8', errors='replace')
        results = []
        compiled = [re.compile(p) for p in patterns]
        for i, line in enumerate(text.splitlines()):
            for pattern, compiled_p in zip(patterns, compiled):
                if compiled_p.search(line):
                    results.append({
                        'line': i,
                        'text': line.strip(),
                        'pattern': pattern,
                    })
        return results

    def get_statistics(self, data: bytes) -> Dict[str, int]:
        text = data.decode('utf-8', errors='replace')
        return {
            'total_lines': len(text.splitlines()),
            'total_chars': len(text),
            'total_bytes': len(data),
            'whitespace_chars': sum(1 for c in text if c.isspace()),
            'alpha_chars': sum(1 for c in text if c.isalpha()),
            'digit_chars': sum(1 for c in text if c.isdigit()),
        }

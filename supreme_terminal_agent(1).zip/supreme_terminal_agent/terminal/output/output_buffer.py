"""OutputBuffer - buffer for terminal output data."""

import threading
from typing import Optional


class OutputBuffer:
    """Buffers terminal output data before writing."""

    def __init__(self, max_size: int = 65536):
        self.max_size = max_size
        self._buffer = bytearray()
        self._lock = threading.RLock()

    def write(self, data: bytes) -> int:
        with self._lock:
            self._buffer.extend(data)
            if len(self._buffer) > self.max_size:
                self._buffer = self._buffer[-self.max_size:]
            return len(data)

    def read(self, size: int = -1) -> bytes:
        with self._lock:
            if not self._buffer:
                return b''
            if size < 0 or size >= len(self._buffer):
                data = bytes(self._buffer)
                self._buffer.clear()
            else:
                data = bytes(self._buffer[:size])
                self._buffer = self._buffer[size:]
            return data

    def peek(self, size: int = -1) -> bytes:
        with self._lock:
            if size < 0 or size >= len(self._buffer):
                return bytes(self._buffer)
            return bytes(self._buffer[:size])

    def clear(self):
        with self._lock:
            self._buffer.clear()

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._buffer)

    @property
    def is_empty(self) -> bool:
        with self._lock:
            return len(self._buffer) == 0

    @property
    def is_full(self) -> bool:
        with self._lock:
            return len(self._buffer) >= self.max_size

    def __len__(self) -> int:
        return self.size

"""OutputTee - tees output to both stdout and other destinations."""

import sys
import os
from typing import List, Optional

from terminal.output.output_splitter import OutputSplitter


class OutputTee:
    """Tees output: writes to both the original destination and additional outputs."""

    def __init__(self):
        self.splitter = OutputSplitter()
        self._original_stdout = sys.stdout
        self._active = False

    def add_file(self, filepath: str):
        self.splitter.add_file(filepath)

    def add_fd(self, fd: int):
        self.splitter.add_fd(fd)

    def start(self):
        if self._active:
            return
        self._active = True

    def stop(self):
        if not self._active:
            return
        self._active = False

    def write(self, data: bytes):
        if self._active:
            self.splitter.write(data)

    def write_text(self, text: str):
        self.write(text.encode('utf-8', errors='replace'))

    def close(self):
        self.stop()
        self.splitter.close_all()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

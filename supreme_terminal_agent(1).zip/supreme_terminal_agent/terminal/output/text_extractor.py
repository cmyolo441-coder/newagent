"""TextExtractor - extracts clean text from terminal output."""

import re
from typing import List, Optional

from terminal.output.ansi_stripper import AnsiStripper


class TextExtractor:
    """Extracts clean, readable text from terminal output containing ANSI escapes."""

    def __init__(self):
        self.stripper = AnsiStripper()

    def extract(self, data: bytes) -> str:
        return self.stripper.strip_to_string(data)

    def extract_lines(self, data: bytes) -> List[str]:
        text = self.extract(data)
        return text.splitlines()

    def extract_words(self, data: bytes) -> List[str]:
        text = self.extract(data)
        return text.split()

    def extract_sentences(self, data: bytes) -> List[str]:
        text = self.extract(data)
        sentences = re.split(r'[.!?]+', text)
        return [s.strip() for s in sentences if s.strip()]

    def extract_table(self, data: bytes) -> List[List[str]]:
        lines = self.extract_lines(data)
        table = []
        for line in lines:
            if not line.strip():
                continue
            if all(c in ' -+|' for c in line):
                continue
            cells = re.split(r'\s{2,}|\|', line)
            cells = [c.strip() for c in cells if c.strip()]
            if cells:
                table.append(cells)
        return table

    def extract_key_value(self, data: bytes, separator: str = ':') -> List[tuple]:
        lines = self.extract_lines(data)
        pairs = []
        for line in lines:
            if separator in line:
                key, value = line.split(separator, 1)
                pairs.append((key.strip(), value.strip()))
        return pairs

    def extract_urls(self, data: bytes) -> List[str]:
        text = self.extract(data)
        return re.findall(r'https?://[^\s<>"\'()]+', text)

    def extract_emails(self, data: bytes) -> List[str]:
        text = self.extract(data)
        return re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)

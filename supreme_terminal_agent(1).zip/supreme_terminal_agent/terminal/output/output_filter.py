"""OutputFilter - filters terminal output based on rules."""

import re
from typing import Callable, List, Optional, Pattern


class OutputFilter:
    """Filters terminal output through configurable rules."""

    def __init__(self):
        self._include_patterns: List[Pattern] = []
        self._exclude_patterns: List[Pattern] = []
        self._transforms: List[Callable[[str], str]] = []

    def add_include(self, pattern: str):
        self._include_patterns.append(re.compile(pattern))

    def add_exclude(self, pattern: str):
        self._exclude_patterns.append(re.compile(pattern))

    def add_transform(self, transform: Callable[[str], str]):
        self._transforms.append(transform)

    def filter(self, data: bytes) -> bytes:
        text = data.decode('utf-8', errors='replace')
        filtered = self._filter_text(text)
        return filtered.encode('utf-8', errors='replace')

    def _filter_text(self, text: str) -> str:
        lines = text.splitlines(keepends=True)
        result = []
        for line in lines:
            if self._exclude_patterns:
                if any(p.search(line) for p in self._exclude_patterns):
                    continue
            if self._include_patterns:
                if not any(p.search(line) for p in self._include_patterns):
                    continue
            result.append(line)
        text = ''.join(result)
        for transform in self._transforms:
            text = transform(text)
        return text

    def filter_line(self, line: str) -> Optional[str]:
        if self._exclude_patterns:
            if any(p.search(line) for p in self._exclude_patterns):
                return None
        if self._include_patterns:
            if not any(p.search(line) for p in self._include_patterns):
                return None
        for transform in self._transforms:
            line = transform(line)
        return line

    def clear(self):
        self._include_patterns.clear()
        self._exclude_patterns.clear()
        self._transforms.clear()

    def remove_ansi(self, text: str) -> str:
        return re.sub(r'\x1b\[[\d;]*[a-zA-Z]', '', text)

"""TerminalEmulator - full terminal emulation engine processing raw I/O."""

import os
import time
import heapq
import struct
import fcntl
import termios
import logging
import threading
from typing import Any, Callable, Dict, List, Optional, Tuple

from terminal.terminal_state import CursorStyle, TerminalMode, TerminalState
from terminal.terminal_capabilities import TerminalCapabilities
from terminal.terminal_renderer import RenderedFrame, RenderedLine, TerminalRenderer
from terminal.screen.screen_buffer import ScreenBuffer
from terminal.screen.screen_manager import ScreenManager
from terminal.screen.screen_scroll import ScreenScroll
from terminal.screen.screen_dirty import ScreenDirty
from terminal.scrollback.scrollback_manager import ScrollbackManager
from terminal.escape.escape_parser import EscapeParser
from terminal.escape.csi_parser import CsiParser
from terminal.escape.osc_parser import OscParser
from terminal.escape.sgr_parser import SgrParser
from terminal.input.input_queue import InputQueue
from terminal.output.output_buffer import OutputBuffer
from terminal.output.ansi_stripper import AnsiStripper

logger = logging.getLogger(__name__)


class TerminalEmulator:
    """Full terminal emulation engine.

    Processes raw byte I/O through escape sequence parsing, screen buffer
    management, scrollback, and input queuing.
    """

    def __init__(
        self,
        rows: int = 24,
        cols: int = 80,
        capabilities: Optional[TerminalCapabilities] = None,
    ):
        self._rows = rows
        self._cols = cols
        self._capabilities = capabilities or TerminalCapabilities()
        self._state = TerminalState(rows, cols)
        self._screen = ScreenManager(rows, cols)
        self._renderer = TerminalRenderer(self._capabilities, self._state)
        self._input_queue = InputQueue()
        self._output_buffer = OutputBuffer()
        self._escape_parser = EscapeParser()
        self._csi_parser = CsiParser()
        self._osc_parser = OscParser()
        self._sgr_parser = SgrParser()
        self._stripper = AnsiStripper()
        self._scrollback = ScrollbackManager()
        self._lock = threading.RLock()
        self._running = False
        self._input_callbacks: List[Callable[[bytes], None]] = []
        self._output_callbacks: List[Callable[[bytes], None]] = []
        self._resize_callbacks: List[Callable[[int, int], None]] = []
        self._title_callbacks: List[Callable[[str], None]] = []
        self._cursor_x: int = 0
        self._cursor_y: int = 0
        self._saved_cursor: Tuple[int, int] = (0, 0)
        self._charset: str = "B"
        self._g0_charset: str = "B"
        self._g1_charset: str = "B"
        self._selected_charset: int = 0
        self._tab_stops: List[int] = [(i + 1) % 8 == 0 for i in range(cols)]

    @property
    def state(self) -> TerminalState:
        return self._state

    @property
    def screen(self) -> ScreenManager:
        return self._screen

    @property
    def renderer(self) -> TerminalRenderer:
        return self._renderer

    @property
    def scrollback(self) -> ScrollbackManager:
        return self._scrollback

    @property
    def input_queue(self) -> InputQueue:
        return self._input_queue

    @property
    def rows(self) -> int:
        return self._rows

    @property
    def cols(self) -> int:
        return self._cols

    @property
    def is_running(self) -> bool:
        return self._running

    def start(self):
        """Start the emulator processing loop."""
        with self._lock:
            self._running = True

    def stop(self):
        """Stop the emulator processing loop."""
        with self._lock:
            self._running = False

    def write_input(self, data: bytes):
        """Queue input data for processing through the emulator."""
        self._input_queue.enqueue(data)

    def process_input(self, data: bytes) -> List[bytes]:
        """Process raw input bytes through the terminal emulator.

        Parses escape sequences, updates screen state, and returns
        processed output chunks.
        """
        with self._lock:
            output: List[bytes] = []
            i = 0
            while i < len(data):
                byte = data[i]
                if byte == 0x1B:
                    seq, consumed = self._escape_parser.feed(data[i:])
                    if seq:
                        result = self._handle_escape(seq)
                        if result:
                            output.append(result)
                    i += consumed if consumed > 0 else 1
                elif byte == 0x0D:
                    self._carriage_return()
                    i += 1
                elif byte == 0x0A:
                    self._linefeed()
                    i += 1
                elif byte == 0x08:
                    self._backspace()
                    i += 1
                elif byte == 0x09:
                    self._tab()
                    i += 1
                elif byte == 0x0B or byte == 0x0C:
                    self._linefeed()
                    i += 1
                elif byte == 0x07:
                    output.append(b"\x07")
                    i += 1
                elif byte < 0x20 or byte == 0x7F:
                    i += 1
                else:
                    decoded = data[i:i + 1]
                    self._print_char(decoded)
                    i += 1
            return output

    def process_output(self, data: bytes) -> bytes:
        """Process output data from the PTY through the terminal.

        This handles the data that would be displayed on a real terminal,
        updating the screen buffer state.
        """
        with self._lock:
            self._screen.write(data)
            self._output_buffer.write(data)
            for cb in self._output_callbacks:
                try:
                    cb(data)
                except Exception:
                    logger.exception("Output callback failed")
            return data

    def feed(self, data: bytes) -> RenderedFrame:
        """Feed raw PTY output bytes into the emulator and produce a rendered frame."""
        self.process_output(data)
        for cb in self._input_callbacks:
            try:
                cb(data)
            except Exception:
                logger.exception("Input callback failed")
        return self.render()

    def render(self) -> RenderedFrame:
        """Render the current screen state into a display frame."""
        with self._lock:
            return self._renderer.render_frame(
                self._screen.active_buffer,
                render_cursor=True,
            )

    def resize(self, rows: int, cols: int):
        """Resize the terminal emulator dimensions."""
        with self._lock:
            old_rows = self._rows
            old_cols = self._cols
            self._rows = rows
            self._cols = cols
            self._state.rows = rows
            self._state.cols = cols
            self._screen.resize(rows, cols)
            self._tab_stops = [
                (i + 1) % 8 == 0 for i in range(cols)
            ]
            for cb in self._resize_callbacks:
                try:
                    cb(rows, cols)
                except Exception:
                    logger.exception("Resize callback failed")

    def reset(self, hard: bool = False):
        """Reset the terminal emulator state."""
        with self._lock:
            self._state.reset()
            self._screen.reset()
            self._input_queue.clear()
            self._output_buffer.clear()
            self._cursor_x = 0
            self._cursor_y = 0
            self._saved_cursor = (0, 0)
            self._charset = "B"
            self._g0_charset = "B"
            self._g1_charset = "B"
            self._selected_charset = 0
            self._tab_stops = [(i + 1) % 8 == 0 for i in range(self._cols)]
            if hard:
                self._scrollback.clear()

    def on_input(self, callback: Callable[[bytes], None]):
        self._input_callbacks.append(callback)

    def on_output(self, callback: Callable[[bytes], None]):
        self._output_callbacks.append(callback)

    def on_resize(self, callback: Callable[[int, int], None]):
        self._resize_callbacks.append(callback)

    def on_title_change(self, callback: Callable[[str], None]):
        self._title_callbacks.append(callback)

    def get_plain_text(self) -> str:
        """Get the visible buffer content as plain text."""
        with self._lock:
            return self._screen.get_visible_text()

    def get_output_buffer(self) -> bytes:
        """Get and clear the raw output buffer."""
        return self._output_buffer.read()

    def _handle_escape(self, seq: bytes) -> Optional[bytes]:
        """Handle a parsed escape sequence."""
        if not seq:
            return None
        first = seq[0]

        if first == 0x5B:
            return self._handle_csi(seq[1:])
        elif first == 0x5D:
            self._handle_osc(seq[1:])
            return None
        elif first == 0x4F:
            self._handle_ss3(seq[1:])
            return None
        elif first == 0x4D:
            self._reverse_index()
            return None
        elif first == 0x48:
            self._set_tab_stop()
            return None
        elif first == 0x37:
            self._saved_cursor = (self._cursor_x, self._cursor_y)
            return None
        elif first == 0x38:
            self._cursor_x, self._cursor_y = self._saved_cursor
            return None
        elif first == 0x63:
            self.reset(hard=True)
            return b"\x1bc"
        elif first == 0x28:
            if len(seq) > 1:
                self._g0_charset = chr(seq[1])
                self._charset = self._g0_charset if self._selected_charset == 0 else self._g1_charset
            return None
        elif first == 0x29:
            if len(seq) > 1:
                self._g1_charset = chr(seq[1])
                self._charset = self._g0_charset if self._selected_charset == 0 else self._g1_charset
            return None
        elif first == 0x4E:
            self._selected_charset = 1
            return None
        elif first == 0x4F:
            self._selected_charset = 0
            return None
        elif first == 0x1B:
            return self._handle_escape(seq[1:]) if len(seq) > 1 else None
        elif first == 0x5B and len(seq) > 1 and seq[1] == 0x3F:
            return self._handle_dec_private(seq[2:])
        elif first == 0x50:
            self._handle_dcs(seq[1:])
            return None
        elif first == 0x5F:
            return None
        elif first == 0x5C:
            return None
        elif first == 0x5B:
            return None
        elif first == 0x1B and len(seq) > 1:
            pass

        return None

    def _handle_csi(self, params: bytes) -> Optional[bytes]:
        """Handle a Control Sequence Introducer sequence."""
        parsed = self._csi_parser.parse(b"\x1b[" + params)
        if parsed is None:
            return None

        cmd = parsed.get("command", "")
        args = parsed.get("args", [])

        if cmd == "A":
            self._state.move_cursor_up(self._first_arg(args, 1))
        elif cmd == "B":
            self._state.move_cursor_down(self._first_arg(args, 1))
        elif cmd == "C":
            self._state.move_cursor_right(self._first_arg(args, 1))
        elif cmd == "D":
            self._state.move_cursor_left(self._first_arg(args, 1))
        elif cmd == "E":
            self._state.move_cursor_down(self._first_arg(args, 1))
            self._state.carriage_return()
        elif cmd == "F":
            self._state.move_cursor_up(self._first_arg(args, 1))
            self._state.carriage_return()
        elif cmd == "G":
            self._state.cursor_x = self._first_arg(args, 1) - 1
        elif cmd == "H" or cmd == "f":
            row = self._first_arg(args, 0, 1) - 1
            col = self._first_arg(args, 1, 1) - 1
            self._state.set_cursor(col, row)
        elif cmd == "J":
            self._erase_display(self._first_arg(args, 0))
        elif cmd == "K":
            self._erase_line(self._first_arg(args, 0))
        elif cmd == "L":
            self._insert_lines(self._first_arg(args, 1))
        elif cmd == "M":
            self._delete_lines(self._first_arg(args, 1))
        elif cmd == "P":
            self._delete_chars(self._first_arg(args, 1))
        elif cmd == "@":
            self._insert_chars(self._first_arg(args, 1))
        elif cmd == "X":
            self._erase_chars(self._first_arg(args, 1))
        elif cmd == "S":
            self._scroll_up(self._first_arg(args, 1))
        elif cmd == "T":
            self._scroll_down(self._first_arg(args, 1))
        elif cmd == "s":
            self._saved_cursor = (self._state.cursor_x, self._state.cursor_y)
        elif cmd == "u":
            self._state.cursor_x, self._state.cursor_y = self._saved_cursor
        elif cmd == "r":
            top = self._first_arg(args, 0, 1) - 1
            bottom = self._first_arg(args, 1, self._rows) - 1
            self._state.set_scroll_region(top, bottom)
            self._state.set_cursor(0, 0)
        elif cmd == "m":
            self._handle_sgr(args)
        elif cmd == "l":
            self._reset_mode(args)
        elif cmd == "h":
            self._set_mode(args)
        elif cmd == "n":
            if self._first_arg(args, 0) == 6:
                return f"\x1b[{self._state.cursor_y + 1};{self._state.cursor_x + 1}R".encode()
        elif cmd == "t":
            self._handle_window_op(args)

        return None

    def _handle_osc(self, data: bytes) -> None:
        """Handle an Operating System Command sequence."""
        parsed = self._osc_parser.parse(b"\x1b]" + data)
        if parsed is None:
            return

        cmd = parsed.get("command", 0)
        text = parsed.get("text", "")

        if cmd == 0 or cmd == 2:
            self._state._icon_name = text
            self._state._title = text
            for cb in self._title_callbacks:
                try:
                    cb(text)
                except Exception:
                    pass
        elif cmd == 1:
            self._state._icon_name = text
        elif cmd == 2:
            self._state._title = text
            for cb in self._title_callbacks:
                try:
                    cb(text)
                except Exception:
                    pass
        elif cmd == 10:
            pass
        elif cmd == 11:
            pass
        elif cmd == 52:
            pass
        elif cmd == 104:
            pass
        elif cmd == 8:
            pass

    def _handle_ss3(self, data: bytes) -> None:
        """Handle a Single Shift 3 sequence (application keypad)."""
        pass

    def _handle_dcs(self, data: bytes) -> None:
        """Handle a Device Control String sequence."""
        pass

    def _handle_sgr(self, args: List[int]) -> None:
        """Handle Select Graphic Rendition parameters."""
        parsed = self._sgr_parser.parse(b"\x1b[" + b";".join(str(a).encode() for a in args) + b"m")
        if parsed:
            s = parsed.get("styles", {})
            self._state._bold = s.get("bold", self._state._bold)
            self._state._dim = s.get("dim", self._state._dim)
            self._state._italic = s.get("italic", self._state._italic)
            self._state._underline = s.get("underline", self._state._underline)
            self._state._blink = s.get("blink", self._state._blink)
            self._state._reverse = s.get("reverse", self._state._reverse)
            self._state._strikethrough = s.get("strikethrough", self._state._strikethrough)
            fg = s.get("fg_color")
            if fg is not None:
                self._state._fg_color = fg
            bg = s.get("bg_color")
            if bg is not None:
                self._state._bg_color = bg

    def _set_mode(self, args: List[int]):
        """Set terminal mode (sm)."""
        for arg in args:
            if arg == 4:
                self._state._insert_mode = True
            elif arg == 20:
                self._state._autowrap = True
            elif arg == 1049 or arg == 1047 or arg == 47:
                self._screen.switch_to_alternate()
            elif arg == 25:
                self._state.cursor_visible = True
            elif arg == 2004:
                self._state._bracketed_paste = True
            elif arg == 1000:
                self._state._mouse_mode = 1
            elif arg == 1002:
                self._state._mouse_mode = 2
            elif arg == 1003:
                self._state._mouse_mode = 3
            elif arg == 1006:
                self._state._mouse_encoding = 1006
            elif arg == 1015:
                self._state._mouse_encoding = 1015
            elif arg == 1:
                self._state._application_cursor = True
            elif arg == 6:
                self._state._origin_mode = True
            elif arg == 12:
                self._state._start_blinking = True
            elif arg == 66:
                self._state._application_keypad = True
            elif arg == 1004:
                self._state._focus_events = True

    def _reset_mode(self, args: List[int]):
        """Reset terminal mode (rm)."""
        for arg in args:
            if arg == 4:
                self._state._insert_mode = False
            elif arg == 20:
                self._state._autowrap = False
            elif arg == 1049 or arg == 1047 or arg == 47:
                self._screen.switch_to_primary()
            elif arg == 25:
                self._state.cursor_visible = False
            elif arg == 2004:
                self._state._bracketed_paste = False
            elif arg == 1000:
                self._state._mouse_mode = 0
            elif arg == 1002:
                self._state._mouse_mode = 0
            elif arg == 1003:
                self._state._mouse_mode = 0
            elif arg == 1006:
                self._state._mouse_encoding = 0
            elif arg == 1:
                self._state._application_cursor = False
            elif arg == 6:
                self._state._origin_mode = False
            elif arg == 66:
                self._state._application_keypad = False
            elif arg == 1004:
                self._state._focus_events = False

    def _handle_dec_private(self, data: bytes) -> Optional[bytes]:
        """Handle DEC private mode sequences."""
        return None

    def _handle_window_op(self, args: List[int]):
        """Handle CSI t window operations."""
        if not args:
            return
        op = args[0]
        if op == 4:
            if len(args) >= 3:
                h, w = args[1], args[2]
                self.resize(h, w)

    def _print_char(self, char: bytes):
        """Print a single character at the current cursor position."""
        try:
            c = char.decode("latin-1")
        except UnicodeDecodeError:
            c = "\ufffd"

        row = self._state.cursor_y
        col = self._state.cursor_x

        if row < 0 or row >= self._rows or col < 0:
            return

        if self._state._insert_mode:
            self._screen.write_at(row, col, c)
            self._move_right(col)
        else:
            self._screen.write_at(row, col, c)

        if self._state._autowrap:
            if col + 1 >= self._cols:
                if row + 1 >= self._scroll_bottom:
                    self._scroll_up(1)
                else:
                    self._state.cursor_y += 1
                self._state.cursor_x = 0
            else:
                self._state.cursor_x = col + 1

    def _carriage_return(self):
        self._state.carriage_return()

    def _linefeed(self):
        scroll_top, scroll_bottom = self._state.scroll_region
        if self._state.cursor_y >= scroll_bottom:
            self._scroll_up(1)
        else:
            self._state.cursor_y += 1

    def _backspace(self):
        self._state.move_cursor_left(1)

    def _tab(self):
        self._state.tab_forward(8)

    def _reverse_index(self):
        scroll_top, scroll_bottom = self._state.scroll_region
        if self._state.cursor_y <= scroll_top:
            self._scroll_down(1)
        else:
            self._state.cursor_y -= 1

    def _set_tab_stop(self):
        self._state.set_tab_stop()

    def _scroll_up(self, n: int = 1):
        scroll_top, scroll_bottom = self._state.scroll_region
        n = min(n, scroll_bottom - scroll_top + 1)
        for _ in range(n):
            self._screen.primary.scroll_up(scroll_top, scroll_bottom)
            self._screen.dirty.mark_lines(scroll_top, scroll_bottom)

    def _scroll_down(self, n: int = 1):
        scroll_top, scroll_bottom = self._state.scroll_region
        n = min(n, scroll_bottom - scroll_top + 1)
        for _ in range(n):
            self._screen.primary.scroll_down(scroll_top, scroll_bottom)
            self._screen.dirty.mark_lines(scroll_top, scroll_bottom)

    def _erase_display(self, mode: int = 0):
        """Erase portions of the display."""
        if mode == 0:
            for r in range(self._state.cursor_y, self._rows):
                for c in range(self._cols):
                    self._screen.write_at(r, c, " ")
                if r == self._state.cursor_y:
                    break
        elif mode == 1:
            for r in range(0, self._state.cursor_y + 1):
                start = 0 if r < self._state.cursor_y else 0
                end = self._cols if r < self._state.cursor_y else self._state.cursor_x + 1
                for c in range(start, end):
                    self._screen.write_at(r, c, " ")
        elif mode == 2 or mode == 3:
            for r in range(self._rows):
                for c in range(self._cols):
                    self._screen.write_at(r, c, " ")

    def _erase_line(self, mode: int = 0):
        """Erase portions of the current line."""
        row = self._state.cursor_y
        if mode == 0:
            for c in range(self._state.cursor_x, self._cols):
                self._screen.write_at(row, c, " ")
        elif mode == 1:
            for c in range(0, self._state.cursor_x + 1):
                self._screen.write_at(row, c, " ")
        elif mode == 2:
            for c in range(self._cols):
                self._screen.write_at(row, c, " ")

    def _insert_lines(self, n: int = 1):
        scroll_top, scroll_bottom = self._state.scroll_region
        row = self._state.cursor_y
        n = min(n, scroll_bottom - row + 1)
        for _ in range(n):
            self._screen.primary.insert_line(row, scroll_bottom)
            self._screen.dirty.mark_lines(row, scroll_bottom)

    def _delete_lines(self, n: int = 1):
        scroll_top, scroll_bottom = self._state.scroll_region
        row = self._state.cursor_y
        n = min(n, scroll_bottom - row + 1)
        for _ in range(n):
            self._screen.primary.delete_line(row, scroll_bottom)
            self._screen.dirty.mark_lines(row, scroll_bottom)

    def _delete_chars(self, n: int = 1):
        n = min(n, self._cols - self._state.cursor_x)
        row = self._state.cursor_y
        col = self._state.cursor_x
        self._screen.primary.delete_chars(row, col, n)
        self._screen.dirty.mark(row, col)

    def _insert_chars(self, n: int = 1):
        n = min(n, self._cols - self._state.cursor_x)
        row = self._state.cursor_y
        col = self._state.cursor_x
        self._screen.primary.insert_chars(row, col, n)
        self._screen.dirty.mark(row, col)

    def _erase_chars(self, n: int = 1):
        n = min(n, self._cols - self._state.cursor_x)
        row = self._state.cursor_y
        col = self._state.cursor_x
        for c in range(col, col + n):
            self._screen.write_at(row, c, " ")
        self._screen.dirty.mark(row, col)

    @property
    def _scroll_bottom(self) -> int:
        return self._state.scroll_region[1]

    def _move_right(self, col: int) -> None:
        pass

    @staticmethod
    def _first_arg(args: List[int], index: int, default: int = 0) -> int:
        return args[index] if index < len(args) and args[index] > 0 else default

    def close(self):
        """Clean up all emulator resources."""
        self.stop()
        self._screen.close()
        self._input_queue.clear()
        self._output_buffer.clear()
        self._input_callbacks.clear()
        self._output_callbacks.clear()
        self._resize_callbacks.clear()
        self._title_callbacks.clear()

    def __repr__(self) -> str:
        return (
            f"TerminalEmulator(rows={self._rows}, cols={self._cols}, "
            f"state={self._state})"
        )

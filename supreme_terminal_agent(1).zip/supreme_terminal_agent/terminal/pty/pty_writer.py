"""PtyWriter - writes data to a PTY master fd with queuing."""

import os
import threading
from collections import deque
from typing import Optional


class PtyWriter:
    """Writes data to a PTY master fd with an internal write queue."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd
        self._queue: deque = deque()
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def set_fd(self, fd: int):
        """Set the PTY fd to write to."""
        self.fd = fd

    def write(self, data: bytes) -> int:
        """Write data directly to the PTY fd."""
        if self.fd is None:
            raise RuntimeError("PtyWriter: no fd set")
        try:
            return os.write(self.fd, data)
        except OSError as e:
            raise RuntimeError(f"PtyWriter write error: {e}") from e

    def enqueue(self, data: bytes):
        """Enqueue data for background writing."""
        with self._lock:
            self._queue.append(data)

    def write_text(self, text: str):
        """Write text (encoded as utf-8) directly."""
        self.write(text.encode('utf-8', errors='replace'))

    def writeline(self, text: str):
        """Write text followed by newline."""
        self.write_text(text + '\n')

    def flush(self) -> int:
        """Write all queued data. Returns total bytes written."""
        total = 0
        with self._lock:
            while self._queue:
                data = self._queue.popleft()
                try:
                    total += os.write(self.fd, data)
                except OSError:
                    self._queue.appendleft(data)
                    break
        return total

    def start(self, interval: float = 0.01):
        """Start background writer thread."""
        if self._running or self.fd is None:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._write_loop, args=(interval,), daemon=True
        )
        self._thread.start()

    def stop(self):
        """Stop background writer thread."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None
        self.flush()

    def _write_loop(self, interval: float):
        """Background write loop."""
        while self._running:
            self.flush()
            threading.Event().wait(interval)

    @property
    def queue_size(self) -> int:
        with self._lock:
            return len(self._queue)

    def close(self):
        """Stop and release resources."""
        self.stop()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

"""PtyBuffer - ring buffer for PTY I/O data."""

import threading
from typing import Optional


class PtyBuffer:
    """A thread-safe ring buffer for PTY data."""

    def __init__(self, max_size: int = 1048576):
        self.max_size = max_size
        self._buffer = bytearray()
        self._lock = threading.RLock()
        self._read_event = threading.Event()

    def write(self, data: bytes) -> int:
        """Write data to the buffer. Returns bytes written."""
        with self._lock:
            self._buffer.extend(data)
            if len(self._buffer) > self.max_size:
                excess = len(self._buffer) - self.max_size
                self._buffer = self._buffer[excess:]
            self._read_event.set()
            return len(data)

    def read(self, size: int = -1) -> bytes:
        """Read data from the buffer."""
        with self._lock:
            if not self._buffer:
                return b''
            if size < 0 or size >= len(self._buffer):
                data = bytes(self._buffer)
                self._buffer.clear()
            else:
                data = bytes(self._buffer[:size])
                self._buffer = self._buffer[size:]
            return data

    def readline(self) -> Optional[bytes]:
        """Read a line from the buffer."""
        with self._lock:
            idx = self._buffer.find(b'\n')
            if idx < 0:
                return None
            line = bytes(self._buffer[:idx + 1])
            self._buffer = self._buffer[idx + 1:]
            return line

    def peek(self, size: int = -1) -> bytes:
        """Read data without removing it."""
        with self._lock:
            if size < 0 or size >= len(self._buffer):
                return bytes(self._buffer)
            return bytes(self._buffer[:size])

    def clear(self):
        """Clear the buffer."""
        with self._lock:
            self._buffer.clear()
            self._read_event.clear()

    def wait_for_data(self, timeout: Optional[float] = None) -> bool:
        """Wait until data is available. Returns True if data available."""
        if self._buffer:
            return True
        self._read_event.clear()
        return self._read_event.wait(timeout=timeout)

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._buffer)

    @property
    def available(self) -> int:
        with self._lock:
            return self.max_size - len(self._buffer)

    @property
    def is_full(self) -> bool:
        with self._lock:
            return len(self._buffer) >= self.max_size

    def __len__(self) -> int:
        return self.size

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()

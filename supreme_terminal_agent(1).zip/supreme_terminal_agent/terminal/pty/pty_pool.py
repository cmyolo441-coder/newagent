"""PtyPool - a pool of reusable PTY controller instances."""

import os
import pty
import threading
from typing import Dict, List, Optional, Tuple

from terminal.pty.pty_controller import PtyController


class PtyPool:
    """A pool of pre-spawned PTY controllers for fast allocation."""

    def __init__(self, min_size: int = 2, max_size: int = 32, shell: str = "/bin/bash"):
        self.min_size = min_size
        self.max_size = max_size
        self.shell = shell
        self._pool: List[PtyController] = []
        self._in_use: Dict[int, PtyController] = {}
        self._lock = threading.Lock()
        self._next_id = 0
        self._grow_lock = threading.Lock()

    def initialize(self):
        """Pre-populate the pool with minimum number of PTYs."""
        for _ in range(self.min_size):
            self._create_pty()

    def _create_pty(self) -> Optional[PtyController]:
        """Create a new PTY controller."""
        try:
            ctrl = PtyController(shell=self.shell)
            ctrl.spawn()
            return ctrl
        except (OSError, RuntimeError):
            return None

    def acquire(self) -> Tuple[int, PtyController]:
        """Acquire a PTY controller from the pool."""
        with self._lock:
            if not self._pool:
                with self._grow_lock:
                    if len(self._in_use) < self.max_size:
                        ctrl = self._create_pty()
                        if ctrl is None:
                            raise RuntimeError("Failed to create new PTY")
                    else:
                        raise RuntimeError("PTY pool exhausted")
            else:
                ctrl = self._pool.pop()
            pid = self._next_id
            self._next_id += 1
            self._in_use[pid] = ctrl
            return pid, ctrl

    def release(self, pid: int):
        """Return a PTY controller to the pool."""
        with self._lock:
            ctrl = self._in_use.pop(pid, None)
            if ctrl is None:
                return
            if not ctrl.is_alive():
                ctrl.close()
                new_ctrl = self._create_pty()
                if new_ctrl:
                    self._pool.append(new_ctrl)
            elif len(self._pool) < self.max_size:
                self._pool.append(ctrl)
            else:
                ctrl.close()

    def get(self, pid: int) -> Optional[PtyController]:
        """Get a PTY controller by its allocation ID."""
        with self._lock:
            return self._in_use.get(pid)

    @property
    def available_count(self) -> int:
        with self._lock:
            return len(self._pool)

    @property
    def in_use_count(self) -> int:
        with self._lock:
            return len(self._in_use)

    @property
    def total_count(self) -> int:
        return self.available_count + self.in_use_count

    def grow(self, count: int):
        """Grow the pool by adding more PTYs."""
        added = 0
        for _ in range(count):
            if self.total_count >= self.max_size:
                break
            ctrl = self._create_pty()
            if ctrl:
                with self._lock:
                    self._pool.append(ctrl)
                added += 1
        return added

    def shrink(self, count: int):
        """Shrink the pool by closing idle PTYs."""
        closed = 0
        with self._lock:
            while self._pool and closed < count:
                ctrl = self._pool.pop()
                ctrl.close()
                closed += 1
        return closed

    def close_all(self):
        """Close all PTYs in the pool."""
        with self._lock:
            for ctrl in self._pool:
                ctrl.close()
            self._pool.clear()
            for pid, ctrl in list(self._in_use.items()):
                ctrl.close()
            self._in_use.clear()

    def health_check(self) -> dict:
        """Check the health of all PTYs in the pool."""
        with self._lock:
            alive = 0
            dead = 0
            for ctrl in self._pool:
                if ctrl.is_alive():
                    alive += 1
                else:
                    dead += 1
            for ctrl in self._in_use.values():
                if ctrl.is_alive():
                    alive += 1
                else:
                    dead += 1
            return {'alive': alive, 'dead': dead, 'total': alive + dead}

    def __enter__(self):
        self.initialize()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close_all()

"""PtyController - high-level controller for PTY operations."""

import os
import pty
import select
import signal
import struct
import fcntl
import termios
import tty
from typing import Optional, Callable


class PtyController:
    """High-level controller for creating and managing PTY-based terminal sessions."""

    def __init__(self, shell: str = "/bin/bash", env: Optional[dict] = None):
        self.shell = shell
        self.env = env or os.environ.copy()
        self.master_fd: Optional[int] = None
        self.slave_fd: Optional[int] = None
        self.child_pid: Optional[int] = None
        self.rows = 24
        self.cols = 80

    def spawn(self, rows: int = 24, cols: int = 80) -> int:
        """Spawn a shell in a PTY. Returns the child PID."""
        self.rows = rows
        self.cols = cols
        self.master_fd, self.slave_fd = pty.openpty()
        self._set_winsize(rows, cols)
        pid = os.fork()
        if pid == 0:
            try:
                os.close(self.master_fd)
                os.setsid()
                os.dup2(self.slave_fd, 0)
                os.dup2(self.slave_fd, 1)
                os.dup2(self.slave_fd, 2)
                if self.slave_fd > 2:
                    os.close(self.slave_fd)
                self.env['TERM'] = self.env.get('TERM', 'xterm-256color')
                self.env['COLUMNS'] = str(cols)
                self.env['LINES'] = str(rows)
                os.execve(self.shell, [self.shell], self.env)
            except OSError:
                os._exit(1)
        else:
            self.child_pid = pid
            os.close(self.slave_fd)
            self.slave_fd = None
        return pid

    def _set_winsize(self, rows: int, cols: int):
        """Set terminal window size via ioctl."""
        if self.master_fd is not None:
            buf = struct.pack('HHHH', rows, cols, 0, 0)
            fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, buf)

    def resize(self, rows: int, cols: int):
        """Resize the terminal and send SIGWINCH to child."""
        self.rows = rows
        self.cols = cols
        self._set_winsize(rows, cols)
        if self.child_pid is not None:
            os.kill(self.child_pid, signal.SIGWINCH)

    def read(self, size: int = 4096) -> bytes:
        """Read output from the PTY."""
        if self.master_fd is None:
            raise RuntimeError("PTY not spawned")
        try:
            return os.read(self.master_fd, size)
        except OSError:
            return b''

    def write(self, data: bytes) -> int:
        """Write input to the PTY."""
        if self.master_fd is None:
            raise RuntimeError("PTY not spawned")
        return os.write(self.master_fd, data)

    def writeline(self, text: str):
        """Write a text line (with newline) to the PTY."""
        self.write((text + '\n').encode('utf-8', errors='replace'))

    def poll(self, timeout: float = 0.1) -> bool:
        """Check if data is available to read."""
        if self.master_fd is None:
            return False
        r, _, _ = select.select([self.master_fd], [], [], timeout)
        return len(r) > 0

    def is_alive(self) -> bool:
        """Check if the child process is still running."""
        if self.child_pid is None:
            return False
        try:
            pid, status = os.waitpid(self.child_pid, os.WNOHANG)
            if pid == self.child_pid:
                self.child_pid = None
                return False
            return True
        except ChildProcessError:
            return False

    def wait(self) -> int:
        """Wait for the child process to exit."""
        if self.child_pid is None:
            return -1
        _, status = os.waitpid(self.child_pid, 0)
        self.child_pid = None
        return status

    def close(self):
        """Close the PTY and kill child if running."""
        if self.child_pid is not None:
            try:
                os.kill(self.child_pid, signal.SIGHUP)
                os.waitpid(self.child_pid, os.WNOHANG)
            except (OSError, ChildProcessError):
                pass
            self.child_pid = None
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None
        if self.slave_fd is not None:
            try:
                os.close(self.slave_fd)
            except OSError:
                pass
            self.slave_fd = None

    def fileno(self) -> int:
        """Return master fd for async IO."""
        if self.master_fd is None:
            raise RuntimeError("PTY not spawned")
        return self.master_fd

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

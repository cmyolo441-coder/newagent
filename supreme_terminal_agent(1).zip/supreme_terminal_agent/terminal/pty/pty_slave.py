"""PtySlave - manages the slave side of a pseudo-terminal."""

import os
import pty
import tty
import termios
from typing import Optional


class PtySlave:
    """Manages the slave end of a pseudo-terminal."""

    def __init__(self):
        self.slave_fd: Optional[int] = None
        self.slave_name: Optional[str] = None

    def open(self, master_fd: int) -> int:
        """Get the slave fd from the master. Returns the slave fd."""
        self.slave_fd = pty.openpty()[1]
        self.slave_name = os.ttyname(self.slave_fd)
        return self.slave_fd

    def set_raw(self):
        """Set the slave to raw mode."""
        if self.slave_fd is not None:
            tty.setraw(self.slave_fd)

    def set_cbreak(self):
        """Set the slave to cbreak mode."""
        if self.slave_fd is not None:
            tty.setcbreak(self.slave_fd)

    def get_attrs(self):
        """Get terminal attributes."""
        if self.slave_fd is None:
            raise RuntimeError("PtySlave not opened")
        return termios.tcgetattr(self.slave_fd)

    def set_attrs(self, attrs):
        """Set terminal attributes."""
        if self.slave_fd is None:
            raise RuntimeError("PtySlave not opened")
        termios.tcsetattr(self.slave_fd, termios.TCSANOW, attrs)

    def close(self):
        """Close the slave fd."""
        if self.slave_fd is not None:
            try:
                os.close(self.slave_fd)
            except OSError:
                pass
            self.slave_fd = None

    def get_name(self) -> Optional[str]:
        """Get the slave device name."""
        return self.slave_name

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

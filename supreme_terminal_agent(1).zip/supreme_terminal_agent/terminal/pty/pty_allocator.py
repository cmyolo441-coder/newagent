"""PtyAllocator - manages allocation and deallocation of PTY resources."""

import os
import pty
import threading
from typing import Dict, List, Optional, Tuple


class PtyAllocator:
    """Allocates and tracks pseudo-terminal resources across the system."""

    MAX_PTYS = 512

    def __init__(self):
        self._lock = threading.Lock()
        self._allocated: Dict[int, dict] = {}
        self._next_id = 0

    def allocate(self, rows: int = 24, cols: int = 80) -> Tuple[int, int, int]:
        """Allocate a new PTY. Returns (alloc_id, master_fd, slave_fd)."""
        with self._lock:
            if len(self._allocated) >= self.MAX_PTYS:
                raise RuntimeError(f"Maximum number of PTYs ({self.MAX_PTYS}) reached")
            master_fd, slave_fd = pty.openpty()
            alloc_id = self._next_id
            self._next_id += 1
            self._allocated[alloc_id] = {
                'master_fd': master_fd,
                'slave_fd': slave_fd,
                'slave_name': os.ttyname(slave_fd),
                'rows': rows,
                'cols': cols,
            }
            return alloc_id, master_fd, slave_fd

    def release(self, alloc_id: int) -> bool:
        """Release a PTY allocation by ID."""
        with self._lock:
            entry = self._allocated.pop(alloc_id, None)
            if entry is None:
                return False
            try:
                os.close(entry['master_fd'])
            except OSError:
                pass
            try:
                os.close(entry['slave_fd'])
            except OSError:
                pass
            return True

    def release_by_fd(self, fd: int) -> bool:
        """Release a PTY by file descriptor."""
        with self._lock:
            for alloc_id, entry in list(self._allocated.items()):
                if entry['master_fd'] == fd or entry['slave_fd'] == fd:
                    return self.release(alloc_id)
            return False

    def get(self, alloc_id: int) -> Optional[dict]:
        """Get info about an allocated PTY."""
        with self._lock:
            return self._allocated.get(alloc_id)

    def list_active(self) -> List[dict]:
        """List all active PTY allocations."""
        with self._lock:
            return [
                {'id': aid, **info}
                for aid, info in self._allocated.items()
            ]

    @property
    def count(self) -> int:
        """Return number of active PTY allocations."""
        with self._lock:
            return len(self._allocated)

    @property
    def available(self) -> int:
        """Return number of available PTY slots."""
        return self.MAX_PTYS - self.count

    def release_all(self):
        """Release all allocated PTYs."""
        with self._lock:
            for alloc_id in list(self._allocated.keys()):
                self.release(alloc_id)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release_all()

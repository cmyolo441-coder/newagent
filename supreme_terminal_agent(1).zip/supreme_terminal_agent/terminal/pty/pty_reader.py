"""PtyReader - reads data from PTY master fd into a buffer."""

import os
import select
import threading
from typing import Callable, Optional

from terminal.pty.pty_buffer import PtyBuffer


class PtyReader:
    """Reads data from a PTY master fd with buffering."""

    def __init__(self, fd: Optional[int] = None, buffer_size: int = 4096):
        self.fd = fd
        self.buffer = PtyBuffer(max_size=buffer_size * 64)
        self._chunk_size = buffer_size
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._on_data: Optional[Callable[[bytes], None]] = None
        self._lock = threading.Lock()

    def set_fd(self, fd: int):
        """Set the PTY fd to read from."""
        self.fd = fd

    def set_callback(self, callback: Callable[[bytes], None]):
        """Set a callback for each chunk read."""
        self._on_data = callback

    def read_once(self) -> bytes:
        """Perform a single non-blocking read."""
        if self.fd is None:
            return b''
        try:
            r, _, _ = select.select([self.fd], [], [], 0.0)
            if r:
                data = os.read(self.fd, self._chunk_size)
                if data:
                    self.buffer.write(data)
                    if self._on_data:
                        self._on_data(data)
                    return data
        except (OSError, ValueError):
            pass
        return b''

    def start(self):
        """Start continuous reading in a background thread."""
        if self._running or self.fd is None:
            return
        self._running = True
        self._thread = threading.Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop background reading."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None

    def _read_loop(self):
        """Background read loop."""
        while self._running:
            try:
                r, _, _ = select.select([self.fd], [], [], 0.1)
                if r:
                    data = os.read(self.fd, self._chunk_size)
                    if data:
                        self.buffer.write(data)
                        if self._on_data:
                            self._on_data(data)
                    else:
                        break
            except (OSError, ValueError):
                break

    def read_available(self) -> bytes:
        """Read all available data at once."""
        result = bytearray()
        while True:
            chunk = self.read_once()
            if not chunk:
                break
            result.extend(chunk)
        return bytes(result)

    def close(self):
        """Stop reading and clear buffer."""
        self.stop()
        self.buffer.clear()

    @property
    def is_running(self) -> bool:
        return self._running

"""PtySignalHandler - manages signal forwarding and handling for PTY processes."""

import os
import signal
import threading
from typing import Callable, Dict, Optional, Set


class PtySignalHandler:
    """Handles and forwards signals between the agent and PTY child processes."""

    _SIGNAL_MAP = {
        signal.SIGINT: 'SIGINT',
        signal.SIGTERM: 'SIGTERM',
        signal.SIGHUP: 'SIGHUP',
        signal.SIGQUIT: 'SIGQUIT',
        signal.SIGWINCH: 'SIGWINCH',
        signal.SIGCONT: 'SIGCONT',
        signal.SIGTSTP: 'SIGTSTP',
        signal.SIGTTIN: 'SIGTTIN',
        signal.SIGTTOU: 'SIGTTOU',
    }

    def __init__(self):
        self._children: Dict[int, Set[int]] = {}  # group_id -> {pid_set}
        self._handlers: Dict[int, Callable] = {}
        self._original_handlers: Dict[int, Optional[Callable]] = {}
        self._lock = threading.Lock()
        self._installed = False

    def install(self):
        """Install signal handlers for forwarding."""
        if self._installed:
            return
        with self._lock:
            for signum in self._SIGNAL_MAP:
                self._original_handlers[signum] = signal.getsignal(signum)
                signal.signal(signum, self._make_handler(signum))
            self._installed = True

    def _make_handler(self, signum: int):
        """Create a signal handler function for a given signal number."""
        def handler(frame, signum=signum):
            self._forward_signal(signum)
            original = self._original_handlers.get(signum)
            if original and original != signal.SIG_DFL and original != signal.SIG_IGN:
                if callable(original):
                    original(frame, signum)
        return handler

    def uninstall(self):
        """Restore original signal handlers."""
        if not self._installed:
            return
        with self._lock:
            for signum, handler in self._original_handlers.items():
                if handler is not None:
                    signal.signal(signum, handler)
            self._original_handlers.clear()
            self._installed = False

    def register_child(self, pid: int, group_id: int = 0):
        """Register a child PID for signal forwarding."""
        with self._lock:
            if group_id not in self._children:
                self._children[group_id] = set()
            self._children[group_id].add(pid)

    def unregister_child(self, pid: int, group_id: int = 0):
        """Unregister a child PID."""
        with self._lock:
            if group_id in self._children:
                self._children[group_id].discard(pid)

    def register_handler(self, signum: int, handler: Callable):
        """Register a custom signal handler."""
        with self._lock:
            self._handlers[signum] = handler

    def _forward_signal(self, signum: int):
        """Forward a signal to all registered child processes."""
        with self._lock:
            handler = self._handlers.get(signum)
            if handler:
                handler(signum)
            for group_id, pids in self._children.items():
                for pid in list(pids):
                    try:
                        os.kill(pid, signum)
                    except OSError:
                        pass

    def forward_to(self, pid: int, signum: int):
        """Forward a specific signal to a specific PID."""
        try:
            os.kill(pid, signum)
        except OSError:
            pass

    def forward_to_group(self, group_id: int, signum: int):
        """Forward a signal to all PIDs in a group."""
        with self._lock:
            pids = self._children.get(group_id, set())
            for pid in list(pids):
                try:
                    os.kill(pid, signum)
                except OSError:
                    pass

    def clear(self):
        """Unregister all children."""
        with self._lock:
            self._children.clear()

    @property
    def child_count(self) -> int:
        with self._lock:
            return sum(len(pids) for pids in self._children.values())

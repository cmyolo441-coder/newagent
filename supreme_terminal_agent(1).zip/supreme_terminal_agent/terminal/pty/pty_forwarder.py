"""PtyForwarder - forwards PTY data between sources and destinations."""

import os
import select
import threading
from typing import Callable, Dict, List, Optional, Tuple


class PtyForwarder:
    """Forwards data between PTY fds and external I/O streams."""

    def __init__(self):
        self._pairs: List[Dict] = []
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def add_pair(self, src_fd: int, dst_fd: int, bidirectional: bool = True):
        """Add a forwarding pair. Optionally bidirectional."""
        with self._lock:
            self._pairs.append({
                'src': src_fd,
                'dst': dst_fd,
                'bidirectional': bidirectional,
            })

    def remove_pair(self, src_fd: int, dst_fd: int):
        """Remove a forwarding pair."""
        with self._lock:
            self._pairs = [
                p for p in self._pairs
                if not (p['src'] == src_fd and p['dst'] == dst_fd)
            ]

    def remove_by_fd(self, fd: int):
        """Remove all pairs involving the given fd."""
        with self._lock:
            self._pairs = [
                p for p in self._pairs
                if p['src'] != fd and p['dst'] != fd
            ]

    def forward_once(self, timeout: float = 0.1) -> int:
        """Perform one round of forwarding. Returns bytes forwarded."""
        with self._lock:
            pairs = list(self._pairs)
        if not pairs:
            return 0
        read_fds = [p['src'] for p in pairs]
        if any(p['bidirectional'] for p in pairs):
            read_fds.extend([p['dst'] for p in pairs if p['bidirectional']])
        try:
            r, _, _ = select.select(read_fds, [], [], timeout)
        except (ValueError, OSError):
            return 0
        total = 0
        for pair in pairs:
            if pair['src'] in r:
                try:
                    data = os.read(pair['src'], 4096)
                    if data:
                        os.write(pair['dst'], data)
                        total += len(data)
                except OSError:
                    pass
            if pair['bidirectional'] and pair['dst'] in r:
                try:
                    data = os.read(pair['dst'], 4096)
                    if data:
                        os.write(pair['src'], data)
                        total += len(data)
                except OSError:
                    pass
        return total

    def start(self, interval: float = 0.05):
        """Start forwarding in a background thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, args=(interval,), daemon=True)
        self._thread.start()

    def stop(self):
        """Stop the forwarding loop."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None

    def _run_loop(self, interval: float):
        """Background forwarding loop."""
        while self._running:
            self.forward_once(timeout=interval)

    def clear(self):
        """Remove all forwarding pairs."""
        with self._lock:
            self._pairs.clear()

"""PtyRecorder - records PTY I/O data to a file or buffer."""

import os
import time
import threading
from typing import Optional


class PtyRecorder:
    """Records PTY input/output data for later replay or analysis."""

    def __init__(self, filepath: Optional[str] = None):
        self.filepath = filepath
        self._file: Optional[object] = None
        self._lock = threading.Lock()
        self._buffer: list = []
        self._recording = False
        self._start_time = 0.0

    def start(self, filepath: Optional[str] = None):
        """Start recording. Optionally specify a file path."""
        with self._lock:
            self._buffer = []
            self._start_time = time.time()
            self._recording = True
            if filepath:
                self.filepath = filepath
            if self.filepath:
                self._file = open(self.filepath, 'wb')
                self._write_header()

    def _write_header(self):
        """Write recording header metadata."""
        if self._file:
            header = f"# PTY Recording\n# Started: {time.ctime(self._start_time)}\n# Format: timestamp,direction,data\n".encode()
            self._file.write(header)

    def record_input(self, data: bytes):
        """Record input (data written to PTY)."""
        if not self._recording:
            return
        timestamp = time.time() - self._start_time
        entry = (timestamp, 'in', data)
        with self._lock:
            self._buffer.append(entry)
            if self._file:
                line = f"{timestamp:.6f},IN,{data.hex()}\n".encode()
                self._file.write(line)
                self._file.flush()

    def record_output(self, data: bytes):
        """Record output (data read from PTY)."""
        if not self._recording:
            return
        timestamp = time.time() - self._start_time
        entry = (timestamp, 'out', data)
        with self._lock:
            self._buffer.append(entry)
            if self._file:
                line = f"{timestamp:.6f},OUT,{data.hex()}\n".encode()
                self._file.write(line)
                self._file.flush()

    def stop(self) -> list:
        """Stop recording and return captured data."""
        with self._lock:
            self._recording = False
            if self._file:
                self._file.close()
                self._file = None
            result = list(self._buffer)
            return result

    def get_buffer(self) -> list:
        """Get the current recording buffer without stopping."""
        with self._lock:
            return list(self._buffer)

    def clear(self):
        """Clear the recording buffer."""
        with self._lock:
            self._buffer.clear()

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def duration(self) -> float:
        """Return recording duration so far."""
        if not self._start_time:
            return 0.0
        return time.time() - self._start_time

    def close(self):
        """Stop recording and release resources."""
        self.stop()

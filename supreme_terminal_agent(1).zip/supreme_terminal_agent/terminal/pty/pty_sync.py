"""PtySync - synchronization primitives for PTY operations."""

import os
import select
import threading
import time
from typing import Callable, List, Optional


class PtySync:
    """Synchronization helpers for coordinating PTY reads and writes."""

    def __init__(self):
        self._lock = threading.RLock()
        self._read_event = threading.Event()
        self._write_event = threading.Event()
        self._error_event = threading.Event()
        self._waiters: List[dict] = []

    def notify_read(self):
        """Signal that data is available for reading."""
        self._read_event.set()

    def notify_write(self):
        """Signal that write completed."""
        self._write_event.set()

    def notify_error(self):
        """Signal an error condition."""
        self._error_event.set()

    def wait_read(self, timeout: Optional[float] = None) -> bool:
        """Wait for read availability."""
        self._read_event.clear()
        return self._read_event.wait(timeout=timeout)

    def wait_write(self, timeout: Optional[float] = None) -> bool:
        """Wait for write availability."""
        self._write_event.clear()
        return self._write_event.wait(timeout=timeout)

    def wait_any(self, timeout: Optional[float] = None) -> str:
        """Wait for any event. Returns 'read', 'write', or 'timeout'."""
        events = {
            self._read_event: 'read',
            self._write_event: 'write',
            self._error_event: 'error',
        }
        self._read_event.clear()
        self._write_event.clear()
        self._error_event.clear()
        for event, name in events.items():
            if event.is_set():
                return name
        if timeout is not None:
            deadline = time.time() + timeout
            while time.time() < deadline:
                for event, name in events.items():
                    if event.is_set():
                        return name
                time.sleep(0.01)
            return 'timeout'
        self._read_event.wait()
        return 'read'

    def add_waiter(self, condition: Callable[[], bool], callback: Callable[[], None]):
        """Add a conditional waiter that triggers callback when condition is met."""
        with self._lock:
            self._waiters.append({'condition': condition, 'callback': callback})

    def check_waiters(self):
        """Check and fire any pending waiters whose conditions are met."""
        with self._lock:
            for waiter in self._waiters:
                if waiter['condition']():
                    waiter['callback']()
            self._waiters = [
                w for w in self._waiters
                if not w['condition']()
            ]

    def synchronized(self, fn: Callable, *args, **kwargs):
        """Execute a function under the internal lock."""
        with self._lock:
            return fn(*args, **kwargs)

    def clear(self):
        """Reset all events."""
        self._read_event.clear()
        self._write_event.clear()
        self._error_event.clear()
        with self._lock:
            self._waiters.clear()

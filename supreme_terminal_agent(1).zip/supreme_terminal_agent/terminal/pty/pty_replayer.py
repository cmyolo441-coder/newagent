"""PtyReplayer - replays recorded PTY sessions."""

import os
import time
import threading
from typing import Callable, List, Optional, Tuple


class PtyReplayer:
    """Replays previously recorded PTY sessions."""

    def __init__(self):
        self._entries: List[Tuple[float, str, bytes]] = []
        self._playing = False
        self._thread: Optional[threading.Thread] = None
        self._on_output: Optional[Callable[[bytes], None]] = None

    def load_file(self, filepath: str):
        """Load a recording from a file."""
        self._entries = []
        with open(filepath, 'rb') as f:
            for line in f:
                line = line.strip()
                if line.startswith(b'#') or not line:
                    continue
                try:
                    parts = line.split(b',', 2)
                    if len(parts) == 3:
                        timestamp = float(parts[0])
                        direction = parts[1].decode()
                        data = bytes.fromhex(parts[2].decode())
                    self._entries.append((timestamp, direction, data))
                except (ValueError, IndexError):
                    continue

    def load_buffer(self, entries: List[Tuple[float, str, bytes]]):
        """Load entries from an in-memory buffer."""
        self._entries = sorted(entries, key=lambda x: x[0])

    def set_output_callback(self, callback: Callable[[bytes], None]):
        """Set callback for output data during replay."""
        self._on_output = callback

    def play(self, speed: float = 1.0, repeat: bool = False):
        """Play back the recorded session."""
        if self._playing or not self._entries:
            return
        self._playing = True
        start_time = time.time()
        session_start = self._entries[0][0] if self._entries else 0
        index = 0
        while self._playing and index < len(self._entries):
            timestamp, direction, data = self._entries[index]
            elapsed = time.time() - start_time
            target_delay = (timestamp - session_start) / speed
            if target_delay > elapsed:
                time.sleep(min(target_delay - elapsed, 0.1))
                continue
            if direction == 'out' and self._on_output:
                self._on_output(data)
            index += 1
            if index >= len(self._entries) and repeat:
                index = 0
                start_time = time.time()
        self._playing = False

    def start(self, speed: float = 1.0, repeat: bool = False):
        """Start replay in a background thread."""
        if self._playing:
            return
        self._thread = threading.Thread(
            target=self.play, args=(speed, repeat), daemon=True
        )
        self._thread.start()

    def stop(self):
        """Stop playback."""
        self._playing = False
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None

    @property
    def is_playing(self) -> bool:
        return self._playing

    @property
    def entry_count(self) -> int:
        return len(self._entries)

    @property
    def total_duration(self) -> float:
        if len(self._entries) < 2:
            return 0.0
        return self._entries[-1][0] - self._entries[0][0]

    def clear(self):
        """Clear loaded entries."""
        self._entries.clear()

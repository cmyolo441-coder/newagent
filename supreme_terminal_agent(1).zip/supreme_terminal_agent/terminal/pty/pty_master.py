"""PtyMaster - manages the master side of a pseudo-terminal."""

import os
import pty
import fcntl
import termios
import signal
import struct
from typing import Optional


class PtyMaster:
    """Manages the master end of a pseudo-terminal."""

    def __init__(self, rows: int = 24, cols: int = 80):
        self.master_fd: Optional[int] = None
        self.slave_fd: Optional[int] = None
        self.slave_name: Optional[str] = None
        self.rows = rows
        self.cols = cols
        self._child_pid: Optional[int] = None

    def open(self) -> tuple[int, int]:
        """Open a new pseudo-terminal. Returns (master_fd, slave_fd)."""
        self.master_fd, self.slave_fd = pty.openpty()
        self.slave_name = os.ttyname(self.slave_fd)
        self._set_winsize(self.rows, self.cols)
        return self.master_fd, self.slave_fd

    def _set_winsize(self, rows: int, cols: int):
        """Set the terminal window size."""
        if self.master_fd is not None:
            buf = struct.pack('HHHH', rows, cols, 0, 0)
            fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, buf)

    def resize(self, rows: int, cols: int):
        """Resize the pseudo-terminal."""
        self.rows = rows
        self.cols = cols
        self._set_winsize(rows, cols)
        if self._child_pid:
            os.kill(self._child_pid, signal.SIGWINCH)

    def read(self, size: int = 4096) -> bytes:
        """Read data from the master fd."""
        if self.master_fd is None:
            raise RuntimeError("PtyMaster not opened")
        try:
            return os.read(self.master_fd, size)
        except OSError:
            return b''

    def write(self, data: bytes) -> int:
        """Write data to the master fd."""
        if self.master_fd is None:
            raise RuntimeError("PtyMaster not opened")
        return os.write(self.master_fd, data)

    def fileno(self) -> int:
        """Return the master fd for use in select loops."""
        if self.master_fd is None:
            raise RuntimeError("PtyMaster not opened")
        return self.master_fd

    def close(self):
        """Close the master fd."""
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None
        if self.slave_fd is not None:
            try:
                os.close(self.slave_fd)
            except OSError:
                pass
            self.slave_fd = None

"""PtyMultiplexer - multiplexes multiple PTY I/O streams."""

import os
import select
import threading
from typing import Callable, Dict, List, Optional


class PtyMultiplexer:
    """Multiplexes multiple PTY master file descriptors for concurrent I/O."""

    def __init__(self):
        self._fds: Dict[int, dict] = {}
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def register(self, fd: int, callback: Optional[Callable[[bytes], None]] = None, name: str = ""):
        """Register a PTY fd for multiplexing."""
        with self._lock:
            self._fds[fd] = {'callback': callback, 'name': name, 'buffer': b''}

    def unregister(self, fd: int):
        """Unregister a PTY fd."""
        with self._lock:
            self._fds.pop(fd, None)

    def set_callback(self, fd: int, callback: Callable[[bytes], None]):
        """Set or update the read callback for a fd."""
        with self._lock:
            if fd in self._fds:
                self._fds[fd]['callback'] = callback

    def write_all(self, data: bytes):
        """Write data to all registered PTY fds."""
        with self._lock:
            for fd in self._fds:
                try:
                    os.write(fd, data)
                except OSError:
                    pass

    def write_to(self, fd: int, data: bytes) -> int:
        """Write data to a specific PTY fd."""
        try:
            return os.write(fd, data)
        except OSError:
            return -1

    def poll(self, timeout: float = 0.1) -> Dict[int, bytes]:
        """Poll all registered fds for readable data."""
        with self._lock:
            fds = list(self._fds.keys())
        if not fds:
            return {}
        r, _, _ = select.select(fds, [], [], timeout)
        result = {}
        for fd in r:
            try:
                data = os.read(fd, 4096)
                if data:
                    result[fd] = data
                    with self._lock:
                        entry = self._fds.get(fd)
                        if entry and entry['callback']:
                            entry['callback'](data)
            except OSError:
                pass
        return result

    def start(self, interval: float = 0.05):
        """Start the multiplexer polling loop in a background thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, args=(interval,), daemon=True)
        self._thread.start()

    def stop(self):
        """Stop the multiplexer polling loop."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None

    def _run_loop(self, interval: float):
        """Background polling loop."""
        while self._running:
            self.poll(timeout=interval)

    @property
    def active_fds(self) -> List[int]:
        """Return list of active file descriptors."""
        with self._lock:
            return list(self._fds.keys())

    @property
    def active_count(self) -> int:
        """Return number of registered PTYs."""
        with self._lock:
            return len(self._fds)

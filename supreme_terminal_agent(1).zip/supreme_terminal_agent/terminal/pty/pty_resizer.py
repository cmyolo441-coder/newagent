"""PtyResizer - handles terminal window resizing for PTYs."""

import os
import signal
import struct
import fcntl
import termios
import threading
from typing import Dict, Optional


class PtyResizer:
    """Manages terminal window size changes for PTY master fds."""

    def __init__(self):
        self._windows: Dict[int, dict] = {}
        self._lock = threading.Lock()

    def register(self, fd: int, child_pid: Optional[int] = None, rows: int = 24, cols: int = 80):
        """Register a PTY fd for resize tracking."""
        with self._lock:
            self._windows[fd] = {
                'child_pid': child_pid,
                'rows': rows,
                'cols': cols,
            }

    def unregister(self, fd: int):
        """Unregister a PTY fd."""
        with self._lock:
            self._windows.pop(fd, None)

    def resize(self, fd: int, rows: int, cols: int) -> bool:
        """Resize a specific PTY fd."""
        with self._lock:
            entry = self._windows.get(fd)
            if entry is None:
                return False
            entry['rows'] = rows
            entry['cols'] = cols
            buf = struct.pack('HHHH', rows, cols, 0, 0)
            try:
                fcntl.ioctl(fd, termios.TIOCSWINSZ, buf)
            except OSError:
                return False
            if entry['child_pid'] is not None:
                try:
                    os.kill(entry['child_pid'], signal.SIGWINCH)
                except OSError:
                    pass
            return True

    def get_size(self, fd: int) -> Optional[tuple]:
        """Get the current size of a registered fd."""
        with self._lock:
            entry = self._windows.get(fd)
            if entry is None:
                return None
            return (entry['rows'], entry['cols'])

    def resize_all(self, rows: int, cols: int):
        """Resize all registered PTYs."""
        with self._lock:
            for fd in list(self._windows.keys()):
                self.resize(fd, rows, cols)

    def handle_sigwinch(self, fd: int):
        """Handle SIGWINCH by re-reading terminal size."""
        try:
            import array
            buf = array.array('H', [0, 0, 0, 0])
            fcntl.ioctl(fd, termios.TIOCGWINSZ, buf, True)
            rows, cols = buf[0], buf[1]
            if rows > 0 and cols > 0:
                self.resize(fd, rows, cols)
        except (OSError, ImportError):
            pass

    @property
    def count(self) -> int:
        with self._lock:
            return len(self._windows)

    def clear(self):
        """Unregister all tracked PTYs."""
        with self._lock:
            self._windows.clear()

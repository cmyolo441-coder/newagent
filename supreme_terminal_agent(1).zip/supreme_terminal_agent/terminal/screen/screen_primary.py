"""ScreenPrimary - the primary screen buffer."""

from terminal.screen.screen_buffer import ScreenBuffer


class ScreenPrimary(ScreenBuffer):
    """Primary screen buffer (the default visible screen)."""

    def __init__(self, rows: int = 24, cols: int = 80):
        super().__init__(rows, cols)
        self._scrollback_lines: list = []
        self._max_scrollback = 10000

    def save_scrollback(self):
        """Move lines off-screen into scrollback history."""
        pass

    def _scroll_up(self):
        if self._lines:
            line = self._lines.pop(0)
            self._scrollback_lines.append(line)
            if len(self._scrollback_lines) > self._max_scrollback:
                self._scrollback_lines.pop(0)
        self._lines.append(self._create_line())

    def _create_line(self):
        from terminal.screen.screen_line import ScreenLine
        return ScreenLine(self.cols)

    @property
    def scrollback(self) -> list:
        return list(self._scrollback_lines)

    def get_scrollback_text(self, max_lines: int = -1) -> str:
        lines = self._scrollback_lines
        if max_lines > 0:
            lines = lines[-max_lines:]
        return '\n'.join(line.text for line in lines)

    def clear_scrollback(self):
        self._scrollback_lines.clear()

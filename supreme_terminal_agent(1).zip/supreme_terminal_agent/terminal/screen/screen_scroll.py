"""ScreenScroll - handles scrolling regions and scroll behavior."""

from typing import Optional, Tuple


class ScreenScroll:
    """Manages scroll regions and scrolling behavior on the screen."""

    def __init__(self):
        self._scroll_region: Optional[Tuple[int, int]] = None
        self._scroll_speed: int = 1
        self._smooth_scroll: bool = False
        self._autoscroll: bool = True

    def set_scroll_region(self, top: int, bottom: int):
        """Set the scroll region (top and bottom lines, inclusive)."""
        self._scroll_region = (top, bottom)

    def clear_scroll_region(self):
        self._scroll_region = None

    @property
    def scroll_region(self) -> Optional[Tuple[int, int]]:
        return self._scroll_region

    @property
    def has_scroll_region(self) -> bool:
        return self._scroll_region is not None

    def set_speed(self, speed: int):
        self._scroll_speed = max(1, speed)

    @property
    def scroll_speed(self) -> int:
        return self._scroll_speed

    def enable_smooth_scroll(self):
        self._smooth_scroll = True

    def disable_smooth_scroll(self):
        self._smooth_scroll = False

    @property
    def smooth_scroll(self) -> bool:
        return self._smooth_scroll

    def enable_autoscroll(self):
        self._autoscroll = True

    def disable_autoscroll(self):
        self._autoscroll = False

    @property
    def autoscroll(self) -> bool:
        return self._autoscroll

    def scroll_up(self, n: int = 1):
        pass

    def scroll_down(self, n: int = 1):
        pass

    def reset(self):
        self._scroll_region = None
        self._scroll_speed = 1
        self._smooth_scroll = False
        self._autoscroll = True

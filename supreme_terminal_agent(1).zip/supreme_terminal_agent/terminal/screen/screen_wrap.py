"""ScreenWrap - handles line wrapping behavior on the screen."""

from typing import List, Optional, Set


class ScreenWrap:
    """Manages line wrapping mode and behavior."""

    def __init__(self):
        self._auto_wrap: bool = True
        self._wrap_at: int = 80
        self._word_wrap: bool = False
        self._reverse_wrap: bool = False

    def enable_auto_wrap(self):
        self._auto_wrap = True

    def disable_auto_wrap(self):
        self._auto_wrap = False

    @property
    def auto_wrap(self) -> bool:
        return self._auto_wrap

    @auto_wrap.setter
    def auto_wrap(self, value: bool):
        self._auto_wrap = value

    def enable_word_wrap(self):
        self._word_wrap = True

    def disable_word_wrap(self):
        self._word_wrap = False

    @property
    def word_wrap(self) -> bool:
        return self._word_wrap

    @property
    def wrap_at(self) -> int:
        return self._wrap_at

    @wrap_at.setter
    def wrap_at(self, value: int):
        self._wrap_at = max(1, value)

    def enable_reverse_wrap(self):
        self._reverse_wrap = True

    def disable_reverse_wrap(self):
        self._reverse_wrap = False

    @property
    def reverse_wrap(self) -> bool:
        return self._reverse_wrap

    def wrap_text(self, text: str, cols: Optional[int] = None) -> List[str]:
        """Wrap text according to current settings."""
        width = cols or self._wrap_at
        if self._word_wrap:
            return self._word_wrap_text(text, width)
        return self._char_wrap_text(text, width)

    def _char_wrap_text(self, text: str, width: int) -> List[str]:
        lines = []
        for i in range(0, len(text), width):
            lines.append(text[i:i + width])
        return lines

    def _word_wrap_text(self, text: str, width: int) -> List[str]:
        words = text.split()
        lines = []
        current = ""
        for word in words:
            if current and len(current) + 1 + len(word) > width:
                lines.append(current)
                current = word
            elif current:
                current += " " + word
            else:
                current = word
        if current:
            lines.append(current)
        return lines if lines else [text]

    def reset(self):
        self._auto_wrap = True
        self._wrap_at = 80
        self._word_wrap = False
        self._reverse_wrap = False

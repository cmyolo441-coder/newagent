"""ScreenDiff - computes differences between screen states."""

from __future__ import annotations

import difflib
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from terminal.screen.screen_manager import ScreenManager


class ScreenDiff:
    """Computes and tracks differences between screen states."""

    def __init__(self, manager: ScreenManager):
        self.manager = manager
        self._previous: Optional[str] = None

    def snapshot(self):
        """Save current screen state as baseline."""
        self._previous = self.manager.get_visible_text()

    def diff(self) -> str:
        """Compute diff from the saved snapshot."""
        current = self.manager.get_visible_text()
        if self._previous is None:
            self._previous = current
            return ""
        if current == self._previous:
            return ""
        diff_lines = difflib.unified_diff(
            self._previous.splitlines(keepends=True),
            current.splitlines(keepends=True),
            fromfile='previous',
            tofile='current',
        )
        return ''.join(diff_lines)

    def diff_lines(self) -> List[Tuple[str, str]]:
        """Get per-line differences as (status, line) pairs."""
        current = self.manager.get_visible_text()
        if self._previous is None:
            self._previous = current
            return []
        prev_lines = self._previous.splitlines()
        curr_lines = current.splitlines()
        result = []
        matcher = difflib.SequenceMatcher(None, prev_lines, curr_lines)
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                for line in prev_lines[i1:i2]:
                    result.append((' ', line))
            elif tag == 'replace':
                for line in prev_lines[i1:i2]:
                    result.append(('-', line))
                for line in curr_lines[j1:j2]:
                    result.append(('+', line))
            elif tag == 'delete':
                for line in prev_lines[i1:i2]:
                    result.append(('-', line))
            elif tag == 'insert':
                for line in curr_lines[j1:j2]:
                    result.append(('+', line))
        self._previous = current
        return result

    def has_changed(self) -> bool:
        current = self.manager.get_visible_text()
        return self._previous is not None and current != self._previous

    def changed_lines(self) -> List[int]:
        """Get line numbers that have changed."""
        current = self.manager.get_visible_text()
        if self._previous is None:
            return []
        prev_lines = self._previous.splitlines()
        curr_lines = current.splitlines()
        changes = []
        max_lines = max(len(prev_lines), len(curr_lines))
        for i in range(max_lines):
            p = prev_lines[i] if i < len(prev_lines) else ''
            c = curr_lines[i] if i < len(curr_lines) else ''
            if p != c:
                changes.append(i)
        return changes

    def clear(self):
        self._previous = None

"""ScreenMargin - manages screen margins (DEC private mode)."""

from typing import Optional, Tuple


class ScreenMargin:
    """Manages left/right and top/bottom screen margins."""

    def __init__(self):
        self._top: int = 0
        self._bottom: int = 0
        self._left: int = 0
        self._right: int = 0
        self._margins_set: bool = False

    def set_top_bottom(self, top: int, bottom: int):
        self._top = top
        self._bottom = bottom
        self._margins_set = True

    def set_left_right(self, left: int, right: int):
        self._left = left
        self._right = right
        self._margins_set = True

    def clear(self):
        self._top = 0
        self._bottom = 0
        self._left = 0
        self._right = 0
        self._margins_set = False

    @property
    def top(self) -> int:
        return self._top

    @property
    def bottom(self) -> int:
        return self._bottom

    @property
    def left(self) -> int:
        return self._left

    @property
    def right(self) -> int:
        return self._right

    @property
    def is_set(self) -> bool:
        return self._margins_set

    def constrain_cursor(self, x: int, y: int) -> Tuple[int, int]:
        if not self._margins_set:
            return (x, y)
        cx = max(self._left, min(x, self._right))
        cy = max(self._top, min(y, self._bottom))
        return (cx, cy)

    def to_dict(self) -> dict:
        return {
            'top': self._top,
            'bottom': self._bottom,
            'left': self._left,
            'right': self._right,
            'set': self._margins_set,
        }

    def load_from(self, data: dict):
        self._top = data.get('top', 0)
        self._bottom = data.get('bottom', 0)
        self._left = data.get('left', 0)
        self._right = data.get('right', 0)
        self._margins_set = data.get('set', False)

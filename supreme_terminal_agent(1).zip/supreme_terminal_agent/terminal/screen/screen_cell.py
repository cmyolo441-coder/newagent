"""ScreenCell - represents a single cell (character + attributes) on the screen."""


class ScreenCell:
    """Represents a single character cell on the terminal screen with attributes."""

    def __init__(self, char: str = ' ', fg_color: str = "default", bg_color: str = "default",
                 bold: bool = False, dim: bool = False, italic: bool = False,
                 underline: bool = False, blink: bool = False, reverse: bool = False,
                 strikethrough: bool = False):
        self.char = char
        self.fg_color = fg_color
        self.bg_color = bg_color
        self.bold = bold
        self.dim = dim
        self.italic = italic
        self.underline = underline
        self.blink = blink
        self.reverse = reverse
        self.strikethrough = strikethrough

    def reset(self):
        self.char = ' '
        self.fg_color = "default"
        self.bg_color = "default"
        self.bold = False
        self.dim = False
        self.italic = False
        self.underline = False
        self.blink = False
        self.reverse = False
        self.strikethrough = False

    def to_dict(self) -> dict:
        return {
            'char': self.char,
            'fg': self.fg_color,
            'bg': self.bg_color,
            'bold': self.bold,
            'dim': self.dim,
            'italic': self.italic,
            'underline': self.underline,
            'blink': self.blink,
            'reverse': self.reverse,
            'strikethrough': self.strikethrough,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'ScreenCell':
        return cls(
            char=data.get('char', ' '),
            fg_color=data.get('fg', 'default'),
            bg_color=data.get('bg', 'default'),
            bold=data.get('bold', False),
            dim=data.get('dim', False),
            italic=data.get('italic', False),
            underline=data.get('underline', False),
            blink=data.get('blink', False),
            reverse=data.get('reverse', False),
            strikethrough=data.get('strikethrough', False),
        )

    def __repr__(self) -> str:
        return f"ScreenCell({self.char!r}, fg={self.fg_color}, bg={self.bg_color})"

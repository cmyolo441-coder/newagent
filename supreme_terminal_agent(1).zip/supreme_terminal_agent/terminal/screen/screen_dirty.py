"""ScreenDirty - tracks which cells have been modified for efficient rendering."""

import threading
from typing import List, Set, Tuple


class ScreenDirty:
    """Tracks dirty (modified) cells on the screen for optimized rendering."""

    def __init__(self, rows: int = 24, cols: int = 80):
        self.rows = rows
        self.cols = cols
        self._dirty: List[List[bool]] = [[False] * cols for _ in range(rows)]
        self._lock = threading.RLock()

    def mark(self, row: int, col: int):
        if 0 <= row < self.rows and 0 <= col < self.cols:
            with self._lock:
                self._dirty[row][col] = True

    def mark_all(self):
        with self._lock:
            for r in range(self.rows):
                for c in range(self.cols):
                    self._dirty[r][c] = True

    def mark_line(self, row: int):
        if 0 <= row < self.rows:
            with self._lock:
                for c in range(self.cols):
                    self._dirty[row][c] = True

    def mark_region(self, top: int, left: int, bottom: int, right: int):
        with self._lock:
            for r in range(max(0, top), min(bottom + 1, self.rows)):
                for c in range(max(0, left), min(right + 1, self.cols)):
                    self._dirty[r][c] = True

    def clear(self, row: int, col: int):
        if 0 <= row < self.rows and 0 <= col < self.cols:
            with self._lock:
                self._dirty[row][col] = False

    def clear_all(self):
        with self._lock:
            for r in range(self.rows):
                for c in range(self.cols):
                    self._dirty[r][c] = False

    def is_dirty(self, row: int, col: int) -> bool:
        if 0 <= row < self.rows and 0 <= col < self.cols:
            with self._lock:
                return self._dirty[row][col]
        return False

    def get_dirty_cells(self) -> List[Tuple[int, int]]:
        cells = []
        with self._lock:
            for r in range(self.rows):
                for c in range(self.cols):
                    if self._dirty[r][c]:
                        cells.append((r, c))
        return cells

    def get_dirty_lines(self) -> List[int]:
        lines = set()
        with self._lock:
            for r in range(self.rows):
                for c in range(self.cols):
                    if self._dirty[r][c]:
                        lines.add(r)
                        break
        return sorted(lines)

    @property
    def dirty_count(self) -> int:
        return len(self.get_dirty_cells())

    @property
    def has_dirty(self) -> bool:
        with self._lock:
            for r in range(self.rows):
                for c in range(self.cols):
                    if self._dirty[r][c]:
                        return True
            return False

    def resize(self, rows: int, cols: int):
        with self._lock:
            new_dirty = [[True] * cols for _ in range(rows)]
            self.rows = rows
            self.cols = cols
            self._dirty = new_dirty

"""ScreenLine - represents a single line on the terminal screen."""

import copy
import threading
from typing import List, Optional

from terminal.screen.screen_cell import ScreenCell


class ScreenLine:
    """Represents a single line of terminal screen content."""

    def __init__(self, cols: int = 80):
        self.cols = cols
        self._cells: List[ScreenCell] = [ScreenCell(' ') for _ in range(cols)]
        self._lock = threading.RLock()

    def set_cell(self, col: int, char: str, attrs: Optional[dict] = None):
        if col < 0 or col >= self.cols:
            return
        with self._lock:
            cell = self._cells[col]
            cell.char = char
            if attrs:
                if 'bold' in attrs:
                    cell.bold = attrs['bold']
                if 'fg' in attrs:
                    cell.fg_color = attrs['fg']
                if 'bg' in attrs:
                    cell.bg_color = attrs['bg']

    def get_cell(self, col: int) -> ScreenCell:
        if col < 0 or col >= self.cols:
            return ScreenCell(' ')
        with self._lock:
            return self._cells[col]

    @property
    def text(self) -> str:
        with self._lock:
            return ''.join(cell.char for cell in self._cells)

    def clear(self):
        with self._lock:
            self._cells = [ScreenCell(' ') for _ in range(self.cols)]

    def clear_from(self, col: int):
        if col < 0:
            col = 0
        with self._lock:
            for i in range(col, self.cols):
                self._cells[i] = ScreenCell(' ')

    def clear_to(self, col: int):
        with self._lock:
            for i in range(min(col + 1, self.cols)):
                self._cells[i] = ScreenCell(' ')

    def resized(self, new_cols: int) -> 'ScreenLine':
        with self._lock:
            new_line = ScreenLine(new_cols)
            for i in range(min(self.cols, new_cols)):
                new_line._cells[i] = copy.copy(self._cells[i])
            return new_line

    def insert_char(self, col: int, char: str):
        if col < 0 or col >= self.cols:
            return
        with self._lock:
            self._cells.insert(col, ScreenCell(char))
            self._cells.pop()

    def delete_char(self, col: int):
        if col < 0 or col >= self.cols:
            return
        with self._lock:
            self._cells.pop(col)
            self._cells.append(ScreenCell(' '))

    def __repr__(self) -> str:
        return f"ScreenLine({self.text!r})"

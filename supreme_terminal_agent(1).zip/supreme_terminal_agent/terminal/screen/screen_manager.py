"""ScreenManager - manages the terminal screen state."""

import threading
from typing import Dict, List, Optional, Tuple

from terminal.screen.screen_buffer import ScreenBuffer
from terminal.screen.screen_primary import ScreenPrimary
from terminal.screen.screen_alternate import ScreenAlternate
from terminal.screen.screen_renderer import ScreenRenderer
from terminal.screen.screen_diff import ScreenDiff
from terminal.screen.screen_capture import ScreenCapture
from terminal.screen.screen_dirty import ScreenDirty


class ScreenManager:
    """Manages the terminal screen state including primary and alternate buffers."""

    def __init__(self, rows: int = 24, cols: int = 80):
        self.rows = rows
        self.cols = cols
        self.primary = ScreenPrimary(rows, cols)
        self.alternate = ScreenAlternate(rows, cols)
        self.renderer = ScreenRenderer(self)
        self.diff = ScreenDiff(self)
        self.capture = ScreenCapture(self)
        self.dirty = ScreenDirty(rows, cols)
        self._active_buffer: str = "primary"
        self._lock = threading.RLock()

    @property
    def active_buffer(self) -> ScreenBuffer:
        with self._lock:
            if self._active_buffer == "alternate":
                return self.alternate
            return self.primary

    @property
    def is_alternate(self) -> bool:
        return self._active_buffer == "alternate"

    def switch_to_alternate(self):
        with self._lock:
            self._active_buffer = "alternate"
            self.dirty.mark_all()

    def switch_to_primary(self):
        with self._lock:
            self._active_buffer = "primary"
            self.dirty.mark_all()

    def write(self, data: bytes):
        buf = self.active_buffer
        buf.write(data)
        self.dirty.mark_all()

    def write_at(self, row: int, col: int, char: str):
        buf = self.active_buffer
        buf.set_cell(row, col, char)
        self.dirty.mark(row, col)

    def get_cell(self, row: int, col: int) -> str:
        buf = self.active_buffer
        return buf.get_cell(row, col)

    def get_line(self, row: int) -> str:
        buf = self.active_buffer
        return buf.get_line(row)

    def get_visible_text(self) -> str:
        buf = self.active_buffer
        lines = []
        for r in range(self.rows):
            lines.append(buf.get_line(r))
        return '\n'.join(lines).rstrip('\n')

    def resize(self, rows: int, cols: int):
        with self._lock:
            self.primary.resize(rows, cols)
            self.alternate.resize(rows, cols)
            self.rows = rows
            self.cols = cols
            self.dirty.resize(rows, cols)

    def clear(self):
        self.active_buffer.clear()
        self.dirty.mark_all()

    def reset(self):
        self.primary.clear()
        self.alternate.clear()
        self._active_buffer = "primary"
        self.dirty.mark_all()

    def close(self):
        self.primary.clear()
        self.alternate.clear()

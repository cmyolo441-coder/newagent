"""ScreenAlternate - the alternate screen buffer."""

from terminal.screen.screen_buffer import ScreenBuffer


class ScreenAlternate(ScreenBuffer):
    """Alternate screen buffer (used by full-screen applications like vim, less)."""

    def __init__(self, rows: int = 24, cols: int = 80):
        super().__init__(rows, cols)
        self._saved_primary: list = []

    def save_primary_state(self, primary_lines: list):
        """Save the primary screen state before switching."""
        self._saved_primary = list(primary_lines)

    def restore_saved_state(self) -> list:
        """Get the saved primary screen state."""
        saved = self._saved_primary
        self._saved_primary = []
        return saved

    def has_saved_state(self) -> bool:
        return len(self._saved_primary) > 0

    def clear_saved_state(self):
        self._saved_primary = []

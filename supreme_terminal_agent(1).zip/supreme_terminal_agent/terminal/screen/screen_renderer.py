"""ScreenRenderer - renders the screen buffer to output."""

from __future__ import annotations

from typing import List, Optional, Set, Tuple

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from terminal.screen.screen_manager import ScreenManager


class ScreenRenderer:
    """Renders the terminal screen buffer to a string or output stream."""

    def __init__(self, manager: ScreenManager):
        self.manager = manager

    def render(self, full: bool = False) -> str:
        """Render the active buffer to a string."""
        buf = self.manager.active_buffer
        lines = []
        for r in range(self.manager.rows):
            lines.append(buf.get_line(r))
        return '\n'.join(lines)

    def render_range(self, start_row: int, end_row: int) -> str:
        buf = self.manager.active_buffer
        lines = []
        for r in range(max(0, start_row), min(end_row, self.manager.rows)):
            lines.append(buf.get_line(r))
        return '\n'.join(lines)

    def render_dirty(self) -> str:
        """Render only dirty cells."""
        buf = self.manager.active_buffer
        dirty = self.manager.dirty
        output_parts = []
        for r in range(self.manager.rows):
            for c in range(self.manager.cols):
                if dirty.is_dirty(r, c):
                    output_parts.append(buf.get_cell(r, c))
                    dirty.clear(r, c)
                else:
                    output_parts.append(buf.get_cell(r, c))
        result_parts = []
        current_row = ""
        for i, ch in enumerate(output_parts):
            if i > 0 and i % self.manager.cols == 0:
                result_parts.append(current_row)
                current_row = ""
            current_row += ch
        if current_row:
            result_parts.append(current_row)
        return '\n'.join(result_parts)

    def render_diff(self, previous: str) -> str:
        """Render diff from previous state."""
        current = self.render()
        if current == previous:
            return ""
        return current

    def to_ansi(self) -> str:
        """Render to ANSI escape sequence output."""
        return self.render()

    def to_html(self, dark_bg: bool = True) -> str:
        """Render to HTML."""
        text = self.render()
        escaped = (text.replace('&', '&amp;')
                   .replace('<', '&lt;')
                   .replace('>', '&gt;'))
        bg = "#000" if dark_bg else "#fff"
        fg = "#fff" if dark_bg else "#000"
        return f'<pre style="background:{bg};color:{fg};font-family:monospace;">{escaped}</pre>'

    def render_region(self, top: int, left: int, bottom: int, right: int) -> str:
        buf = self.manager.active_buffer
        lines = []
        for r in range(top, min(bottom + 1, self.manager.rows)):
            line = ''
            for c in range(left, min(right + 1, self.manager.cols)):
                line += buf.get_cell(r, c)
            lines.append(line)
        return '\n'.join(lines)

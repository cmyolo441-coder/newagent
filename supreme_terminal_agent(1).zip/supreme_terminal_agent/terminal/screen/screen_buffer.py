"""ScreenBuffer - base class for screen buffer implementations."""

import copy
import threading
from typing import List, Optional, Tuple

from terminal.screen.screen_line import ScreenLine
from terminal.screen.screen_cell import ScreenCell


class ScreenBuffer:
    """Base class for terminal screen buffers."""

    def __init__(self, rows: int = 24, cols: int = 80):
        self.rows = rows
        self.cols = cols
        self._lines: List[ScreenLine] = []
        self._cursor_x = 0
        self._cursor_y = 0
        self._lock = threading.RLock()
        self._init_lines()

    def _init_lines(self):
        self._lines = [ScreenLine(self.cols) for _ in range(self.rows)]

    def set_cell(self, row: int, col: int, char: str, attrs: Optional[dict] = None):
        if row < 0 or row >= self.rows or col < 0 or col >= self.cols:
            return
        with self._lock:
            self._lines[row].set_cell(col, char, attrs)

    def get_cell(self, row: int, col: int) -> str:
        if row < 0 or row >= self.rows or col < 0 or col >= self.cols:
            return ' '
        with self._lock:
            return self._lines[row].get_cell(col).char

    def get_cell_obj(self, row: int, col: int) -> ScreenCell:
        if row < 0 or row >= self.rows:
            return ScreenCell(' ')
        with self._lock:
            return self._lines[row].get_cell(col)

    def get_line(self, row: int) -> str:
        if row < 0 or row >= self.rows:
            return ' ' * self.cols
        with self._lock:
            return self._lines[row].text

    def get_line_obj(self, row: int) -> ScreenLine:
        if row < 0 or row >= self.rows:
            return ScreenLine(self.cols)
        with self._lock:
            return self._lines[row]

    def write(self, data: bytes):
        text = data.decode('utf-8', errors='replace')
        with self._lock:
            for ch in text:
                if ch == '\n':
                    self._cursor_y += 1
                    self._cursor_x = 0
                elif ch == '\r':
                    self._cursor_x = 0
                elif ch == '\t':
                    self._cursor_x = (self._cursor_x + 8) & ~7
                else:
                    self.set_cell(self._cursor_y, self._cursor_x, ch)
                    self._cursor_x += 1
                    if self._cursor_x >= self.cols:
                        self._cursor_x = 0
                        self._cursor_y += 1
                if self._cursor_y >= self.rows:
                    self._scroll_up()
                    self._cursor_y = self.rows - 1

    def _scroll_up(self):
        self._lines.pop(0)
        self._lines.append(ScreenLine(self.cols))

    def _scroll_down(self):
        self._lines.pop()
        self._lines.insert(0, ScreenLine(self.cols))

    def scroll_up(self, n: int = 1):
        with self._lock:
            for _ in range(n):
                self._scroll_up()

    def scroll_down(self, n: int = 1):
        with self._lock:
            for _ in range(n):
                self._scroll_down()

    def clear(self):
        with self._lock:
            self._lines = [ScreenLine(self.cols) for _ in range(self.rows)]
            self._cursor_x = 0
            self._cursor_y = 0

    def clear_line(self, row: int):
        if 0 <= row < self.rows:
            with self._lock:
                self._lines[row] = ScreenLine(self.cols)

    def clear_to_eol(self, row: int, col: int):
        if 0 <= row < self.rows:
            with self._lock:
                self._lines[row].clear_from(col)

    def insert_lines(self, n: int = 1, at_row: Optional[int] = None):
        with self._lock:
            row = at_row if at_row is not None else self._cursor_y
            for _ in range(n):
                self._lines.insert(row, ScreenLine(self.cols))
                self._lines.pop()

    def delete_lines(self, n: int = 1, at_row: Optional[int] = None):
        with self._lock:
            row = at_row if at_row is not None else self._cursor_y
            for _ in range(n):
                if row < len(self._lines):
                    self._lines.pop(row)
                    self._lines.append(ScreenLine(self.cols))

    def resize(self, rows: int, cols: int):
        with self._lock:
            old_rows, old_cols = self.rows, self.cols
            self.rows, self.cols = rows, cols
            new_lines = []
            for i in range(rows):
                if i < old_rows:
                    line = self._lines[i]
                    if cols != old_cols:
                        line = line.resized(cols)
                    new_lines.append(line)
                else:
                    new_lines.append(ScreenLine(cols))
            self._lines = new_lines

    @property
    def cursor(self) -> Tuple[int, int]:
        return (self._cursor_x, self._cursor_y)

    @cursor.setter
    def cursor(self, pos: Tuple[int, int]):
        self._cursor_x, self._cursor_y = pos

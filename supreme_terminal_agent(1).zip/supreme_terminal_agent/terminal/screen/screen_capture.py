"""ScreenCapture - captures screen content to various formats."""

from __future__ import annotations

import io
from typing import Optional

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from terminal.screen.screen_manager import ScreenManager


class ScreenCapture:
    """Captures terminal screen content to various output formats."""

    def __init__(self, manager: ScreenManager):
        self.manager = manager

    def capture_text(self) -> str:
        """Capture visible screen as plain text."""
        return self.manager.get_visible_text()

    def capture_lines(self, start: int = 0, end: Optional[int] = None) -> str:
        """Capture a range of lines as text."""
        if end is None:
            end = self.manager.rows
        buf = self.manager.active_buffer
        lines = []
        for r in range(max(0, start), min(end, self.manager.rows)):
            lines.append(buf.get_line(r))
        return '\n'.join(lines)

    def capture_region(self, top: int, left: int, bottom: int, right: int) -> str:
        return self.manager.renderer.render_region(top, left, bottom, right)

    def capture_html(self, dark_bg: bool = True) -> str:
        return self.manager.renderer.to_html(dark_bg)

    def capture_json(self) -> dict:
        """Capture screen content as JSON structure."""
        buf = self.manager.active_buffer
        rows = []
        for r in range(self.manager.rows):
            cells = []
            for c in range(self.manager.cols):
                cell = buf.get_cell_obj(r, c)
                cells.append({
                    'char': cell.char,
                    'bold': cell.bold,
                    'fg': cell.fg_color,
                    'bg': cell.bg_color,
                })
            rows.append(cells)
        return {
            'rows': self.manager.rows,
            'cols': self.manager.cols,
            'content': rows,
        }

    def capture_to_file(self, filepath: str, fmt: str = 'text'):
        """Capture screen to a file."""
        if fmt == 'text':
            content = self.capture_text()
        elif fmt == 'html':
            content = self.capture_html()
        else:
            content = self.capture_text()
        with open(filepath, 'w') as f:
            f.write(content)

    def capture_all_buffers(self) -> dict:
        """Capture both primary and alternate buffers."""
        was_alternate = self.manager.is_alternate
        primary_text = ""
        alternate_text = ""
        if was_alternate:
            self.manager.switch_to_primary()
            primary_text = self.capture_text()
            self.manager.switch_to_alternate()
            alternate_text = self.capture_text()
        else:
            primary_text = self.capture_text()
            self.manager.switch_to_alternate()
            alternate_text = self.capture_text()
            self.manager.switch_to_primary()
        return {'primary': primary_text, 'alternate': alternate_text}

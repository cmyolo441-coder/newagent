"""TerminalNegotiation - terminal feature negotiation protocol (DA1/DA2/DA3/xterm)."""

import re
import time
import threading
from typing import Any, Dict, List, Optional, Tuple

from terminal.terminal_capabilities import ColorCapability, TerminalCapabilities, TerminalFeature


DA2_RESPONSE_RE = re.compile(
    r"\x1b\[>(?P<version>\d+);(?P<revision>\d+);(?P<variant>\d+)c"
)
DA1_RESPONSE_RE = re.compile(r"\x1b\[\?(?P<codes>[\d;]+)c")
DA3_RESPONSE_RE = re.compile(r"\x1bP!\|(?P<data>.+?)\x1b\\")

XTVERSION_RESPONSE_RE = re.compile(r"\x1bP>(?P<version>.+?)\x1b\\")


class NegotiationResult:
    """Result of a terminal negotiation exchange."""

    def __init__(self):
        self.device_attributes: List[str] = []
        self.terminal_id: int = 0
        self.terminal_version: int = 0
        self.terminal_variant: int = 0
        self.xterm_version: Optional[str] = None
        self.primary_da: List[int] = []
        self.secondary_da: List[Tuple[int, int, int]] = []
        self.tertiary_da: Optional[str] = None
        self.sixel_supported: bool = False
        self.kitty_supported: bool = False
        self.truecolor_supported: bool = False
        self.features: Dict[str, bool] = {}
        self.elapsed: float = 0.0

    def to_dict(self) -> dict:
        return {
            "device_attributes": self.device_attributes,
            "terminal_id": self.terminal_id,
            "terminal_version": self.terminal_version,
            "terminal_variant": self.terminal_variant,
            "xterm_version": self.xterm_version,
            "primary_da": self.primary_da,
            "secondary_da": [(a, b, c) for a, b, c in self.secondary_da],
            "tertiary_da": self.tertiary_da,
            "sixel_supported": self.sixel_supported,
            "kitty_supported": self.kitty_supported,
            "truecolor_supported": self.truecolor_supported,
            "features": self.features,
            "elapsed": self.elapsed,
        }


_DA1_BASIC = set(range(1, 10))
_DA1_XTERM = {
    4, 6, 7, 12, 15, 16, 17, 18, 19, 21, 22, 23, 24, 25, 28, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
    49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
    65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
    81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96,
    97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
    111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124,
    125, 126, 127, 128,
}
_DA1_KITTY = {31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128,
    1300, 1301, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1334, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1387, 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607}


class TerminalNegotiation:
    """Performs terminal feature negotiation using DA1, DA2, DA3, and XTVERSION."""

    def __init__(self, capabilities: Optional[TerminalCapabilities] = None):
        self._capabilities = capabilities or TerminalCapabilities()
        self._lock = threading.RLock()
        self._negotiated: Dict[str, NegotiationResult] = {}

    def negotiate(self, writer, reader, timeout: float = 2.0) -> NegotiationResult:
        """Run full negotiation sequence via a writer/reader pair."""
        start = time.monotonic()
        result = NegotiationResult()

        try:
            da1 = self._negotiate_da1(writer, reader, timeout)
            result.primary_da = da1

            da2 = self._negotiate_da2(writer, reader, timeout)
            if da2:
                result.terminal_id, result.terminal_version, result.terminal_variant = da2

            da3 = self._negotiate_da3(writer, reader, timeout)
            if da3:
                result.tertiary_da = da3

            xtversion = self._negotiate_xtversion(writer, reader, timeout)
            if xtversion:
                result.xterm_version = xtversion

            result.truecolor_supported = self._capabilities.supports_truecolor()
            result.sixel_supported = self._capabilities.supports_sixel()
            result.kitty_supported = self._capabilities.supports_kitty()

            result.features["alternate_screen"] = self._capabilities.has_feature(
                TerminalFeature.ALTERNATE_SCREEN
            )
            result.features["bracketed_paste"] = self._capabilities.has_feature(
                TerminalFeature.BRACKETED_PASTE
            )
            result.features["mouse_tracking"] = self._capabilities.has_feature(
                TerminalFeature.MOUSE_TRACKING
            )
            result.features["mouse_sgr"] = self._capabilities.has_feature(
                TerminalFeature.MOUSE_SGR
            )
            result.features["cursor_visibility"] = self._capabilities.has_feature(
                TerminalFeature.CURSOR_VISIBILITY
            )
            result.features["cursor_style"] = self._capabilities.has_feature(
                TerminalFeature.CURSOR_STYLE
            )
            result.features["focus_events"] = self._capabilities.has_feature(
                TerminalFeature.FOCUS_EVENTS
            )
            result.features["hyperlinks"] = self._capabilities.has_feature(
                TerminalFeature.OSC_8_HYPERLINKS
            )
            result.features["sixel"] = result.sixel_supported
            result.features["truecolor"] = result.truecolor_supported
            result.features["kitty_graphics"] = result.kitty_supported

        except (RuntimeError, TimeoutError, OSError):
            pass

        result.elapsed = time.monotonic() - start
        with self._lock:
            self._negotiated[self._capabilities.term] = result
        return result

    def get_negotiation(self, term: Optional[str] = None) -> Optional[NegotiationResult]:
        key = term or self._capabilities.term
        with self._lock:
            return self._negotiated.get(key)

    def negotiate_da1(self, writer, reader, timeout: float = 2.0) -> List[int]:
        """Send DA1 (Device Attributes) request and parse response."""
        return self._negotiate_da1(writer, reader, timeout)

    def negotiate_da2(self, writer, reader, timeout: float = 2.0) -> Optional[Tuple[int, int, int]]:
        """Send DA2 (Secondary Device Attributes) request and parse response."""
        return self._negotiate_da2(writer, reader, timeout)

    def negotiate_da3(self, writer, reader, timeout: float = 2.0) -> Optional[str]:
        """Send DA3 (Tertiary Device Attributes) request and parse response."""
        return self._negotiate_da3(writer, reader, timeout)

    def negotiate_xtversion(self, writer, reader, timeout: float = 2.0) -> Optional[str]:
        """Send XTVERSION request and parse response."""
        return self._negotiate_xtversion(writer, reader, timeout)

    def _negotiate_da1(self, writer, reader, timeout: float) -> List[int]:
        writer(b"\x1b[c")
        raw = self._read_response(reader, timeout, b"\x1b[?")
        if not raw:
            return []
        m = DA1_RESPONSE_RE.search(raw.decode("latin-1", errors="replace"))
        if m:
            codes_str = m.group("codes")
            return [int(c) for c in codes_str.split(";") if c.isdigit()]
        return []

    def _negotiate_da2(self, writer, reader, timeout: float) -> Optional[Tuple[int, int, int]]:
        writer(b"\x1b[>c")
        raw = self._read_response(reader, timeout, b"\x1b[>")
        if not raw:
            return None
        m = DA2_RESPONSE_RE.search(raw.decode("latin-1", errors="replace"))
        if m:
            return (
                int(m.group("version")),
                int(m.group("revision")),
                int(m.group("variant")),
            )
        return None

    def _negotiate_da3(self, writer, reader, timeout: float) -> Optional[str]:
        writer(b"\x1bP!|~" + b"\x1b\\")
        raw = self._read_response(reader, timeout, b"\x1bP!")
        if not raw:
            return None
        m = DA3_RESPONSE_RE.search(raw.decode("latin-1", errors="replace"))
        if m:
            return m.group("data")
        return None

    def _negotiate_xtversion(self, writer, reader, timeout: float) -> Optional[str]:
        writer(b"\x1b[>q")
        raw = self._read_response(reader, timeout, b"\x1bP>")
        if not raw:
            return None
        m = XTVERSION_RESPONSE_RE.search(raw.decode("latin-1", errors="replace"))
        if m:
            return m.group("version")
        return None

    def negotiate_features(self, writer, reader, timeout: float = 2.0) -> Dict[str, bool]:
        """Query specific terminal features by sending test sequences."""
        result: Dict[str, bool] = {}

        writer(b"\x1b[?12$p")
        raw = self._read_response(reader, timeout, b"\x1b[?")
        result["cursor_blink"] = raw is not None and b"12;1$y" in raw

        writer(b"\x1b[?25$p")
        raw = self._read_response(reader, timeout, b"\x1b[?")
        result["cursor_visible"] = raw is not None and b"25;1$y" in raw

        writer(b"\x1b[?2004$p")
        raw = self._read_response(reader, timeout, b"\x1b[?")
        result["bracketed_paste"] = raw is not None and b"2004;1$y" in raw

        writer(b"\x1b[?1000$p")
        raw = self._read_response(reader, timeout, b"\x1b[?")
        result["mouse_normal"] = raw is not None and b"1000;1$y" in raw

        writer(b"\x1b[?1006$p")
        raw = self._read_response(reader, timeout, b"\x1b[?")
        result["mouse_sgr"] = raw is not None and b"1006;1$y" in raw

        return result

    @staticmethod
    def _read_response(reader, timeout: float, expected_prefix: bytes, max_size: int = 4096) -> Optional[bytes]:
        """Read response from reader with timeout and expected prefix."""
        deadline = time.monotonic() + timeout
        buffer = bytearray()

        while time.monotonic() < deadline:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                chunk = reader(max_size)
                if not chunk:
                    break
                buffer.extend(chunk)
                decoded = buffer.decode("latin-1", errors="replace")
                if "c" in decoded or "\x1b\\" in decoded:
                    return bytes(buffer)
            except (OSError, RuntimeError):
                break

        return bytes(buffer) if buffer else None

    @staticmethod
    def interpret_da1(codes: List[int]) -> Dict[str, bool]:
        """Interpret DA1 response codes into feature flags."""
        features: Dict[str, bool] = {}
        code_set = set(codes)

        features["basic_vt100"] = bool(code_set & _DA1_BASIC)
        features["xterm"] = bool(code_set & _DA1_XTERM)
        features["kitty"] = bool(code_set & _DA1_KITTY)
        features["sixel"] = 4 in code_set
        features["sixel_scroll_left"] = 16 in code_set
        features["sixel_scroll_right"] = 17 in code_set
        features["window_ops"] = 18 in code_set
        features["cursor_visibility"] = 25 in code_set
        features["bracketed_paste"] = 2004 in code_set
        features["focus_events"] = 1004 in code_set
        features["mouse_sgr"] = 1006 in code_set
        features["mouse_urxvt"] = 1015 in code_set
        features["alternate_scroll"] = 1007 in code_set
        features["sync_updates"] = 2026 in code_set
        features["kitty_keyboard"] = "kitty" in str(codes) and 31 in code_set

        return features

    @staticmethod
    def interpret_da2(terminal_id: int, version: int, variant: int) -> Dict[str, Any]:
        """Interpret DA2 response into terminal identification."""
        info: Dict[str, Any] = {
            "terminal_id": terminal_id,
            "version": version,
            "variant": variant,
            "terminal_name": "unknown",
        }

        id_map = {
            0: "VT100 with AVO",
            1: "VT220",
            2: "VT240",
            18: "VT330",
            24: "VT340",
            41: "VT420",
            61: "VT510",
            64: "VT520",
            65: "VT525",
            83: "xterm",
            136: "kitty",
        }

        info["terminal_name"] = id_map.get(terminal_id, f"unknown({terminal_id})")
        info["xterm"] = terminal_id == 83
        info["kitty"] = terminal_id == 136
        info["vt420"] = terminal_id == 41

        if terminal_id == 83:
            if version >= 300:
                info["truecolor"] = True
            info["mouse_sgr"] = version >= 277
            info["focus_events"] = version >= 290
            info["bracketed_paste"] = version >= 268

        if terminal_id == 136:
            info["truecolor"] = True
            info["kitty_graphics"] = version >= 1
            info["sync_updates"] = version >= 1
            info["hyperlinks"] = version >= 2

        return info

    def __repr__(self) -> str:
        return f"TerminalNegotiation(term={self._capabilities.term!r})"

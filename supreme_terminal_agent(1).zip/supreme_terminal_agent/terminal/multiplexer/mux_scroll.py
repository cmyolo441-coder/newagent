"""MuxScroll - handles scrolling within panes."""

import os
from typing import Optional

from terminal.multiplexer.mux_pane import MuxPane


class MuxScroll:
    """Handles scrolling operations within multiplexer panes."""

    def __init__(self, controller):
        self.controller = controller
        self._scrollback_lines: int = 10000

    def scroll_up(self, pane: Optional[MuxPane] = None, lines: int = 1):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(f"\x1b[{lines}S".encode())

    def scroll_down(self, pane: Optional[MuxPane] = None, lines: int = 1):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(f"\x1b[{lines}T".encode())

    def scroll_to_top(self, pane: Optional[MuxPane] = None):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(b"\x1b[H")

    def scroll_to_bottom(self, pane: Optional[MuxPane] = None):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        self._send_scroll(pane, self._scrollback_lines)

    def scroll_page_up(self, pane: Optional[MuxPane] = None):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(b"\x1b[6~")

    def scroll_page_down(self, pane: Optional[MuxPane] = None):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(b"\x1b[5~")

    def scroll_half_page_up(self, pane: Optional[MuxPane] = None):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        half = max(1, (pane.rows or 24) // 2)
        pane.write(f"\x1b[{half}S".encode())

    def scroll_half_page_down(self, pane: Optional[MuxPane] = None):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        half = max(1, (pane.rows or 24) // 2)
        pane.write(f"\x1b[{half}T".encode())

    def _send_scroll(self, pane: MuxPane, lines: int):
        for _ in range(min(lines, 100)):
            pane.write(b"\x1b[S")

    def enter_copy_mode(self, pane: Optional[MuxPane] = None):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(b"\x1b[?1049h")

    def exit_copy_mode(self, pane: Optional[MuxPane] = None):
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(b"\x1b[?1049l")

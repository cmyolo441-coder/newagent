"""MuxLayout - manages layout of panes within a window."""

from enum import Enum
from typing import Dict, List, Optional, Tuple


class LayoutDirection(Enum):
    HORIZONTAL = "horizontal"
    VERTICAL = "vertical"
    GRID = "grid"
    FULLSCREEN = "fullscreen"


class MuxLayout:
    """Manages the spatial layout of panes within a window."""

    def __init__(self):
        self.direction = LayoutDirection.HORIZONTAL
        self._ratios: Dict[str, float] = {}

    def set_direction(self, direction: LayoutDirection):
        self.direction = direction

    def set_ratio(self, pane_id: str, ratio: float):
        self._ratios[pane_id] = max(0.0, min(1.0, ratio))

    def get_ratio(self, pane_id: str) -> float:
        return self._ratios.get(pane_id, 1.0)

    def remove_ratio(self, pane_id: str):
        self._ratios.pop(pane_id, None)

    def calculate_positions(self, panes: list, total_rows: int, total_cols: int) -> List[dict]:
        """Calculate pixel/char positions for each pane based on layout."""
        positions = []
        count = len(panes)
        if count == 0:
            return positions
        if count == 1:
            positions.append({'x': 0, 'y': 0, 'rows': total_rows, 'cols': total_cols})
            return positions
        if self.direction == LayoutDirection.HORIZONTAL:
            widths = self._distribute(total_cols, count)
            x = 0
            for i, pane in enumerate(panes):
                positions.append({
                    'x': x, 'y': 0,
                    'rows': total_rows,
                    'cols': widths[i] - 1,
                })
                x += widths[i]
        elif self.direction == LayoutDirection.VERTICAL:
            heights = self._distribute(total_rows, count)
            y = 0
            for i, pane in enumerate(panes):
                positions.append({
                    'x': 0, 'y': y,
                    'rows': heights[i] - 1,
                    'cols': total_cols,
                })
                y += heights[i]
        elif self.direction == LayoutDirection.GRID:
            cols = max(1, int(count ** 0.5))
            rows = (count + cols - 1) // cols
            cell_w = total_cols // cols
            cell_h = total_rows // rows
            for i, pane in enumerate(panes):
                gx = i % cols
                gy = i // cols
                positions.append({
                    'x': gx * cell_w,
                    'y': gy * cell_h,
                    'rows': cell_h - 1,
                    'cols': cell_w - 1,
                })
        else:
            for pane in panes:
                positions.append({'x': 0, 'y': 0, 'rows': total_rows, 'cols': total_cols})
        return positions

    def _distribute(self, total: int, count: int) -> List[int]:
        base = total // count
        remainder = total % count
        result = []
        for i in range(count):
            result.append(base + (1 if i < remainder else 0))
        return result

    def to_dict(self) -> dict:
        return {
            'direction': self.direction.value,
            'ratios': dict(self._ratios),
        }

    def load_from(self, data: dict):
        self.direction = LayoutDirection(data.get('direction', 'horizontal'))
        self._ratios.update(data.get('ratios', {}))

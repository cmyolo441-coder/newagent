"""MuxResize - handles resizing of panes and windows."""

from typing import Optional

from terminal.multiplexer.mux_pane import MuxPane
from terminal.multiplexer.mux_window import MuxWindow


class MuxResize:
    """Handles resizing of panes within the multiplexer."""

    def __init__(self, controller):
        self.controller = controller

    def resize_pane(self, window_id: str, pane_id: str, rows: int, cols: int):
        window = self.controller.get_window(window_id)
        if window is None:
            return
        pane = window.get_pane(pane_id)
        if pane:
            pane.resize(rows, cols)

    def resize_window(self, window_id: str, rows: int, cols: int):
        window = self.controller.get_window(window_id)
        if window is None:
            return
        for pane in window.panes:
            pane.resize(rows, cols)

    def resize_active_pane(self, rows: int, cols: int):
        window_id = self.controller.focus.focused_window
        if window_id is None:
            return
        window = self.controller.get_window(window_id)
        if window is None:
            return
        pane = window.active_pane
        if pane:
            pane.resize(rows, cols)

    def resize_all(self, rows: int, cols: int):
        for window_id in self.controller.list_windows():
            self.resize_window(window_id, rows, cols)

    def grow_pane(self, window_id: str, pane_id: str, amount: int = 1):
        window = self.controller.get_window(window_id)
        if window is None:
            return
        pane = window.get_pane(pane_id)
        if pane:
            pane.resize(pane.rows + amount, pane.cols)

    def shrink_pane(self, window_id: str, pane_id: str, amount: int = 1):
        window = self.controller.get_window(window_id)
        if window is None:
            return
        pane = window.get_pane(pane_id)
        if pane:
            new_rows = max(1, pane.rows - amount)
            new_cols = max(1, pane.cols - amount)
            pane.resize(new_rows, new_cols)

"""MuxSearch - provides search functionality within panes."""

from typing import List, Optional, Tuple

from terminal.multiplexer.mux_pane import MuxPane


class MuxSearch:
    """Provides search functionality within multiplexer pane content."""

    def __init__(self, controller):
        self.controller = controller
        self._query: str = ""
        self._results: List[Tuple[int, str]] = []
        self._current_match: int = -1

    def search(self, query: str, pane: Optional[MuxPane] = None) -> List[Tuple[int, str]]:
        """Search for text in pane content. Returns [(line_number, line), ...]."""
        self._query = query
        self._results = []
        target = pane or self.controller.get_active_pane()
        if target is None:
            return []
        return self._results

    def find_next(self) -> Optional[Tuple[int, str]]:
        """Go to the next search result."""
        if not self._results:
            return None
        self._current_match = (self._current_match + 1) % len(self._results)
        return self._results[self._current_match]

    def find_prev(self) -> Optional[Tuple[int, str]]:
        """Go to the previous search result."""
        if not self._results:
            return None
        self._current_match = (self._current_match - 1 + len(self._results)) % len(self._results)
        return self._results[self._current_match]

    def highlight_all(self):
        pass

    def clear_highlight(self):
        pass

    @property
    def query(self) -> str:
        return self._query

    @property
    def result_count(self) -> int:
        return len(self._results)

    @property
    def current_index(self) -> int:
        return self._current_match

    @property
    def has_results(self) -> bool:
        return len(self._results) > 0

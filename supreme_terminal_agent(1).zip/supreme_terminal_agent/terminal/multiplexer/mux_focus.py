"""MuxFocus - manages focus between windows and panes."""

from typing import Optional

from terminal.multiplexer.mux_pane import MuxPane
from terminal.multiplexer.mux_window import MuxWindow


class MuxFocus:
    """Manages which window and pane currently has focus."""

    def __init__(self, controller):
        self.controller = controller
        self._focused_window_id: Optional[str] = None
        self._focused_pane_id: Optional[str] = None

    @property
    def focused_window(self) -> Optional[MuxWindow]:
        if self._focused_window_id:
            return self.controller.get_window(self._focused_window_id)
        windows = self.controller.list_windows()
        if windows:
            self._focused_window_id = windows[0]
            return self.controller.get_window(windows[0])
        return None

    @focused_window.setter
    def focused_window(self, window_id: str):
        self._focused_window_id = window_id

    @property
    def focused_pane(self) -> Optional[MuxPane]:
        window = self.focused_window
        if window:
            if self._focused_pane_id:
                pane = window.get_pane(self._focused_pane_id)
                if pane:
                    return pane
            return window.active_pane
        return None

    @focused_pane.setter
    def focused_pane(self, pane_id: str):
        self._focused_pane_id = pane_id

    def focus_next_pane(self):
        window = self.focused_window
        if window is None:
            return
        panes = window.panes
        if not panes:
            return
        if self._focused_pane_id is None:
            self._focused_pane_id = panes[0].pane_id
            return
        for i, pane in enumerate(panes):
            if pane.pane_id == self._focused_pane_id:
                next_idx = (i + 1) % len(panes)
                self._focused_pane_id = panes[next_idx].pane_id
                window.active_pane = self._focused_pane_id
                return
        self._focused_pane_id = panes[0].pane_id

    def focus_prev_pane(self):
        window = self.focused_window
        if window is None:
            return
        panes = window.panes
        if not panes:
            return
        if self._focused_pane_id is None:
            self._focused_pane_id = panes[-1].pane_id
            return
        for i, pane in enumerate(panes):
            if pane.pane_id == self._focused_pane_id:
                prev_idx = (i - 1 + len(panes)) % len(panes)
                self._focused_pane_id = panes[prev_idx].pane_id
                window.active_pane = self._focused_pane_id
                return
        self._focused_pane_id = panes[-1].pane_id

    def focus_next_window(self):
        windows = self.controller.list_windows()
        if not windows:
            return
        if self._focused_window_id is None:
            self._focused_window_id = windows[0]
            return
        for i, wid in enumerate(windows):
            if wid == self._focused_window_id:
                next_idx = (i + 1) % len(windows)
                self._focused_window_id = windows[next_idx]
                return
        self._focused_window_id = windows[0]

    def focus_prev_window(self):
        windows = self.controller.list_windows()
        if not windows:
            return
        if self._focused_window_id is None:
            self._focused_window_id = windows[-1]
            return
        for i, wid in enumerate(windows):
            if wid == self._focused_window_id:
                prev_idx = (i - 1 + len(windows)) % len(windows)
                self._focused_window_id = windows[prev_idx]
                return
        self._focused_window_id = windows[-1]

"""MuxSplit - handles splitting panes in the multiplexer."""

from typing import Optional

from terminal.multiplexer.mux_pane import MuxPane
from terminal.multiplexer.mux_layout import LayoutDirection
from terminal.multiplexer.mux_window import MuxWindow


class MuxSplit:
    """Handles splitting of panes within a window."""

    def __init__(self, controller):
        self.controller = controller

    def split_horizontal(self, window_id: str, source_pane_id: Optional[str] = None) -> Optional[MuxPane]:
        """Split a pane horizontally (left/right)."""
        window = self.controller.get_window(window_id)
        if window is None:
            return None
        source = self._get_source_pane(window, source_pane_id)
        if source is None:
            return None
        new_pane = MuxPane(name=f"split_{window.pane_count}")
        new_pane.spawn(rows=source.rows, cols=source.cols // 2)
        source.resize(source.rows, source.cols // 2)
        window.add_pane(new_pane)
        window.layout.direction = LayoutDirection.HORIZONTAL
        return new_pane

    def split_vertical(self, window_id: str, source_pane_id: Optional[str] = None) -> Optional[MuxPane]:
        """Split a pane vertically (top/bottom)."""
        window = self.controller.get_window(window_id)
        if window is None:
            return None
        source = self._get_source_pane(window, source_pane_id)
        if source is None:
            return None
        new_pane = MuxPane(name=f"split_{window.pane_count}")
        new_pane.spawn(rows=source.rows // 2, cols=source.cols)
        source.resize(source.rows // 2, source.cols)
        window.add_pane(new_pane)
        window.layout.direction = LayoutDirection.VERTICAL
        return new_pane

    def _get_source_pane(self, window: MuxWindow, pane_id: Optional[str] = None) -> Optional[MuxPane]:
        if pane_id:
            return window.get_pane(pane_id)
        return window.active_pane

    def close_pane(self, window_id: str, pane_id: str) -> bool:
        window = self.controller.get_window(window_id)
        if window is None:
            return False
        return window.remove_pane(pane_id)

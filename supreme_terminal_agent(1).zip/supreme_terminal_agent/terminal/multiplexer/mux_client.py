"""MuxClient - client for connecting to a remote multiplexer server."""

import json
import socket
from typing import Optional


class MuxClient:
    """Client for connecting to a remote multiplexer server."""

    def __init__(self):
        self._socket: Optional[socket.socket] = None
        self._connected = False

    def connect(self, host: str = "localhost", port: int = 0) -> bool:
        """Connect to a multiplexer server."""
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self._socket.connect((host, port))
            self._connected = True
            return True
        except (OSError, ConnectionRefusedError):
            self._socket = None
            return False

    def disconnect(self):
        if self._socket:
            try:
                self._socket.close()
            except OSError:
                pass
            self._socket = None
        self._connected = False

    def send_message(self, message: dict) -> Optional[dict]:
        """Send a JSON message and receive response."""
        if not self._connected or self._socket is None:
            return None
        try:
            self._socket.sendall(json.dumps(message).encode('utf-8'))
            response = self._socket.recv(4096)
            if response:
                return json.loads(response.decode('utf-8', errors='replace'))
            return None
        except (OSError, json.JSONDecodeError):
            self._connected = False
            return None

    def list_windows(self) -> list:
        response = self.send_message({'action': 'list_windows'})
        return response.get('windows', []) if response else []

    def broadcast(self, data: bytes):
        self.send_message({
            'action': 'broadcast',
            'data': data.hex(),
        })

    @property
    def is_connected(self) -> bool:
        return self._connected

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

"""MuxCopyMode - copy mode for selecting and copying text from panes."""

from typing import Optional, Tuple

from terminal.multiplexer.mux_pane import MuxPane


class MuxCopyMode:
    """Provides copy mode functionality for selecting and copying text."""

    def __init__(self, controller):
        self.controller = controller
        self._active = False
        self._start: Optional[Tuple[int, int]] = None
        self._end: Optional[Tuple[int, int]] = None
        self._selection: str = ""

    def enter(self, pane: Optional[MuxPane] = None):
        """Enter copy mode."""
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(b"\x1b[?1049h")
        self._active = True
        self._start = None
        self._end = None
        self._selection = ""

    def exit(self, pane: Optional[MuxPane] = None):
        """Exit copy mode."""
        pane = pane or self.controller.get_active_pane()
        if pane is None:
            return
        pane.write(b"\x1b[?1049l")
        self._active = False

    def set_selection(self, start: Tuple[int, int], end: Tuple[int, int]):
        self._start = start
        self._end = end

    def copy(self) -> str:
        return self._selection

    def copy_selection(self, text: str):
        self._selection = text

    def copy_to_clipboard(self, text: str):
        self._selection = text
        try:
            import pyperclip
            pyperclip.copy(text)
        except ImportError:
            pass

    @property
    def is_active(self) -> bool:
        return self._active

    @property
    def has_selection(self) -> bool:
        return self._start is not None and self._end is not None

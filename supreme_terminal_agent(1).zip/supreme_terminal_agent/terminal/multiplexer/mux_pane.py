"""MuxPane - a single pane within a multiplexer window."""

import uuid
import threading
from typing import Optional, Callable

from terminal.pty.pty_controller import PtyController


class MuxPane:
    """A single pane/split within a terminal multiplexer window."""

    def __init__(self, pane_id: Optional[str] = None, name: Optional[str] = None):
        self.pane_id = pane_id or str(uuid.uuid4())
        self.name = name or f"pane_{self.pane_id[:8]}"
        self.pty: Optional[PtyController] = None
        self._x = 0
        self._y = 0
        self._rows = 24
        self._cols = 80
        self._visible = True
        self._lock = threading.RLock()

    def spawn(self, shell: str = "/bin/bash", rows: int = 24, cols: int = 80):
        self.pty = PtyController(shell=shell)
        self.pty.spawn(rows=rows, cols=cols)
        self._rows = rows
        self._cols = cols

    def write(self, data: bytes) -> int:
        if self.pty is None:
            raise RuntimeError("Pane not spawned")
        return self.pty.write(data)

    def read(self, size: int = 4096) -> bytes:
        if self.pty is None:
            return b''
        return self.pty.read(size)

    def resize(self, rows: int, cols: int):
        self._rows = rows
        self._cols = cols
        if self.pty:
            self.pty.resize(rows, cols)

    def set_position(self, x: int, y: int):
        self._x = x
        self._y = y

    @property
    def x(self) -> int:
        return self._x

    @property
    def y(self) -> int:
        return self._y

    @property
    def rows(self) -> int:
        return self._rows

    @property
    def cols(self) -> int:
        return self._cols

    @property
    def visible(self) -> bool:
        return self._visible

    @visible.setter
    def visible(self, value: bool):
        self._visible = value

    @property
    def is_alive(self) -> bool:
        if self.pty is None:
            return False
        return self.pty.is_alive()

    def close(self):
        if self.pty:
            self.pty.close()
            self.pty = None

    def fileno(self) -> int:
        if self.pty is None:
            raise RuntimeError("Pane not spawned")
        return self.pty.master_fd

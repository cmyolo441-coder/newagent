"""MuxServer - network server for remote multiplexer access."""

import json
import socket
import threading
from typing import Optional, Callable


class MuxServer:
    """TCP server for remote multiplexer access."""

    def __init__(self, controller):
        self.controller = controller
        self._server_socket: Optional[socket.socket] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._clients: list = []

    def start(self, host: str = "localhost", port: int = 0) -> int:
        """Start the server. Returns the port number."""
        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_socket.bind((host, port))
        self._server_socket.listen(5)
        self._server_socket.settimeout(1.0)
        self._running = True
        self._port = self._server_socket.getsockname()[1]
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()
        return self._port

    def stop(self):
        self._running = False
        if self._server_socket:
            try:
                self._server_socket.close()
            except OSError:
                pass
            self._server_socket = None
        for client in self._clients:
            try:
                client.close()
            except OSError:
                pass
        self._clients.clear()

    def _accept_loop(self):
        while self._running:
            try:
                client, addr = self._server_socket.accept()
                self._clients.append(client)
                handler = threading.Thread(
                    target=self._handle_client, args=(client, addr), daemon=True
                )
                handler.start()
            except socket.timeout:
                continue
            except OSError:
                break

    def _handle_client(self, client: socket.socket, addr: tuple):
        try:
            while self._running:
                data = client.recv(4096)
                if not data:
                    break
                response = self._process_message(data)
                if response:
                    client.sendall(response)
        except (OSError, ConnectionResetError):
            pass
        finally:
            try:
                client.close()
            except OSError:
                pass
            if client in self._clients:
                self._clients.remove(client)

    def _process_message(self, data: bytes) -> Optional[bytes]:
        try:
            msg = json.loads(data.decode('utf-8', errors='replace'))
            action = msg.get('action', '')
            if action == 'list_windows':
                windows = self.controller.list_windows()
                return json.dumps({'windows': windows}).encode()
            elif action == 'broadcast':
                payload = bytes.fromhex(msg.get('data', ''))
                self.controller.broadcast_to_all(payload)
                return json.dumps({'status': 'ok'}).encode()
            return json.dumps({'error': 'unknown_action'}).encode()
        except (json.JSONDecodeError, ValueError):
            return json.dumps({'error': 'invalid_message'}).encode()

    @property
    def port(self) -> int:
        return getattr(self, '_port', 0)

    @property
    def is_running(self) -> bool:
        return self._running

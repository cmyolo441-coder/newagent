"""MuxWindow - a window in the multiplexer containing panes."""

import uuid
import threading
from typing import Dict, List, Optional

from terminal.multiplexer.mux_pane import MuxPane
from terminal.multiplexer.mux_layout import MuxLayout


class MuxWindow:
    """A window in the terminal multiplexer, containing one or more panes."""

    def __init__(self, name: Optional[str] = None, window_id: Optional[str] = None):
        self.window_id = window_id or str(uuid.uuid4())
        self.name = name or f"window_{self.window_id[:8]}"
        self._panes: Dict[str, MuxPane] = {}
        self._pane_order: List[str] = []
        self._active_pane_id: Optional[str] = None
        self.layout = MuxLayout()
        self._lock = threading.RLock()

    def add_pane(self, pane: MuxPane) -> str:
        with self._lock:
            self._panes[pane.pane_id] = pane
            self._pane_order.append(pane.pane_id)
            if self._active_pane_id is None:
                self._active_pane_id = pane.pane_id
        return pane.pane_id

    def remove_pane(self, pane_id: str) -> bool:
        with self._lock:
            if pane_id not in self._panes:
                return False
            del self._panes[pane_id]
            self._pane_order = [p for p in self._pane_order if p != pane_id]
            if self._active_pane_id == pane_id:
                self._active_pane_id = self._pane_order[0] if self._pane_order else None
            return True

    def get_pane(self, pane_id: str) -> Optional[MuxPane]:
        with self._lock:
            return self._panes.get(pane_id)

    @property
    def active_pane(self) -> Optional[MuxPane]:
        with self._lock:
            if self._active_pane_id:
                return self._panes.get(self._active_pane_id)
            return None

    @active_pane.setter
    def active_pane(self, pane_id: str):
        with self._lock:
            if pane_id in self._panes:
                self._active_pane_id = pane_id

    @property
    def pane_count(self) -> int:
        with self._lock:
            return len(self._panes)

    @property
    def panes(self) -> List[MuxPane]:
        with self._lock:
            return [self._panes[pid] for pid in self._pane_order if pid in self._panes]

    def write_to_active(self, data: bytes):
        pane = self.active_pane
        if pane:
            pane.write(data)

    def write_to_all(self, data: bytes):
        with self._lock:
            for pane in self._panes.values():
                pane.write(data)

    def close(self):
        with self._lock:
            for pane in self._panes.values():
                pane.close()
            self._panes.clear()
            self._pane_order.clear()
            self._active_pane_id = None

"""MuxController - high-level multiplexer controller."""

import os
import signal
import threading
from typing import Dict, List, Optional, Callable

from terminal.multiplexer.mux_window import MuxWindow
from terminal.multiplexer.mux_pane import MuxPane
from terminal.multiplexer.mux_tab import MuxTab
from terminal.multiplexer.mux_layout import MuxLayout
from terminal.multiplexer.mux_focus import MuxFocus
from terminal.multiplexer.mux_resize import MuxResize
from terminal.multiplexer.mux_scroll import MuxScroll
from terminal.multiplexer.mux_search import MuxSearch
from terminal.multiplexer.mux_sync import MuxSync
from terminal.multiplexer.mux_broadcast import MuxBroadcast
from terminal.multiplexer.mux_server import MuxServer


class MuxController:
    """High-level controller for terminal multiplexing operations."""

    def __init__(self):
        self._windows: Dict[str, MuxWindow] = {}
        self._lock = threading.RLock()
        self.focus = MuxFocus(self)
        self.resize = MuxResize(self)
        self.scroll = MuxScroll(self)
        self.search = MuxSearch(self)
        self.sync = MuxSync(self)
        self.broadcast = MuxBroadcast(self)
        self.server = MuxServer(self)

    def create_window(self, name: Optional[str] = None) -> MuxWindow:
        window = MuxWindow(name=name)
        with self._lock:
            self._windows[window.window_id] = window
        return window

    def destroy_window(self, window_id: str):
        with self._lock:
            self._windows.pop(window_id, None)

    def get_window(self, window_id: str) -> Optional[MuxWindow]:
        with self._lock:
            return self._windows.get(window_id)

    def list_windows(self) -> List[str]:
        with self._lock:
            return list(self._windows.keys())

    def add_pane(self, window_id: str, pane: MuxPane) -> bool:
        window = self.get_window(window_id)
        if window:
            window.add_pane(pane)
            return True
        return False

    def remove_pane(self, window_id: str, pane_id: str) -> bool:
        window = self.get_window(window_id)
        if window:
            return window.remove_pane(pane_id)
        return False

    def get_active_pane(self) -> Optional[MuxPane]:
        with self._lock:
            for window in self._windows.values():
                pane = window.active_pane
                if pane:
                    return pane
            return None

    def broadcast_to_all(self, data: bytes):
        self.broadcast.broadcast(data)

    def broadcast_to_window(self, window_id: str, data: bytes):
        window = self.get_window(window_id)
        if window:
            self.broadcast.broadcast_to_window(window_id, data)

    def start_server(self, host: str = "localhost", port: int = 0):
        self.server.start(host, port)

    def stop_server(self):
        self.server.stop()

    def close(self):
        self.stop_server()
        with self._lock:
            for window in self._windows.values():
                window.close()
            self._windows.clear()

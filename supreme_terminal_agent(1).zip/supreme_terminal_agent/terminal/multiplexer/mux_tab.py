"""MuxTab - tab management for multiplexer windows."""

import uuid
import threading
from typing import Dict, List, Optional

from terminal.multiplexer.mux_window import MuxWindow


class MuxTab:
    """Represents a tab containing one or more windows."""

    def __init__(self, name: Optional[str] = None, tab_id: Optional[str] = None):
        self.tab_id = tab_id or str(uuid.uuid4())
        self.name = name or f"tab_{self.tab_id[:8]}"
        self._windows: Dict[str, MuxWindow] = {}
        self._active_window_id: Optional[str] = None
        self._lock = threading.RLock()

    def add_window(self, window: MuxWindow):
        with self._lock:
            self._windows[window.window_id] = window
            if self._active_window_id is None:
                self._active_window_id = window.window_id

    def remove_window(self, window_id: str) -> bool:
        with self._lock:
            if window_id not in self._windows:
                return False
            window = self._windows.pop(window_id)
            window.close()
            if self._active_window_id == window_id:
                self._active_window_id = next(iter(self._windows)) if self._windows else None
            return True

    def get_window(self, window_id: str) -> Optional[MuxWindow]:
        with self._lock:
            return self._windows.get(window_id)

    @property
    def active_window(self) -> Optional[MuxWindow]:
        with self._lock:
            if self._active_window_id:
                return self._windows.get(self._active_window_id)
            return None

    @active_window.setter
    def active_window(self, window_id: str):
        with self._lock:
            if window_id in self._windows:
                self._active_window_id = window_id

    @property
    def windows(self) -> List[MuxWindow]:
        with self._lock:
            return list(self._windows.values())

    @property
    def window_count(self) -> int:
        with self._lock:
            return len(self._windows)

    def close(self):
        with self._lock:
            for window in self._windows.values():
                window.close()
            self._windows.clear()
            self._active_window_id = None

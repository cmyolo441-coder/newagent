"""MuxSync - synchronizes input/output across multiple panes."""

import threading
from typing import Dict, List, Optional, Set

from terminal.multiplexer.mux_pane import MuxPane


class MuxSync:
    """Synchronizes input across multiple panes."""

    def __init__(self, controller):
        self.controller = controller
        self._sync_groups: Dict[str, Set[str]] = {}
        self._lock = threading.RLock()

    def create_sync_group(self, name: str) -> str:
        group_id = name
        with self._lock:
            self._sync_groups[group_id] = set()
        return group_id

    def add_to_group(self, group_id: str, pane_id: str):
        with self._lock:
            if group_id in self._sync_groups:
                self._sync_groups[group_id].add(pane_id)

    def remove_from_group(self, group_id: str, pane_id: str):
        with self._lock:
            if group_id in self._sync_groups:
                self._sync_groups[group_id].discard(pane_id)

    def sync_write(self, group_id: str, data: bytes):
        """Write data to all panes in a sync group."""
        with self._lock:
            pane_ids = list(self._sync_groups.get(group_id, set()))
        for pane_id in pane_ids:
            for window_id in self.controller.list_windows():
                window = self.controller.get_window(window_id)
                if window:
                    pane = window.get_pane(pane_id)
                    if pane:
                        try:
                            pane.write(data)
                        except (RuntimeError, OSError):
                            pass

    def sync_broadcast(self, data: bytes):
        """Broadcast data to all panes in all sync groups."""
        with self._lock:
            group_ids = list(self._sync_groups.keys())
        for gid in group_ids:
            self.sync_write(gid, data)

    def list_groups(self) -> List[str]:
        with self._lock:
            return list(self._sync_groups.keys())

    def get_group_panes(self, group_id: str) -> List[str]:
        with self._lock:
            return list(self._sync_groups.get(group_id, set()))

    def remove_group(self, group_id: str):
        with self._lock:
            self._sync_groups.pop(group_id, None)

    @property
    def is_syncing(self) -> bool:
        with self._lock:
            return any(len(panes) > 1 for panes in self._sync_groups.values())

    def clear(self):
        with self._lock:
            self._sync_groups.clear()

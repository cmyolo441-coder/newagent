"""MuxBroadcast - broadcasts input across multiple panes/windows."""

from typing import List, Optional

from terminal.multiplexer.mux_pane import MuxPane
from terminal.multiplexer.mux_window import MuxWindow


class MuxBroadcast:
    """Broadcasts input to multiple panes and windows."""

    def __init__(self, controller):
        self.controller = controller
        self._broadcast_enabled = False

    def enable_broadcast(self):
        self._broadcast_enabled = True

    def disable_broadcast(self):
        self._broadcast_enabled = False

    @property
    def is_broadcasting(self) -> bool:
        return self._broadcast_enabled

    def broadcast(self, data: bytes):
        """Broadcast data to all panes in all windows."""
        window_ids = self.controller.list_windows()
        for wid in window_ids:
            self.broadcast_to_window(wid, data)

    def broadcast_to_window(self, window_id: str, data: bytes):
        """Broadcast data to all panes in a specific window."""
        window = self.controller.get_window(window_id)
        if window is None:
            return
        for pane in window.panes:
            try:
                pane.write(data)
            except (RuntimeError, OSError):
                pass

    def broadcast_to_panes(self, pane_ids: List[str], data: bytes):
        """Broadcast data to specific panes across windows."""
        for window_id in self.controller.list_windows():
            window = self.controller.get_window(window_id)
            if window:
                for pane_id in pane_ids:
                    pane = window.get_pane(pane_id)
                    if pane:
                        try:
                            pane.write(data)
                        except (RuntimeError, OSError):
                            pass

    def toggle_broadcast(self):
        self._broadcast_enabled = not self._broadcast_enabled

    def broadcast_if_enabled(self, data: bytes):
        if self._broadcast_enabled:
            self.broadcast(data)

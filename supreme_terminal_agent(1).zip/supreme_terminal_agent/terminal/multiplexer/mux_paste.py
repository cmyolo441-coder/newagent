"""MuxPaste - handles paste operations in the multiplexer."""

from typing import Optional

from terminal.multiplexer.mux_pane import MuxPane


class MuxPaste:
    """Handles pasting text into multiplexer panes."""

    def __init__(self, controller):
        self.controller = controller

    def paste(self, text: str, pane: Optional[MuxPane] = None):
        """Paste text into a pane."""
        target = pane or self.controller.get_active_pane()
        if target is None:
            return
        data = text.encode('utf-8', errors='replace')
        target.write(data)

    def paste_from_clipboard(self, pane: Optional[MuxPane] = None):
        """Paste from system clipboard into a pane."""
        try:
            import pyperclip
            text = pyperclip.paste()
            self.paste(text, pane)
        except ImportError:
            pass

    def paste_bracketed(self, text: str, pane: Optional[MuxPane] = None):
        """Paste with bracketed paste mode."""
        target = pane or self.controller.get_active_pane()
        if target is None:
            return
        data = f"\x1b[200~{text}\x1b[201~".encode('utf-8', errors='replace')
        target.write(data)

    def paste_line(self, text: str, pane: Optional[MuxPane] = None):
        """Paste text followed by newline."""
        self.paste(text + '\n', pane)

    def paste_from_history(self, index: int = -1, pane: Optional[MuxPane] = None):
        pass

"""TerminalMaster - master controller coordinating all terminal subsystems."""

import os
import time
import signal
import logging
import threading
from typing import Any, Callable, Dict, List, Optional, Set

from terminal.terminal_state import TerminalState
from terminal.terminal_controller import TerminalController, TerminalStatus
from terminal.terminal_emulator import TerminalEmulator
from terminal.terminal_renderer import RenderedFrame, RenderedLine, TerminalRenderer
from terminal.terminal_capabilities import ColorCapability, TerminalCapabilities, TerminalFeature
from terminal.terminal_negotiation import NegotiationResult, TerminalNegotiation
from terminal.session.session_manager import SessionManager
from terminal.session.session_controller import SessionController
from terminal.protocols.protocol_manager import ProtocolManager
from terminal.protocols.base_protocol import BaseProtocol
from terminal.screen.screen_manager import ScreenManager
from terminal.output.output_buffer import OutputBuffer
from terminal.escape.escape_parser import EscapeParser

logger = logging.getLogger(__name__)


class TerminalMaster:
    """Master controller that coordinates all terminal subsystems.

    Provides a unified API for:
    - Creating and managing terminal instances
    - Multi-terminal session coordination
    - Protocol management (SSH, serial, telnet, etc.)
    - Broadcast and multiplex operations
    - Capability detection and negotiation
    """

    def __init__(self):
        self._terminals: Dict[str, TerminalController] = {}
        self._session_manager = SessionManager()
        self._protocol_manager = ProtocolManager()
        self._capabilities_cache: Dict[str, TerminalCapabilities] = {}
        self._negotiation_cache: Dict[str, NegotiationResult] = {}
        self._default_rows: int = 24
        self._default_cols: int = 80
        self._default_term: str = os.environ.get("TERM", "xterm-256color")
        self._lock = threading.RLock()
        self._running = False
        self._select_interval: float = 0.05
        self._poll_thread: Optional[threading.Thread] = None
        self._broadcast_mode: bool = False
        self._broadcast_targets: Set[str] = set()
        self._global_callbacks: Dict[str, List[Callable]] = {
            "on_create": [],
            "on_destroy": [],
            "on_resize": [],
            "on_error": [],
            "on_data": [],
            "on_broadcast": [],
        }

    @property
    def session_manager(self) -> SessionManager:
        return self._session_manager

    @property
    def protocol_manager(self) -> ProtocolManager:
        return self._protocol_manager

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def terminal_count(self) -> int:
        with self._lock:
            return len(self._terminals)

    @property
    def active_terminal_count(self) -> int:
        with self._lock:
            return sum(1 for t in self._terminals.values() if t.is_active)

    def create_terminal(
        self,
        terminal_id: Optional[str] = None,
        rows: Optional[int] = None,
        cols: Optional[int] = None,
        shell: str = "/bin/bash",
        env: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        term: Optional[str] = None,
    ) -> TerminalController:
        """Create and initialize a new terminal instance."""
        tid = terminal_id or self._generate_id()
        rows = rows or self._default_rows
        cols = cols or self._default_cols
        term = term or self._default_term

        controller = TerminalController(rows=rows, cols=cols, terminal_id=tid)
        controller.initialize(shell=shell, env=env, cwd=cwd, term=term)

        controller.on_data(lambda data: self._on_terminal_data(tid, data))
        controller.on_status_change(lambda s: self._on_terminal_status(tid, s))
        controller.on_error(lambda e: self._on_terminal_error(tid, e))

        with self._lock:
            self._terminals[tid] = controller

        for cb in self._global_callbacks["on_create"]:
            try:
                cb(tid, controller)
            except Exception:
                logger.exception("on_create callback failed")

        logger.info("Created terminal %s (pid=%s)", tid, controller.fileno())
        return controller

    def destroy_terminal(self, terminal_id: str):
        """Destroy a terminal instance and release its resources."""
        with self._lock:
            controller = self._terminals.pop(terminal_id, None)

        if controller:
            controller.close()
            self._broadcast_targets.discard(terminal_id)
            for cb in self._global_callbacks["on_destroy"]:
                try:
                    cb(terminal_id, controller)
                except Exception:
                    logger.exception("on_destroy callback failed")
            logger.info("Destroyed terminal %s", terminal_id)

    def get_terminal(self, terminal_id: str) -> Optional[TerminalController]:
        """Get a terminal controller by ID."""
        with self._lock:
            return self._terminals.get(terminal_id)

    def list_terminals(self) -> List[str]:
        """List all terminal IDs."""
        with self._lock:
            return list(self._terminals.keys())

    def list_active_terminals(self) -> List[TerminalController]:
        """List all active terminal controllers."""
        with self._lock:
            return [t for t in self._terminals.values() if t.is_active]

    def get_terminal_state(self, terminal_id: str) -> Optional[Dict[str, Any]]:
        """Get serialized state for a terminal."""
        controller = self.get_terminal(terminal_id)
        if controller:
            return controller.get_state()
        return None

    def write_to_terminal(self, terminal_id: str, data: bytes) -> int:
        """Write data to a specific terminal."""
        controller = self.get_terminal(terminal_id)
        if not controller:
            raise ValueError(f"Terminal not found: {terminal_id}")
        return controller.write(data)

    def write_to_all(self, data: bytes, exclude: Optional[List[str]] = None):
        """Write data to all active terminals."""
        exclude_set = set(exclude or [])
        with self._lock:
            targets = [
                t for tid, t in self._terminals.items()
                if t.is_active and tid not in exclude_set
            ]
        for t in targets:
            try:
                t.write(data)
            except (RuntimeError, OSError) as e:
                logger.warning("Write to %s failed: %s", t.terminal_id, e)

    def resize_terminal(self, terminal_id: str, rows: int, cols: int):
        """Resize a specific terminal."""
        controller = self.get_terminal(terminal_id)
        if not controller:
            raise ValueError(f"Terminal not found: {terminal_id}")
        controller.resize(rows, cols)
        for cb in self._global_callbacks["on_resize"]:
            try:
                cb(terminal_id, rows, cols)
            except Exception:
                pass

    def resize_all(self, rows: int, cols: int):
        """Resize all terminals."""
        with self._lock:
            for tid in list(self._terminals.keys()):
                try:
                    self.resize_terminal(tid, rows, cols)
                except ValueError:
                    pass

    def render_terminal(self, terminal_id: str) -> Optional[RenderedFrame]:
        """Render a specific terminal's current state."""
        controller = self.get_terminal(terminal_id)
        if not controller:
            return None
        return controller.render()

    def get_terminal_plain_text(self, terminal_id: str) -> Optional[str]:
        """Get plain text from a terminal."""
        controller = self.get_terminal(terminal_id)
        if not controller:
            return None
        return controller.get_plain_text()

    def set_broadcast_mode(self, enabled: bool, targets: Optional[List[str]] = None):
        """Enable or disable broadcast mode with optional targets."""
        with self._lock:
            self._broadcast_mode = enabled
            if targets:
                self._broadcast_targets = set(targets)
            elif enabled and not self._broadcast_targets:
                self._broadcast_targets = set(self._terminals.keys())

    def broadcast(self, data: bytes):
        """Broadcast data to all broadcast targets."""
        if not self._broadcast_mode:
            return
        with self._lock:
            targets = [
                tid for tid in self._broadcast_targets
                if tid in self._terminals and self._terminals[tid].is_active
            ]
        for tid in targets:
            try:
                self._terminals[tid].write(data)
            except (RuntimeError, OSError) as e:
                logger.warning("Broadcast to %s failed: %s", tid, e)
        for cb in self._global_callbacks["on_broadcast"]:
            try:
                cb(data, targets)
            except Exception:
                pass

    def get_capabilities(self, terminal_id: str) -> Optional[TerminalCapabilities]:
        """Get the detected capabilities for a terminal."""
        controller = self.get_terminal(terminal_id)
        if not controller:
            return None
        return controller.capabilities

    def detect_terminal_capabilities(self, term_env: Optional[str] = None) -> TerminalCapabilities:
        """Detect capabilities for a terminal environment string."""
        key = term_env or os.environ.get("TERM", "unknown")
        if key not in self._capabilities_cache:
            caps = TerminalCapabilities(term_env=key)
            self._capabilities_cache[key] = caps
        return self._capabilities_cache[key]

    def negotiate_terminal(
        self,
        terminal_id: str,
        timeout: float = 2.0,
    ) -> Optional[NegotiationResult]:
        """Run full capability negotiation on a terminal."""
        controller = self.get_terminal(terminal_id)
        if not controller:
            return None

        result = controller.negotiation.negotiate(
            writer=lambda d: controller.write(d),
            reader=lambda s: controller.read(s),
            timeout=timeout,
        )
        self._negotiation_cache[terminal_id] = result
        return result

    def get_negotiation(self, terminal_id: str) -> Optional[NegotiationResult]:
        """Get cached negotiation result for a terminal."""
        return self._negotiation_cache.get(terminal_id)

    def start(self):
        """Start the master event loop."""
        with self._lock:
            if self._running:
                return
            self._running = True
        self._poll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._poll_thread.start()
        logger.info("TerminalMaster started")

    def stop(self):
        """Stop the master event loop."""
        with self._lock:
            self._running = False
        if self._poll_thread:
            self._poll_thread.join(timeout=2)
            self._poll_thread = None
        logger.info("TerminalMaster stopped")

    def shutdown(self):
        """Shut down all terminals and resources."""
        self.stop()
        with self._lock:
            terminal_ids = list(self._terminals.keys())
        for tid in terminal_ids:
            self.destroy_terminal(tid)
        self._session_manager.close()
        self._capabilities_cache.clear()
        self._negotiation_cache.clear()
        self._global_callbacks.clear()
        logger.info("TerminalMaster shutdown complete")

    def register_protocol(self, name: str, protocol_cls):
        """Register a connection protocol."""
        self._protocol_manager.register(name, protocol_cls)
        logger.debug("Registered protocol: %s", name)

    def create_protocol_connection(self, name: str, **kwargs) -> Optional[BaseProtocol]:
        """Create a protocol connection."""
        return self._protocol_manager.create(name, **kwargs)

    def connect_via_protocol(
        self,
        protocol: BaseProtocol,
        terminal_id: Optional[str] = None,
    ) -> TerminalController:
        """Create a terminal connected via the given protocol."""
        controller = self.create_terminal(terminal_id=terminal_id)
        fd = protocol.connect()
        # Replace the PTY fd in the controller with the protocol's fd
        controller._master_fd = fd
        return controller

    def on_create(self, callback: Callable[[str, TerminalController], None]):
        self._global_callbacks["on_create"].append(callback)

    def on_destroy(self, callback: Callable[[str, TerminalController], None]):
        self._global_callbacks["on_destroy"].append(callback)

    def on_resize(self, callback: Callable[[str, int, int], None]):
        self._global_callbacks["on_resize"].append(callback)

    def on_error(self, callback: Callable[[str, Exception], None]):
        self._global_callbacks["on_error"].append(callback)

    def on_data(self, callback: Callable[[str, bytes], None]):
        self._global_callbacks["on_data"].append(callback)

    def on_broadcast(self, callback: Callable[[bytes, List[str]], None]):
        self._global_callbacks["on_broadcast"].append(callback)

    def _poll_loop(self):
        """Background loop for periodic I/O processing."""
        import select
        poller = select.poll()
        fd_to_tid: Dict[int, str] = {}

        while self._running:
            with self._lock:
                active = {
                    tid: ctrl for tid, ctrl in self._terminals.items()
                    if ctrl.is_active and ctrl.master_fd is not None
                }
                new_fd_map = {ctrl.master_fd: tid for tid, ctrl in active.items()}

                if new_fd_map != fd_to_tid:
                    poller.unregister(*fd_to_tid.keys()) if fd_to_tid else None
                    for fd in new_fd_map:
                        poller.register(fd, select.POLLIN)
                    fd_to_tid = new_fd_map

            if not fd_to_tid:
                time.sleep(self._select_interval)
                continue

            try:
                events = poller.poll(int(self._select_interval * 1000))
            except (select.error, OSError):
                events = []
                time.sleep(self._select_interval)

            for fd, event in events:
                tid = fd_to_tid.get(fd)
                if not tid:
                    continue
                controller = self._terminals.get(tid)
                if not controller:
                    continue

                if event & select.POLLIN:
                    try:
                        data = controller.read(4096)
                        if data:
                            for cb in self._global_callbacks["on_data"]:
                                try:
                                    cb(tid, data)
                                except Exception:
                                    pass
                    except (RuntimeError, OSError) as e:
                        logger.error("Poll read error on %s: %s", tid, e)

                if event & (select.POLLHUP | select.POLLERR | select.POLLNVAL):
                    logger.info("Terminal %s hung up", tid)
                    self.destroy_terminal(tid)

    def _on_terminal_data(self, terminal_id: str, data: bytes):
        """Handle data events from terminals."""
        pass

    def _on_terminal_status(self, terminal_id: str, status: TerminalStatus):
        """Handle status change events from terminals."""
        pass

    def _on_terminal_error(self, terminal_id: str, error: Exception):
        """Handle error events from terminals."""
        for cb in self._global_callbacks["on_error"]:
            try:
                cb(terminal_id, error)
            except Exception:
                pass

    def _generate_id(self) -> str:
        import uuid
        return f"term_{uuid.uuid4().hex[:12]}"

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "running": self._running,
                "terminal_count": self.terminal_count,
                "active_count": self.active_terminal_count,
                "broadcast_mode": self._broadcast_mode,
                "broadcast_targets": list(self._broadcast_targets),
                "default_rows": self._default_rows,
                "default_cols": self._default_cols,
                "terminals": list(self._terminals.keys()),
            }

    def __repr__(self) -> str:
        return (
            f"TerminalMaster(terminals={self.terminal_count}, "
            f"active={self.active_terminal_count}, "
            f"running={self._running})"
        )

from __future__ import annotations
"""TtyRawMode - raw terminal mode implementation."""

import os
import termios
import tty
from typing import Optional


class TtyRawMode:
    """Manages raw terminal mode (minimal processing, character-by-character I/O)."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd
        self._previous: Optional[list] = None

    def set_fd(self, fd: int):
        self.fd = fd

    def enter(self):
        """Enter raw mode."""
        if self.fd is None:
            return
        try:
            self._previous = termios.tcgetattr(self.fd)
            tty.setraw(self.fd)
        except (termios.error, OSError):
            pass

    def exit(self):
        """Exit raw mode by restoring previous attributes."""
        if self.fd is not None and self._previous is not None:
            try:
                termios.tcsetattr(self.fd, termios.TCSANOW, self._previous)
            except termios.error:
                pass

    def get_flags(self) -> dict:
        """Get the raw mode flag configuration."""
        return {
            'iflag': {
                'ignbrk': True, 'brkint': False, 'ignpar': False,
                'parmrk': False, 'inpck': False, 'istrip': False,
                'inlcr': False, 'igncr': False, 'icrnl': False,
                'ixon': False, 'ixoff': False,
            },
            'oflag': {
                'opost': False,
            },
            'cflag': {
                'cs8': True,
            },
            'lflag': {
                'echo': False, 'icanon': False, 'isig': False, 'iexten': False,
            },
        }

    def __enter__(self):
        self.enter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.exit()

from __future__ import annotations
"""TtyDiscipline - manages terminal line discipline settings."""

import os
import termios
from typing import Dict, Optional


class TtyDiscipline:
    """Manages TTY line discipline parameters."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd

    def set_fd(self, fd: int):
        self.fd = fd

    def set_vintr(self, char: int = 3):
        """Set interrupt character (default ^C)."""
        self._set_cc(termios.VINTR, char)

    def set_vquit(self, char: int = 28):
        """Set quit character (default ^\)."""
        self._set_cc(termios.VQUIT, char)

    def set_verase(self, char: int = 127):
        """Set erase character (default ^?)."""
        self._set_cc(termios.VERASE, char)

    def set_vkill(self, char: int = 21):
        """Set kill character (default ^U)."""
        self._set_cc(termios.VKILL, char)

    def set_veof(self, char: int = 4):
        """Set EOF character (default ^D)."""
        self._set_cc(termios.VEOF, char)

    def set_vtime(self, deciseconds: int = 0):
        """Set timeout for non-canonical read (in deciseconds)."""
        self._set_cc(termios.VTIME, deciseconds)

    def set_vmin(self, min_chars: int = 1):
        """Set minimum chars for non-canonical read."""
        self._set_cc(termios.VMIN, min_chars)

    def set_vstart(self, char: int = 17):
        """Set start character (default ^Q)."""
        self._set_cc(termios.VSTART, char)

    def set_vstop(self, char: int = 19):
        """Set stop character (default ^S)."""
        self._set_cc(termios.VSTOP, char)

    def set_vsusp(self, char: int = 26):
        """Set suspend character (default ^Z)."""
        self._set_cc(termios.VSUSP, char)

    def set_veol(self, char: int = 0):
        """Set EOL character."""
        self._set_cc(termios.VEOL, char)

    def set_vwerase(self, char: int = 23):
        """Set word erase character (default ^W)."""
        self._set_cc(termios.VWERASE, char)

    def set_vreprint(self, char: int = 18):
        """Set reprint character (default ^R)."""
        self._set_cc(termios.VREPRINT, char)

    def _set_cc(self, index: int, value: int):
        """Set a control character value."""
        if self.fd is None:
            return
        try:
            attrs = termios.tcgetattr(self.fd)
            attrs[6][index] = value
            termios.tcsetattr(self.fd, termios.TCSANOW, attrs)
        except (termios.error, OSError):
            pass

    def get_cc(self) -> Dict[str, int]:
        """Get all control characters."""
        if self.fd is None:
            return {}
        try:
            attrs = termios.tcgetattr(self.fd)
            cc = attrs[6]
            return {
                'vintr': cc[termios.VINTR],
                'vquit': cc[termios.VQUIT],
                'verase': cc[termios.VERASE],
                'vkill': cc[termios.VKILL],
                'veof': cc[termios.VEOF],
                'vtime': cc[termios.VTIME],
                'vmin': cc[termios.VMIN],
                'vstart': cc[termios.VSTART],
                'vstop': cc[termios.VSTOP],
                'vsusp': cc[termios.VSUSP],
                'veol': cc[termios.VEOL],
                'vreprint': cc[termios.VREPRINT],
                'vwerase': cc[termios.VWERASE],
            }
        except (termios.error, OSError):
            return {}

    def set_line_discipline(self, disc: int = 0):
        """Set line discipline (usually 0 = N_TTY)."""
        if self.fd is not None:
            try:
                import fcntl
                fcntl.ioctl(self.fd, termios.TIOCSETD, disc)
            except (OSError, ImportError):
                pass

    def get_line_discipline(self) -> int:
        """Get current line discipline number."""
        if self.fd is not None:
            try:
                import fcntl
                import array
                disc = array.array('i', [0])
                fcntl.ioctl(self.fd, termios.TIOCGETD, disc, True)
                return disc[0]
            except (OSError, ImportError):
                pass
        return 0

from __future__ import annotations
"""TtyConfigurator - configures TTY settings."""

import os
import termios
import tty
from typing import Dict, List, Optional


class TtyConfigurator:
    """Configures various terminal I/O settings."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd

    def set_fd(self, fd: int):
        self.fd = fd

    def get_attrs(self) -> Optional[list]:
        """Get current terminal attributes."""
        if self.fd is None:
            return None
        try:
            return termios.tcgetattr(self.fd)
        except termios.error:
            return None

    def set_attrs(self, attrs: list):
        """Set terminal attributes immediately."""
        if self.fd is not None:
            try:
                termios.tcsetattr(self.fd, termios.TCSANOW, attrs)
            except termios.error:
                pass

    def set_attrs_drain(self, attrs: list):
        """Set terminal attributes after draining output."""
        if self.fd is not None:
            try:
                termios.tcsetattr(self.fd, termios.TCSADRAIN, attrs)
            except termios.error:
                pass

    def set_attrs_flush(self, attrs: list):
        """Set terminal attributes after flushing."""
        if self.fd is not None:
            try:
                termios.tcsetattr(self.fd, termios.TCSAFLUSH, attrs)
            except termios.error:
                pass

    def set_local_modes(self, flags: Dict[str, bool]):
        """Set local mode flags (ECHO, ICANON, ISIG, etc)."""
        attrs = self.get_attrs()
        if attrs is None:
            return
        local = attrs[3]
        flag_map = {
            'echo': termios.ECHO,
            'icanon': termios.ICANON,
            'isig': termios.ISIG,
            'iexten': termios.IEXTEN,
        }
        for name, flag in flag_map.items():
            if name in flags:
                if flags[name]:
                    local |= flag
                else:
                    local &= ~flag
        attrs[3] = local
        self.set_attrs(attrs)

    def set_input_modes(self, flags: Dict[str, bool]):
        """Set input mode flags."""
        attrs = self.get_attrs()
        if attrs is None:
            return
        iflag = attrs[0]
        flag_map = {
            'ignbrk': termios.IGNBRK,
            'brkint': termios.BRKINT,
            'ignpar': termios.IGNPAR,
            'parmrk': termios.PARMRK,
            'inpck': termios.INPCK,
            'istrip': termios.ISTRIP,
            'inlcr': termios.INLCR,
            'igncr': termios.IGNCR,
            'icrnl': termios.ICRNL,
            'ixon': termios.IXON,
            'ixoff': termios.IXOFF,
        }
        for name, flag in flag_map.items():
            if name in flags:
                if flags[name]:
                    iflag |= flag
                else:
                    iflag &= ~flag
        attrs[0] = iflag
        self.set_attrs(attrs)

    def set_output_modes(self, flags: Dict[str, bool]):
        """Set output mode flags."""
        attrs = self.get_attrs()
        if attrs is None:
            return
        oflag = attrs[1]
        flag_map = {
            'opost': termios.OPOST,
            'onlcr': termios.ONLCR,
            'ocrnl': termios.OCRNL,
            'onocr': termios.ONOCR,
            'onlret': termios.ONLRET,
        }
        for name, flag in flag_map.items():
            if name in flags:
                if flags[name]:
                    oflag |= flag
                else:
                    oflag &= ~flag
        attrs[1] = oflag
        self.set_attrs(attrs)

    def set_control_modes(self, flags: Dict[str, bool]):
        """Set control mode flags."""
        attrs = self.get_attrs()
        if attrs is None:
            return
        cflag = attrs[2]
        flag_map = {
            'cs8': termios.CS8,
            'cs7': termios.CS7,
            'cstopb': termios.CSTOPB,
            'cread': termios.CREAD,
            'parenb': termios.PARENB,
            'hupcl': termios.HUPCL,
            'clocal': termios.CLOCAL,
        }
        for name, flag in flag_map.items():
            if name in flags:
                if flags[name]:
                    cflag |= flag
                else:
                    cflag &= ~flag
        attrs[2] = cflag
        self.set_attrs(attrs)

    def set_cc(self, control_char: str, value: int):
        """Set a special control character."""
        attrs = self.get_attrs()
        if attrs is None:
            return
        cc = attrs[6]
        cc_map = {
            'vintr': termios.VINTR,
            'vquit': termios.VQUIT,
            'verase': termios.VERASE,
            'vkill': termios.VKILL,
            'veof': termios.VEOF,
            'vtime': termios.VTIME,
            'vmin': termios.VMIN,
            'vstart': termios.VSTART,
            'vstop': termios.VSTOP,
            'vsusp': termios.VSUSP,
            'veol': termios.VEOL,
            'vreprint': termios.VREPRINT,
            'vwerase': termios.VWERASE,
        }
        idx = cc_map.get(control_char)
        if idx is not None:
            cc[idx] = value
        attrs[6] = cc
        self.set_attrs(attrs)

    def drain(self):
        """Wait for all output to be transmitted."""
        if self.fd is not None:
            try:
                termios.tcdrain(self.fd)
            except termios.error:
                pass

    def flush_input(self):
        """Flush input data."""
        if self.fd is not None:
            try:
                termios.tcflush(self.fd, termios.TCIFLUSH)
            except termios.error:
                pass

    def flush_output(self):
        """Flush output data."""
        if self.fd is not None:
            try:
                termios.tcflush(self.fd, termios.TCOFLUSH)
            except termios.error:
                pass

    def flush_io(self):
        """Flush both input and output."""
        if self.fd is not None:
            try:
                termios.tcflush(self.fd, termios.TCIOFLUSH)
            except termios.error:
                pass

    def send_break(self, duration: float = 0.25):
        """Send a break signal."""
        if self.fd is not None:
            try:
                termios.tcsendbreak(self.fd, int(duration * 1000))
            except termios.error:
                pass

    def get_speed(self) -> Tuple[int, int]:
        """Get input and output baud rates."""
        if self.fd is None:
            return (0, 0)
        try:
            return (termios.cfgetispeed(self.fd), termios.cfgetospeed(self.fd))
        except termios.error:
            return (0, 0)

    def set_speed(self, baud: int):
        """Set both input and output baud rates."""
        if self.fd is not None:
            try:
                termios.cfsetispeed(self.fd, baud)
                termios.cfsetospeed(self.fd, baud)
            except termios.error:
                pass

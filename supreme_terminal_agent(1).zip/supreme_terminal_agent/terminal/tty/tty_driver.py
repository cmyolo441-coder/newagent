from __future__ import annotations
"""TtyDriver - serial/terminal driver level operations."""

import os
import termios
import fcntl
import struct
from typing import Dict, Optional, Tuple


class TtyDriver:
    """Low-level TTY driver operations."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd

    def set_fd(self, fd: int):
        self.fd = fd

    def modem_status(self) -> Dict[str, bool]:
        """Get modem status lines."""
        if self.fd is None:
            return {}
        try:
            status = fcntl.ioctl(self.fd, termios.TIOCMGET, struct.pack('I', 0))
            bits = struct.unpack('I', status)[0]
            return {
                'dtr': bool(bits & termios.TIOCM_DTR),
                'rts': bool(bits & termios.TIOCM_RTS),
                'cts': bool(bits & termios.TIOCM_CTS),
                'dsr': bool(bits & termios.TIOCM_DSR),
                'ri': bool(bits & termios.TIOCM_RI),
                'dcd': bool(bits & termios.TIOCM_CD),
            }
        except (OSError, struct.error):
            return {}

    def set_modem_lines(self, dtr: Optional[bool] = None, rts: Optional[bool] = None):
        """Set modem control lines."""
        if self.fd is None:
            return
        try:
            status = fcntl.ioctl(self.fd, termios.TIOCMGET, struct.pack('I', 0))
            bits = struct.unpack('I', status)[0]
            if dtr is not None:
                if dtr:
                    bits |= termios.TIOCM_DTR
                else:
                    bits &= ~termios.TIOCM_DTR
            if rts is not None:
                if rts:
                    bits |= termios.TIOCM_RTS
                else:
                    bits &= ~termios.TIOCM_RTS
            fcntl.ioctl(self.fd, termios.TIOCMSET, struct.pack('I', bits))
        except OSError:
            pass

    def set_dtr(self, state: bool):
        """Set Data Terminal Ready."""
        self.set_modem_lines(dtr=state)

    def set_rts(self, state: bool):
        """Set Request To Send."""
        self.set_modem_lines(rts=state)

    def wait_for_modem(self, mask: int = 0, timeout: int = 0) -> bool:
        """Wait for modem status change."""
        if self.fd is None:
            return False
        try:
            fcntl.ioctl(self.fd, termios.TIOCMIWAIT, mask)
            return True
        except OSError:
            return False

    def is_pty(self) -> bool:
        """Check if the fd is a pseudo-terminal."""
        if self.fd is None:
            return False
        try:
            return os.isatty(self.fd) and not os.open('/dev/tty', os.O_RDONLY)
        except OSError:
            return os.isatty(self.fd)

    def get_driver_info(self) -> Dict[str, object]:
        """Get driver information."""
        return {
            'isatty': os.isatty(self.fd) if self.fd else False,
            'fd': self.fd,
            'modem_status': self.modem_status(),
        }

    def send_break(self, duration_ms: int = 250):
        """Send a break signal."""
        if self.fd is not None:
            try:
                termios.tcsendbreak(self.fd, duration_ms)
            except termios.error:
                pass

    def drain(self):
        """Drain output."""
        if self.fd is not None:
            try:
                termios.tcdrain(self.fd)
            except termios.error:
                pass

    def flush(self, queue_selector: int = 2):
        """Flush I/O queues. 0=input, 1=output, 2=both."""
        if self.fd is not None:
            try:
                termios.tcflush(self.fd, queue_selector)
            except termios.error:
                pass

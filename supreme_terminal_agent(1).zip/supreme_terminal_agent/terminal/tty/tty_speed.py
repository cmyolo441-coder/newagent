from __future__ import annotations
"""TtySpeed - manages terminal baud rate / speed settings."""

import os
import termios
from typing import Dict, Optional, Tuple


class TtySpeed:
    """Manages terminal baud rate (speed) settings."""

    BAUDS = {
        0: termios.B0, 50: termios.B50, 75: termios.B75,
        110: termios.B110, 134: termios.B134, 150: termios.B150,
        200: termios.B200, 300: termios.B300, 600: termios.B600,
        1200: termios.B1200, 1800: termios.B1800, 2400: termios.B2400,
        4800: termios.B4800, 9600: termios.B9600, 19200: termios.B19200,
        38400: termios.B38400, 57600: termios.B57600,
        115200: termios.B115200, 230400: termios.B230400,
    }

    REVERSE_BAUDS = {v: k for k, v in BAUDS.items()}

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd

    def set_fd(self, fd: int):
        self.fd = fd

    def get_speed(self) -> Tuple[int, int]:
        """Get (input_speed, output_speed) in baud."""
        if self.fd is None:
            return (0, 0)
        try:
            ispeed = termios.cfgetispeed(self.fd)
            ospeed = termios.cfgetospeed(self.fd)
            return (self.REVERSE_BAUDS.get(ispeed, 0),
                    self.REVERSE_BAUDS.get(ospeed, 0))
        except (termios.error, OSError):
            return (0, 0)

    def set_input_speed(self, baud: int) -> bool:
        """Set input baud rate."""
        if self.fd is None:
            return False
        baud_const = self.BAUDS.get(baud)
        if baud_const is None:
            return False
        try:
            termios.cfsetispeed(self.fd, baud_const)
            return True
        except (termios.error, OSError):
            return False

    def set_output_speed(self, baud: int) -> bool:
        """Set output baud rate."""
        if self.fd is None:
            return False
        baud_const = self.BAUDS.get(baud)
        if baud_const is None:
            return False
        try:
            termios.cfsetospeed(self.fd, baud_const)
            return True
        except (termios.error, OSError):
            return False

    def set_speed(self, baud: int) -> bool:
        """Set both input and output baud rate."""
        return self.set_input_speed(baud) and self.set_output_speed(baud)

    def set_ospeed(self, baud: int):
        """Alias for set_output_speed."""
        return self.set_output_speed(baud)

    def get_ospeed_value(self) -> int:
        """Output speed."""
        _, ospeed = self.get_speed()
        return ospeed

    def get_ispeed_value(self) -> int:
        """Input speed."""
        ispeed, _ = self.get_speed()
        return ispeed

    def validate_baud(self, baud: int) -> bool:
        """Check if a baud rate is valid."""
        return baud in self.BAUDS

    def list_valid_bauds(self) -> list:
        """List all valid baud rates."""
        return sorted(self.BAUDS.keys())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

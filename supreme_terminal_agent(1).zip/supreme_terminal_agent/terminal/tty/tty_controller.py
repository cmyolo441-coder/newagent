from __future__ import annotations
"""TtyController - high-level controller for TTY configuration."""

import os
import termios
import tty
import fcntl
import struct
from typing import Optional, Tuple

from terminal.tty.tty_configurator import TtyConfigurator
from terminal.tty.tty_mode_handler import TtyModeHandler


class TtyController:
    """High-level controller for terminal TTY configuration."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd
        self.configurator = TtyConfigurator(fd)
        self.mode_handler = TtyModeHandler(fd)
        self._original_attrs: Optional[list] = None

    def set_fd(self, fd: int):
        """Set the TTY fd."""
        self.fd = fd
        self.configurator.fd = fd
        self.mode_handler.fd = fd

    def save_state(self):
        """Save current terminal attributes."""
        if self.fd is not None:
            try:
                self._original_attrs = termios.tcgetattr(self.fd)
            except termios.error:
                pass

    def restore_state(self):
        """Restore previously saved terminal attributes."""
        if self.fd is not None and self._original_attrs is not None:
            try:
                termios.tcsetattr(self.fd, termios.TCSANOW, self._original_attrs)
            except termios.error:
                pass

    def set_raw(self):
        """Set terminal to raw mode."""
        if self.fd is not None:
            tty.setraw(self.fd)

    def set_cbreak(self):
        """Set terminal to cbreak mode."""
        if self.fd is not None:
            tty.setcbreak(self.fd)

    def set_cooked(self):
        """Set terminal to cooked mode."""
        if self.fd is not None and self._original_attrs is not None:
            try:
                termios.tcsetattr(self.fd, termios.TCSANOW, self._original_attrs)
            except termios.error:
                pass

    def get_size(self) -> Tuple[int, int]:
        """Get terminal size (rows, cols)."""
        if self.fd is None:
            return (24, 80)
        try:
            buf = struct.pack('HHHH', 0, 0, 0, 0)
            result = fcntl.ioctl(self.fd, termios.TIOCGWINSZ, buf)
            rows, cols = struct.unpack('HHHH', result)[:2]
            return (rows or 24, cols or 80)
        except (OSError, struct.error):
            return (24, 80)

    def set_size(self, rows: int, cols: int):
        """Set terminal size."""
        if self.fd is not None:
            try:
                buf = struct.pack('HHHH', rows, cols, 0, 0)
                fcntl.ioctl(self.fd, termios.TIOCSWINSZ, buf)
            except OSError:
                pass

    @property
    def isatty(self) -> bool:
        if self.fd is None:
            return False
        return os.isatty(self.fd)

    def close(self):
        """Restore state and release."""
        self.restore_state()
        self.fd = None

from __future__ import annotations
"""TtyModeHandler - manages terminal mode transitions."""

import os
import termios
import tty
from enum import Enum
from typing import Optional

from terminal.tty.tty_raw_mode import TtyRawMode
from terminal.tty.tty_cooked_mode import TtyCookedMode
from terminal.tty.tty_cbreak_mode import TtyCBreakMode


class TerminalMode(Enum):
    RAW = "raw"
    COOKED = "cooked"
    CBREAK = "cbreak"


class TtyModeHandler:
    """Handles switching between terminal modes."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd
        self._current_mode: Optional[TerminalMode] = None
        self._saved_attrs: Optional[list] = None
        self.raw_mode = TtyRawMode(fd)
        self.cooked_mode = TtyCookedMode(fd)
        self.cbreak_mode = TtyCBreakMode(fd)

    def set_fd(self, fd: int):
        self.fd = fd
        self.raw_mode.fd = fd
        self.cooked_mode.fd = fd
        self.cbreak_mode.fd = fd

    def save(self):
        """Save current terminal attributes."""
        if self.fd is not None:
            try:
                self._saved_attrs = termios.tcgetattr(self.fd)
            except termios.error:
                pass

    def restore(self):
        """Restore previously saved attributes."""
        if self.fd is not None and self._saved_attrs is not None:
            try:
                termios.tcsetattr(self.fd, termios.TCSANOW, self._saved_attrs)
                self._current_mode = TerminalMode.COOKED
            except termios.error:
                pass

    def set_raw(self):
        """Switch to raw mode."""
        if self.fd is None:
            return
        if self._current_mode == TerminalMode.RAW:
            return
        if self._current_mode is None:
            self.save()
        self.raw_mode.enter()
        self._current_mode = TerminalMode.RAW

    def set_cooked(self):
        """Switch to cooked mode."""
        if self.fd is None:
            return
        if self._current_mode == TerminalMode.COOKED:
            return
        self.cooked_mode.enter()
        self._current_mode = TerminalMode.COOKED

    def set_cbreak(self):
        """Switch to cbreak mode."""
        if self.fd is None:
            return
        if self._current_mode == TerminalMode.CBREAK:
            return
        if self._current_mode is None:
            self.save()
        self.cbreak_mode.enter()
        self._current_mode = TerminalMode.CBREAK

    @property
    def current_mode(self) -> Optional[TerminalMode]:
        return self._current_mode

    @property
    def is_raw(self) -> bool:
        return self._current_mode == TerminalMode.RAW

    @property
    def is_cooked(self) -> bool:
        return self._current_mode == TerminalMode.COOKED

    @property
    def is_cbreak(self) -> bool:
        return self._current_mode == TerminalMode.CBREAK

    def close(self):
        """Restore and release."""
        self.restore()
        self.fd = None

from __future__ import annotations
"""TtyCBreakMode - cbreak terminal mode (between raw and cooked)."""

import os
import termios
from typing import Optional


class TtyCBreakMode:
    """Manages cbreak terminal mode (character-at-a-time but with signal processing)."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd
        self._previous: Optional[list] = None

    def set_fd(self, fd: int):
        self.fd = fd

    def enter(self):
        """Enter cbreak mode."""
        if self.fd is None:
            return
        try:
            self._previous = termios.tcgetattr(self.fd)
            attrs = termios.tcgetattr(self.fd)
            attrs[0] &= ~(termios.IGNBRK | termios.BRKINT | termios.PARMRK | termios.ISTRIP
                          | termios.INLCR | termios.IGNCR | termios.ICRNL | termios.IXON)
            attrs[1] &= ~termios.OPOST
            attrs[3] &= ~(termios.ECHO | termios.ECHOE | termios.ECHOK | termios.ECHONL | termios.ICANON)
            attrs[3] |= termios.ISIG
            attrs[6][termios.VMIN] = 1
            attrs[6][termios.VTIME] = 0
            termios.tcsetattr(self.fd, termios.TCSANOW, attrs)
        except termios.error:
            pass

    def exit(self):
        """Exit cbreak mode."""
        if self.fd is not None and self._previous is not None:
            try:
                termios.tcsetattr(self.fd, termios.TCSANOW, self._previous)
            except termios.error:
                pass

    def get_flags(self) -> dict:
        """Get the cbreak mode flag configuration."""
        return {
            'iflag': {
                'ignbrk': True, 'brkint': False, 'parmrk': False,
                'istrip': False, 'inlcr': False, 'igncr': False,
                'icrnl': False, 'ixon': False,
            },
            'oflag': {
                'opost': False,
            },
            'lflag': {
                'echo': False, 'icanon': False, 'isig': True,
            },
            'cc': {
                'vmin': 1, 'vtime': 0,
            },
        }

    def __enter__(self):
        self.enter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.exit()

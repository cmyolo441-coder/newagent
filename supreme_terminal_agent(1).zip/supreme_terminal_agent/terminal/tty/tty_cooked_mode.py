from __future__ import annotations
"""TtyCookedMode - cooked (canonical) terminal mode."""

import os
import termios
from typing import Optional


class TtyCookedMode:
    """Manages cooked (canonical) terminal mode (line-buffered, echo)."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd

    def set_fd(self, fd: int):
        self.fd = fd

    def enter(self):
        """Enter cooked mode: enable canonical processing, echo."""
        if self.fd is None:
            return
        try:
            attrs = termios.tcgetattr(self.fd)
            attrs[0] |= termios.ICRNL
            attrs[1] |= termios.OPOST | termios.ONLCR
            attrs[3] |= termios.ECHO | termios.ECHOE | termios.ECHOK | termios.ICANON | termios.ISIG
            termios.tcsetattr(self.fd, termios.TCSANOW, attrs)
        except termios.error:
            pass

    def get_flags(self) -> dict:
        """Get the cooked mode flag configuration."""
        return {
            'iflag': {
                'icrnl': True,
            },
            'oflag': {
                'opost': True, 'onlcr': True,
            },
            'lflag': {
                'echo': True, 'echoe': True, 'echok': True,
                'icanon': True, 'isig': True, 'iexten': True,
            },
        }

    def __enter__(self):
        self.enter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

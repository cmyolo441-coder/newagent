from __future__ import annotations
"""TtyVirtual - virtual TTY implementation for testing and simulation."""

import os
import io
import termios
import tty
import errno
from typing import Dict, Optional, Tuple


class TtyVirtual:
    """A virtual TTY that simulates terminal behavior without a real TTY device."""

    def __init__(self, rows: int = 24, cols: int = 80):
        self.rows = rows
        self.cols = cols
        self._input_buffer = io.BytesIO()
        self._output_buffer = io.BytesIO()
        self._attrs = self._default_attrs()
        self._mode = 'cooked'

    def _default_attrs(self) -> list:
        """Create default terminal attributes."""
        iflag = 0
        oflag = termios.OPOST | termios.ONLCR
        cflag = termios.CS8 | termios.CREAD
        lflag = termios.ECHO | termios.ECHOE | termios.ECHOK | termios.ICANON | termios.ISIG | termios.IEXTEN
        ispeed = termios.B38400
        ospeed = termios.B38400
        cc = [0] * 32
        cc[termios.VINTR] = 3
        cc[termios.VQUIT] = 28
        cc[termios.VERASE] = 127
        cc[termios.VKILL] = 21
        cc[termios.VEOF] = 4
        cc[termios.VTIME] = 0
        cc[termios.VMIN] = 1
        cc[termios.VSTART] = 17
        cc[termios.VSTOP] = 19
        cc[termios.VSUSP] = 26
        cc[termios.VEOL] = 0
        cc[termios.VWERASE] = 23
        cc[termios.VREPRINT] = 18
        return [iflag, oflag, cflag, lflag, ispeed, ospeed, cc]

    def read(self, size: int = 4096) -> bytes:
        """Read from virtual input buffer."""
        return self._input_buffer.read(size)

    def write(self, data: bytes) -> int:
        """Write to virtual output buffer."""
        if self._mode == 'cooked':
            processed = self._cooked_output(data)
        else:
            processed = data
        return self._output_buffer.write(processed)

    def write_to_input(self, data: bytes) -> int:
        """Write data to the virtual input (simulating user input)."""
        return self._input_buffer.write(data)

    def read_output(self, size: int = 4096) -> bytes:
        """Read accumulated output."""
        return self._output_buffer.read(size)

    def _cooked_output(self, data: bytes) -> bytes:
        """Process output in cooked mode."""
        result = bytearray()
        for byte in data:
            if byte == ord('\n'):
                result.extend(b'\r\n')
            else:
                result.append(byte)
        return bytes(result)

    def get_size(self) -> Tuple[int, int]:
        return (self.rows, self.cols)

    def set_size(self, rows: int, cols: int):
        self.rows = rows
        self.cols = cols

    def tcgetattr(self) -> list:
        return self._attrs

    def tcsetattr(self, when: int, attrs: list):
        self._attrs = list(attrs)
        if attrs[3] & termios.ICANON:
            self._mode = 'cooked'
        elif attrs[3] & termios.ISIG:
            self._mode = 'cbreak'
        else:
            self._mode = 'raw'

    def set_raw(self):
        """Set virtual terminal to raw mode."""
        iflag = 0
        oflag = 0
        cflag = termios.CS8 | termios.CREAD
        lflag = 0
        cc = [0] * 32
        cc[termios.VMIN] = 1
        cc[termios.VTIME] = 0
        self._attrs = [iflag, oflag, cflag, lflag, termios.B38400, termios.B38400, cc]
        self._mode = 'raw'

    def set_cbreak(self):
        """Set virtual terminal to cbreak mode."""
        iflag = 0
        oflag = 0
        cflag = termios.CS8 | termios.CREAD
        lflag = termios.ISIG
        cc = [0] * 32
        cc[termios.VMIN] = 1
        cc[termios.VTIME] = 0
        self._attrs = [iflag, oflag, cflag, lflag, termios.B38400, termios.B38400, cc]
        self._mode = 'cbreak'

    def clear_output(self):
        """Clear the output buffer."""
        self._output_buffer = io.BytesIO()

    def clear_input(self):
        """Clear the input buffer."""
        self._input_buffer = io.BytesIO()

    @property
    def output_data(self) -> bytes:
        return self._output_buffer.getvalue()

    @property
    def input_data(self) -> bytes:
        return self._input_buffer.getvalue()

    @property
    def mode(self) -> str:
        return self._mode

    def close(self):
        """Close virtual TTY."""
        self._input_buffer.close()
        self._output_buffer.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

from __future__ import annotations
"""TtyAttributes - wrapper for termios terminal attribute manipulation."""

import os
import termios
from typing import Dict, List, Optional, Tuple


class TtyAttributes:
    """Encapsulates terminal I/O attributes with easy access to flags and settings."""

    def __init__(self, fd: Optional[int] = None):
        self.fd = fd
        self._iflag: int = 0
        self._oflag: int = 0
        self._cflag: int = 0
        self._lflag: int = 0
        self._ispeed: int = 0
        self._ospeed: int = 0
        self._cc: List[int] = [0] * 32

    def load(self):
        """Load attributes from the terminal fd."""
        if self.fd is None:
            return False
        try:
            attrs = termios.tcgetattr(self.fd)
            self._iflag = attrs[0]
            self._oflag = attrs[1]
            self._cflag = attrs[2]
            self._lflag = attrs[3]
            self._ispeed = attrs[4]
            self._ospeed = attrs[5]
            self._cc = list(attrs[6])
            return True
        except (termios.error, OSError):
            return False

    def apply(self):
        """Apply attributes to the terminal fd."""
        if self.fd is None:
            return False
        try:
            attrs = [self._iflag, self._oflag, self._cflag, self._lflag,
                     self._ispeed, self._ospeed, self._cc]
            termios.tcsetattr(self.fd, termios.TCSANOW, attrs)
            return True
        except (termios.error, OSError):
            return False

    def to_dict(self) -> Dict[str, dict]:
        """Convert attributes to a dictionary."""
        return {
            'iflag': {
                'ignbrk': bool(self._iflag & termios.IGNBRK),
                'brkint': bool(self._iflag & termios.BRKINT),
                'ignpar': bool(self._iflag & termios.IGNPAR),
                'parmrk': bool(self._iflag & termios.PARMRK),
                'inpck': bool(self._iflag & termios.INPCK),
                'istrip': bool(self._iflag & termios.ISTRIP),
                'inlcr': bool(self._iflag & termios.INLCR),
                'igncr': bool(self._iflag & termios.IGNCR),
                'icrnl': bool(self._iflag & termios.ICRNL),
                'ixon': bool(self._iflag & termios.IXON),
                'ixoff': bool(self._iflag & termios.IXOFF),
            },
            'oflag': {
                'opost': bool(self._oflag & termios.OPOST),
                'onlcr': bool(self._oflag & termios.ONLCR),
                'ocrnl': bool(self._oflag & termios.OCRNL),
                'onocr': bool(self._oflag & termios.ONOCR),
                'onlret': bool(self._oflag & termios.ONLRET),
            },
            'cflag': {
                'cs8': bool(self._cflag & termios.CS8),
                'cs7': bool(self._cflag & termios.CS7),
                'cstopb': bool(self._cflag & termios.CSTOPB),
                'cread': bool(self._cflag & termios.CREAD),
                'parenb': bool(self._cflag & termios.PARENB),
                'hupcl': bool(self._cflag & termios.HUPCL),
                'clocal': bool(self._cflag & termios.CLOCAL),
            },
            'lflag': {
                'echo': bool(self._lflag & termios.ECHO),
                'echoe': bool(self._lflag & termios.ECHOE),
                'echok': bool(self._lflag & termios.ECHOK),
                'echonl': bool(self._lflag & termios.ECHONL),
                'icanon': bool(self._lflag & termios.ICANON),
                'isig': bool(self._lflag & termios.ISIG),
                'iexten': bool(self._lflag & termios.IEXTEN),
            },
        }

    @property
    def iflag(self) -> int:
        return self._iflag

    @iflag.setter
    def iflag(self, value: int):
        self._iflag = value

    @property
    def oflag(self) -> int:
        return self._oflag

    @oflag.setter
    def oflag(self, value: int):
        self._oflag = value

    @property
    def cflag(self) -> int:
        return self._cflag

    @cflag.setter
    def cflag(self, value: int):
        self._cflag = value

    @property
    def lflag(self) -> int:
        return self._lflag

    @lflag.setter
    def lflag(self, value: int):
        self._lflag = value

    @property
    def ispeed(self) -> int:
        return self._ispeed

    @ispeed.setter
    def ispeed(self, value: int):
        self._ispeed = value

    @property
    def ospeed(self) -> int:
        return self._ospeed

    @ospeed.setter
    def ospeed(self, value: int):
        self._ospeed = value

    @property
    def cc(self) -> List[int]:
        return self._cc

    @cc.setter
    def cc(self, value: List[int]):
        self._cc = list(value)

"""TerminalCapabilities - detects and models terminal feature capabilities."""

import os
import re
import struct
import sys
import termios
import threading
from enum import Flag, auto
from typing import Dict, List, Optional, Set, Tuple


class ColorCapability(Flag):
    MONOCHROME = 0
    ANSI_16 = auto()
    ANSI_256 = auto()
    TRUECOLOR = auto()


class TerminalFeature(Flag):
    NONE = 0
    CURSOR_POSITION = auto()
    CURSOR_VISIBILITY = auto()
    CURSOR_STYLE = auto()
    ALTERNATE_SCREEN = auto()
    SCROLLBACK = auto()
    BRACKETED_PASTE = auto()
    MOUSE_TRACKING = auto()
    MOUSE_SGR = auto()
    MOUSE_URXVT = auto()
    APPLICATION_KEYPAD = auto()
    APPLICATION_CURSOR = auto()
    SIXEL_GRAPHICS = auto()
    KITTY_GRAPHICS = auto()
    ITERM2_GRAPHICS = auto()
    SYNCHRONIZED_UPDATE = auto()
    FOCUS_EVENTS = auto()
    RESIZE_EVENTS = auto()
    CLIPBOARD_READ = auto()
    CLIPBOARD_WRITE = auto()
    OSC_8_HYPERLINKS = auto()
    DA1 = auto()
    DA2 = auto()
    DA3 = auto()
    TABS = auto()
    SOFT_RESET = auto()
    HARD_RESET = auto()
    SAVE_CURSOR = auto()
    TITLE_SET = auto()
    COLOR_QUERY = auto()
    DYNAMIC_COLOR = auto()
    WIN32_KEEP_OPEN = auto()


_TERMINFO_CACHE: Dict[str, Optional[str]] = {}


class TerminalCapabilities:
    """Detects and exposes terminal emulator capabilities."""

    def __init__(self, term_env: Optional[str] = None):
        self._term = term_env or os.environ.get("TERM", "unknown")
        self._color_term = os.environ.get("COLORTERM", "")
        self._tmux = "TMUX" in os.environ
        self._screen = "TERM" in os.environ and "screen" in os.environ["TERM"]
        self._colors: ColorCapability = ColorCapability.MONOCHROME
        self._features: TerminalFeature = TerminalFeature.NONE
        self._lock = threading.RLock()
        self._detect()

    @property
    def term(self) -> str:
        return self._term

    @property
    def colors(self) -> ColorCapability:
        return self._colors

    @property
    def features(self) -> TerminalFeature:
        return self._features

    @property
    def color_count(self) -> int:
        colors = self._colors
        if ColorCapability.TRUECOLOR in colors:
            return 16777216
        if ColorCapability.ANSI_256 in colors:
            return 256
        if ColorCapability.ANSI_16 in colors:
            return 16
        return 2

    def has_feature(self, feature: TerminalFeature) -> bool:
        return feature in self._features

    def has_color(self, color_cap: ColorCapability) -> bool:
        return color_cap in self._colors

    def supports_truecolor(self) -> bool:
        return ColorCapability.TRUECOLOR in self._colors

    def supports_256color(self) -> bool:
        return ColorCapability.ANSI_256 in self._colors or self.supports_truecolor()

    def supports_sixel(self) -> bool:
        return TerminalFeature.SIXEL_GRAPHICS in self._features

    def supports_kitty(self) -> bool:
        return TerminalFeature.KITTY_GRAPHICS in self._features

    def supports_iterm2(self) -> bool:
        return TerminalFeature.ITERM2_GRAPHICS in self._features

    def supports_mouse(self) -> bool:
        return (
            TerminalFeature.MOUSE_TRACKING in self._features
            or TerminalFeature.MOUSE_SGR in self._features
        )

    def supports_bracketed_paste(self) -> bool:
        return TerminalFeature.BRACKETED_PASTE in self._features

    def supports_hyperlinks(self) -> bool:
        return TerminalFeature.OSC_8_HYPERLINKS in self._features

    def supports_focus_events(self) -> bool:
        return TerminalFeature.FOCUS_EVENTS in self._features

    def is_tmux(self) -> bool:
        return self._tmux

    def is_screen(self) -> bool:
        return self._screen

    @staticmethod
    def get_terminfo(key: str) -> Optional[str]:
        """Query terminfo capability via tput."""
        if key in _TERMINFO_CACHE:
            return _TERMINFO_CACHE[key]
        try:
            import subprocess
            result = subprocess.run(
                ["tput", key], capture_output=True, text=True, timeout=1
            )
            value: Optional[str] = result.stdout.strip()
            _TERMINFO_CACHE[key] = value if value else None
            return _TERMINFO_CACHE[key]
        except (subprocess.SubprocessError, FileNotFoundError):
            _TERMINFO_CACHE[key] = None
            return None

    @staticmethod
    def detect_ioctl() -> Dict[str, int]:
        """Detect terminal size via ioctl."""
        import fcntl
        try:
            packed = fcntl.ioctl(sys.stdout.fileno(), termios.TIOCGWINSZ, struct.pack("HHHH", 0, 0, 0, 0))
            rows, cols, xpix, ypix = struct.unpack("HHHH", packed)
            return {"rows": rows, "cols": cols, "width": xpix, "height": ypix}
        except (OSError, struct.error):
            return {"rows": 24, "cols": 80, "width": 0, "height": 0}

    def _detect(self):
        """Auto-detect capabilities from environment and terminfo."""
        with self._lock:
            self._detect_colors()
            self._detect_features()

    def _detect_colors(self):
        """Detect color depth supported by the terminal."""
        if self._color_term:
            ct = self._color_term.lower()
            if "truecolor" in ct or "24bit" in ct:
                self._colors |= ColorCapability.TRUECOLOR
                self._colors |= ColorCapability.ANSI_256
                self._colors |= ColorCapability.ANSI_16
                return

        if "256color" in self._term or "256" in self._term:
            self._colors |= ColorCapability.ANSI_256
            self._colors |= ColorCapability.ANSI_16
            return

        term_colors = self.get_terminfo("colors")
        if term_colors:
            n = int(term_colors)
            if n >= 16777216:
                self._colors |= ColorCapability.TRUECOLOR
                self._colors |= ColorCapability.ANSI_256
                self._colors |= ColorCapability.ANSI_16
            elif n >= 256:
                self._colors |= ColorCapability.ANSI_256
                self._colors |= ColorCapability.ANSI_16
            elif n >= 16:
                self._colors |= ColorCapability.ANSI_16
            elif n >= 8:
                self._colors |= ColorCapability.ANSI_16
            return

        if "xterm" in self._term or "xterm-256color" in self._term:
            self._colors |= ColorCapability.ANSI_256
            self._colors |= ColorCapability.ANSI_16
            return

        if os.name == "nt":
            import ctypes
            kernel32 = ctypes.windll.kernel32
            if hasattr(kernel32, "GetConsoleMode"):
                self._colors |= ColorCapability.ANSI_16
                if hasattr(kernel32, "SetConsoleColorAttribute"):
                    self._colors |= ColorCapability.ANSI_256
                return

        self._colors = ColorCapability.ANSI_16

    def _detect_features(self):
        """Detect advanced terminal features."""
        self._features = TerminalFeature.NONE

        if self.get_terminfo("civis"):
            self._features |= TerminalFeature.CURSOR_VISIBILITY
            self._features |= TerminalFeature.CURSOR_POSITION
            self._features |= TerminalFeature.CURSOR_STYLE
            self._features |= TerminalFeature.SAVE_CURSOR
            self._features |= TerminalFeature.TITLE_SET
            self._features |= TerminalFeature.SOFT_RESET
            self._features |= TerminalFeature.HARD_RESET

        if self.get_terminfo("smcup"):
            self._features |= TerminalFeature.ALTERNATE_SCREEN

        if self.get_terminfo("Smulx"):
            self._features |= TerminalFeature.CURSOR_STYLE

        if self._term and ("xterm" in self._term or "kitty" in self._term):
            self._features |= TerminalFeature.CURSOR_POSITION
            self._features |= TerminalFeature.CURSOR_VISIBILITY
            self._features |= TerminalFeature.CURSOR_STYLE
            self._features |= TerminalFeature.ALTERNATE_SCREEN
            self._features |= TerminalFeature.BRACKETED_PASTE
            self._features |= TerminalFeature.MOUSE_TRACKING
            self._features |= TerminalFeature.MOUSE_SGR
            self._features |= TerminalFeature.APPLICATION_KEYPAD
            self._features |= TerminalFeature.APPLICATION_CURSOR
            self._features |= TerminalFeature.FOCUS_EVENTS
            self._features |= TerminalFeature.SAVE_CURSOR
            self._features |= TerminalFeature.TITLE_SET
            self._features |= TerminalFeature.TABS
            self._features |= TerminalFeature.SOFT_RESET
            self._features |= TerminalFeature.HARD_RESET
            self._features |= TerminalFeature.DA1
            self._features |= TerminalFeature.DA2
            self._features |= TerminalFeature.RESIZE_EVENTS
            self._features |= TerminalFeature.CLIPBOARD_WRITE
            self._features |= TerminalFeature.OSC_8_HYPERLINKS
            self._features |= TerminalFeature.DYNAMIC_COLOR

        if "kitty" in self._term:
            self._features |= TerminalFeature.KITTY_GRAPHICS
            self._features |= TerminalFeature.SYNCHRONIZED_UPDATE
            self._features |= TerminalFeature.DA3
            self._features |= TerminalFeature.COLOR_QUERY

        if "iterm" in self._term or "iTerm2" in self._term:
            self._features |= TerminalFeature.ITERM2_GRAPHICS
            self._features |= TerminalFeature.CLIPBOARD_READ
            self._features |= TerminalFeature.COLOR_QUERY

        if "mlterm" in self._term:
            self._features |= TerminalFeature.MOUSE_URXVT

        if self._tmux:
            self._features |= TerminalFeature.ALTERNATE_SCREEN
            self._features |= TerminalFeature.BRACKETED_PASTE
            self._features |= TerminalFeature.MOUSE_TRACKING
            self._features |= TerminalFeature.MOUSE_SGR
            self._features |= TerminalFeature.CURSOR_VISIBILITY
            self._features |= TerminalFeature.CURSOR_STYLE
            self._features |= TerminalFeature.SAVE_CURSOR
            self._features |= TerminalFeature.TITLE_SET
            self._features |= TerminalFeature.TABS

        if os.name == "nt":
            self._features |= TerminalFeature.CURSOR_VISIBILITY
            self._features |= TerminalFeature.CURSOR_STYLE
            self._features |= TerminalFeature.TITLE_SET

        if "vscode" in os.environ.get("TERM_PROGRAM", "").lower():
            self._features |= TerminalFeature.TRUECOLOR
            self._features |= TerminalFeature.HYPERLINKS

    def to_dict(self) -> Dict:
        with self._lock:
            return {
                "term": self._term,
                "color_term": self._color_term,
                "colors": [c.name for c in ColorCapability if c in self._colors and c.value > 0],
                "color_count": self.color_count,
                "features": [f.name for f in TerminalFeature if f in self._features and f.value > 0],
                "tmux": self._tmux,
                "screen": self._screen,
            }

    def __repr__(self) -> str:
        return (
            f"TerminalCapabilities(term={self._term!r}, "
            f"colors={self._colors!r}, "
            f"features={self._features!r})"
        )

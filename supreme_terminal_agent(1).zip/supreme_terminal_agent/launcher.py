"""
Agent launcher - starts the agent in various modes
"""
import sys
from core.orchestrator import Orchestrator
from config import Config

def launch(mode="interactive"):
    config = Config.load()
    orch = Orchestrator(config)
    if mode == "daemon":
        orch.start_daemon()
    elif mode == "repl":
        orch.start_repl()
    else:
        orch.start_interactive()

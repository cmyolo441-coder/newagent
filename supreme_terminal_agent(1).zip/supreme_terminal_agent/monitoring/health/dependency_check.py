import time
import logging
from typing import Any, Dict, List, Optional, Callable, Awaitable
from dataclasses import dataclass


@dataclass
class Dependency:
    name: str
    check_fn: Callable[[], Awaitable[bool]]
    required: bool = True
    timeout: float = 5.0
    last_check: float = 0.0
    last_status: bool = False
    latency: float = 0.0
    error: Optional[str] = None


class DependencyCheck:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._dependencies: Dict[str, Dependency] = {}

    def register(
        self,
        name: str,
        check_fn: Callable[[], Awaitable[bool]],
        required: bool = True,
        timeout: float = 5.0,
    ) -> Dependency:
        if name in self._dependencies:
            raise ValueError(f"Dependency '{name}' already registered")
        dep = Dependency(
            name=name,
            check_fn=check_fn,
            required=required,
            timeout=timeout,
        )
        self._dependencies[name] = dep
        return dep

    def unregister(self, name: str) -> None:
        self._dependencies.pop(name, None)

    def get(self, name: str) -> Optional[Dependency]:
        return self._dependencies.get(name)

    async def check(self, name: str) -> Dict[str, Any]:
        dep = self._dependencies.get(name)
        if not dep:
            return {"name": name, "status": "unknown", "error": "Not registered"}

        start = time.time()
        try:
            result = await dep.check_fn()
            latency = time.time() - start
            dep.last_status = result
            dep.last_check = time.time()
            dep.latency = latency
            dep.error = None
            return {
                "name": name,
                "status": "healthy" if result else "unhealthy",
                "required": dep.required,
                "latency": latency,
                "last_check": dep.last_check,
            }
        except Exception as e:
            latency = time.time() - start
            dep.last_status = False
            dep.last_check = time.time()
            dep.latency = latency
            dep.error = str(e)
            self._logger.error("Dependency check '%s' failed: %s", name, e)
            return {
                "name": name,
                "status": "unhealthy",
                "required": dep.required,
                "latency": latency,
                "error": str(e),
                "last_check": dep.last_check,
            }

    async def check_all(self) -> Dict[str, Dict[str, Any]]:
        results = {}
        for name in self._dependencies:
            results[name] = await self.check(name)
        return results

    async def check_required(self) -> bool:
        for name, dep in self._dependencies.items():
            if dep.required:
                result = await self.check(name)
                if result.get("status") != "healthy":
                    return False
        return True

    def all_healthy(self) -> bool:
        return all(
            dep.last_status for dep in self._dependencies.values() if dep.required
        )

    @property
    def dependency_count(self) -> int:
        return len(self._dependencies)

    @property
    def unhealthy_count(self) -> int:
        return sum(1 for dep in self._dependencies.values() if not dep.last_status)

import time
import logging
from typing import Any, Dict, Optional


class LivenessCheck:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._is_alive = True
        self._last_activity: float = time.time()
        self._timeout: float = 300.0
        self._custom_checks: list = []

    def set_timeout(self, timeout: float) -> None:
        self._timeout = timeout

    def mark_alive(self) -> None:
        self._is_alive = True
        self._last_activity = time.time()

    def mark_dead(self) -> None:
        self._is_alive = False

    def register_check(self, check_fn) -> None:
        self._custom_checks.append(check_fn)

    async def check(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "status": "healthy",
            "timestamp": time.time(),
            "last_activity": self._last_activity,
            "checks": {},
        }

        if not self._is_alive:
            result["status"] = "unhealthy"
            result["reason"] = "Marked as dead"
            return result

        elapsed = time.time() - self._last_activity
        if elapsed > self._timeout:
            result["status"] = "unhealthy"
            result["reason"] = f"No activity for {elapsed:.1f}s (timeout: {self._timeout}s)"
            return result

        for check_fn in self._custom_checks:
            try:
                if callable(check_fn):
                    check_result = check_fn()
                    check_name = getattr(check_fn, "__name__", str(check_fn))
                    result["checks"][check_name] = check_result
                    if check_result is False:
                        result["status"] = "unhealthy"
                        result["reason"] = f"Custom check '{check_name}' failed"
                        return result
            except Exception as e:
                result["status"] = "unhealthy"
                result["reason"] = f"Custom check error: {e}"
                return result

        return result

import time
import logging
from typing import Any, Dict, List, Optional, Callable


class SelfCheck:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._checks: Dict[str, Callable[[], bool]] = {}
        self._results: Dict[str, Any] = {}
        self._last_check_time: float = 0.0

    def register(self, name: str, check_fn: Callable[[], bool]) -> None:
        if name in self._checks:
            raise ValueError(f"Self-check '{name}' already registered")
        self._checks[name] = check_fn

    def unregister(self, name: str) -> None:
        self._checks.pop(name, None)

    def register_memory_check(self, threshold_mb: float = 500.0) -> None:
        def check_memory() -> bool:
            try:
                import psutil
                mem = psutil.Process().memory_info().rss / (1024 * 1024)
                return mem < threshold_mb
            except ImportError:
                return True
        self.register("memory", check_memory)

    def register_cpu_check(self, threshold_percent: float = 80.0) -> None:
        def check_cpu() -> bool:
            try:
                import psutil
                cpu = psutil.Process().cpu_percent(interval=0.1)
                return cpu < threshold_percent
            except ImportError:
                return True
        self.register("cpu", check_cpu)

    def register_disk_check(self, path: str = "/", threshold_percent: float = 90.0) -> None:
        def check_disk() -> bool:
            try:
                import psutil
                usage = psutil.disk_usage(path)
                return usage.percent < threshold_percent
            except ImportError:
                return True
        self.register("disk", check_disk)

    async def check(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "status": "healthy",
            "timestamp": time.time(),
            "checks": {},
            "failed_checks": [],
        }

        for name, check_fn in self._checks.items():
            try:
                check_result = check_fn()
                check_status = "passed" if check_result else "failed"
                result["checks"][name] = {
                    "status": check_status,
                    "passed": check_result,
                }
                if not check_result:
                    result["failed_checks"].append(name)
                    result["status"] = "unhealthy"
            except Exception as e:
                self._logger.error("Self-check '%s' error: %s", name, e)
                result["checks"][name] = {
                    "status": "error",
                    "error": str(e),
                }
                result["failed_checks"].append(name)
                result["status"] = "unhealthy"

        self._results = result
        self._last_check_time = time.time()
        return result

    def get_last_results(self) -> Dict[str, Any]:
        return dict(self._results)

    @property
    def is_healthy(self) -> bool:
        return self._results.get("status") == "healthy"

    @property
    def check_count(self) -> int:
        return len(self._checks)

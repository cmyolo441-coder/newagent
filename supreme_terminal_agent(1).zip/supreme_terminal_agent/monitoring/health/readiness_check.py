import time
import logging
from typing import Any, Dict, List, Optional


class ReadinessCheck:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._is_ready = True
        self._required_components: List[str] = []
        self._component_status: Dict[str, bool] = {}
        self._custom_checks: list = []

    def mark_ready(self) -> None:
        self._is_ready = True

    def mark_not_ready(self) -> None:
        self._is_ready = False

    def require_component(self, component_name: str) -> None:
        if component_name not in self._required_components:
            self._required_components.append(component_name)
            self._component_status[component_name] = False

    def set_component_ready(self, component_name: str, ready: bool) -> None:
        self._component_status[component_name] = ready

    def is_component_ready(self, component_name: str) -> bool:
        return self._component_status.get(component_name, False)

    def register_check(self, check_fn) -> None:
        self._custom_checks.append(check_fn)

    async def check(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "status": "healthy",
            "timestamp": time.time(),
            "is_ready": self._is_ready,
            "components": {},
        }

        if not self._is_ready:
            result["status"] = "unhealthy"
            result["reason"] = "Explicitly marked as not ready"
            return result

        for component in self._required_components:
            ready = self._component_status.get(component, False)
            result["components"][component] = ready
            if not ready:
                result["status"] = "unhealthy"
                result["reason"] = f"Required component '{component}' is not ready"

        for check_fn in self._custom_checks:
            try:
                check_result = check_fn()
                check_name = getattr(check_fn, "__name__", str(check_fn))
                result["components"][check_name] = bool(check_result)
                if not check_result:
                    result["status"] = "unhealthy"
                    result["reason"] = f"Readiness check '{check_name}' failed"
            except Exception as e:
                result["status"] = "unhealthy"
                result["reason"] = f"Readiness check '{check_name}' error: {e}"

        return result

import asyncio
import time
import logging
from typing import Any, Dict, List, Optional, Callable, Awaitable
from enum import Enum

from monitoring.health.liveness_check import LivenessCheck
from monitoring.health.readiness_check import ReadinessCheck
from monitoring.health.dependency_check import DependencyCheck
from monitoring.health.self_check import SelfCheck


class HealthStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class HealthManager:
    def __init__(self, check_interval: float = 30.0):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._check_interval = check_interval
        self._is_running = False
        self._status = HealthStatus.HEALTHY
        self._liveness_check = LivenessCheck()
        self._readiness_check = ReadinessCheck()
        self._dependency_check = DependencyCheck()
        self._self_check = SelfCheck()
        self._health_listeners: List[Callable[[HealthStatus], Awaitable[None]]] = []
        self._last_check_time: float = 0.0
        self._check_results: Dict[str, Any] = {}
        self._task: Optional[asyncio.Task] = None

    async def start(self) -> None:
        if self._is_running:
            return
        self._is_running = True
        self._task = asyncio.create_task(self._health_check_loop())
        self._logger.info("Health manager started")

    async def stop(self) -> None:
        if not self._is_running:
            return
        self._is_running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._logger.info("Health manager stopped")

    async def _health_check_loop(self) -> None:
        while self._is_running:
            try:
                await self.run_all_checks()
                await asyncio.sleep(self._check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                self._logger.error("Health check loop error: %s", e)
                await asyncio.sleep(5.0)

    def on_health_change(self, listener: Callable[[HealthStatus], Awaitable[None]]) -> None:
        self._health_listeners.append(listener)

    async def run_all_checks(self) -> Dict[str, Any]:
        liveness = await self._liveness_check.check()
        readiness = await self._readiness_check.check()
        dependencies = await self._dependency_check.check_all()
        self_check = await self._self_check.check()

        results = {
            "liveness": liveness,
            "readiness": readiness,
            "dependencies": dependencies,
            "self_check": self_check,
            "timestamp": time.time(),
        }

        self._check_results = results
        new_status = self._determine_status(results)
        old_status = self._status
        self._status = new_status
        self._last_check_time = time.time()

        if new_status != old_status:
            self._logger.info(
                "Health status changed: %s -> %s",
                old_status.value,
                new_status.value,
            )
            await self._notify_listeners(new_status)

        return results

    def _determine_status(self, results: Dict[str, Any]) -> HealthStatus:
        liveness = results.get("liveness", {})
        if liveness.get("status") == "unhealthy":
            return HealthStatus.UNHEALTHY

        dependencies = results.get("dependencies", {})
        deps_unhealthy = 0
        for dep in dependencies.values():
            if isinstance(dep, dict) and dep.get("status") == "unhealthy":
                deps_unhealthy += 1

        if deps_unhealthy > 0:
            return HealthStatus.DEGRADED

        self_check = results.get("self_check", {})
        if self_check.get("status") == "unhealthy":
            return HealthStatus.DEGRADED

        readiness = results.get("readiness", {})
        if readiness.get("status") == "unhealthy":
            return HealthStatus.DEGRADED

        return HealthStatus.HEALTHY

    async def _notify_listeners(self, status: HealthStatus) -> None:
        for listener in self._health_listeners:
            try:
                await listener(status)
            except Exception as e:
                self._logger.error("Health listener error: %s", e)

    @property
    def status(self) -> HealthStatus:
        return self._status

    @property
    def is_healthy(self) -> bool:
        return self._status == HealthStatus.HEALTHY

    @property
    def is_degraded(self) -> bool:
        return self._status == HealthStatus.DEGRADED

    @property
    def is_unhealthy(self) -> bool:
        return self._status == HealthStatus.UNHEALTHY

    def get_liveness(self) -> LivenessCheck:
        return self._liveness_check

    def get_readiness(self) -> ReadinessCheck:
        return self._readiness_check

    def get_dependency_check(self) -> DependencyCheck:
        return self._dependency_check

    def get_self_check(self) -> SelfCheck:
        return self._self_check

    def get_last_results(self) -> Dict[str, Any]:
        return dict(self._check_results)

    def get_summary(self) -> Dict[str, Any]:
        return {
            "status": self._status.value,
            "is_healthy": self.is_healthy,
            "last_check_time": self._last_check_time,
            "liveness": self._check_results.get("liveness", {}).get("status"),
            "readiness": self._check_results.get("readiness", {}).get("status"),
            "dependencies": {
                k: v.get("status") if isinstance(v, dict) else "unknown"
                for k, v in self._check_results.get("dependencies", {}).items()
            },
        }

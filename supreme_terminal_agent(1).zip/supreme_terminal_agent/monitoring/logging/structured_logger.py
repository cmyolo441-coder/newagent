import json
import logging
from typing import Any, Dict, Optional
from datetime import datetime
from threading import local


class StructuredLogger:
    def __init__(self):
        self._local = local()
        self._default_context: Dict[str, Any] = {}

    def set_default(self, key: str, value: Any) -> None:
        self._default_context[key] = value

    def set_defaults(self, context: Dict[str, Any]) -> None:
        self._default_context.update(context)

    def remove_default(self, key: str) -> None:
        self._default_context.pop(key, None)

    def clear_defaults(self) -> None:
        self._default_context.clear()

    def bind(self, **kwargs) -> None:
        if not hasattr(self._local, "context"):
            self._local.context = {}
        self._local.context.update(kwargs)

    def unbind(self, key: str) -> None:
        if hasattr(self._local, "context"):
            self._local.context.pop(key, None)

    def clear_context(self) -> None:
        if hasattr(self._local, "context"):
            self._local.context.clear()

    def _build_record(
        self,
        level: int,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        exc_info: Optional[Exception] = None,
    ) -> Dict[str, Any]:
        record: Dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": logging.getLevelName(level),
            "message": message,
        }

        if self._default_context:
            record.update(self._default_context)

        thread_context = getattr(self._local, "context", {})
        if thread_context:
            record.update(thread_context)

        if context:
            record.update(context)

        if exc_info:
            record["exception"] = {
                "type": type(exc_info).__name__,
                "message": str(exc_info),
            }

        return record

    def log(
        self,
        level: int,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        exc_info: Optional[Exception] = None,
    ) -> str:
        record = self._build_record(level, message, context, exc_info)
        output = json.dumps(record)
        logger = logging.getLogger("structured")
        logger.log(level, output)
        return output

    def debug(self, message: str, **context) -> str:
        return self.log(logging.DEBUG, message, context)

    def info(self, message: str, **context) -> str:
        return self.log(logging.INFO, message, context)

    def warning(self, message: str, **context) -> str:
        return self.log(logging.WARNING, message, context)

    def error(self, message: str, exc_info: Optional[Exception] = None, **context) -> str:
        return self.log(logging.ERROR, message, context, exc_info)

    def critical(self, message: str, exc_info: Optional[Exception] = None, **context) -> str:
        return self.log(logging.CRITICAL, message, context, exc_info)

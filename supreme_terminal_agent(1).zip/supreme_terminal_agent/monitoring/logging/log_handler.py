import logging
import sys
from typing import Optional, TextIO
from pathlib import Path

from monitoring.logging.log_formatter import LogFormatter, LogFormat


class LogHandler:
    def __init__(
        self,
        name: str = "default",
        level: int = logging.DEBUG,
        formatter: Optional[LogFormatter] = None,
        output: Optional[TextIO] = None,
    ):
        self._name = name
        self._level = level
        self._formatter = formatter or LogFormatter()
        self._output: Optional[TextIO] = output
        self._file_path: Optional[Path] = None
        self._handler: Optional[logging.Handler] = None
        self._create_handler()

    def _create_handler(self) -> None:
        if self._output:
            self._handler = logging.StreamHandler(self._output)
        elif self._file_path:
            self._handler = logging.FileHandler(str(self._file_path))
        else:
            self._handler = logging.StreamHandler(sys.stderr)

        self._handler.setLevel(self._level)
        self._handler.setFormatter(self._formatter.get_logging_formatter())

    def set_output(self, output: TextIO) -> None:
        self._output = output
        self._create_handler()

    def set_file_path(self, file_path: str) -> None:
        self._file_path = Path(file_path)
        self._file_path.parent.mkdir(parents=True, exist_ok=True)
        self._output = None
        self._create_handler()

    def set_level(self, level: int) -> None:
        self._level = level
        if self._handler:
            self._handler.setLevel(level)

    def set_formatter(self, formatter: LogFormatter) -> None:
        self._formatter = formatter
        if self._handler:
            self._handler.setFormatter(formatter.get_logging_formatter())

    def flush(self) -> None:
        if self._handler:
            self._handler.flush()

    def close(self) -> None:
        if self._handler:
            self._handler.close()

    def get_logging_handler(self) -> logging.Handler:
        return self._handler

    @staticmethod
    def create_stdout_handler(name: str = "stdout", level: int = logging.INFO) -> "LogHandler":
        return LogHandler(name=name, level=level, output=sys.stdout)

    @staticmethod
    def create_stderr_handler(name: str = "stderr", level: int = logging.WARNING) -> "LogHandler":
        return LogHandler(name=name, level=level, output=sys.stderr)

    @staticmethod
    def create_file_handler(file_path: str, name: str = "file", level: int = logging.DEBUG) -> "LogHandler":
        handler = LogHandler(name=name, level=level)
        handler.set_file_path(file_path)
        return handler

import asyncio
import logging
from typing import Any, Dict, List, Optional
from collections import deque


class AsyncLogger:
    def __init__(self, max_queue_size: int = 10000, flush_interval: float = 1.0):
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=max_queue_size)
        self._flush_interval = flush_interval
        self._is_running = False
        self._task: Optional[asyncio.Task] = None
        self._logger = logging.getLogger("async_logger")
        self._log_count = 0
        self._dropped_count = 0

    async def start(self) -> None:
        if self._is_running:
            return
        self._is_running = True
        self._task = asyncio.create_task(self._process_logs())
        self._logger.debug("Async logger started")

    async def stop(self) -> None:
        if not self._is_running:
            return
        self._is_running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        await self.flush()
        self._logger.debug("Async logger stopped")

    async def log(
        self,
        level: int,
        message: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        record = {
            "level": level,
            "message": message,
            "context": context or {},
            "timestamp": __import__("time").time(),
        }
        try:
            self._queue.put_nowait(record)
            self._log_count += 1
        except asyncio.QueueFull:
            self._dropped_count += 1
            self._logger.warning("Async log queue full, dropping message: %s", message)

    async def _process_logs(self) -> None:
        while self._is_running:
            try:
                record = await asyncio.wait_for(
                    self._queue.get(), timeout=self._flush_interval
                )
                self._write_log(record)
                self._queue.task_done()
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                self._logger.error("Async log processing error: %s", e)

    def _write_log(self, record: Dict[str, Any]) -> None:
        level = record["level"]
        message = record["message"]
        self._logger.log(level, "%s | context=%s", message, record["context"])

    async def flush(self) -> None:
        remaining = []
        while not self._queue.empty():
            try:
                remaining.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        for record in remaining:
            self._write_log(record)
            self._queue.task_done()

    @property
    def queue_size(self) -> int:
        return self._queue.qsize()

    @property
    def log_count(self) -> int:
        return self._log_count

    @property
    def dropped_count(self) -> int:
        return self._dropped_count

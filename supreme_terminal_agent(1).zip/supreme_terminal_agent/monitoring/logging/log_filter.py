import logging
import re
from typing import Any, Callable, Dict, List, Optional, Pattern


class LogFilter:
    def __init__(self, name: str = "default"):
        self._name = name
        self._level_min: Optional[int] = None
        self._level_max: Optional[int] = None
        self._include_loggers: List[str] = []
        self._exclude_loggers: List[str] = []
        self._include_patterns: List[Pattern] = []
        self._exclude_patterns: List[Pattern] = []
        self._custom_filters: List[Callable[[logging.LogRecord], bool]] = []
        self._fields: Dict[str, Any] = {}

    def set_level_range(self, min_level: int, max_level: int) -> None:
        self._level_min = min_level
        self._level_max = max_level

    def set_min_level(self, level: int) -> None:
        self._level_min = level

    def set_max_level(self, level: int) -> None:
        self._level_max = level

    def include_logger(self, logger_name: str) -> None:
        if logger_name not in self._include_loggers:
            self._include_loggers.append(logger_name)

    def exclude_logger(self, logger_name: str) -> None:
        if logger_name not in self._exclude_loggers:
            self._exclude_loggers.append(logger_name)

    def include_pattern(self, pattern: str) -> None:
        self._include_patterns.append(re.compile(pattern))

    def exclude_pattern(self, pattern: str) -> None:
        self._exclude_patterns.append(re.compile(pattern))

    def add_custom_filter(self, filter_fn: Callable[[logging.LogRecord], bool]) -> None:
        self._custom_filters.append(filter_fn)

    def set_field(self, key: str, value: Any) -> None:
        self._fields[key] = value

    def filter(self, record: logging.LogRecord) -> bool:
        if self._level_min is not None and record.levelno < self._level_min:
            return False
        if self._level_max is not None and record.levelno > self._level_max:
            return False

        if self._include_loggers:
            if not any(record.name.startswith(l) for l in self._include_loggers):
                return False
        if self._exclude_loggers:
            if any(record.name.startswith(l) for l in self._exclude_loggers):
                return False

        message = record.getMessage()
        if self._include_patterns:
            if not any(p.search(message) for p in self._include_patterns):
                return False
        if self._exclude_patterns:
            if any(p.search(message) for p in self._exclude_patterns):
                return False

        if self._custom_filters:
            if not all(f(record) for f in self._custom_filters):
                return False

        if self._fields:
            for key, value in self._fields.items():
                if key == "level":
                    if record.levelno != value:
                        return False
                elif key == "logger":
                    if record.name != value:
                        return False

        return True

    def get_logging_filter(self) -> logging.Filter:
        return logging.Filter()

    @staticmethod
    def create_error_filter() -> "LogFilter":
        f = LogFilter("error_filter")
        f.set_min_level(logging.ERROR)
        return f

    @staticmethod
    def create_info_filter() -> "LogFilter":
        f = LogFilter("info_filter")
        f.set_level_range(logging.INFO, logging.INFO)
        return f

    @staticmethod
    def create_debug_filter() -> "LogFilter":
        f = LogFilter("debug_filter")
        f.set_level_range(logging.DEBUG, logging.DEBUG)
        return f

    @staticmethod
    def create_logger_filter(included_loggers: List[str]) -> "LogFilter":
        f = LogFilter("logger_filter")
        for logger_name in included_loggers:
            f.include_logger(logger_name)
        return f

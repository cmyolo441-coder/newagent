import logging
import uuid
from typing import Any, Dict, Optional
from threading import local
from contextvars import ContextVar

from monitoring.logging.structured_logger import StructuredLogger


_request_id_var: ContextVar[str] = ContextVar("request_id", default="")
_session_id_var: ContextVar[str] = ContextVar("session_id", default="")
_user_id_var: ContextVar[str] = ContextVar("user_id", default="")
_trace_id_var: ContextVar[str] = ContextVar("trace_id", default="")


class ContextLogger:
    def __init__(self):
        self._local = local()
        self._structured = StructuredLogger()
        self._context_providers: Dict[str, callable] = {}

    def set_request_id(self, request_id: str) -> None:
        _request_id_var.set(request_id)

    def set_session_id(self, session_id: str) -> None:
        _session_id_var.set(session_id)

    def set_user_id(self, user_id: str) -> None:
        _user_id_var.set(user_id)

    def set_trace_id(self, trace_id: str) -> None:
        _trace_id_var.set(trace_id)

    def generate_request_id(self) -> str:
        request_id = str(uuid.uuid4())
        _request_id_var.set(request_id)
        return request_id

    def register_context_provider(self, name: str, provider: callable) -> None:
        self._context_providers[name] = provider

    def unregister_context_provider(self, name: str) -> None:
        self._context_providers.pop(name, None)

    def _get_context(self) -> Dict[str, Any]:
        ctx: Dict[str, Any] = {}
        try:
            request_id = _request_id_var.get()
            if request_id:
                ctx["request_id"] = request_id
        except LookupError:
            pass

        try:
            session_id = _session_id_var.get()
            if session_id:
                ctx["session_id"] = session_id
        except LookupError:
            pass

        try:
            user_id = _user_id_var.get()
            if user_id:
                ctx["user_id"] = user_id
        except LookupError:
            pass

        try:
            trace_id = _trace_id_var.get()
            if trace_id:
                ctx["trace_id"] = trace_id
        except LookupError:
            pass

        thread_ctx = getattr(self._local, "context", {})
        if thread_ctx:
            ctx.update(thread_ctx)

        for name, provider in self._context_providers.items():
            try:
                value = provider()
                if value is not None:
                    ctx[name] = value
            except Exception:
                pass

        return ctx

    def bind(self, **kwargs) -> None:
        if not hasattr(self._local, "context"):
            self._local.context = {}
        self._local.context.update(kwargs)

    def unbind(self, key: str) -> None:
        if hasattr(self._local, "context"):
            self._local.context.pop(key, None)

    def log(self, level: int, message: str, extra_context: Optional[Dict[str, Any]] = None) -> str:
        ctx = self._get_context()
        if extra_context:
            ctx.update(extra_context)
        return self._structured.log(level, message, ctx)

    def debug(self, message: str, **context) -> str:
        return self.log(logging.DEBUG, message, context)

    def info(self, message: str, **context) -> str:
        return self.log(logging.INFO, message, context)

    def warning(self, message: str, **context) -> str:
        return self.log(logging.WARNING, message, context)

    def error(self, message: str, exc_info: Optional[Exception] = None, **context) -> str:
        ctx = self._get_context()
        ctx.update(context)
        return self._structured.log(logging.ERROR, message, ctx, exc_info)

    def critical(self, message: str, exc_info: Optional[Exception] = None, **context) -> str:
        ctx = self._get_context()
        ctx.update(context)
        return self._structured.log(logging.CRITICAL, message, ctx, exc_info)

import os
import time
import logging
import gzip
import shutil
from typing import List, Optional
from pathlib import Path
from datetime import datetime, timedelta
from enum import Enum


class RotationStrategy(Enum):
    SIZE = "size"
    TIME = "time"
    BOTH = "both"


class LogRotator:
    def __init__(
        self,
        base_path: str = "logs",
        max_bytes: int = 10 * 1024 * 1024,
        backup_count: int = 5,
        max_age_days: int = 30,
        strategy: RotationStrategy = RotationStrategy.SIZE,
        rotate_interval_hours: int = 24,
        compress: bool = False,
    ):
        self._base_path = Path(base_path)
        self._max_bytes = max_bytes
        self._backup_count = backup_count
        self._max_age_days = max_age_days
        self._strategy = strategy
        self._rotate_interval_hours = rotate_interval_hours
        self._compress = compress
        self._last_rotation_time: float = time.time()
        self._logger = logging.getLogger(self.__class__.__name__)
        self._current_size: Dict[str, int] = {}

        self._base_path.mkdir(parents=True, exist_ok=True)

    def should_rotate(self, filepath: str) -> bool:
        path = Path(filepath)
        if not path.exists():
            return False

        file_size = path.stat().st_size
        now = time.time()

        if self._strategy in (RotationStrategy.SIZE, RotationStrategy.BOTH):
            if file_size >= self._max_bytes:
                return True

        if self._strategy in (RotationStrategy.TIME, RotationStrategy.BOTH):
            elapsed = now - self._last_rotation_time
            if elapsed >= self._rotate_interval_hours * 3600:
                return True

        return False

    def rotate(self, filepath: str) -> Optional[str]:
        path = Path(filepath)
        if not path.exists():
            return None

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        rotated_name = f"{path.stem}_{timestamp}{path.suffix}"
        rotated_path = path.parent / rotated_name

        try:
            shutil.copy2(str(path), str(rotated_path))
            with open(filepath, "w") as f:
                f.truncate(0)
            self._last_rotation_time = time.time()

            if self._compress:
                self._compress_file(str(rotated_path))

            self._cleanup_old_backups(path)
            self._logger.info("Rotated log file: %s -> %s", filepath, rotated_name)
            return str(rotated_path)
        except OSError as e:
            self._logger.error("Failed to rotate log file %s: %s", filepath, e)
            return None

    def rotate_if_needed(self, filepath: str) -> Optional[str]:
        if self.should_rotate(filepath):
            return self.rotate(filepath)
        return None

    def rotate_all(self, filepaths: List[str]) -> List[str]:
        rotated = []
        for fp in filepaths:
            result = self.rotate_if_needed(fp)
            if result:
                rotated.append(result)
        return rotated

    def _compress_file(self, filepath: str) -> None:
        compressed_path = f"{filepath}.gz"
        try:
            with open(filepath, "rb") as f_in:
                with gzip.open(compressed_path, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
            os.remove(filepath)
            self._logger.debug("Compressed log file: %s", compressed_path)
        except OSError as e:
            self._logger.error("Failed to compress %s: %s", filepath, e)

    def _cleanup_old_backups(self, original_path: Path) -> None:
        pattern = f"{original_path.stem}_*{original_path.suffix}*"
        backups = sorted(original_path.parent.glob(pattern))

        while len(backups) > self._backup_count:
            oldest = backups.pop(0)
            try:
                oldest.unlink()
                self._logger.debug("Removed old backup: %s", oldest)
            except OSError as e:
                self._logger.error("Failed to remove %s: %s", oldest, e)

        cutoff = time.time() - (self._max_age_days * 86400)
        for backup in backups:
            if backup.stat().st_mtime < cutoff:
                try:
                    backup.unlink()
                    self._logger.debug("Removed expired backup: %s", backup)
                except OSError as e:
                    self._logger.error("Failed to remove %s: %s", backup, e)

    def cleanup_all(self) -> int:
        removed = 0
        cutoff = time.time() - (self._max_age_days * 86400)
        for f in self._base_path.glob("*_*"):
            if f.is_file() and f.stat().st_mtime < cutoff:
                try:
                    f.unlink()
                    removed += 1
                except OSError:
                    pass
        return removed

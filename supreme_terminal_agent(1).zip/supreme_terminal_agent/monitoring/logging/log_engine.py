import asyncio
import logging
import time
from typing import Any, Dict, List, Optional
from pathlib import Path

from monitoring.logging.log_handler import LogHandler
from monitoring.logging.log_formatter import LogFormatter, LogFormat
from monitoring.logging.log_filter import LogFilter
from monitoring.logging.log_rotator import LogRotator
from monitoring.logging.structured_logger import StructuredLogger
from monitoring.logging.context_logger import ContextLogger
from monitoring.logging.async_logger import AsyncLogger


class LogEngine:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._handlers: List[LogHandler] = []
        self._filters: List[LogFilter] = []
        self._formatter = LogFormatter()
        self._rotator: Optional[LogRotator] = None
        self._structured_logger: Optional[StructuredLogger] = None
        self._context_logger: Optional[ContextLogger] = None
        self._async_logger: Optional[AsyncLogger] = None
        self._is_running = False
        self._log_count = 0
        self._error_count = 0
        self._level = logging.INFO
        self._root_logger = logging.getLogger()
        self._root_logger.setLevel(self._level)

    async def start(self) -> None:
        if self._is_running:
            return
        self._is_running = True
        if self._async_logger:
            await self._async_logger.start()
        self._logger.info("Log engine started")

    async def stop(self) -> None:
        if not self._is_running:
            return
        self._is_running = False
        if self._async_logger:
            await self._async_logger.stop()
        await self.flush()
        self._logger.info("Log engine stopped")

    def add_handler(self, handler: LogHandler) -> None:
        self._handlers.append(handler)
        self._root_logger.addHandler(handler.get_logging_handler())

    def remove_handler(self, handler: LogHandler) -> None:
        if handler in self._handlers:
            self._handlers.remove(handler)
            self._root_logger.removeHandler(handler.get_logging_handler())

    def add_filter(self, log_filter: LogFilter) -> None:
        self._filters.append(log_filter)
        self._root_logger.addFilter(log_filter.get_logging_filter())

    def remove_filter(self, log_filter: LogFilter) -> None:
        if log_filter in self._filters:
            self._filters.remove(log_filter)
            self._root_logger.removeFilter(log_filter.get_logging_filter())

    def set_level(self, level: int) -> None:
        self._level = level
        self._root_logger.setLevel(level)
        for handler in self._handlers:
            handler.set_level(level)

    def set_format(self, format_type: LogFormat) -> None:
        self._formatter.set_format(format_type)
        self._apply_formatter()

    def set_custom_format(self, fmt: str) -> None:
        self._formatter.set_custom_format(fmt)
        self._apply_formatter()

    def set_rotator(self, rotator: LogRotator) -> None:
        self._rotator = rotator

    def enable_structured_logging(self) -> StructuredLogger:
        self._structured_logger = StructuredLogger()
        return self._structured_logger

    def enable_context_logging(self) -> ContextLogger:
        self._context_logger = ContextLogger()
        return self._context_logger

    def enable_async_logging(self) -> AsyncLogger:
        self._async_logger = AsyncLogger()
        return self._async_logger

    def _apply_formatter(self) -> None:
        for handler in self._handlers:
            handler.set_formatter(self._formatter)

    def log(
        self,
        level: int,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        exc_info: bool = False,
    ) -> None:
        extra = {"context": context or {}}
        if self._structured_logger:
            self._structured_logger.log(level, message, context=context)
        elif self._async_logger:
            asyncio.ensure_future(
                self._async_logger.log(level, message, context=context)
            )
        else:
            self._root_logger.log(level, message, extra=extra, exc_info=exc_info)

        self._log_count += 1
        if level >= logging.ERROR:
            self._error_count += 1

    def debug(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        self.log(logging.DEBUG, message, context)

    def info(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        self.log(logging.INFO, message, context)

    def warning(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        self.log(logging.WARNING, message, context)

    def error(self, message: str, context: Optional[Dict[str, Any]] = None, exc_info: bool = True) -> None:
        self.log(logging.ERROR, message, context, exc_info=exc_info)

    def critical(self, message: str, context: Optional[Dict[str, Any]] = None, exc_info: bool = True) -> None:
        self.log(logging.CRITICAL, message, context, exc_info=exc_info)

    async def flush(self) -> None:
        for handler in self._handlers:
            handler.flush()
        if self._rotator:
            self._rotator.rotate_if_needed()

    def get_stats(self) -> Dict[str, Any]:
        return {
            "is_running": self._is_running,
            "log_count": self._log_count,
            "error_count": self._error_count,
            "level": logging.getLevelName(self._level),
            "handler_count": len(self._handlers),
            "filter_count": len(self._filters),
            "structured_enabled": self._structured_logger is not None,
            "context_enabled": self._context_logger is not None,
            "async_enabled": self._async_logger is not None,
        }

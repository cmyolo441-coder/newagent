import json
import logging
from typing import Any, Dict, Optional
from enum import Enum
from datetime import datetime


class LogFormat(Enum):
    JSON = "json"
    PLAINTEXT = "plaintext"
    COLORED = "colored"
    CUSTOM = "custom"


class LogFormatter:
    def __init__(self, format_type: LogFormat = LogFormat.JSON):
        self._format_type = format_type
        self._custom_format: str = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        self._date_format: str = "%Y-%m-%dT%H:%M:%S"

    def set_format(self, format_type: LogFormat) -> None:
        self._format_type = format_type

    def set_custom_format(self, fmt: str) -> None:
        self._custom_format = fmt

    def set_date_format(self, date_format: str) -> None:
        self._date_format = date_format

    def format(self, record: logging.LogRecord) -> str:
        if self._format_type == LogFormat.JSON:
            return self._format_json(record)
        elif self._format_type == LogFormat.COLORED:
            return self._format_colored(record)
        elif self._format_type == LogFormat.CUSTOM:
            return self._format_custom(record)
        else:
            return self._format_plaintext(record)

    def _format_json(self, record: logging.LogRecord) -> str:
        log_entry: Dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created).strftime(self._date_format),
            "level": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
            "process": record.process,
            "thread": record.thread,
        }
        if hasattr(record, "context") and record.context:
            log_entry["context"] = record.context
        if record.exc_info and record.exc_info[0]:
            log_entry["exception"] = {
                "type": record.exc_info[0].__name__,
                "message": str(record.exc_info[1]),
            }
        return json.dumps(log_entry)

    def _format_plaintext(self, record: logging.LogRecord) -> str:
        timestamp = datetime.fromtimestamp(record.created).strftime(self._date_format)
        return f"{timestamp} [{record.levelname}] {record.name}: {record.getMessage()}"

    def _format_colored(self, record: logging.LogRecord) -> str:
        colors = {
            "DEBUG": "\033[36m",
            "INFO": "\033[32m",
            "WARNING": "\033[33m",
            "ERROR": "\033[31m",
            "CRITICAL": "\033[35m",
        }
        reset = "\033[0m"
        timestamp = datetime.fromtimestamp(record.created).strftime(self._date_format)
        color = colors.get(record.levelname, "")
        return f"{timestamp} [{color}{record.levelname}{reset}] {record.name}: {record.getMessage()}"

    def _format_custom(self, record: logging.LogRecord) -> str:
        return self._custom_format % {
            "asctime": datetime.fromtimestamp(record.created).strftime(self._date_format),
            "levelname": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "funcName": record.funcName,
            "lineno": record.lineno,
            "process": record.process,
            "thread": record.thread,
        }

    def get_logging_formatter(self) -> logging.Formatter:
        return logging.Formatter(self._custom_format, self._date_format)

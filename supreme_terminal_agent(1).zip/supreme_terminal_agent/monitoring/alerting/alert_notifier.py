import asyncio
import logging
from typing import Any, Dict, List, Optional, Callable
from enum import Enum


class NotificationChannel(Enum):
    LOG = "log"
    CONSOLE = "console"
    WEBHOOK = "webhook"
    EMAIL = "email"
    SLACK = "slack"
    PAGERDUTY = "pagerduty"


class AlertNotifier:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._channels: Dict[str, NotificationChannel] = {}
        self._webhooks: Dict[str, str] = {}
        self._custom_notifiers: List[Callable[[Dict[str, Any]], None]] = []
        self._notify_count = 0

    def add_channel(self, name: str, channel: NotificationChannel) -> None:
        self._channels[name] = channel

    def remove_channel(self, name: str) -> None:
        self._channels.pop(name, None)

    def add_webhook(self, name: str, url: str) -> None:
        self._webhooks[name] = url

    def remove_webhook(self, name: str) -> None:
        self._webhooks.pop(name, None)

    def add_custom_notifier(self, notifier: Callable[[Dict[str, Any]], None]) -> None:
        self._custom_notifiers.append(notifier)

    def remove_custom_notifier(self, notifier: Callable[[Dict[str, Any]], None]) -> None:
        if notifier in self._custom_notifiers:
            self._custom_notifiers.remove(notifier)

    async def notify(self, alert: Dict[str, Any]) -> None:
        state = alert.get("state", "unknown")
        rule_name = alert.get("rule_name", "unknown")

        for name, channel in self._channels.items():
            try:
                if channel == NotificationChannel.LOG:
                    self._notify_log(alert)
                elif channel == NotificationChannel.CONSOLE:
                    self._notify_console(alert)
                elif channel == NotificationChannel.WEBHOOK:
                    await self._notify_webhook(alert)
                else:
                    self._notify_log(alert)
            except Exception as e:
                self._logger.error("Notification channel '%s' failed: %s", name, e)

        for webhook_name, url in self._webhooks.items():
            try:
                await self._send_webhook(url, alert)
            except Exception as e:
                self._logger.error("Webhook '%s' failed: %s", webhook_name, e)

        for notifier in self._custom_notifiers:
            try:
                notifier(alert)
            except Exception as e:
                self._logger.error("Custom notifier failed: %s", e)

        self._notify_count += 1

    def _notify_log(self, alert: Dict[str, Any]) -> None:
        state = alert.get("state", "unknown")
        severity = alert.get("severity", "unknown")
        rule_name = alert.get("rule_name", "unknown")
        description = alert.get("description", "")
        self._logger.log(
            logging.WARNING if state == "firing" else logging.INFO,
            "[%s] [%s] %s: %s",
            state.upper(),
            severity.upper(),
            rule_name,
            description,
        )

    def _notify_console(self, alert: Dict[str, Any]) -> None:
        border = "=" * 60
        lines = [
            border,
            f"  ALERT: {alert.get('rule_name', 'unknown')}",
            f"  STATE: {alert.get('state', 'unknown').upper()}",
            f"  SEVERITY: {alert.get('severity', 'unknown').upper()}",
            f"  DESCRIPTION: {alert.get('description', '')}",
            border,
        ]
        print("\n".join(lines))

    async def _notify_webhook(self, alert: Dict[str, Any]) -> None:
        pass

    async def _send_webhook(self, url: str, alert: Dict[str, Any]) -> None:
        self._logger.debug("Webhook not implemented: %s", url)

    @property
    def notify_count(self) -> int:
        return self._notify_count

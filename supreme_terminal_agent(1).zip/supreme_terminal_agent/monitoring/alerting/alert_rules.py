import re
import time
from typing import Any, Callable, Dict, List, Optional
from enum import Enum
from dataclasses import dataclass, field


class AlertSeverity(Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"
    DEBUG = "debug"


class AlertState(Enum):
    FIRING = "firing"
    RESOLVED = "resolved"
    PENDING = "pending"


@dataclass
class AlertRule:
    name: str
    condition_fn: Callable[[], Any]
    severity: AlertSeverity = AlertSeverity.WARNING
    description: str = ""
    duration: float = 0.0
    labels: Dict[str, str] = field(default_factory=dict)
    annotations: Dict[str, str] = field(default_factory=dict)
    enabled: bool = True
    created_at: float = 0.0

    def __post_init__(self):
        if self.created_at == 0.0:
            self.created_at = time.time()


class AlertRules:
    def __init__(self):
        self._rules: Dict[str, AlertRule] = {}

    def add(self, rule: AlertRule) -> None:
        if rule.name in self._rules:
            raise ValueError(f"Alert rule '{rule.name}' already exists")
        self._rules[rule.name] = rule

    def remove(self, name: str) -> None:
        self._rules.pop(name, None)

    def get(self, name: str) -> Optional[AlertRule]:
        return self._rules.get(name)

    def enable(self, name: str) -> None:
        rule = self._rules.get(name)
        if rule:
            rule.enabled = True

    def disable(self, name: str) -> None:
        rule = self._rules.get(name)
        if rule:
            rule.enabled = False

    def list_enabled(self) -> List[AlertRule]:
        return [r for r in self._rules.values() if r.enabled]

    def list_disabled(self) -> List[AlertRule]:
        return [r for r in self._rules.values() if not r.enabled]

    def list_by_severity(self, severity: AlertSeverity) -> List[AlertRule]:
        return [r for r in self._rules.values() if r.severity == severity]

    def add_cpu_threshold_rule(
        self, name: str, threshold: float = 80.0, severity: AlertSeverity = AlertSeverity.WARNING
    ) -> AlertRule:
        def check_cpu() -> bool:
            try:
                import psutil
                return psutil.Process().cpu_percent(interval=0.1) > threshold
            except ImportError:
                return False

        rule = AlertRule(
            name=name,
            condition_fn=check_cpu,
            severity=severity,
            description=f"CPU usage exceeds {threshold}%",
        )
        self.add(rule)
        return rule

    def add_memory_threshold_rule(
        self, name: str, threshold_mb: float = 500.0, severity: AlertSeverity = AlertSeverity.WARNING
    ) -> AlertRule:
        def check_memory() -> bool:
            try:
                import psutil
                mem = psutil.Process().memory_info().rss / (1024 * 1024)
                return mem > threshold_mb
            except ImportError:
                return False

        rule = AlertRule(
            name=name,
            condition_fn=check_memory,
            severity=severity,
            description=f"Memory usage exceeds {threshold_mb} MB",
        )
        self.add(rule)
        return rule

    @property
    def count(self) -> int:
        return len(self._rules)

    @property
    def all(self) -> List[AlertRule]:
        return list(self._rules.values())

import time
import logging
from typing import Any, Dict, List, Optional, Set
from dataclasses import dataclass


@dataclass
class SilenceRule:
    rule_name: str
    duration: float
    created_at: float
    reason: str = ""
    matchers: Dict[str, str] = None

    def __post_init__(self):
        if self.matchers is None:
            self.matchers = {}

    @property
    def expires_at(self) -> float:
        return self.created_at + self.duration

    @property
    def is_expired(self) -> bool:
        return time.time() > self.expires_at


class AlertSilencer:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._silences: Dict[str, SilenceRule] = {}
        self._muted_rules: Set[str] = set()

    def silence(self, rule_name: str, duration: float = 300.0, reason: str = "") -> SilenceRule:
        if rule_name in self._silences:
            raise ValueError(f"Rule '{rule_name}' is already silenced")
        silence = SilenceRule(
            rule_name=rule_name,
            duration=duration,
            created_at=time.time(),
            reason=reason,
        )
        self._silences[rule_name] = silence
        self._logger.info("Silenced rule '%s' for %ss: %s", rule_name, duration, reason)
        return silence

    def unsilence(self, rule_name: str) -> bool:
        if rule_name in self._silences:
            del self._silences[rule_name]
            self._logger.info("UnsILENCED rule '%s'", rule_name)
            return True
        if rule_name in self._muted_rules:
            self._muted_rules.discard(rule_name)
            return True
        return False

    def mute(self, rule_name: str) -> None:
        self._muted_rules.add(rule_name)

    def unmute(self, rule_name: str) -> None:
        self._muted_rules.discard(rule_name)

    def is_silenced(self, rule_name: str) -> bool:
        if rule_name in self._muted_rules:
            return True

        silence = self._silences.get(rule_name)
        if silence is None:
            return False
        if silence.is_expired:
            del self._silences[rule_name]
            return False
        return True

    def get_silence(self, rule_name: str) -> Optional[SilenceRule]:
        return self._silences.get(rule_name)

    def cleanup_expired(self) -> int:
        now = time.time()
        expired = [name for name, s in self._silences.items() if s.expires_at <= now]
        for name in expired:
            del self._silences[name]
        return len(expired)

    def clear_all(self) -> None:
        self._silences.clear()
        self._muted_rules.clear()

    @property
    def silenced_rules(self) -> List[str]:
        self.cleanup_expired()
        return list(self._silences.keys())

    @property
    def muted_rules(self) -> Set[str]:
        return set(self._muted_rules)

    @property
    def silence_count(self) -> int:
        self.cleanup_expired()
        return len(self._silences)

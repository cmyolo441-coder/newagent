import asyncio
import time
import logging
from typing import Any, Dict, List, Optional, Callable
from enum import Enum

from monitoring.alerting.alert_rules import AlertRules, AlertRule, AlertSeverity, AlertState
from monitoring.alerting.alert_evaluator import AlertEvaluator
from monitoring.alerting.alert_notifier import AlertNotifier
from monitoring.alerting.alert_silencer import AlertSilencer


class AlertManager:
    def __init__(self, evaluation_interval: float = 10.0):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._evaluation_interval = evaluation_interval
        self._is_running = False
        self._task: Optional[asyncio.Task] = None
        self._rules = AlertRules()
        self._evaluator = AlertEvaluator(self._rules)
        self._notifier = AlertNotifier()
        self._silencer = AlertSilencer()
        self._firing_alerts: Dict[str, Dict[str, Any]] = {}
        self._alert_count = 0
        self._listeners: List[Callable] = []

    async def start(self) -> None:
        if self._is_running:
            return
        self._is_running = True
        self._task = asyncio.create_task(self._evaluation_loop())
        self._logger.info("Alert manager started")

    async def stop(self) -> None:
        if not self._is_running:
            return
        self._is_running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._logger.info("Alert manager stopped")

    async def _evaluation_loop(self) -> None:
        while self._is_running:
            try:
                await self.evaluate_all()
                await asyncio.sleep(self._evaluation_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                self._logger.error("Alert evaluation loop error: %s", e)
                await asyncio.sleep(5.0)

    def add_rule(self, rule: AlertRule) -> None:
        self._rules.add(rule)

    def remove_rule(self, rule_name: str) -> None:
        self._rules.remove(rule_name)

    def on_alert(self, listener: Callable) -> None:
        self._listeners.append(listener)

    async def evaluate_all(self) -> List[Dict[str, Any]]:
        firing = await self._evaluator.evaluate_all()
        new_alerts = []
        for alert in firing:
            alert_id = alert.get("rule_name", alert.get("id", "unknown"))
            if self._silencer.is_silenced(alert_id):
                continue

            prev_state = self._firing_alerts.get(alert_id, {}).get("state")
            if alert.get("state") == AlertState.FIRING.value and prev_state != AlertState.FIRING.value:
                new_alerts.append(alert)
                self._alert_count += 1
                await self._notifier.notify(alert)
                for listener in self._listeners:
                    try:
                        await listener(alert)
                    except Exception as e:
                        self._logger.error("Alert listener error: %s", e)

            self._firing_alerts[alert_id] = alert

        resolved = []
        for alert_id, prev_alert in list(self._firing_alerts.items()):
            if not any(a.get("rule_name", a.get("id", "")) == alert_id for a in firing):
                resolved_alert = {**prev_alert, "state": AlertState.RESOLVED.value}
                resolved.append(resolved_alert)
                del self._firing_alerts[alert_id]
                await self._notifier.notify(resolved_alert)

        return firing

    async def evaluate(self, rule_name: str) -> Optional[Dict[str, Any]]:
        return await self._evaluator.evaluate(rule_name)

    @property
    def rules(self) -> AlertRules:
        return self._rules

    @property
    def notifier(self) -> AlertNotifier:
        return self._notifier

    @property
    def silencer(self) -> AlertSilencer:
        return self._silencer

    @property
    def firing_alerts(self) -> Dict[str, Dict[str, Any]]:
        return dict(self._firing_alerts)

    @property
    def alert_count(self) -> int:
        return self._alert_count

    def get_stats(self) -> Dict[str, Any]:
        return {
            "is_running": self._is_running,
            "rule_count": self._rules.count,
            "firing_count": len(self._firing_alerts),
            "total_alerts": self._alert_count,
            "silenced_rules": len(self._silencer.silenced_rules),
        }

import time
import logging
from typing import Any, Dict, List, Optional

from monitoring.alerting.alert_rules import AlertRules, AlertRule, AlertState, AlertSeverity


class AlertEvaluator:
    def __init__(self, rules: AlertRules):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._rules = rules
        self._pending_starts: Dict[str, float] = {}
        self._last_evaluation: Dict[str, Any] = {}

    async def evaluate_all(self) -> List[Dict[str, Any]]:
        results = []
        for rule in self._rules.list_enabled():
            try:
                result = await self._evaluate_rule(rule)
                if result:
                    results.append(result)
            except Exception as e:
                self._logger.error("Error evaluating rule '%s': %s", rule.name, e)
                results.append({
                    "rule_name": rule.name,
                    "state": AlertState.FIRING.value,
                    "severity": rule.severity.value,
                    "error": str(e),
                    "timestamp": time.time(),
                })
        return results

    async def evaluate(self, rule_name: str) -> Optional[Dict[str, Any]]:
        rule = self._rules.get(rule_name)
        if not rule or not rule.enabled:
            return None
        try:
            return await self._evaluate_rule(rule)
        except Exception as e:
            self._logger.error("Error evaluating rule '%s': %s", rule_name, e)
            return {
                "rule_name": rule_name,
                "state": AlertState.FIRING.value,
                "severity": rule.severity.value,
                "error": str(e),
                "timestamp": time.time(),
            }

    async def _evaluate_rule(self, rule: AlertRule) -> Optional[Dict[str, Any]]:
        now = time.time()
        condition_result = rule.condition_fn()

        is_firing = bool(condition_result) if not isinstance(condition_result, (int, float)) else bool(condition_result)

        base_alert = {
            "rule_name": rule.name,
            "severity": rule.severity.value,
            "description": rule.description,
            "labels": dict(rule.labels),
            "annotations": dict(rule.annotations),
            "timestamp": now,
        }

        if rule.duration > 0:
            if is_firing:
                if rule.name not in self._pending_starts:
                    self._pending_starts[rule.name] = now
                    return {**base_alert, "state": AlertState.PENDING.value}

                elapsed = now - self._pending_starts[rule.name]
                if elapsed >= rule.duration:
                    result = {**base_alert, "state": AlertState.FIRING.value}
                    self._last_evaluation[rule.name] = result
                    return result
                else:
                    return {**base_alert, "state": AlertState.PENDING.value}
            else:
                self._pending_starts.pop(rule.name, None)
                if rule.name in self._last_evaluation:
                    resolved = {**base_alert, "state": AlertState.RESOLVED.value}
                    del self._last_evaluation[rule.name]
                    return resolved
                return None
        else:
            if is_firing:
                result = {**base_alert, "state": AlertState.FIRING.value}
                self._last_evaluation[rule.name] = result
                return result
            else:
                if rule.name in self._last_evaluation:
                    resolved = {**base_alert, "state": AlertState.RESOLVED.value}
                    del self._last_evaluation[rule.name]
                    return resolved
                return None

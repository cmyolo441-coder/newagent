import asyncio
import time
import logging
from typing import Any, Dict, List, Optional, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum
from concurrent.futures import ThreadPoolExecutor

from monitoring.metrics import MetricsCollector
from monitoring.tracing import TraceEngine
from monitoring.logging import LogEngine
from monitoring.health import HealthManager
from monitoring.alerting import AlertManager


class MonitorState(Enum):
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"
    STOPPING = "stopping"


@dataclass
class MonitorConfig:
    poll_interval: float = 5.0
    metrics_enabled: bool = True
    tracing_enabled: bool = True
    logging_enabled: bool = True
    health_enabled: bool = True
    alerting_enabled: bool = True
    thread_pool_size: int = 4
    max_queue_size: int = 1000
    flush_interval: float = 10.0


class MonitorEngine:
    def __init__(self, config: Optional[MonitorConfig] = None):
        self.config = config or MonitorConfig()
        self.state = MonitorState.STOPPED
        self._logger = logging.getLogger(self.__class__.__name__)
        self._event_queue: asyncio.Queue = asyncio.Queue(maxsize=self.config.max_queue_size)
        self._tasks: List[asyncio.Task] = []
        self._executor = ThreadPoolExecutor(max_workers=self.config.thread_pool_size)
        self._listeners: Dict[str, List[Callable[..., Awaitable[None]]]] = {}

        self.metrics_collector = MetricsCollector() if self.config.metrics_enabled else None
        self.trace_engine = TraceEngine() if self.config.tracing_enabled else None
        self.log_engine = LogEngine() if self.config.logging_enabled else None
        self.health_manager = HealthManager() if self.config.health_enabled else None
        self.alert_manager = AlertManager() if self.config.alerting_enabled else None

        self._start_time: float = 0.0
        self._event_count: int = 0
        self._error_count: int = 0

    async def start(self) -> None:
        if self.state == MonitorState.RUNNING:
            self._logger.warning("Monitor engine is already running")
            return
        try:
            self.state = MonitorState.STARTING
            self._logger.info("Starting monitor engine")
            self._start_time = time.time()

            components = []
            if self.metrics_collector:
                components.append(self.metrics_collector.start())
            if self.trace_engine:
                components.append(self.trace_engine.start())
            if self.log_engine:
                components.append(self.log_engine.start())
            if self.health_manager:
                components.append(self.health_manager.start())
            if self.alert_manager:
                components.append(self.alert_manager.start())

            if components:
                await asyncio.gather(*components, return_exceptions=True)

            self._tasks.append(asyncio.create_task(self._event_loop()))
            self._tasks.append(asyncio.create_task(self._flush_loop()))

            self.state = MonitorState.RUNNING
            self._logger.info("Monitor engine started successfully")
        except Exception as e:
            self.state = MonitorState.ERROR
            self._logger.error("Failed to start monitor engine: %s", e)
            raise

    async def stop(self) -> None:
        if self.state in (MonitorState.STOPPED, MonitorState.STOPPING):
            return
        try:
            self.state = MonitorState.STOPPING
            self._logger.info("Stopping monitor engine")

            for task in self._tasks:
                task.cancel()
            if self._tasks:
                await asyncio.gather(*self._tasks, return_exceptions=True)
            self._tasks.clear()

            components = []
            if self.metrics_collector:
                components.append(self.metrics_collector.stop())
            if self.trace_engine:
                components.append(self.trace_engine.stop())
            if self.log_engine:
                components.append(self.log_engine.stop())
            if self.health_manager:
                components.append(self.health_manager.stop())
            if self.alert_manager:
                components.append(self.alert_manager.stop())

            if components:
                await asyncio.gather(*components, return_exceptions=True)

            self._executor.shutdown(wait=False)
            self.state = MonitorState.STOPPED
            self._logger.info("Monitor engine stopped")
        except Exception as e:
            self.state = MonitorState.ERROR
            self._logger.error("Error stopping monitor engine: %s", e)
            raise

    async def pause(self) -> None:
        if self.state != MonitorState.RUNNING:
            raise RuntimeError(f"Cannot pause monitor in state: {self.state.value}")
        self.state = MonitorState.PAUSED
        self._logger.info("Monitor engine paused")

    async def resume(self) -> None:
        if self.state != MonitorState.PAUSED:
            raise RuntimeError(f"Cannot resume monitor in state: {self.state.value}")
        self.state = MonitorState.RUNNING
        self._logger.info("Monitor engine resumed")

    async def emit_event(self, event_type: str, data: Any) -> None:
        event = {
            "type": event_type,
            "data": data,
            "timestamp": time.time(),
            "sequence": self._event_count,
        }
        self._event_count += 1
        try:
            self._event_queue.put_nowait(event)
        except asyncio.QueueFull:
            self._error_count += 1
            self._logger.warning("Event queue full, dropping event: %s", event_type)

    def on(self, event_type: str, callback: Callable[..., Awaitable[None]]) -> None:
        self._listeners.setdefault(event_type, []).append(callback)

    def off(self, event_type: str, callback: Callable[..., Awaitable[None]]) -> None:
        listeners = self._listeners.get(event_type, [])
        if callback in listeners:
            listeners.remove(callback)

    async def _event_loop(self) -> None:
        while True:
            try:
                if self.state == MonitorState.PAUSED:
                    await asyncio.sleep(0.1)
                    continue
                event = await asyncio.wait_for(
                    self._event_queue.get(), timeout=self.config.poll_interval
                )
                await self._dispatch_event(event)
                self._event_queue.task_done()
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                self._error_count += 1
                self._logger.error("Event loop error: %s", e)

    async def _dispatch_event(self, event: Dict[str, Any]) -> None:
        event_type = event["type"]
        listeners = self._listeners.get(event_type, [])
        wildcard_listeners = self._listeners.get("*", [])
        all_listeners = listeners + wildcard_listeners
        if not all_listeners:
            return
        results = await asyncio.gather(
            *[listener(event) for listener in all_listeners],
            return_exceptions=True,
        )
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                self._error_count += 1
                self._logger.error(
                    "Listener error for event %s: %s", event_type, result
                )

    async def _flush_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(self.config.flush_interval)
                if self.metrics_collector:
                    await self.metrics_collector.flush()
                if self.log_engine:
                    await self.log_engine.flush()
            except asyncio.CancelledError:
                break
            except Exception as e:
                self._logger.error("Flush loop error: %s", e)

    @property
    def uptime(self) -> float:
        if self._start_time == 0:
            return 0.0
        return time.time() - self._start_time

    @property
    def event_count(self) -> int:
        return self._event_count

    @property
    def error_count(self) -> int:
        return self._error_count

    def get_stats(self) -> Dict[str, Any]:
        return {
            "state": self.state.value,
            "uptime": self.uptime,
            "event_count": self._event_count,
            "error_count": self._error_count,
            "queue_size": self._event_queue.qsize(),
            "components": {
                "metrics": self.metrics_collector is not None,
                "tracing": self.trace_engine is not None,
                "logging": self.log_engine is not None,
                "health": self.health_manager is not None,
                "alerting": self.alert_manager is not None,
            },
        }

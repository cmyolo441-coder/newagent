import asyncio
import time
import uuid
import logging
from typing import Any, Dict, List, Optional, ContextManager
from contextlib import contextmanager
from dataclasses import dataclass, field

from monitoring.tracing.span_manager import SpanManager, Span
from monitoring.tracing.context_propagation import ContextPropagator
from monitoring.tracing.trace_exporter import TraceExporter
from monitoring.tracing.sampling import Sampler, SamplingDecision


class TraceEngineError(Exception):
    pass


@dataclass
class TraceConfig:
    service_name: str = "supreme_terminal_agent"
    sample_rate: float = 1.0
    max_spans_per_trace: int = 1000
    max_attribute_length: int = 4096
    export_interval: float = 5.0
    enabled: bool = True


class TraceEngine:
    def __init__(self, config: Optional[TraceConfig] = None):
        self.config = config or TraceConfig()
        self._logger = logging.getLogger(self.__class__.__name__)
        self._span_manager = SpanManager()
        self._context_propagator = ContextPropagator()
        self._exporter = TraceExporter()
        self._sampler = Sampler(rate=self.config.sample_rate)
        self._is_running = False
        self._trace_count = 0
        self._span_count = 0
        self._active_traces: Dict[str, List[Span]] = {}

    async def start(self) -> None:
        if self._is_running:
            return
        self._is_running = True
        self._logger.info("Trace engine started (service: %s)", self.config.service_name)

    async def stop(self) -> None:
        if not self._is_running:
            return
        self._is_running = False
        await self.flush()
        self._logger.info("Trace engine stopped")

    def start_span(
        self,
        operation_name: str,
        parent_span: Optional[Span] = None,
        attributes: Optional[Dict[str, Any]] = None,
        trace_id: Optional[str] = None,
        span_id: Optional[str] = None,
    ) -> Span:
        if not self.config.enabled:
            return self._span_manager.create_span(
                operation_name, Span(name=operation_name, trace_id="", span_id=""),
            )

        new_trace = False
        if parent_span is None:
            trace_id = trace_id or str(uuid.uuid4())
            new_trace = True
        else:
            trace_id = trace_id or parent_span.trace_id

        decision = self._sampler.should_sample(trace_id)
        if decision == SamplingDecision.DROP:
            return self._span_manager.create_span(
                operation_name, Span(name=operation_name, trace_id=trace_id, span_id=""),
            )

        span = self._span_manager.create_span(
            operation_name=operation_name,
            parent_span=parent_span,
            trace_id=trace_id,
            span_id=span_id,
            attributes=attributes,
        )

        if new_trace:
            self._active_traces[trace_id] = []
            self._trace_count += 1
        self._active_traces.setdefault(trace_id, []).append(span)
        self._span_count += 1

        return span

    def end_span(self, span: Span) -> None:
        if not span or not span.span_id:
            return
        span.end()
        trace_id = span.trace_id
        if trace_id in self._active_traces:
            try:
                self._active_traces[trace_id].remove(span)
                if not self._active_traces[trace_id]:
                    trace_data = self._span_manager.get_trace(trace_id)
                    if trace_data:
                        asyncio.ensure_future(self._exporter.export(trace_data))
                    del self._active_traces[trace_id]
            except ValueError:
                pass

    @contextmanager
    def span(
        self,
        operation_name: str,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Span:
        span = self.start_span(operation_name, attributes=attributes)
        try:
            yield span
        except Exception as e:
            span.set_attribute("error", True)
            span.set_attribute("error.message", str(e))
            raise
        finally:
            self.end_span(span)

    def inject_context(self, span: Span, carrier: Dict[str, str]) -> None:
        self._context_propagator.inject(span, carrier)

    def extract_context(self, carrier: Dict[str, str]) -> Optional[Span]:
        return self._context_propagator.extract(carrier)

    def get_span(self, span_id: str) -> Optional[Span]:
        return self._span_manager.get_span(span_id)

    def get_trace(self, trace_id: str) -> Optional[Dict[str, Any]]:
        return self._span_manager.get_trace(trace_id)

    def set_attribute(self, span: Span, key: str, value: Any) -> None:
        span.set_attribute(key, value)

    def add_event(self, span: Span, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        span.add_event(name, attributes)

    def set_status(self, span: Span, code: int, description: str = "") -> None:
        span.set_status(code, description)

    async def flush(self) -> None:
        remaining_traces = list(self._active_traces.keys())
        for trace_id in remaining_traces:
            trace_data = self._span_manager.get_trace(trace_id)
            if trace_data:
                await self._exporter.export(trace_data)
        self._active_traces.clear()

    @property
    def is_running(self) -> bool:
        return self._is_running

    @property
    def trace_count(self) -> int:
        return self._trace_count

    @property
    def span_count(self) -> int:
        return self._span_count

    def get_stats(self) -> Dict[str, Any]:
        return {
            "service_name": self.config.service_name,
            "enabled": self.config.enabled,
            "trace_count": self._trace_count,
            "span_count": self._span_count,
            "active_traces": len(self._active_traces),
            "sampler": self._sampler.get_info(),
        }

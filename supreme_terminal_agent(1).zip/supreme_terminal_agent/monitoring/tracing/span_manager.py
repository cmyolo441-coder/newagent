import time
import uuid
import threading
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class Span:
    name: str
    trace_id: str
    span_id: str = ""
    parent_span_id: str = ""
    operation_name: str = ""
    start_time: float = 0.0
    end_time: float = 0.0
    attributes: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    status_code: int = 0
    status_description: str = ""
    error: bool = False

    def __post_init__(self):
        if not self.span_id:
            self.span_id = str(uuid.uuid4())
        if not self.operation_name:
            self.operation_name = self.name
        if self.start_time == 0.0:
            self.start_time = time.time()

    def end(self) -> None:
        if self.end_time == 0.0:
            self.end_time = time.time()

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value

    def set_attributes(self, attributes: Dict[str, Any]) -> None:
        self.attributes.update(attributes)

    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        self.events.append({
            "name": name,
            "timestamp": time.time(),
            "attributes": attributes or {},
        })

    def set_status(self, code: int, description: str = "") -> None:
        self.status_code = code
        self.status_description = description
        if code >= 2:
            self.error = True

    @property
    def duration(self) -> float:
        if self.end_time == 0.0:
            return time.time() - self.start_time
        return self.end_time - self.start_time

    @property
    def is_recording(self) -> bool:
        return self.end_time == 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id,
            "operation_name": self.operation_name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration": self.duration,
            "attributes": dict(self.attributes),
            "events": list(self.events),
            "status_code": self.status_code,
            "status_description": self.status_description,
            "error": self.error,
        }


class SpanManager:
    def __init__(self):
        self._spans: Dict[str, Span] = {}
        self._traces: Dict[str, List[Span]] = {}
        self._lock = threading.RLock()

    def create_span(
        self,
        operation_name: str,
        parent_span: Optional[Span] = None,
        trace_id: Optional[str] = None,
        span_id: Optional[str] = None,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Span:
        with self._lock:
            actual_trace_id = trace_id or (parent_span.trace_id if parent_span else str(uuid.uuid4()))
            actual_span_id = span_id or str(uuid.uuid4())

            span = Span(
                name=operation_name,
                trace_id=actual_trace_id,
                span_id=actual_span_id,
                parent_span_id=parent_span.span_id if parent_span else "",
                operation_name=operation_name,
                attributes=attributes or {},
            )

            self._spans[actual_span_id] = span
            self._traces.setdefault(actual_trace_id, []).append(span)
            return span

    def get_span(self, span_id: str) -> Optional[Span]:
        with self._lock:
            return self._spans.get(span_id)

    def get_trace(self, trace_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            spans = self._traces.get(trace_id)
            if not spans:
                return None
            return {
                "trace_id": trace_id,
                "span_count": len(spans),
                "spans": [s.to_dict() for s in spans],
                "start_time": min(s.start_time for s in spans),
                "end_time": max(s.end_time for s in spans if s.end_time > 0) or 0.0,
            }

    def get_active_spans(self, trace_id: str) -> List[Span]:
        with self._lock:
            return [s for s in self._traces.get(trace_id, []) if s.is_recording]

    def remove_span(self, span_id: str) -> bool:
        with self._lock:
            span = self._spans.pop(span_id, None)
            if span:
                trace_id = span.trace_id
                if trace_id in self._traces:
                    try:
                        self._traces[trace_id].remove(span)
                        if not self._traces[trace_id]:
                            del self._traces[trace_id]
                    except ValueError:
                        pass
                return True
            return False

    def clear(self) -> None:
        with self._lock:
            self._spans.clear()
            self._traces.clear()

    @property
    def span_count(self) -> int:
        with self._lock:
            return len(self._spans)

    @property
    def trace_count(self) -> int:
        with self._lock:
            return len(self._traces)

    @property
    def active_trace_count(self) -> int:
        with self._lock:
            return sum(1 for spans in self._traces.values() if any(s.is_recording for s in spans))

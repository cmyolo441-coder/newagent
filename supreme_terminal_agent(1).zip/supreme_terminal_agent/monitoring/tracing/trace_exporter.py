import json
import time
import logging
from typing import Any, Dict, List, Optional, Callable
from enum import Enum
from pathlib import Path


class ExportProtocol(Enum):
    HTTP = "http"
    GRPC = "grpc"
    CONSOLE = "console"
    FILE = "file"


class TraceExporter:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._exporters: Dict[str, Callable] = {}
        self._export_count = 0
        self._is_running = False
        self._default_protocol = ExportProtocol.CONSOLE
        self._export_path: Optional[Path] = None

    async def start(self) -> None:
        self._is_running = True
        self._logger.info("Trace exporter started")

    async def stop(self) -> None:
        self._is_running = False
        self._logger.info("Trace exporter stopped")

    def set_export_path(self, path: str) -> None:
        self._export_path = Path(path)
        self._export_path.parent.mkdir(parents=True, exist_ok=True)

    def register_exporter(self, name: str, exporter_fn: Callable) -> None:
        if name in self._exporters:
            raise ValueError(f"Exporter '{name}' already registered")
        self._exporters[name] = exporter_fn

    def unregister_exporter(self, name: str) -> None:
        self._exporters.pop(name, None)

    async def export(self, trace_data: Dict[str, Any], protocol: Optional[ExportProtocol] = None) -> bool:
        protocol = protocol or self._default_protocol
        try:
            if protocol == ExportProtocol.CONSOLE:
                self._export_console(trace_data)
            elif protocol == ExportProtocol.FILE:
                self._export_file(trace_data)
            elif protocol == ExportProtocol.HTTP:
                await self._export_http(trace_data)
            elif protocol == ExportProtocol.GRPC:
                await self._export_grpc(trace_data)
            else:
                raise ValueError(f"Unsupported protocol: {protocol}")

            for name, fn in self._exporters.items():
                try:
                    fn(trace_data)
                except Exception as e:
                    self._logger.error("Custom exporter '%s' failed: %s", name, e)

            self._export_count += 1
            return True
        except Exception as e:
            self._logger.error("Export failed: %s", e)
            return False

    async def export_batch(self, traces: List[Dict[str, Any]]) -> int:
        success_count = 0
        for trace_data in traces:
            if await self.export(trace_data):
                success_count += 1
        return success_count

    def _export_console(self, trace_data: Dict[str, Any]) -> None:
        output = json.dumps(trace_data, indent=2, default=str)
        self._logger.info("Trace export:\n%s", output)

    def _export_file(self, trace_data: Dict[str, Any]) -> None:
        if not self._export_path:
            self._export_path = Path("traces.jsonl")
        trace_id = trace_data.get("trace_id", "unknown")
        timestamp = int(time.time())
        filename = self._export_path
        if filename.suffix == ".jsonl":
            with open(filename, "a") as f:
                f.write(json.dumps(trace_data, default=str) + "\n")
        else:
            filepath = filename.parent / f"trace_{trace_id}_{timestamp}.json"
            with open(filepath, "w") as f:
                json.dump(trace_data, f, indent=2, default=str)

    async def _export_http(self, trace_data: Dict[str, Any]) -> None:
        self._logger.debug("HTTP export not implemented, falling back to console")
        self._export_console(trace_data)

    async def _export_grpc(self, trace_data: Dict[str, Any]) -> None:
        self._logger.debug("gRPC export not implemented, falling back to console")
        self._export_console(trace_data)

    def flush(self) -> None:
        pass

    @property
    def is_running(self) -> bool:
        return self._is_running

    @property
    def export_count(self) -> int:
        return self._export_count

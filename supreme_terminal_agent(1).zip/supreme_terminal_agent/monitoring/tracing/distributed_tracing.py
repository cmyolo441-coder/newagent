import logging
import uuid
from typing import Any, Dict, List, Optional

from monitoring.tracing.span_manager import Span
from monitoring.tracing.context_propagation import ContextPropagator


class DistributedTracer:
    def __init__(self, service_name: str = "supreme_terminal_agent"):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._service_name = service_name
        self._context_propagator = ContextPropagator()

    def start_client_span(
        self,
        operation_name: str,
        parent_span: Span,
        peer_service: str,
        peer_address: str = "",
    ) -> Span:
        span = Span(
            name=operation_name,
            trace_id=parent_span.trace_id,
            parent_span_id=parent_span.span_id,
        )
        span.set_attribute("span.kind", "client")
        span.set_attribute("peer.service", peer_service)
        if peer_address:
            span.set_attribute("peer.address", peer_address)
        span.set_attribute("service.name", self._service_name)
        return span

    def start_server_span(
        self,
        operation_name: str,
        carrier: Dict[str, str],
        service_name: Optional[str] = None,
    ) -> Span:
        parent_context = self._context_propagator.extract(carrier)
        if parent_context:
            trace_id = parent_context.trace_id
            parent_span_id = parent_context.span_id
        else:
            trace_id = str(uuid.uuid4())
            parent_span_id = ""

        span = Span(
            name=operation_name,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
        )
        span.set_attribute("span.kind", "server")
        span.set_attribute("service.name", service_name or self._service_name)

        if parent_context:
            baggage = parent_context.attributes.get("baggage", {})
            if isinstance(baggage, dict):
                span.set_attribute("baggage", dict(baggage))

        return span

    def inject_span_context(self, span: Span, carrier: Dict[str, str]) -> None:
        self._context_propagator.inject(span, carrier)

    def extract_span_context(self, carrier: Dict[str, str]) -> Optional[Span]:
        return self._context_propagator.extract(carrier)

    def serialize_context(self, span: Span) -> Dict[str, str]:
        carrier: Dict[str, str] = {}
        self._context_propagator.inject(span, carrier)
        return carrier

    def deserialize_context(self, carrier: Dict[str, str]) -> Optional[Span]:
        return self._context_propagator.extract(carrier)

    def create_rpc_client_span(
        self,
        method: str,
        target: str,
        parent_span: Span,
        request_metadata: Optional[Dict[str, str]] = None,
    ) -> Span:
        span = self.start_client_span(
            f"{method} {target}",
            parent_span,
            peer_service=target,
        )
        span.set_attribute("rpc.method", method)
        span.set_attribute("rpc.target", target)
        span.set_attribute("rpc.system", "grpc")
        if request_metadata:
            span.set_attribute("rpc.request_metadata", str(request_metadata))
        return span

    def create_http_client_span(
        self,
        method: str,
        url: str,
        parent_span: Span,
        request_headers: Optional[Dict[str, str]] = None,
    ) -> Span:
        span = self.start_client_span(
            f"{method} {url}",
            parent_span,
            peer_service=url,
        )
        span.set_attribute("http.method", method)
        span.set_attribute("http.url", url)
        span.set_attribute("http.kind", "client")
        if request_headers:
            span.set_attribute("http.request_headers", str(request_headers))
        return span

    def create_http_server_span(
        self,
        method: str,
        path: str,
        carrier: Dict[str, str],
        service_name: Optional[str] = None,
    ) -> Span:
        span = self.start_server_span(f"{method} {path}", carrier, service_name)
        span.set_attribute("http.method", method)
        span.set_attribute("http.path", path)
        span.set_attribute("http.kind", "server")
        return span

    def add_request_headers(self, span: Span, headers: Dict[str, str]) -> None:
        self._context_propagator.inject(span, headers)

    def parse_request_headers(self, headers: Dict[str, str]) -> Optional[Span]:
        return self._context_propagator.extract(headers)

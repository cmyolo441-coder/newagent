import hashlib
import logging
import random
import threading
from typing import Dict, Optional, Set
from enum import Enum


class SamplingDecision(Enum):
    ACCEPT = "accept"
    DROP = "drop"


class SamplingStrategy(Enum):
    ALWAYS = "always"
    NEVER = "never"
    RATE = "rate"
    RATE_LIMITED = "rate_limited"
    PROBABILISTIC = "probabilistic"
    PARENT_BASED = "parent_based"


class Sampler:
    def __init__(
        self,
        rate: float = 1.0,
        strategy: SamplingStrategy = SamplingStrategy.RATE,
        max_per_second: Optional[float] = None,
    ):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._rate = rate
        self._strategy = strategy
        self._max_per_second = max_per_second
        self._lock = threading.Lock()
        self._second_budget: float = max_per_second or float("inf")
        self._last_reset: float = __import__("time").time()
        self._sampled_count = 0
        self._dropped_count = 0

        if strategy == SamplingStrategy.ALWAYS:
            self._rate = 1.0
        elif strategy == SamplingStrategy.NEVER:
            self._rate = 0.0

    def should_sample(self, trace_id: str) -> SamplingDecision:
        decision = self._make_decision(trace_id)
        with self._lock:
            if decision == SamplingDecision.ACCEPT:
                self._sampled_count += 1
            else:
                self._dropped_count += 1
        return decision

    def _make_decision(self, trace_id: str) -> SamplingDecision:
        if self._strategy == SamplingStrategy.ALWAYS:
            return SamplingDecision.ACCEPT
        if self._strategy == SamplingStrategy.NEVER:
            return SamplingDecision.DROP

        if self._strategy == SamplingStrategy.RATE:
            hash_val = int(hashlib.md5(trace_id.encode()).hexdigest(), 16)
            normalized = (hash_val % 1000000) / 1000000.0
            return SamplingDecision.ACCEPT if normalized < self._rate else SamplingDecision.DROP

        if self._strategy == SamplingStrategy.PROBABILISTIC:
            return SamplingDecision.ACCEPT if random.random() < self._rate else SamplingDecision.DROP

        if self._strategy == SamplingStrategy.RATE_LIMITED:
            return self._rate_limited_decision()

        if self._strategy == SamplingStrategy.PARENT_BASED:
            return SamplingDecision.ACCEPT

        return SamplingDecision.ACCEPT

    def _rate_limited_decision(self) -> SamplingDecision:
        import time
        now = time.time()
        with self._lock:
            elapsed = now - self._last_reset
            if elapsed >= 1.0:
                self._second_budget = self._max_per_second or float("inf")
                self._last_reset = now
            if self._second_budget > 0:
                self._second_budget -= 1
                return SamplingDecision.ACCEPT
            return SamplingDecision.DROP

    def set_rate(self, rate: float) -> None:
        if not 0.0 <= rate <= 1.0:
            raise ValueError("Rate must be between 0.0 and 1.0")
        with self._lock:
            self._rate = rate

    def set_strategy(self, strategy: SamplingStrategy) -> None:
        with self._lock:
            self._strategy = strategy

    def set_max_per_second(self, max_per_second: Optional[float]) -> None:
        with self._lock:
            self._max_per_second = max_per_second
            self._second_budget = max_per_second or float("inf")

    def reset_counts(self) -> None:
        with self._lock:
            self._sampled_count = 0
            self._dropped_count = 0

    def get_info(self) -> Dict:
        with self._lock:
            return {
                "strategy": self._strategy.value,
                "rate": self._rate,
                "max_per_second": self._max_per_second,
                "sampled": self._sampled_count,
                "dropped": self._dropped_count,
            }

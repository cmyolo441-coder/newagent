import json
import logging
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass

from monitoring.tracing.span_manager import Span


TRACE_PARENT_KEY = "traceparent"
TRACE_STATE_KEY = "tracestate"
BAGGAGE_KEY_PREFIX = "baggage-"


@dataclass
class PropagatedContext:
    trace_id: str
    span_id: str
    trace_flags: int = 0
    trace_state: Dict[str, str] = None
    baggage: Dict[str, str] = None

    def __post_init__(self):
        if self.trace_state is None:
            self.trace_state = {}
        if self.baggage is None:
            self.baggage = {}


class ContextPropagator:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)

    def inject(self, span: Span, carrier: Dict[str, str]) -> None:
        if not span or not span.span_id:
            return
        trace_flags = "01"
        carrier[TRACE_PARENT_KEY] = (
            f"00-{span.trace_id.replace('-', '')}-{span.span_id.replace('-', '')}-{trace_flags}"
        )
        if span.attributes.get("trace_state"):
            carrier[TRACE_STATE_KEY] = self._encode_trace_state(
                span.attributes["trace_state"]
            )
        baggage = span.attributes.get("baggage", {})
        if isinstance(baggage, dict):
            for key, value in baggage.items():
                carrier[f"{BAGGAGE_KEY_PREFIX}{key}"] = str(value)

    def extract(self, carrier: Dict[str, str]) -> Optional[Span]:
        traceparent = carrier.get(TRACE_PARENT_KEY)
        if not traceparent:
            return None
        try:
            parts = traceparent.split("-")
            if len(parts) < 4:
                self._logger.warning("Invalid traceparent format: %s", traceparent)
                return None
            version = parts[0]
            trace_id = parts[1]
            span_id = parts[2]
            trace_flags = int(parts[3], 16)

            trace_state = {}
            if TRACE_STATE_KEY in carrier:
                trace_state = self._decode_trace_state(carrier[TRACE_STATE_KEY])

            baggage = {}
            for key, value in carrier.items():
                if key.startswith(BAGGAGE_KEY_PREFIX):
                    baggage_key = key[len(BAGGAGE_KEY_PREFIX):]
                    baggage[baggage_key] = value

            if version == "00":
                trace_id = f"{trace_id[:32]:0>32}"
                span_id = f"{span_id[:16]:0>16}"

            span = Span(
                name="extracted",
                trace_id=trace_id,
                span_id=span_id,
            )
            span.set_attribute("trace_flags", trace_flags)
            span.set_attribute("trace_state", trace_state)
            span.set_attribute("baggage", baggage)
            return span
        except (ValueError, IndexError) as e:
            self._logger.error("Failed to extract context: %s", e)
            return None

    def inject_baggage(self, carrier: Dict[str, str], baggage: Dict[str, str]) -> None:
        for key, value in baggage.items():
            carrier[f"{BAGGAGE_KEY_PREFIX}{key}"] = str(value)

    def extract_baggage(self, carrier: Dict[str, str]) -> Dict[str, str]:
        baggage = {}
        for key, value in carrier.items():
            if key.startswith(BAGGAGE_KEY_PREFIX):
                baggage_key = key[len(BAGGAGE_KEY_PREFIX):]
                baggage[baggage_key] = value
        return baggage

    @staticmethod
    def _encode_trace_state(trace_state: Dict[str, str]) -> str:
        return ",".join(f"{k}={v}" for k, v in trace_state.items())

    @staticmethod
    def _decode_trace_state(trace_state_str: str) -> Dict[str, str]:
        result = {}
        for part in trace_state_str.split(","):
            part = part.strip()
            if "=" in part:
                key, value = part.split("=", 1)
                result[key.strip()] = value.strip()
        return result

    def create_child_context(self, parent_span: Span) -> Span:
        child = Span(
            name=parent_span.operation_name,
            trace_id=parent_span.trace_id,
            parent_span_id=parent_span.span_id,
        )
        if parent_span.attributes.get("baggage"):
            child.set_attribute("baggage", dict(parent_span.attributes["baggage"]))
        return child

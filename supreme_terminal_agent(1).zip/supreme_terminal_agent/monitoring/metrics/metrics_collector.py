import time
import logging
from typing import Any, Dict, List, Optional, Union
from collections import defaultdict

from monitoring.metrics.counter import Counter
from monitoring.metrics.gauge import Gauge
from monitoring.metrics.histogram import Histogram
from monitoring.metrics.summary import Summary


class MetricRegistrationError(Exception):
    pass


class MetricsCollector:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._counters: Dict[str, Counter] = {}
        self._gauges: Dict[str, Gauge] = {}
        self._histograms: Dict[str, Histogram] = {}
        self._summaries: Dict[str, Summary] = {}
        self._labels: Dict[str, Dict[str, str]] = {}
        self._is_running = False
        self._collection_count = 0

    async def start(self) -> None:
        self._is_running = True
        self._logger.info("Metrics collector started")

    async def stop(self) -> None:
        self._is_running = False
        self._logger.info("Metrics collector stopped")

    def register_counter(
        self, name: str, description: str = "", labels: Optional[Dict[str, str]] = None
    ) -> Counter:
        if name in self._counters:
            raise MetricRegistrationError(f"Counter '{name}' already registered")
        counter = Counter(name, description, labels or {})
        self._counters[name] = counter
        self._labels[name] = labels or {}
        return counter

    def register_gauge(
        self, name: str, description: str = "", labels: Optional[Dict[str, str]] = None
    ) -> Gauge:
        if name in self._gauges:
            raise MetricRegistrationError(f"Gauge '{name}' already registered")
        gauge = Gauge(name, description, labels or {})
        self._gauges[name] = gauge
        self._labels[name] = labels or {}
        return gauge

    def register_histogram(
        self,
        name: str,
        description: str = "",
        buckets: Optional[List[float]] = None,
        labels: Optional[Dict[str, str]] = None,
    ) -> Histogram:
        if name in self._histograms:
            raise MetricRegistrationError(f"Histogram '{name}' already registered")
        histogram = Histogram(name, description, buckets, labels or {})
        self._histograms[name] = histogram
        self._labels[name] = labels or {}
        return histogram

    def register_summary(
        self,
        name: str,
        description: str = "",
        quantiles: Optional[List[float]] = None,
        labels: Optional[Dict[str, str]] = None,
    ) -> Summary:
        if name in self._summaries:
            raise MetricRegistrationError(f"Summary '{name}' already registered")
        summary = Summary(name, description, quantiles, labels or {})
        self._summaries[name] = summary
        self._labels[name] = labels or {}
        return summary

    def get_counter(self, name: str) -> Counter:
        if name not in self._counters:
            raise KeyError(f"Counter '{name}' not found")
        return self._counters[name]

    def get_gauge(self, name: str) -> Gauge:
        if name not in self._gauges:
            raise KeyError(f"Gauge '{name}' not found")
        return self._gauges[name]

    def get_histogram(self, name: str) -> Histogram:
        if name not in self._histograms:
            raise KeyError(f"Histogram '{name}' not found")
        return self._histograms[name]

    def get_summary(self, name: str) -> Summary:
        if name not in self._summaries:
            raise KeyError(f"Summary '{name}' not found")
        return self._summaries[name]

    def increment_counter(self, name: str, value: float = 1.0) -> None:
        if name not in self._counters:
            self.register_counter(name)
        self._counters[name].increment(value)

    def set_gauge(self, name: str, value: float) -> None:
        if name not in self._gauges:
            self.register_gauge(name)
        self._gauges[name].set(value)

    def observe_histogram(self, name: str, value: float) -> None:
        if name not in self._histograms:
            self.register_histogram(name)
        self._histograms[name].observe(value)

    def observe_summary(self, name: str, value: float) -> None:
        if name not in self._summaries:
            self.register_summary(name)
        self._summaries[name].observe(value)

    def collect_all(self) -> Dict[str, Any]:
        self._collection_count += 1
        result = {
            "counters": {k: v.snapshot() for k, v in self._counters.items()},
            "gauges": {k: v.snapshot() for k, v in self._gauges.items()},
            "histograms": {k: v.snapshot() for k, v in self._histograms.items()},
            "summaries": {k: v.snapshot() for k, v in self._summaries.items()},
            "collection_timestamp": time.time(),
            "collection_count": self._collection_count,
        }
        return result

    def collect_metrics(self, metric_type: str) -> Dict[str, Any]:
        if metric_type == "counter":
            return {k: v.snapshot() for k, v in self._counters.items()}
        elif metric_type == "gauge":
            return {k: v.snapshot() for k, v in self._gauges.items()}
        elif metric_type == "histogram":
            return {k: v.snapshot() for k, v in self._histograms.items()}
        elif metric_type == "summary":
            return {k: v.snapshot() for k, v in self._summaries.items()}
        else:
            raise ValueError(f"Unknown metric type: {metric_type}")

    def remove_metric(self, name: str) -> bool:
        removed = False
        if name in self._counters:
            del self._counters[name]
            removed = True
        if name in self._gauges:
            del self._gauges[name]
            removed = True
        if name in self._histograms:
            del self._histograms[name]
            removed = True
        if name in self._summaries:
            del self._summaries[name]
            removed = True
        self._labels.pop(name, None)
        return removed

    def clear_all(self) -> None:
        self._counters.clear()
        self._gauges.clear()
        self._histograms.clear()
        self._summaries.clear()
        self._labels.clear()
        self._collection_count = 0

    async def flush(self) -> None:
        pass

    @property
    def metric_count(self) -> int:
        return (
            len(self._counters)
            + len(self._gauges)
            + len(self._histograms)
            + len(self._summaries)
        )

    @property
    def is_running(self) -> bool:
        return self._is_running

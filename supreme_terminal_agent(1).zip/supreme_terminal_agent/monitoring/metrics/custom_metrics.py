import time
import logging
from typing import Any, Callable, Dict, List, Optional, Tuple
from enum import Enum


class MetricType(Enum):
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    SUMMARY = "summary"
    STRING = "string"
    TIMESTAMP = "timestamp"
    INFO = "info"


class CustomMetric:
    def __init__(
        self,
        name: str,
        metric_type: MetricType,
        value_fn: Callable[[], Any],
        description: str = "",
        labels: Optional[Dict[str, str]] = None,
    ):
        self.name = name
        self.metric_type = metric_type
        self.value_fn = value_fn
        self.description = description
        self.labels = labels or {}
        self._created_at = time.time()
        self._last_collected: float = 0.0

    def collect(self) -> Any:
        try:
            value = self.value_fn()
            self._last_collected = time.time()
            return value
        except Exception as e:
            raise RuntimeError(f"Failed to collect custom metric '{self.name}': {e}")

    def snapshot(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "type": self.metric_type.value,
            "description": self.description,
            "labels": dict(self.labels),
            "value": self.collect(),
            "last_collected": self._last_collected,
            "created_at": self._created_at,
        }


class CustomMetrics:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._metrics: Dict[str, CustomMetric] = {}
        self._is_running = False

    async def start(self) -> None:
        self._is_running = True
        self._logger.info("Custom metrics started")

    async def stop(self) -> None:
        self._is_running = False
        self._logger.info("Custom metrics stopped")

    def register(
        self,
        name: str,
        metric_type: MetricType,
        value_fn: Callable[[], Any],
        description: str = "",
        labels: Optional[Dict[str, str]] = None,
    ) -> CustomMetric:
        if name in self._metrics:
            raise ValueError(f"Custom metric '{name}' already registered")
        metric = CustomMetric(name, metric_type, value_fn, description, labels)
        self._metrics[name] = metric
        return metric

    def unregister(self, name: str) -> None:
        self._metrics.pop(name, None)

    def get(self, name: str) -> CustomMetric:
        if name not in self._metrics:
            raise KeyError(f"Custom metric '{name}' not found")
        return self._metrics[name]

    def collect(self, name: str) -> Any:
        return self.get(name).collect()

    def collect_all(self) -> Dict[str, Dict[str, Any]]:
        results = {}
        for name, metric in self._metrics.items():
            try:
                results[name] = metric.snapshot()
            except Exception as e:
                self._logger.error("Error collecting metric '%s': %s", name, e)
                results[name] = {"name": name, "error": str(e)}
        return results

    def register_info_metric(
        self, name: str, info: Dict[str, str], description: str = ""
    ) -> CustomMetric:
        return self.register(
            name,
            MetricType.INFO,
            lambda: info,
            description=description,
        )

    def register_string_metric(
        self, name: str, value_fn: Callable[[], str], description: str = ""
    ) -> CustomMetric:
        return self.register(name, MetricType.STRING, value_fn, description=description)

    def register_timestamp_metric(
        self, name: str, value_fn: Optional[Callable[[], float]] = None, description: str = ""
    ) -> CustomMetric:
        fn = value_fn or (lambda: time.time())
        return self.register(name, MetricType.TIMESTAMP, fn, description=description)

    def clear(self) -> None:
        self._metrics.clear()

    @property
    def metric_count(self) -> int:
        return len(self._metrics)

    @property
    def metric_names(self) -> List[str]:
        return list(self._metrics.keys())

    @property
    def is_running(self) -> bool:
        return self._is_running

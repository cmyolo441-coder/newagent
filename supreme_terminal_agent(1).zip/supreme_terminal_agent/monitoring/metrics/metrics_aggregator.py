import time
import logging
import threading
from typing import Any, Dict, List, Optional, Tuple
from collections import defaultdict
from dataclasses import dataclass, field
from statistics import mean, median, stdev


@dataclass
class AggregatedValue:
    count: int = 0
    sum: float = 0.0
    min: float = float("inf")
    max: float = float("-inf")
    last: float = 0.0
    mean: float = 0.0
    median: float = 0.0
    stddev: float = 0.0
    p50: float = 0.0
    p90: float = 0.0
    p95: float = 0.0
    p99: float = 0.0
    timestamp: float = 0.0


class AggregationWindow:
    def __init__(self, window_size: int = 1000):
        self.window_size = window_size
        self.values: List[float] = []
        self._lock = threading.Lock()

    def add(self, value: float) -> None:
        with self._lock:
            self.values.append(value)
            if len(self.values) > self.window_size:
                self.values.pop(0)

    def clear(self) -> None:
        with self._lock:
            self.values.clear()

    def aggregate(self) -> AggregatedValue:
        with self._lock:
            if not self.values:
                return AggregatedValue(timestamp=time.time())
            vals = sorted(self.values)
            n = len(vals)
            total = sum(vals)
            avg = total / n
            med = median(vals) if n >= 1 else 0.0
            sd = stdev(vals) if n >= 2 else 0.0
            result = AggregatedValue(
                count=n,
                sum=total,
                min=vals[0],
                max=vals[-1],
                last=self.values[-1],
                mean=avg,
                median=med,
                stddev=sd,
                p50=self._percentile(vals, 50),
                p90=self._percentile(vals, 90),
                p95=self._percentile(vals, 95),
                p99=self._percentile(vals, 99),
                timestamp=time.time(),
            )
            return result

    @staticmethod
    def _percentile(sorted_vals: List[float], percentile: float) -> float:
        if not sorted_vals:
            return 0.0
        k = (percentile / 100.0) * (len(sorted_vals) - 1)
        f = int(k)
        c = f + 1
        if c >= len(sorted_vals):
            return sorted_vals[-1]
        return sorted_vals[f] + (k - f) * (sorted_vals[c] - sorted_vals[f])


class MetricsAggregator:
    def __init__(self, window_size: int = 1000):
        self._logger = logging.getLogger(self.__class__.__name__)
        self.window_size = window_size
        self._windows: Dict[str, AggregationWindow] = {}
        self._aggregated: Dict[str, AggregatedValue] = {}
        self._lock = threading.RLock()
        self._is_running = False

    async def start(self) -> None:
        self._is_running = True
        self._logger.info("Metrics aggregator started")

    async def stop(self) -> None:
        self._is_running = False
        self._logger.info("Metrics aggregator stopped")

    def add_value(self, metric_name: str, value: float) -> None:
        with self._lock:
            if metric_name not in self._windows:
                self._windows[metric_name] = AggregationWindow(self.window_size)
            self._windows[metric_name].add(value)

    def aggregate(self, metric_name: str) -> Optional[AggregatedValue]:
        with self._lock:
            window = self._windows.get(metric_name)
            if window is None:
                return None
            result = window.aggregate()
            self._aggregated[metric_name] = result
            return result

    def aggregate_all(self) -> Dict[str, AggregatedValue]:
        with self._lock:
            results = {}
            for name, window in self._windows.items():
                results[name] = window.aggregate()
            self._aggregated.update(results)
            return results

    def get_aggregated(self, metric_name: str) -> Optional[AggregatedValue]:
        with self._lock:
            return self._aggregated.get(metric_name)

    def reset(self, metric_name: str) -> None:
        with self._lock:
            window = self._windows.get(metric_name)
            if window:
                window.clear()
            self._aggregated.pop(metric_name, None)

    def reset_all(self) -> None:
        with self._lock:
            for window in self._windows.values():
                window.clear()
            self._aggregated.clear()

    @property
    def metric_count(self) -> int:
        with self._lock:
            return len(self._windows)

    @property
    def is_running(self) -> bool:
        return self._is_running

import threading
import bisect
import time
from typing import Any, Dict, List, Optional


DEFAULT_QUANTILES = [0.5, 0.9, 0.95, 0.99]


class Summary:
    def __init__(
        self,
        name: str,
        description: str = "",
        quantiles: Optional[List[float]] = None,
        labels: Optional[Dict[str, str]] = None,
        max_age: float = 600.0,
        age_buckets: int = 5,
        buf_cap: int = 500,
    ):
        self._name = name
        self._description = description
        self._labels = labels or {}
        self._quantiles = sorted(quantiles) if quantiles else DEFAULT_QUANTILES
        self._values: List[float] = []
        self._total_count: int = 0
        self._sum: float = 0.0
        self._max_age = max_age
        self._age_buckets = age_buckets
        self._buf_cap = buf_cap
        self._lock = threading.Lock()
        self._created_at = time.time()
        self._updated_at = time.time()

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def labels(self) -> Dict[str, str]:
        return dict(self._labels)

    def observe(self, value: float) -> None:
        with self._lock:
            bisect.insort(self._values, value)
            self._total_count += 1
            self._sum += value
            if len(self._values) > self._buf_cap:
                self._values = self._values[-self._buf_cap:]
            self._updated_at = time.time()

    def reset(self) -> None:
        with self._lock:
            self._values.clear()
            self._total_count = 0
            self._sum = 0.0
            self._updated_at = time.time()

    def _quantile_value(self, q: float) -> float:
        if not self._values:
            return 0.0
        idx = q * (len(self._values) - 1)
        f_idx = int(idx)
        c_idx = f_idx + 1
        if c_idx >= len(self._values):
            return self._values[-1]
        return self._values[f_idx] + (idx - f_idx) * (self._values[c_idx] - self._values[f_idx])

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            quantiles = {str(q): self._quantile_value(q) for q in self._quantiles}
            return {
                "name": self._name,
                "description": self._description,
                "labels": dict(self._labels),
                "quantiles": quantiles,
                "count": self._total_count,
                "sum": self._sum,
                "created_at": self._created_at,
                "updated_at": self._updated_at,
            }

    def __repr__(self) -> str:
        return f"Summary(name={self._name}, count={self._total_count}, sum={self._sum})"

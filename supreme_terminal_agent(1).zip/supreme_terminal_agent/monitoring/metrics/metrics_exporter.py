import json
import time
import logging
from typing import Any, Dict, List, Optional, Callable
from enum import Enum
from pathlib import Path


class ExportFormat(Enum):
    JSON = "json"
    PROMETHEUS = "prometheus"
    OPENMETRICS = "openmetrics"
    GRAPHITE = "graphite"
    INFLUXDB = "influxdb"
    CSV = "csv"


class ExportError(Exception):
    pass


class MetricsExporter:
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._exporters: Dict[str, Callable] = {}
        self._is_running = False
        self._export_count = 0

    async def start(self) -> None:
        self._is_running = True
        self._logger.info("Metrics exporter started")

    async def stop(self) -> None:
        self._is_running = False
        self._logger.info("Metrics exporter stopped")

    def register_exporter(self, name: str, exporter_fn: Callable) -> None:
        if name in self._exporters:
            raise ExportError(f"Exporter '{name}' already registered")
        self._exporters[name] = exporter_fn

    def unregister_exporter(self, name: str) -> None:
        self._exporters.pop(name, None)

    def export(self, metrics: Dict[str, Any], format: ExportFormat = ExportFormat.JSON) -> str:
        if format == ExportFormat.JSON:
            return self._export_json(metrics)
        elif format == ExportFormat.PROMETHEUS:
            return self._export_prometheus(metrics)
        elif format == ExportFormat.GRAPHITE:
            return self._export_graphite(metrics)
        elif format == ExportFormat.INFLUXDB:
            return self._export_influxdb(metrics)
        elif format == ExportFormat.CSV:
            return self._export_csv(metrics)
        else:
            raise ExportError(f"Unsupported export format: {format}")

    def export_to_all(self, metrics: Dict[str, Any]) -> Dict[str, str]:
        results = {}
        for format in ExportFormat:
            try:
                results[format.value] = self.export(metrics, format)
            except Exception as e:
                self._logger.error("Export to %s failed: %s", format.value, e)
                results[format.value] = ""
        return results

    def export_to_file(self, metrics: Dict[str, Any], filepath: str) -> None:
        path = Path(filepath)
        suffix = path.suffix.lower()
        format_map = {
            ".json": ExportFormat.JSON,
            ".prom": ExportFormat.PROMETHEUS,
            ".csv": ExportFormat.CSV,
        }
        format = format_map.get(suffix, ExportFormat.JSON)
        data = self.export(metrics, format)
        path.write_text(data)

    def export_custom(self, metrics: Dict[str, Any], exporter_name: str) -> str:
        if exporter_name not in self._exporters:
            raise ExportError(f"Exporter '{exporter_name}' not registered")
        return self._exporters[exporter_name](metrics)

    def _export_json(self, metrics: Dict[str, Any]) -> str:
        return json.dumps(metrics, indent=2, default=str)

    def _export_prometheus(self, metrics: Dict[str, Any]) -> str:
        lines: List[str] = []
        for metric_type in ("counters", "gauges", "histograms", "summaries"):
            items = metrics.get(metric_type, {})
            for name, data in items.items():
                if isinstance(data, dict):
                    value = data.get("value", data.get("count", 0))
                    labels = data.get("labels", {})
                    label_str = ",".join(f'{k}="{v}"' for k, v in labels.items())
                    if label_str:
                        lines.append(f'{name}{{{label_str}}} {value}')
                    else:
                        lines.append(f"{name} {value}")
                    if metric_type == "histogram" and "buckets" in data:
                        for bucket, count in data["buckets"].items():
                            lines.append(f'{name}_bucket{{{label_str},le="{bucket}"}} {count}')
                        lines.append(f'{name}_bucket{{{label_str},le="+Inf"}} {data.get("count", 0)}')
                        lines.append(f'{name}_sum {data.get("sum", 0)}')
                        lines.append(f'{name}_count {data.get("count", 0)}')
        return "\n".join(lines)

    def _export_graphite(self, metrics: Dict[str, Any]) -> str:
        lines: List[str] = []
        timestamp = int(time.time())
        for metric_type in ("counters", "gauges", "histograms", "summaries"):
            items = metrics.get(metric_type, {})
            for name, data in items.items():
                if isinstance(data, dict):
                    value = data.get("value", data.get("count", 0))
                    lines.append(f"metrics.{name} {value} {timestamp}")
        return "\n".join(lines)

    def _export_influxdb(self, metrics: Dict[str, Any]) -> str:
        lines: List[str] = []
        timestamp = int(time.time() * 1e9)
        for metric_type in ("counters", "gauges", "histograms", "summaries"):
            items = metrics.get(metric_type, {})
            for name, data in items.items():
                if isinstance(data, dict):
                    labels = data.get("labels", {})
                    tag_str = ",".join(f"{k}={v}" for k, v in labels.items())
                    value = data.get("value", data.get("count", 0))
                    if tag_str:
                        lines.append(f"{metric_type}_{name},{tag_str} value={value} {timestamp}")
                    else:
                        lines.append(f"{metric_type}_{name} value={value} {timestamp}")
        return "\n".join(lines)

    def _export_csv(self, metrics: Dict[str, Any]) -> str:
        lines = ["metric_type,metric_name,value,timestamp"]
        timestamp = time.time()
        for metric_type in ("counters", "gauges", "histograms", "summaries"):
            items = metrics.get(metric_type, {})
            for name, data in items.items():
                if isinstance(data, dict):
                    value = data.get("value", data.get("count", 0))
                    lines.append(f"{metric_type},{name},{value},{timestamp}")
        return "\n".join(lines)

    @property
    def is_running(self) -> bool:
        return self._is_running

    @property
    def export_count(self) -> int:
        return self._export_count

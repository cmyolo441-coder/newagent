import threading
import time
from typing import Any, Dict, Optional


class Gauge:
    def __init__(
        self,
        name: str,
        description: str = "",
        labels: Optional[Dict[str, str]] = None,
    ):
        self._name = name
        self._description = description
        self._labels = labels or {}
        self._value: float = 0.0
        self._lock = threading.Lock()
        self._created_at = time.time()
        self._updated_at = time.time()

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def labels(self) -> Dict[str, str]:
        return dict(self._labels)

    def set(self, value: float) -> None:
        with self._lock:
            self._value = value
            self._updated_at = time.time()

    def increment(self, value: float = 1.0) -> None:
        with self._lock:
            self._value += value
            self._updated_at = time.time()

    def decrement(self, value: float = 1.0) -> None:
        with self._lock:
            self._value -= value
            self._updated_at = time.time()

    def get(self) -> float:
        with self._lock:
            return self._value

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "name": self._name,
                "description": self._description,
                "labels": dict(self._labels),
                "value": self._value,
                "created_at": self._created_at,
                "updated_at": self._updated_at,
            }

    def __repr__(self) -> str:
        return f"Gauge(name={self._name}, value={self._value})"

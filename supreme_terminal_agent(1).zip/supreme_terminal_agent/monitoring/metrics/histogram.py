import threading
import time
from typing import Any, Dict, List, Optional, Tuple


DEFAULT_BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0]


class Histogram:
    def __init__(
        self,
        name: str,
        description: str = "",
        buckets: Optional[List[float]] = None,
        labels: Optional[Dict[str, str]] = None,
    ):
        self._name = name
        self._description = description
        self._labels = labels or {}
        self._buckets = sorted(buckets) if buckets else DEFAULT_BUCKETS
        self._counts: List[int] = [0] * len(self._buckets)
        self._total_count: int = 0
        self._sum: float = 0.0
        self._lock = threading.Lock()
        self._created_at = time.time()
        self._updated_at = time.time()

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def labels(self) -> Dict[str, str]:
        return dict(self._labels)

    def observe(self, value: float) -> None:
        with self._lock:
            self._total_count += 1
            self._sum += value
            for i, bucket in enumerate(self._buckets):
                if value <= bucket:
                    self._counts[i] += 1
                    break
            self._updated_at = time.time()

    def reset(self) -> None:
        with self._lock:
            self._counts = [0] * len(self._buckets)
            self._total_count = 0
            self._sum = 0.0
            self._updated_at = time.time()

    @property
    def buckets(self) -> List[float]:
        return list(self._buckets)

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            bucket_counts = {}
            cumulative = 0
            for i, bucket in enumerate(self._buckets):
                cumulative += self._counts[i]
                bucket_counts[str(bucket)] = cumulative
            return {
                "name": self._name,
                "description": self._description,
                "labels": dict(self._labels),
                "buckets": bucket_counts,
                "count": self._total_count,
                "sum": self._sum,
                "created_at": self._created_at,
                "updated_at": self._updated_at,
            }

    def __repr__(self) -> str:
        return f"Histogram(name={self._name}, count={self._total_count}, sum={self._sum})"

"""Custom Serializer - User-defined serialization."""

from __future__ import annotations

from typing import Any, Callable, Optional


class CustomSerializer:
    def __init__(
        self,
        serialize_fn: Optional[Callable] = None,
        deserialize_fn: Optional[Callable] = None,
    ):
        self._serialize_fn = serialize_fn
        self._deserialize_fn = deserialize_fn

    def set_serialize_fn(self, fn: Callable) -> None:
        self._serialize_fn = fn

    def set_deserialize_fn(self, fn: Callable) -> None:
        self._deserialize_fn = fn

    def serialize(self, data: Any, **kwargs) -> bytes:
        if self._serialize_fn:
            return self._serialize_fn(data, **kwargs)
        raise NotImplementedError("Serialize function not set")

    def deserialize(self, data: bytes, **kwargs) -> Any:
        if self._deserialize_fn:
            return self._deserialize_fn(data, **kwargs)
        raise NotImplementedError("Deserialize function not set")

    def __repr__(self) -> str:
        return "<CustomSerializer>"

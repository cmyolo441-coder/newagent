"""Protobuf Serializer."""

from __future__ import annotations

from typing import Any, Type


class ProtobufSerializer:
    def __init__(self, message_class: Any = None):
        self._message_class = message_class

    def serialize(self, data: Any, **kwargs) -> bytes:
        if self._message_class:
            msg = self._message_class()
            for key, value in data.items():
                if hasattr(msg, key):
                    setattr(msg, key, value)
            return msg.SerializeToString()
        return data.SerializeToString()

    def deserialize(self, data: bytes, **kwargs) -> Any:
        if self._message_class:
            msg = self._message_class()
            msg.ParseFromString(data)
            return msg
        return data

    def __repr__(self) -> str:
        return f"<ProtobufSerializer message_class={self._message_class.__name__ if self._message_class else 'None'}>"

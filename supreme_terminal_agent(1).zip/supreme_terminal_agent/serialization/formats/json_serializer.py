"""JSON Serializer."""

from __future__ import annotations

import json
from typing import Any


class JSONSerializer:
    def serialize(self, data: Any, **kwargs) -> bytes:
        return json.dumps(data, **kwargs).encode("utf-8")

    def deserialize(self, data: bytes, **kwargs) -> Any:
        return json.loads(data.decode("utf-8"), **kwargs)

    def __repr__(self) -> str:
        return "<JSONSerializer>"

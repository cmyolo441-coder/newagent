"""YAML Serializer."""

from __future__ import annotations

from typing import Any


class YAMLSerializer:
    def serialize(self, data: Any, **kwargs) -> bytes:
        import yaml
        return yaml.dump(data, **kwargs).encode("utf-8")

    def deserialize(self, data: bytes, **kwargs) -> Any:
        import yaml
        return yaml.safe_load(data.decode("utf-8"), **kwargs)

    def __repr__(self) -> str:
        return "<YAMLSerializer>"

"""Pickle Serializer."""

from __future__ import annotations

import pickle
from typing import Any


class PickleSerializer:
    def serialize(self, data: Any, **kwargs) -> bytes:
        protocol = kwargs.get("protocol", pickle.HIGHEST_PROTOCOL)
        return pickle.dumps(data, protocol=protocol)

    def deserialize(self, data: bytes, **kwargs) -> Any:
        return pickle.loads(data)

    def __repr__(self) -> str:
        return "<PickleSerializer>"

"""TOML Serializer."""

from __future__ import annotations

from typing import Any


class TOMLSerializer:
    def serialize(self, data: Any, **kwargs) -> bytes:
        import tomli_w
        return tomli_w.dumps(data).encode("utf-8")

    def deserialize(self, data: bytes, **kwargs) -> Any:
        import tomllib
        return tomllib.loads(data.decode("utf-8"))

    def __repr__(self) -> str:
        return "<TOMLSerializer>"

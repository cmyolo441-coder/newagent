"""CBOR Serializer."""

from __future__ import annotations

from typing import Any


class CBORSerializer:
    def serialize(self, data: Any, **kwargs) -> bytes:
        import cbor2
        return cbor2.dumps(data, **kwargs)

    def deserialize(self, data: bytes, **kwargs) -> Any:
        import cbor2
        return cbor2.loads(data, **kwargs)

    def __repr__(self) -> str:
        return "<CBORSerializer>"

"""XML Serializer."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import Any


class XMLSerializer:
    def serialize(self, data: Any, **kwargs) -> bytes:
        root_name = kwargs.get("root_name", "root")
        root = ET.Element(root_name)
        self._dict_to_xml(root, data)
        return ET.tostring(root, encoding="utf-8")

    def _dict_to_xml(self, parent: ET.Element, data: Any) -> None:
        if isinstance(data, dict):
            for key, value in data.items():
                child = ET.SubElement(parent, key)
                self._dict_to_xml(child, value)
        elif isinstance(data, list):
            for item in data:
                child = ET.SubElement(parent, "item")
                self._dict_to_xml(child, item)
        else:
            parent.text = str(data)

    def deserialize(self, data: bytes, **kwargs) -> Any:
        root = ET.fromstring(data)
        return self._xml_to_dict(root)

    def _xml_to_dict(self, element: ET.Element) -> Any:
        result = {}
        for child in element:
            if len(child) > 0:
                result[child.tag] = self._xml_to_dict(child)
            else:
                result[child.tag] = child.text
        if not result:
            return element.text
        return result

    def __repr__(self) -> str:
        return "<XMLSerializer>"

"""MessagePack Serializer."""

from __future__ import annotations

from typing import Any


class MsgPackSerializer:
    def serialize(self, data: Any, **kwargs) -> bytes:
        import msgpack
        return msgpack.packb(data, **kwargs)

    def deserialize(self, data: bytes, **kwargs) -> Any:
        import msgpack
        return msgpack.unpackb(data, **kwargs)

    def __repr__(self) -> str:
        return "<MsgPackSerializer>"

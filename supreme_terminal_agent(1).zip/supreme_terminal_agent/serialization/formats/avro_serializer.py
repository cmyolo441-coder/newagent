"""Avro Serializer."""

from __future__ import annotations

from typing import Any, Dict, Optional


class AvroSerializer:
    def __init__(self, schema: Optional[Dict[str, Any]] = None):
        self._schema = schema

    def serialize(self, data: Any, **kwargs) -> bytes:
        import fastavro
        schema = kwargs.get("schema", self._schema)
        if schema is None:
            raise ValueError("Avro schema required")
        return fastavro.writer(None, schema, [data])

    def deserialize(self, data: bytes, **kwargs) -> Any:
        import fastavro
        schema = kwargs.get("schema")
        if schema:
            return fastavro.reader(data, schema)
        return fastavro.reader(data)

    def __repr__(self) -> str:
        return "<AvroSerializer>"

"""Serialization Manager - Manages serialization formats."""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Type

logger = logging.getLogger(__name__)


class SerializationManager:
    def __init__(self):
        self._serializers: Dict[str, Any] = {}

    def register(self, name: str, serializer: Any) -> None:
        self._serializers[name] = serializer

    def unregister(self, name: str) -> None:
        self._serializers.pop(name, None)

    def get_serializer(self, name: str) -> Any:
        serializer = self._serializers.get(name)
        if serializer is None:
            raise ValueError(f"Unknown serializer: {name}")
        return serializer

    def serialize(self, name: str, data: Any, **kwargs) -> bytes:
        serializer = self.get_serializer(name)
        return serializer.serialize(data, **kwargs)

    def deserialize(self, name: str, data: bytes, **kwargs) -> Any:
        serializer = self.get_serializer(name)
        return serializer.deserialize(data, **kwargs)

    def get_available(self) -> list:
        return list(self._serializers.keys())

    def __repr__(self) -> str:
        return f"<SerializationManager formats={len(self._serializers)}>"

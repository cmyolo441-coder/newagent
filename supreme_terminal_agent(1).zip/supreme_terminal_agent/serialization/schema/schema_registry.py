"""Schema Registry - Stores and retrieves schemas."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class SchemaRegistry:
    def __init__(self):
        self._schemas: Dict[str, Any] = {}

    def register(self, name: str, schema: Any) -> None:
        self._schemas[name] = schema
        logger.debug(f"Registered schema: {name}")

    def unregister(self, name: str) -> None:
        self._schemas.pop(name, None)

    def get(self, name: str) -> Optional[Any]:
        return self._schemas.get(name)

    def has(self, name: str) -> bool:
        return name in self._schemas

    def get_all(self) -> Dict[str, Any]:
        return dict(self._schemas)

    def get_names(self) -> List[str]:
        return list(self._schemas.keys())

    def clear(self) -> None:
        self._schemas.clear()

    def __repr__(self) -> str:
        return f"<SchemaRegistry schemas={len(self._schemas)}>"

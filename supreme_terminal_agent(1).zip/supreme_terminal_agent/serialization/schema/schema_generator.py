"""Schema Generator - Generates schemas from data."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class SchemaGenerator:
    def __init__(self):
        self._generators: Dict[str, Any] = {}

    def register_generator(self, format_name: str, generator_fn: Any) -> None:
        self._generators[format_name] = generator_fn

    def generate(self, data: Any, format_name: str = "json", **kwargs) -> Any:
        generator = self._generators.get(format_name)
        if generator is None:
            raise ValueError(f"No generator for format '{format_name}'")
        return generator(data, **kwargs)

    def infer_schema(self, data: Any) -> Dict[str, Any]:
        schema: Dict[str, Any] = {}
        if isinstance(data, dict):
            for key, value in data.items():
                schema[key] = self._infer_type(value)
        elif isinstance(data, list) and data:
            schema["items"] = self.infer_schema(data[0])
            schema["type"] = "array"
        else:
            schema["type"] = self._infer_type(data)
        return schema

    def _infer_type(self, value: Any) -> str:
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if isinstance(value, int):
            return "integer"
        if isinstance(value, float):
            return "number"
        if isinstance(value, str):
            return "string"
        if isinstance(value, list):
            return "array"
        if isinstance(value, dict):
            return "object"
        return "unknown"

    def remove_generator(self, format_name: str) -> None:
        self._generators.pop(format_name, None)

    def __repr__(self) -> str:
        return f"<SchemaGenerator generators={len(self._generators)}>"

"""Schema Evolution - Manages schema versioning and migration."""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class SchemaEvolution:
    def __init__(self):
        self._migrations: Dict[str, Dict[int, Callable]] = {}
        self._current_versions: Dict[str, int] = {}

    def register_migration(self, schema_name: str, from_version: int, to_version: int, fn: Callable) -> None:
        if schema_name not in self._migrations:
            self._migrations[schema_name] = {}
        self._migrations[schema_name][from_version] = (to_version, fn)

    def migrate(self, schema_name: str, data: Any, from_version: int, to_version: int) -> Any:
        current = from_version
        result = data
        while current < to_version:
            migration = self._migrations.get(schema_name, {}).get(current)
            if migration is None:
                raise ValueError(f"No migration path from v{current} for '{schema_name}'")
            next_version, fn = migration
            result = fn(result)
            current = next_version
        return result

    def set_version(self, schema_name: str, version: int) -> None:
        self._current_versions[schema_name] = version

    def get_version(self, schema_name: str) -> int:
        return self._current_versions.get(schema_name, 0)

    def __repr__(self) -> str:
        return f"<SchemaEvolution schemas={len(self._migrations)}>"

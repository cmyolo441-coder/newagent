"""Schema Validator - Validates data against schemas."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class SchemaValidator:
    def __init__(self):
        self._validators: Dict[str, Any] = {}

    def register_validator(self, schema_name: str, validator_fn: Any) -> None:
        self._validators[schema_name] = validator_fn

    def validate(self, schema_name: str, data: Any) -> List[str]:
        validator = self._validators.get(schema_name)
        if validator is None:
            raise ValueError(f"No validator for schema '{schema_name}'")
        errors = validator(data)
        return errors if isinstance(errors, list) else []

    def is_valid(self, schema_name: str, data: Any) -> bool:
        errors = self.validate(schema_name, data)
        return len(errors) == 0

    def remove_validator(self, schema_name: str) -> None:
        self._validators.pop(schema_name, None)

    def __repr__(self) -> str:
        return f"<SchemaValidator validators={len(self._validators)}>"

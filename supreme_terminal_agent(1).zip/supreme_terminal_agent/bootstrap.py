"""
System bootstrap - initializes all components
"""
from core.lifecycle import LifecycleManager
from config import Config

def bootstrap():
    config = Config.load()
    lifecycle = LifecycleManager(config)
    lifecycle.initialize_all()
    return lifecycle

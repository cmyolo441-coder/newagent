from platforms.platform_detector import PlatformDetector
from platforms.platform_adapter import PlatformAdapter

__all__ = ["PlatformDetector", "PlatformAdapter"]

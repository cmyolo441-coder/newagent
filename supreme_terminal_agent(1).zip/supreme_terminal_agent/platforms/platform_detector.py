import os
import sys
import platform
import subprocess
from enum import Enum
from typing import Optional


class PlatformType(Enum):
    LINUX = "linux"
    MACOS = "macos"
    WINDOWS = "windows"
    UNKNOWN = "unknown"


class Architecture(Enum):
    X86_32 = "x86_32"
    X86_64 = "x86_64"
    ARM_32 = "arm_32"
    ARM_64 = "arm_64"
    RISCV_64 = "riscv_64"
    UNKNOWN = "unknown"


class PlatformInfo:
    def __init__(self) -> None:
        self.platform_type: PlatformType = PlatformDetector.detect_platform()
        self.architecture: Architecture = PlatformDetector.detect_architecture()
        self.os_name: str = platform.system()
        self.os_release: str = platform.release()
        self.os_version: str = platform.version()
        self.hostname: str = platform.node()
        self.machine: str = platform.machine()
        self.processor: str = platform.processor()
        self.python_version: str = sys.version
        self.python_implementation: str = platform.python_implementation()
        self.is_64bit: bool = sys.maxsize > 2 ** 32
        self.is_container: bool = PlatformDetector.is_running_in_container()
        self.is_vm: bool = PlatformDetector.is_running_in_vm()
        self.is_wsl: bool = PlatformDetector.is_wsl()


class PlatformDetector:
    @staticmethod
    def detect_platform() -> PlatformType:
        system = platform.system().lower()
        if system == "linux":
            return PlatformType.LINUX
        elif system == "darwin":
            return PlatformType.MACOS
        elif system == "windows":
            return PlatformType.WINDOWS
        return PlatformType.UNKNOWN

    @staticmethod
    def detect_architecture() -> Architecture:
        machine = platform.machine().lower()
        if machine in ("x86_64", "amd64", "x64"):
            return Architecture.X86_64
        elif machine in ("i386", "i686", "x86"):
            return Architecture.X86_32
        elif machine in ("aarch64", "arm64"):
            return Architecture.ARM_64
        elif machine.startswith("arm"):
            return Architecture.ARM_32
        elif machine.startswith("riscv64"):
            return Architecture.RISCV_64
        return Architecture.UNKNOWN

    @staticmethod
    def is_running_in_container() -> bool:
        if not sys.platform.startswith("linux"):
            return False
        try:
            if os.path.isfile("/.dockerenv"):
                return True
            if os.path.isfile("/proc/1/cgroup"):
                with open("/proc/1/cgroup") as f:
                    content = f.read()
                if any(kw in content for kw in ("docker", "kubepods", "containerd")):
                    return True
        except OSError:
            pass
        return False

    @staticmethod
    def is_running_in_vm() -> bool:
        if not sys.platform.startswith("linux"):
            return False
        try:
            result = subprocess.run(
                ["systemd-detect-virt", "--vm"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip() == "none":
                return False
            return result.returncode == 0
        except (FileNotFoundError, subprocess.SubprocessError):
            pass
        try:
            with open("/proc/cpuinfo") as f:
                cpuinfo = f.read().lower()
            return any(kw in cpuinfo for kw in ("hypervisor", "qemu", "kvm", "vmware", "virtualbox"))
        except OSError:
            pass
        return False

    @staticmethod
    def is_wsl() -> bool:
        if not sys.platform.startswith("linux"):
            return False
        try:
            with open("/proc/version") as f:
                return "microsoft" in f.read().lower()
        except OSError:
            pass
        return False

    @staticmethod
    def get_platform_info() -> PlatformInfo:
        return PlatformInfo()

    @staticmethod
    def get_system_details() -> dict:
        info = PlatformInfo()
        return {
            "platform": info.platform_type.value,
            "architecture": info.architecture.value,
            "os_name": info.os_name,
            "os_release": info.os_release,
            "os_version": info.os_version,
            "hostname": info.hostname,
            "machine": info.machine,
            "processor": info.processor,
            "python_version": info.python_version,
            "python_implementation": info.python_implementation,
            "is_64bit": info.is_64bit,
            "is_container": info.is_container,
            "is_vm": info.is_vm,
            "is_wsl": info.is_wsl,
        }

    @staticmethod
    def get_shell() -> str:
        if sys.platform == "win32":
            return os.environ.get("COMSPEC", "cmd.exe")
        return os.environ.get("SHELL", "/bin/sh")

    @staticmethod
    def get_temp_dir() -> str:
        if sys.platform == "win32":
            return os.environ.get("TEMP", os.environ.get("TMP", "C:\\Temp"))
        return "/tmp"

    @staticmethod
    def get_user_home() -> str:
        return os.path.expanduser("~")

    @staticmethod
    def get_username() -> str:
        return os.environ.get("USER", os.environ.get("USERNAME", "unknown"))

    @staticmethod
    def get_pid() -> int:
        return os.getpid()

    @staticmethod
    def get_cpu_count() -> int:
        return os.cpu_count() or 1

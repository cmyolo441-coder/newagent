from __future__ import annotations

import os
import signal
import psutil
from typing import Optional, Any
from exceptions.execution_exceptions import ProcessError
from constants.signal_constants import SIGNAL_MAP


class ProcessInfo:
    def __init__(self, pid: int) -> None:
        self.pid = pid
        self.name: str = ""
        self.exe: str = ""
        self.cmdline: list[str] = []
        self.cwd: str = ""
        self.username: str = ""
        self.status: str = ""
        self.create_time: float = 0.0
        self.cpu_percent: float = 0.0
        self.memory_percent: float = 0.0
        self.memory_rss: int = 0
        self.memory_vms: int = 0
        self.nice: int = 0
        self.num_threads: int = 0
        self.children: list[ProcessInfo] = []
        self.parent_pid: Optional[int] = None
        self.terminal: str = ""
        self._load()

    def _load(self) -> None:
        try:
            p = psutil.Process(self.pid)
            self.name = p.name()
            self.exe = p.exe()
            self.cmdline = p.cmdline()
            self.cwd = p.cwd()
            self.username = p.username()
            self.status = p.status()
            self.create_time = p.create_time()
            self.cpu_percent = p.cpu_percent(interval=0.0)
            self.memory_percent = p.memory_percent()
            self.memory_rss = p.memory_info().rss
            self.memory_vms = p.memory_info().vms
            self.nice = p.nice()
            self.num_threads = p.num_threads()
            self.parent_pid = p.ppid()
            self.terminal = p.terminal() or ""
            self.children = [ProcessInfo(c.pid) for c in p.children()]
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            raise ProcessError(f"Cannot access process {self.pid}: {e}") from e

    def to_dict(self) -> dict[str, Any]:
        return {
            "pid": self.pid,
            "name": self.name,
            "exe": self.exe,
            "cmdline": self.cmdline,
            "cwd": self.cwd,
            "username": self.username,
            "status": self.status,
            "create_time": self.create_time,
            "cpu_percent": self.cpu_percent,
            "memory_percent": self.memory_percent,
            "memory_rss": self.memory_rss,
            "memory_vms": self.memory_vms,
            "nice": self.nice,
            "num_threads": self.num_threads,
            "parent_pid": self.parent_pid,
            "terminal": self.terminal,
        }


class LinuxProcessManager:
    def __init__(self) -> None:
        self._managed_processes: dict[int, subprocess.Popen] = {}  # type: ignore

    def list_processes(self) -> list[dict[str, Any]]:
        result = []
        for proc in psutil.process_iter(["pid", "name", "status", "cpu_percent", "memory_percent"]):
            try:
                result.append(proc.info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return result

    def get_process(self, pid: int) -> ProcessInfo:
        return ProcessInfo(pid)

    def kill_process(self, pid: int, force: bool = False) -> bool:
        sig = signal.SIGKILL if force else signal.SIGTERM
        try:
            os.kill(pid, sig)
            return True
        except ProcessLookupError:
            return False
        except PermissionError as e:
            raise ProcessError(f"No permission to kill process {pid}: {e}") from e

    def send_signal(self, pid: int, sig: int) -> bool:
        try:
            os.kill(pid, sig)
            return True
        except ProcessLookupError:
            return False
        except PermissionError as e:
            raise ProcessError(f"No permission to signal process {pid}: {e}") from e

    def get_process_by_name(self, name: str) -> list[dict[str, Any]]:
        result = []
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if proc.info["name"] == name:
                    result.append(proc.info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return result

    def get_process_by_port(self, port: int) -> Optional[dict[str, Any]]:
        for conn in psutil.net_connections():
            if hasattr(conn, "laddr") and conn.laddr and conn.laddr.port == port:
                try:
                    p = psutil.Process(conn.pid)
                    return p.as_dict()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        return None

    def get_system_stats(self) -> dict[str, Any]:
        return {
            "cpu_percent": psutil.cpu_percent(interval=0.1, percpu=True),
            "cpu_count": psutil.cpu_count(),
            "memory": dict(psutil.virtual_memory()._asdict()),
            "swap": dict(psutil.swap_memory()._asdict()),
            "disk": {
                mount: dict(psutil.disk_usage(mount)._asdict())
                for mount in ("/", "/home", "/tmp")
                if os.path.isdir(mount)
            },
            "load_avg": psutil.getloadavg(),
            "uptime": int(psutil.boot_time()),
        }

    def suspend_process(self, pid: int) -> bool:
        return self.send_signal(pid, signal.SIGSTOP)

    def resume_process(self, pid: int) -> bool:
        return self.send_signal(pid, signal.SIGCONT)

    def get_process_tree(self, pid: int) -> list[ProcessInfo]:
        try:
            p = psutil.Process(pid)
            children = p.children(recursive=True)
            return [ProcessInfo(pid)] + [ProcessInfo(c.pid) for c in children]
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            raise ProcessError(f"Failed to get process tree for {pid}: {e}") from e

    def set_process_priority(self, pid: int, priority: int) -> None:
        try:
            p = psutil.Process(pid)
            p.nice(priority)
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            raise ProcessError(f"Failed to set priority for {pid}: {e}") from e

    def wait_process(self, pid: int, timeout: Optional[float] = None) -> bool:
        try:
            p = psutil.Process(pid)
            p.wait(timeout=timeout)
            return True
        except psutil.TimeoutExpired:
            return False
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            raise ProcessError(f"Failed to wait for process {pid}: {e}") from e

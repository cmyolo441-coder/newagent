from __future__ import annotations

import os
from typing import Optional, Any


NAMESPACE_TYPES = ["cgroup", "ipc", "mnt", "net", "pid", "user", "uts", "time"]


class NamespaceInfo:
    def __init__(self, pid: int) -> None:
        self.pid = pid
        self.namespaces: dict[str, Optional[int]] = {}
        self._load()

    def _load(self) -> None:
        ns_path = f"/proc/{self.pid}/ns"
        if not os.path.isdir(ns_path):
            return
        for ns in NAMESPACE_TYPES:
            link_path = os.path.join(ns_path, ns)
            try:
                if os.path.islink(link_path):
                    link_target = os.readlink(link_path)
                    inode = int(link_target.strip("[]").split(":")[1]) if ":" in link_target else None
                    self.namespaces[ns] = inode
                else:
                    self.namespaces[ns] = None
            except (OSError, ValueError):
                self.namespaces[ns] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "pid": self.pid,
            "namespaces": self.namespaces,
        }


class NamespaceHandler:
    def __init__(self) -> None:
        pass

    def get_process_namespaces(self, pid: int) -> NamespaceInfo:
        return NamespaceInfo(pid)

    def get_current_namespaces(self) -> NamespaceInfo:
        return NamespaceInfo(os.getpid())

    def compare_namespaces(self, pid1: int, pid2: int) -> dict[str, bool]:
        ns1 = self.get_process_namespaces(pid1)
        ns2 = self.get_process_namespaces(pid2)
        return {
            ns: ns1.namespaces.get(ns) == ns2.namespaces.get(ns)
            for ns in NAMESPACE_TYPES
        }

    def list_namespace_types(self) -> list[str]:
        return list(NAMESPACE_TYPES)

    def create_namespace(self, ns_type: str) -> bool:
        if ns_type not in NAMESPACE_TYPES:
            raise ValueError(f"Invalid namespace type: {ns_type}")
        try:
            pid = os.fork()
            if pid == 0:
                flags = {
                    "cgroup": 0x02000000,
                    "ipc": 0x08000000,
                    "mnt": 0x00020000,
                    "net": 0x40000000,
                    "pid": 0x20000000,
                    "user": 0x10000000,
                    "uts": 0x04000000,
                    "time": 0x80000000,
                }
                import ctypes
                libc = ctypes.CDLL("libc.so.6")
                ret = libc.unshare(flags.get(ns_type, 0))
                os._exit(0 if ret == 0 else 1)
            else:
                _, status = os.waitpid(pid, 0)
                return os.WEXITSTATUS(status) == 0
        except OSError:
            return False

    def is_supported(self, ns_type: str) -> bool:
        path = f"/proc/self/ns/{ns_type}"
        return os.path.islink(path) if ns_type in NAMESPACE_TYPES else False

    def list_supported_namespaces(self) -> list[str]:
        return [ns for ns in NAMESPACE_TYPES if self.is_supported(ns)]

    def enter_namespace(self, pid: int, ns_type: str) -> bool:
        if ns_type not in NAMESPACE_TYPES:
            raise ValueError(f"Invalid namespace type: {ns_type}")
        ns_path = f"/proc/{pid}/ns/{ns_type}"
        if not os.path.exists(ns_path):
            return False
        try:
            ns_fd = os.open(ns_path, os.O_RDONLY)
            try:
                import ctypes
                libc = ctypes.CDLL("libc.so.6")
                ret = libc.setns(ns_fd, 0)
                return ret == 0
            finally:
                os.close(ns_fd)
        except (OSError, AttributeError):
            return False

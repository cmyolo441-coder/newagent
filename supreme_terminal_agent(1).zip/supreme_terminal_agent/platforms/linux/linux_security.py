from __future__ import annotations

import os
import stat
import pwd
import grp
import subprocess
from typing import Optional, Any
from exceptions.security_exceptions import SecurityError, PermissionError as SecPermissionError
from platforms.linux.capabilities_handler import CapabilitiesHandler
from platforms.linux.namespace_handler import NamespaceHandler


class UserInfo:
    def __init__(self, name: str) -> None:
        self.name = name
        self.uid: int = 0
        self.gid: int = 0
        self.gecos: str = ""
        self.home: str = ""
        self.shell: str = ""
        self.groups: list[dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        try:
            pw = pwd.getpwnam(self.name)
            self.uid = pw.pw_uid
            self.gid = pw.pw_gid
            self.gecos = pw.pw_gecos
            self.home = pw.pw_dir
            self.shell = pw.pw_shell
            for g in grp.getgrall():
                if self.name in g.gr_mem or g.gr_gid == self.gid:
                    self.groups.append({"name": g.gr_name, "gid": g.gr_gid})
        except KeyError as e:
            raise SecurityError(f"User not found: {self.name}: {e}") from e


class LinuxSecurityManager:
    def __init__(self) -> None:
        self.capabilities = CapabilitiesHandler()
        self.namespaces = NamespaceHandler()

    def get_current_user(self) -> UserInfo:
        return UserInfo(os.environ.get("USER", "unknown"))

    def get_user(self, name: str) -> UserInfo:
        return UserInfo(name)

    def list_users(self) -> list[dict[str, Any]]:
        users = []
        try:
            with open("/etc/passwd") as f:
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) >= 7:
                        users.append({
                            "name": parts[0],
                            "uid": int(parts[2]),
                            "gid": int(parts[3]),
                            "gecos": parts[4],
                            "home": parts[5],
                            "shell": parts[6],
                        })
        except OSError as e:
            raise SecurityError(f"Failed to list users: {e}") from e
        return users

    def list_groups(self) -> list[dict[str, Any]]:
        groups = []
        try:
            with open("/etc/group") as f:
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) >= 4:
                        groups.append({
                            "name": parts[0],
                            "gid": int(parts[2]),
                            "members": parts[3].split(",") if parts[3] else [],
                        })
        except OSError as e:
            raise SecurityError(f"Failed to list groups: {e}") from e
        return groups

    def check_path_permissions(self, path: str) -> dict[str, Any]:
        try:
            st = os.stat(path)
            return {
                "path": path,
                "owner": pwd.getpwuid(st.st_uid).pw_name,
                "group": grp.getgrgid(st.st_gid).gr_name,
                "mode_str": stat.filemode(st.st_mode),
                "mode_oct": oct(st.st_mode),
                "can_read": os.access(path, os.R_OK),
                "can_write": os.access(path, os.W_OK),
                "can_execute": os.access(path, os.X_OK),
                "is_suid": bool(st.st_mode & stat.S_ISUID),
                "is_sgid": bool(st.st_mode & stat.S_ISGID),
                "is_sticky": bool(st.st_mode & stat.S_ISVTX),
            }
        except OSError as e:
            raise SecPermissionError(f"Cannot check permissions: {path}: {e}") from e

    def get_file_caps(self, path: str) -> Optional[dict[str, Any]]:
        return self.capabilities.get_file_capabilities(path)

    def set_file_caps(self, path: str, caps: str) -> None:
        self.capabilities.set_file_capabilities(path, caps)

    def check_selinux_status(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["selinuxenabled"],
                capture_output=True, timeout=5,
            )
            enabled = result.returncode == 0
            status = {}
            if enabled:
                try:
                    with open("/sys/fs/selinux/enforce") as f:
                        status["enforcing"] = f.read().strip() == "1"
                except OSError:
                    pass
            return {
                "enabled": enabled,
                "status": status,
            }
        except FileNotFoundError:
            return {"enabled": False, "status": {}}

    def check_apparmor_status(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["aa-status", "--json"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                import json as json_mod
                return json_mod.loads(result.stdout)
            return {"enabled": False, "error": result.stderr}
        except (FileNotFoundError, json.JSONDecodeError, subprocess.SubprocessError) as e:
            return {"enabled": False, "error": str(e)}

    def check_firewall_status(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["ufw", "status"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                return {"active": "active" in result.stdout.lower(), "output": result.stdout}
        except FileNotFoundError:
            pass
        try:
            result = subprocess.run(
                ["iptables", "-L", "-n"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                return {"active": True, "output": result.stdout}
        except FileNotFoundError:
            pass
        return {"active": False}

    def verify_integrity(self, path: str, checksum: str, algorithm: str = "sha256") -> bool:
        import hashlib
        h = hashlib.new(algorithm)
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest() == checksum
        except OSError as e:
            raise SecurityError(f"Failed to verify integrity: {path}: {e}") from e

    def is_running_as_root(self) -> bool:
        return os.geteuid() == 0

    def drop_privileges(self, user: str) -> None:
        if not self.is_running_as_root():
            return
        try:
            pw = pwd.getpwnam(user)
            os.setgroups([])
            os.setgid(pw.pw_gid)
            os.setuid(pw.pw_uid)
            os.environ["HOME"] = pw.pw_dir
            os.environ["USER"] = pw.pw_name
        except OSError as e:
            raise SecurityError(f"Failed to drop privileges to {user}: {e}") from e

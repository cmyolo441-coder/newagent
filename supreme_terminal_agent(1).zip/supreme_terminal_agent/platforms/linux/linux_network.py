from __future__ import annotations

import os
import socket
import subprocess
import ipaddress
import netifaces
from typing import Optional, Any
from exceptions.network_exceptions import NetworkError, ConnectionError, DNSResolutionError


class InterfaceInfo:
    def __init__(self, name: str) -> None:
        self.name = name
        self.addresses: list[dict[str, Any]] = []
        self.mac: str = ""
        self.is_up: bool = False
        self.is_loopback: bool = False
        self.mtu: int = 1500
        self._load()

    def _load(self) -> None:
        try:
            addrs = netifaces.ifaddresses(self.name)
            for family, addr_list in addrs.items():
                for addr in addr_list:
                    entry: dict[str, Any] = {"family": family, **addr}
                    self.addresses.append(entry)
                    if family == netifaces.AF_LINK and "addr" in addr:
                        self.mac = addr["addr"]
                    elif family == socket.AF_INET and "addr" in addr:
                        self.is_loopback = addr["addr"].startswith("127.")
            self.mtu = netifaces.ifaddresses(self.name).get(netifaces.AF_LINK, [{}])[0].get("mtu", 1500)
            flags_path = f"/sys/class/net/{self.name}/operstate"
            if os.path.isfile(flags_path):
                with open(flags_path) as f:
                    self.is_up = f.read().strip() == "up"
        except ValueError:
            pass

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}


class ConnectionInfo:
    def __init__(self, conn: Any) -> None:
        self.fd = conn.fd if hasattr(conn, "fd") else None
        self.family = conn.family if hasattr(conn, "family") else None
        self.type = conn.type if hasattr(conn, "type") else None
        self.laddr = (conn.laddr.ip, conn.laddr.port) if hasattr(conn, "laddr") and conn.laddr else None
        self.raddr = (conn.raddr.ip, conn.raddr.port) if hasattr(conn, "raddr") and conn.raddr else None
        self.status = conn.status if hasattr(conn, "status") else None
        self.pid = conn.pid if hasattr(conn, "pid") else None


class LinuxNetworkManager:
    def __init__(self) -> None:
        pass

    def get_interfaces(self) -> list[InterfaceInfo]:
        try:
            names = netifaces.interfaces()
            return [InterfaceInfo(name) for name in sorted(names)]
        except OSError as e:
            raise NetworkError(f"Failed to get interfaces: {e}") from e

    def get_interface(self, name: str) -> InterfaceInfo:
        if name not in netifaces.interfaces():
            raise NetworkError(f"Interface not found: {name}")
        return InterfaceInfo(name)

    def get_connections(self) -> list[dict[str, Any]]:
        import psutil
        result = []
        for conn in psutil.net_connections():
            try:
                result.append({
                    "fd": conn.fd,
                    "family": str(conn.family),
                    "type": str(conn.type),
                    "laddr": f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else None,
                    "raddr": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else None,
                    "status": conn.status,
                    "pid": conn.pid,
                })
            except (AttributeError, OSError):
                continue
        return result

    def resolve_hostname(self, hostname: str) -> list[str]:
        try:
            result = socket.getaddrinfo(hostname, None)
            ips = list(set(addr[4][0] for addr in result))
            return ips
        except socket.gaierror as e:
            raise DNSResolutionError(f"Failed to resolve hostname: {hostname}: {e}") from e

    def reverse_lookup(self, ip: str) -> str:
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)
            return hostname
        except socket.herror as e:
            raise DNSResolutionError(f"Failed to reverse lookup: {ip}: {e}") from e

    def ping(self, host: str, count: int = 4) -> dict[str, Any]:
        try:
            cmd = ["ping", "-c", str(count), host]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return {
                "host": host,
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr,
            }
        except subprocess.TimeoutExpired:
            return {"host": host, "success": False, "output": "", "error": "Ping timed out"}
        except FileNotFoundError:
            raise NetworkError("ping command not found")

    def trace_route(self, host: str) -> dict[str, Any]:
        try:
            cmd = ["traceroute", "-n", host]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            return {
                "host": host,
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr,
            }
        except subprocess.TimeoutExpired:
            return {"host": host, "success": False, "output": "", "error": "Traceroute timed out"}
        except FileNotFoundError:
            raise NetworkError("traceroute command not found")

    def check_port(self, host: str, port: int, timeout: float = 5.0) -> bool:
        try:
            sock = socket.create_connection((host, port), timeout=timeout)
            sock.close()
            return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False

    def get_public_ip(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["curl", "-s", "https://api.ipify.org"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except (subprocess.SubprocessError, OSError):
            pass
        return None

    def is_valid_ip(self, ip: str) -> bool:
        try:
            ipaddress.ip_address(ip)
            return True
        except ValueError:
            return False

    def is_valid_hostname(self, hostname: str) -> bool:
        try:
            socket.getaddrinfo(hostname, None)
            return True
        except socket.gaierror:
            return False

    def get_default_gateway(self) -> Optional[dict[str, str]]:
        try:
            gateways = netifaces.gateways()
            default = gateways.get("default", {})
            if netifaces.AF_INET in default:
                gw = default[netifaces.AF_INET]
                return {"interface": gw[1], "gateway": gw[0]}
        except OSError:
            pass
        return None

    def get_network_stats(self) -> dict[str, Any]:
        import psutil
        return {
            "bytes_sent": psutil.net_io_counters().bytes_sent,
            "bytes_recv": psutil.net_io_counters().bytes_recv,
            "packets_sent": psutil.net_io_counters().packets_sent,
            "packets_recv": psutil.net_io_counters().packets_recv,
            "errin": psutil.net_io_counters().errin,
            "errout": psutil.net_io_counters().errout,
            "dropin": psutil.net_io_counters().dropin,
            "dropout": psutil.net_io_counters().dropout,
        }

from __future__ import annotations

import os
import re
from typing import Optional, Any


class ProcInfo:
    def __init__(self, pid: int) -> None:
        self.pid = pid
        self.comm: str = ""
        self.state: str = ""
        self.ppid: int = 0
        self.pgrp: int = 0
        self.session: int = 0
        self.tty_nr: int = 0
        self.tpgid: int = 0
        self.flags: int = 0
        self.minflt: int = 0
        self.cminflt: int = 0
        self.majflt: int = 0
        self.cmajflt: int = 0
        self.utime: int = 0
        self.stime: int = 0
        self.cutime: int = 0
        self.cstime: int = 0
        self.priority: int = 0
        self.nice: int = 0
        self.num_threads: int = 0
        self.itrealvalue: int = 0
        self.starttime: int = 0
        self.vsize: int = 0
        self.rss: int = 0
        self.rsslim: int = 0
        self._load()

    def _load(self) -> None:
        try:
            with open(f"/proc/{self.pid}/stat") as f:
                data = f.read().strip()
                fields = data.split()
                if len(fields) >= 24:
                    self.comm = fields[1].strip("()")
                    self.state = fields[2]
                    self.ppid = int(fields[3])
                    self.pgrp = int(fields[4])
                    self.session = int(fields[5])
                    self.tty_nr = int(fields[6])
                    self.tpgid = int(fields[7])
                    self.flags = int(fields[8])
                    self.minflt = int(fields[9])
                    self.cminflt = int(fields[10])
                    self.majflt = int(fields[11])
                    self.cmajflt = int(fields[12])
                    self.utime = int(fields[13])
                    self.stime = int(fields[14])
                    self.cutime = int(fields[15])
                    self.cstime = int(fields[16])
                    self.priority = int(fields[17])
                    self.nice = int(fields[18])
                    self.num_threads = int(fields[19])
                    self.itrealvalue = int(fields[20])
                    self.starttime = int(fields[21])
                    self.vsize = int(fields[22])
                    self.rss = int(fields[23])
                    self.rsslim = int(fields[24]) if len(fields) > 24 else 0
        except (OSError, ValueError, IndexError):
            pass

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}


class ProcHandler:
    def __init__(self) -> None:
        self._proc_path = "/proc"

    def list_processes(self) -> list[int]:
        pids = []
        try:
            for entry in os.listdir(self._proc_path):
                if entry.isdigit():
                    pids.append(int(entry))
        except OSError:
            pass
        return sorted(pids)

    def get_process_info(self, pid: int) -> ProcInfo:
        return ProcInfo(pid)

    def get_process_status(self, pid: int) -> dict[str, str]:
        status = {}
        try:
            with open(f"/proc/{pid}/status") as f:
                for line in f:
                    if ":" in line:
                        key, _, value = line.partition(":")
                        status[key.strip().lower()] = value.strip()
        except OSError:
            pass
        return status

    def get_process_env(self, pid: int) -> dict[str, str]:
        env = {}
        try:
            with open(f"/proc/{pid}/environ") as f:
                data = f.read().rstrip("\0")
                for entry in data.split("\0"):
                    if "=" in entry:
                        key, _, value = entry.partition("=")
                        env[key] = value
        except OSError:
            pass
        return env

    def get_process_cmdline(self, pid: int) -> list[str]:
        try:
            with open(f"/proc/{pid}/cmdline") as f:
                data = f.read().rstrip("\0")
                return data.split("\0")
        except OSError:
            return []

    def get_process_cwd(self, pid: int) -> Optional[str]:
        try:
            return os.readlink(f"/proc/{pid}/cwd")
        except OSError:
            return None

    def get_process_exe(self, pid: int) -> Optional[str]:
        try:
            return os.readlink(f"/proc/{pid}/exe")
        except OSError:
            return None

    def get_process_fds(self, pid: int) -> list[dict[str, str]]:
        fds = []
        fd_path = f"/proc/{pid}/fd"
        try:
            for entry in os.listdir(fd_path):
                try:
                    link = os.readlink(os.path.join(fd_path, entry))
                    fds.append({"fd": entry, "target": link})
                except OSError:
                    fds.append({"fd": entry, "target": "?"})
        except OSError:
            pass
        return fds

    def get_process_limits(self, pid: int) -> list[dict[str, str]]:
        limits = []
        try:
            with open(f"/proc/{pid}/limits") as f:
                for i, line in enumerate(f):
                    if i < 1:
                        continue
                    parts = line.split()
                    if len(parts) >= 4:
                        limits.append({
                            "resource": parts[0],
                            "soft": parts[1],
                            "hard": parts[2],
                            "units": parts[3] if len(parts) > 3 else "",
                        })
        except OSError:
            pass
        return limits

    def get_process_maps(self, pid: int) -> list[dict[str, str]]:
        maps = []
        try:
            with open(f"/proc/{pid}/maps") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 5:
                        maps.append({
                            "address": parts[0],
                            "perms": parts[1],
                            "offset": parts[2],
                            "dev": parts[3],
                            "inode": parts[4],
                            "path": parts[5] if len(parts) > 5 else "",
                        })
        except OSError:
            pass
        return maps

    def get_cpu_info(self) -> dict[str, Any]:
        info: dict[str, Any] = {}
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if ":" in line:
                        key, _, value = line.partition(":")
                        info[key.strip()] = value.strip()
        except OSError:
            pass
        return info

    def get_mem_info(self) -> dict[str, str]:
        info = {}
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if ":" in line:
                        key, _, value = line.partition(":")
                        info[key.strip()] = value.strip()
        except OSError:
            pass
        return info

    def get_load_avg(self) -> list[float]:
        try:
            with open("/proc/loadavg") as f:
                parts = f.read().strip().split()[:3]
                return [float(p) for p in parts]
        except (OSError, ValueError):
            return [0.0, 0.0, 0.0]

    def get_uptime(self) -> float:
        try:
            with open("/proc/uptime") as f:
                return float(f.read().strip().split()[0])
        except (OSError, ValueError):
            return 0.0

    def get_disk_stats(self) -> dict[str, Any]:
        stats: dict[str, Any] = {}
        try:
            with open("/proc/diskstats") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 14:
                        name = parts[2]
                        stats[name] = {
                            "reads": int(parts[3]),
                            "reads_merged": int(parts[4]),
                            "sectors_read": int(parts[5]),
                            "read_time": int(parts[6]),
                            "writes": int(parts[7]),
                            "writes_merged": int(parts[8]),
                            "sectors_written": int(parts[9]),
                            "write_time": int(parts[10]),
                            "io_in_progress": int(parts[11]),
                            "io_time": int(parts[12]),
                            "weighted_io_time": int(parts[13]),
                        }
        except OSError:
            pass
        return stats

    def get_net_stats(self) -> dict[str, Any]:
        stats: dict[str, Any] = {}
        try:
            with open("/proc/net/dev") as f:
                for i, line in enumerate(f):
                    if i < 2:
                        continue
                    parts = line.strip().split()
                    if len(parts) >= 17:
                        iface = parts[0].rstrip(":")
                        stats[iface] = {
                            "rx_bytes": int(parts[1]),
                            "rx_packets": int(parts[2]),
                            "rx_errors": int(parts[3]),
                            "rx_dropped": int(parts[4]),
                            "tx_bytes": int(parts[9]),
                            "tx_packets": int(parts[10]),
                            "tx_errors": int(parts[11]),
                            "tx_dropped": int(parts[12]),
                        }
        except (OSError, ValueError):
            pass
        return stats

from __future__ import annotations

import os
import shutil
import stat
import pwd
import grp
import time
from typing import Optional, Any
from exceptions.filesystem_exceptions import (
    FileNotFoundError as FSFileNotFound,
    PermissionDeniedError,
    DiskError,
)


class FileInfo:
    def __init__(self, path: str) -> None:
        self.path = os.path.abspath(path)
        self.name = os.path.basename(self.path)
        self.extension = os.path.splitext(self.name)[1]
        self.is_dir = os.path.isdir(self.path)
        self.is_file = os.path.isfile(self.path)
        self.is_link = os.path.islink(self.path)
        self.is_mount = os.path.ismount(self.path)
        self.size: int = 0
        self.permissions: int = 0
        self.permissions_str: str = ""
        self.owner: str = ""
        self.group: str = ""
        self.owner_uid: int = 0
        self.group_gid: int = 0
        self.modified_time: float = 0.0
        self.access_time: float = 0.0
        self.created_time: float = 0.0
        self.inode: int = 0
        self.device: int = 0
        self.hard_links: int = 0
        self._load()

    def _load(self) -> None:
        try:
            st = os.stat(self.path, follow_symlinks=False)
            self.size = st.st_size
            self.permissions = st.st_mode
            self.permissions_str = stat.filemode(st.st_mode)
            try:
                self.owner = pwd.getpwuid(st.st_uid).pw_name
            except KeyError:
                self.owner = str(st.st_uid)
            try:
                self.group = grp.getgrgid(st.st_gid).gr_name
            except KeyError:
                self.group = str(st.st_gid)
            self.owner_uid = st.st_uid
            self.group_gid = st.st_gid
            self.modified_time = st.st_mtime
            self.access_time = st.st_atime
            self.created_time = st.st_ctime
            self.inode = st.st_ino
            self.device = st.st_dev
            self.hard_links = st.st_nlink
        except FileNotFoundError:
            raise FSFileNotFound(f"File not found: {self.path}")
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {self.path}: {e}") from e

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}


class LinuxFileSystem:
    def __init__(self) -> None:
        self._current_dir = os.getcwd()

    def list_directory(self, path: str = ".") -> list[FileInfo]:
        try:
            entries = os.listdir(path)
            return [FileInfo(os.path.join(path, e)) for e in sorted(entries)]
        except FileNotFoundError as e:
            raise FSFileNotFound(f"Directory not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e

    def get_file_info(self, path: str) -> FileInfo:
        return FileInfo(path)

    def read_file(self, path: str, encoding: str = "utf-8") -> str:
        try:
            with open(path, "r", encoding=encoding) as f:
                return f.read()
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except UnicodeDecodeError as e:
            raise FSFileNotFound(f"Cannot decode file: {path}: {e}") from e

    def read_binary(self, path: str) -> bytes:
        try:
            with open(path, "rb") as f:
                return f.read()
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e

    def write_file(self, path: str, content: str, encoding: str = "utf-8") -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "w", encoding=encoding) as f:
                f.write(content)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to write file: {path}: {e}") from e

    def write_binary(self, path: str, content: bytes) -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "wb") as f:
                f.write(content)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to write file: {path}: {e}") from e

    def create_directory(self, path: str, mode: int = 0o755) -> None:
        try:
            os.makedirs(path, mode=mode, exist_ok=True)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to create directory: {path}: {e}") from e

    def remove_file(self, path: str) -> None:
        try:
            os.remove(path)
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to remove file: {path}: {e}") from e

    def remove_directory(self, path: str, recursive: bool = False) -> None:
        try:
            if recursive:
                shutil.rmtree(path)
            else:
                os.rmdir(path)
        except FileNotFoundError as e:
            raise FSFileNotFound(f"Directory not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to remove directory: {path}: {e}") from e

    def copy(self, src: str, dst: str, recursive: bool = False) -> None:
        try:
            if recursive:
                if os.path.isdir(src):
                    shutil.copytree(src, dst, symlinks=True)
                else:
                    shutil.copy2(src, dst)
            else:
                shutil.copy2(src, dst)
        except (FileNotFoundError, PermissionError, OSError) as e:
            raise DiskError(f"Failed to copy {src} to {dst}: {e}") from e

    def move(self, src: str, dst: str) -> None:
        try:
            shutil.move(src, dst)
        except (FileNotFoundError, PermissionError, OSError) as e:
            raise DiskError(f"Failed to move {src} to {dst}: {e}") from e

    def chmod(self, path: str, mode: int) -> None:
        try:
            os.chmod(path, mode)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e

    def chown(self, path: str, user: Optional[str] = None, group: Optional[str] = None) -> None:
        try:
            uid = -1
            gid = -1
            if user is not None:
                try:
                    uid = pwd.getpwnam(user).pw_uid
                except KeyError:
                    uid = int(user)
            if group is not None:
                try:
                    gid = grp.getgrnam(group).gr_gid
                except KeyError:
                    gid = int(group)
            os.chown(path, uid, gid)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e

    def symlink(self, src: str, dst: str) -> None:
        try:
            os.symlink(src, dst)
        except (FileNotFoundError, PermissionError, OSError) as e:
            raise DiskError(f"Failed to create symlink {dst} -> {src}: {e}") from e

    def readlink(self, path: str) -> str:
        try:
            return os.readlink(path)
        except FileNotFoundError as e:
            raise FSFileNotFound(f"Symlink not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e

    def get_disk_usage(self, path: str = "/") -> dict[str, Any]:
        try:
            usage = shutil.disk_usage(path)
            return {
                "total": usage.total,
                "used": usage.used,
                "free": usage.free,
                "percent": (usage.used / usage.total * 100) if usage.total > 0 else 0,
                "path": path,
            }
        except OSError as e:
            raise DiskError(f"Failed to get disk usage: {path}: {e}") from e

    def get_mounts(self) -> list[dict[str, str]]:
        mounts = []
        try:
            with open("/proc/mounts") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 3:
                        mounts.append({
                            "device": parts[0],
                            "mountpoint": parts[1],
                            "fstype": parts[2],
                            "options": parts[3] if len(parts) > 3 else "",
                        })
        except OSError:
            pass
        return mounts

    def find(self, path: str, pattern: str, max_depth: Optional[int] = None) -> list[str]:
        matches = []
        try:
            for root, dirs, files in os.walk(path):
                depth = root.replace(path, "").count(os.sep)
                if max_depth is not None and depth > max_depth:
                    dirs.clear()
                for name in files + dirs:
                    if pattern in name:
                        matches.append(os.path.join(root, name))
        except PermissionError:
            pass
        return matches

    def get_free_space(self, path: str = "/") -> int:
        usage = shutil.disk_usage(path)
        return usage.free

    def get_inode_usage(self, path: str = "/") -> dict[str, Any]:
        try:
            st = os.statvfs(path)
            return {
                "total": st.f_files,
                "free": st.f_ffree,
                "used": st.f_files - st.f_ffree,
                "percent": ((st.f_files - st.f_ffree) / st.f_files * 100) if st.f_files > 0 else 0,
            }
        except OSError:
            return {}

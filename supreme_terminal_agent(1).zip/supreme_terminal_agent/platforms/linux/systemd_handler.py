from __future__ import annotations

import subprocess
from typing import Optional, Any


class SystemdUnitInfo:
    def __init__(self, name: str, data: dict[str, str]) -> None:
        self.name = name
        self.description = data.get("description", "")
        self.load_state = data.get("load_state", "")
        self.active_state = data.get("active_state", "")
        self.sub_state = data.get("sub_state", "")
        self.pid = int(data.get("pid", "0"))
        self.path = data.get("path", "")


class SystemdHandler:
    def __init__(self) -> None:
        self._systemctl = self._find_systemctl()

    def _find_systemctl(self) -> str:
        for path in ("/usr/bin/systemctl", "/bin/systemctl", "/usr/local/bin/systemctl"):
            if __import__("os").path.isfile(path):
                return path
        return "systemctl"

    def _run(self, args: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [self._systemctl] + args,
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise RuntimeError(f"systemctl not found: {e}") from e

    def get_unit_info(self, unit: str) -> SystemdUnitInfo:
        result = self._run(["show", unit])
        if result.returncode != 0:
            raise RuntimeError(f"Failed to get unit info: {result.stderr}")
        data: dict[str, str] = {}
        for line in result.stdout.strip().split("\n"):
            if "=" in line:
                key, _, value = line.partition("=")
                data[key.lower()] = value
        return SystemdUnitInfo(unit, data)

    def start_unit(self, unit: str) -> bool:
        result = self._run(["start", unit])
        return result.returncode == 0

    def stop_unit(self, unit: str) -> bool:
        result = self._run(["stop", unit])
        return result.returncode == 0

    def restart_unit(self, unit: str) -> bool:
        result = self._run(["restart", unit])
        return result.returncode == 0

    def enable_unit(self, unit: str) -> bool:
        result = self._run(["enable", unit])
        return result.returncode == 0

    def disable_unit(self, unit: str) -> bool:
        result = self._run(["disable", unit])
        return result.returncode == 0

    def is_active(self, unit: str) -> bool:
        result = self._run(["is-active", unit])
        return result.returncode == 0

    def is_enabled(self, unit: str) -> bool:
        result = self._run(["is-enabled", unit])
        return result.returncode == 0

    def unit_status(self, unit: str) -> str:
        result = self._run(["status", unit])
        return result.stdout + result.stderr

    def list_units(self, pattern: Optional[str] = None) -> list[dict[str, str]]:
        args = ["list-units", "--no-legend"]
        if pattern:
            args.append(pattern)
        result = self._run(args)
        units = []
        for line in result.stdout.strip().split("\n"):
            parts = line.split()
            if len(parts) >= 4:
                units.append({
                    "name": parts[0],
                    "load": parts[1],
                    "active": parts[2],
                    "sub": parts[3],
                    "description": " ".join(parts[4:]) if len(parts) > 4 else "",
                })
        return units

    def list_service_files(self) -> list[str]:
        result = self._run(["list-unit-files", "--type=service", "--no-legend"])
        return [line.split()[0] for line in result.stdout.strip().split("\n") if line.strip()]

    def daemon_reload(self) -> bool:
        result = self._run(["daemon-reload"])
        return result.returncode == 0

    def mask_unit(self, unit: str) -> bool:
        result = self._run(["mask", unit])
        return result.returncode == 0

    def unmask_unit(self, unit: str) -> bool:
        result = self._run(["unmask", unit])
        return result.returncode == 0

    def get_journal_logs(self, unit: str, lines: int = 100) -> str:
        try:
            result = subprocess.run(
                ["journalctl", "-u", unit, "-n", str(lines), "--no-pager"],
                capture_output=True, text=True, timeout=30,
            )
            return result.stdout + result.stderr
        except (FileNotFoundError, subprocess.SubprocessError) as e:
            raise RuntimeError(f"Failed to get journal logs: {e}") from e

    def get_unit_dependencies(self, unit: str) -> list[str]:
        result = self._run(["list-dependencies", unit])
        if result.returncode != 0:
            return []
        deps = []
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if line and not line.startswith("●"):
                deps.append(line)
        return deps

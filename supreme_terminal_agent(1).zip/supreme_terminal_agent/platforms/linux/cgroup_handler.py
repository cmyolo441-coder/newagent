from __future__ import annotations

import os
from typing import Optional, Any


class CGroupInfo:
    def __init__(self, path: str) -> None:
        self.path = path
        self.name = os.path.basename(path)
        self.controllers: list[str] = []
        self.tasks: list[int] = []
        self.memory_current: int = 0
        self.memory_limit: int = 0
        self.cpu_shares: int = 0
        self.cpu_quota: int = -1
        self.cpu_period: int = 100000
        self.cpuset_cpus: str = ""
        self.pids_current: int = 0
        self.pids_max: int = 0
        self.io_weight: int = 0
        self._load()

    def _load(self) -> None:
        for controller_dir in ("/sys/fs/cgroup",):
            cg_path = os.path.join(controller_dir, self.path.lstrip("/"))
            if not os.path.isdir(cg_path):
                continue
            self._read_controllers(cg_path)
            self._read_tasks(cg_path)
            self._read_memory(cg_path)
            self._read_cpu(cg_path)
            self._read_cpuset(cg_path)
            self._read_pids(cg_path)
            self._read_io(cg_path)
            break

    def _read_file(self, path: str) -> Optional[str]:
        try:
            with open(path) as f:
                return f.read().strip()
        except OSError:
            return None

    def _read_controllers(self, cg_path: str) -> None:
        content = self._read_file(os.path.join(cg_path, "cgroup.controllers"))
        if content:
            self.controllers = content.split()
        else:
            content = self._read_file(os.path.join(cg_path, "cgroup.subtree_control"))
            if content:
                self.controllers = content.split()

    def _read_tasks(self, cg_path: str) -> None:
        for tasks_file in ("cgroup.procs", "tasks"):
            content = self._read_file(os.path.join(cg_path, tasks_file))
            if content:
                self.tasks = [int(t) for t in content.strip().split("\n") if t.strip()]
                break

    def _read_memory(self, cg_path: str) -> None:
        current = self._read_file(os.path.join(cg_path, "memory.current"))
        if current:
            self.memory_current = int(current)
        limit = self._read_file(os.path.join(cg_path, "memory.max"))
        if limit and limit != "max":
            self.memory_limit = int(limit)
        elif limit == "max":
            self.memory_limit = -1

    def _read_cpu(self, cg_path: str) -> None:
        shares = self._read_file(os.path.join(cg_path, "cpu.weight"))
        if shares:
            self.cpu_shares = int(shares)
        quota = self._read_file(os.path.join(cg_path, "cpu.max"))
        if quota:
            parts = quota.split()
            if len(parts) >= 2:
                try:
                    self.cpu_quota = int(parts[0])
                    self.cpu_period = int(parts[1])
                except ValueError:
                    pass

    def _read_cpuset(self, cg_path: str) -> None:
        cpus = self._read_file(os.path.join(cg_path, "cpuset.cpus"))
        if cpus:
            self.cpuset_cpus = cpus
        else:
            cpus = self._read_file(os.path.join(cg_path, "cpuset.cpus.effective"))
            if cpus:
                self.cpuset_cpus = cpus

    def _read_pids(self, cg_path: str) -> None:
        current = self._read_file(os.path.join(cg_path, "pids.current"))
        if current:
            self.pids_current = int(current)
        max_pids = self._read_file(os.path.join(cg_path, "pids.max"))
        if max_pids and max_pids != "max":
            self.pids_max = int(max_pids)
        elif max_pids == "max":
            self.pids_max = -1

    def _read_io(self, cg_path: str) -> None:
        weight = self._read_file(os.path.join(cg_path, "io.weight"))
        if weight:
            try:
                self.io_weight = int(weight)
            except ValueError:
                pass

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}


class CGroupHandler:
    V1_PATH = "/sys/fs/cgroup"
    V2_PATH = "/sys/fs/cgroup"

    def __init__(self) -> None:
        self._is_v2 = self._detect_version()

    def _detect_version(self) -> bool:
        try:
            with open("/proc/filesystems") as f:
                content = f.read()
            return "cgroup2" in content
        except OSError:
            return False

    def is_cgroup_v2(self) -> bool:
        return self._is_v2

    def get_cgroup_info(self, path: str = "/") -> CGroupInfo:
        return CGroupInfo(path)

    def list_cgroups(self, base_path: str = "/") -> list[str]:
        groups = []
        full_path = os.path.join(self.V2_PATH, base_path.lstrip("/"))
        try:
            for entry in os.listdir(full_path):
                entry_path = os.path.join(full_path, entry)
                if os.path.isdir(entry_path):
                    groups.append(os.path.join(base_path, entry).rstrip("/") or "/")
        except OSError:
            pass
        return sorted(groups)

    def list_cgroups_recursive(self, base_path: str = "/") -> list[str]:
        groups = []
        full_path = os.path.join(self.V2_PATH, base_path.lstrip("/"))
        try:
            for root, dirs, _ in os.walk(full_path):
                for d in sorted(dirs):
                    rel_path = os.path.relpath(os.path.join(root, d), self.V2_PATH)
                    groups.append("/" + rel_path)
        except OSError:
            pass
        return groups

    def get_process_cgroups(self, pid: int) -> list[dict[str, str]]:
        cgroups = []
        try:
            with open(f"/proc/{pid}/cgroup") as f:
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) >= 3:
                        cgroups.append({
                            "hierarchy": parts[0],
                            "controllers": parts[1],
                            "path": parts[2],
                        })
        except OSError:
            pass
        return cgroups

    def write_cgroup_value(self, path: str, filename: str, value: str) -> bool:
        full_path = os.path.join(self.V2_PATH, path.lstrip("/"), filename)
        try:
            with open(full_path, "w") as f:
                f.write(value)
            return True
        except OSError:
            return False

    def get_process_controllers(self, pid: int) -> list[str]:
        info = self.get_process_cgroups(pid)
        controllers = []
        for entry in info:
            if entry["controllers"]:
                controllers.extend(entry["controllers"].split(","))
        return sorted(set(controllers))

from __future__ import annotations

import os
import re
from typing import Optional, Any


class SysHandler:
    def __init__(self) -> None:
        self._sys_path = "/sys"

    def read_sysfs(self, path: str) -> Optional[str]:
        full_path = os.path.join(self._sys_path, path.lstrip("/"))
        try:
            with open(full_path) as f:
                return f.read().strip()
        except OSError:
            return None

    def write_sysfs(self, path: str, value: str) -> bool:
        full_path = os.path.join(self._sys_path, path.lstrip("/"))
        try:
            with open(full_path, "w") as f:
                f.write(value)
            return True
        except OSError:
            return False

    def get_block_devices(self) -> list[dict[str, Any]]:
        devices = []
        block_path = os.path.join(self._sys_path, "class", "block")
        try:
            for device in os.listdir(block_path):
                dev_path = os.path.join(block_path, device)
                info: dict[str, Any] = {"name": device}
                size = self.read_sysfs(f"class/block/{device}/size")
                if size:
                    info["sectors"] = int(size)
                    info["size_bytes"] = int(size) * 512
                removable = self.read_sysfs(f"class/block/{device}/removable")
                if removable:
                    info["removable"] = removable == "1"
                ro = self.read_sysfs(f"class/block/{device}/ro")
                if ro is not None:
                    info["readonly"] = ro == "1"
                try:
                    dev_path_real = os.readlink(dev_path)
                    info["device_path"] = os.path.basename(dev_path_real)
                except OSError:
                    pass
                devices.append(info)
        except OSError:
            pass
        return devices

    def get_cpu_info(self) -> list[dict[str, Any]]:
        cpus = []
        cpu_path = os.path.join(self._sys_path, "devices", "system", "cpu")
        try:
            for entry in os.listdir(cpu_path):
                if not entry.startswith("cpu") or not entry[3:].isdigit():
                    continue
                cpu_num = entry[3:]
                info: dict[str, Any] = {"cpu": int(cpu_num)}
                online = self.read_sysfs(f"devices/system/cpu/{entry}/online")
                if online is not None:
                    info["online"] = online == "1"
                gov = self.read_sysfs(f"devices/system/cpu/{entry}/cpufreq/scaling_governor")
                if gov:
                    info["governor"] = gov
                freq = self.read_sysfs(f"devices/system/cpu/{entry}/cpufreq/scaling_cur_freq")
                if freq:
                    info["current_freq_khz"] = int(freq)
                min_freq = self.read_sysfs(f"devices/system/cpu/{entry}/cpufreq/scaling_min_freq")
                if min_freq:
                    info["min_freq_khz"] = int(min_freq)
                max_freq = self.read_sysfs(f"devices/system/cpu/{entry}/cpufreq/scaling_max_freq")
                if max_freq:
                    info["max_freq_khz"] = int(max_freq)
                cpus.append(info)
        except OSError:
            pass
        return cpus

    def get_memory_info(self) -> dict[str, Any]:
        info: dict[str, Any] = {}
        mem_path = os.path.join(self._sys_path, "devices", "system", "memory")
        try:
            for entry in os.listdir(mem_path):
                if entry.startswith("memory"):
                    state = self.read_sysfs(f"devices/system/memory/{entry}/state")
                    if state:
                        key = f"{entry}_state"
                        info[key] = state
            block_size = self.read_sysfs("devices/system/memory/block_size_bytes")
            if block_size:
                info["block_size_bytes"] = block_size
        except OSError:
            pass
        return info

    def get_power_supply(self) -> list[dict[str, Any]]:
        supplies = []
        power_path = os.path.join(self._sys_path, "class", "power_supply")
        try:
            for entry in os.listdir(power_path):
                info: dict[str, Any] = {"name": entry}
                ptype = self.read_sysfs(f"class/power_supply/{entry}/type")
                if ptype:
                    info["type"] = ptype
                status = self.read_sysfs(f"class/power_supply/{entry}/status")
                if status:
                    info["status"] = status
                capacity = self.read_sysfs(f"class/power_supply/{entry}/capacity")
                if capacity:
                    info["capacity"] = int(capacity)
                voltage = self.read_sysfs(f"class/power_supply/{entry}/voltage_now")
                if voltage:
                    info["voltage_uv"] = int(voltage)
                current = self.read_sysfs(f"class/power_supply/{entry}/current_now")
                if current:
                    info["current_ua"] = int(current)
                supplies.append(info)
        except OSError:
            pass
        return supplies

    def get_thermal_zones(self) -> list[dict[str, Any]]:
        zones = []
        thermal_path = os.path.join(self._sys_path, "class", "thermal")
        try:
            for entry in os.listdir(thermal_path):
                if not entry.startswith("thermal_zone"):
                    continue
                info: dict[str, Any] = {"name": entry}
                temp = self.read_sysfs(f"class/thermal/{entry}/temp")
                if temp:
                    info["temp_celsius"] = int(temp) / 1000.0
                trip_point = self.read_sysfs(f"class/thermal/{entry}/trip_point_0_temp")
                if trip_point:
                    info["trip_temp_celsius"] = int(trip_point) / 1000.0
                policy = self.read_sysfs(f"class/thermal/{entry}/policy")
                if policy:
                    info["policy"] = policy
                zones.append(info)
        except OSError:
            pass
        return zones

    def get_pci_devices(self) -> list[dict[str, str]]:
        devices = []
        pci_path = os.path.join(self._sys_path, "bus", "pci", "devices")
        try:
            for entry in os.listdir(pci_path):
                vendor = self.read_sysfs(f"bus/pci/devices/{entry}/vendor")
                device = self.read_sysfs(f"bus/pci/devices/{entry}/device")
                driver = ""
                try:
                    driver_link = os.readlink(os.path.join(pci_path, entry, "driver"))
                    driver = os.path.basename(driver_link)
                except OSError:
                    pass
                devices.append({
                    "slot": entry,
                    "vendor": vendor or "",
                    "device": device or "",
                    "driver": driver,
                })
        except OSError:
            pass
        return devices

    def get_usb_devices(self) -> list[dict[str, str]]:
        devices = []
        usb_path = os.path.join(self._sys_path, "bus", "usb", "devices")
        try:
            for entry in os.listdir(usb_path):
                vendor = self.read_sysfs(f"bus/usb/devices/{entry}/idVendor")
                product = self.read_sysfs(f"bus/usb/devices/{entry}/idProduct")
                manufacturer = self.read_sysfs(f"bus/usb/devices/{entry}/manufacturer")
                product_name = self.read_sysfs(f"bus/usb/devices/{entry}/product")
                speed = self.read_sysfs(f"bus/usb/devices/{entry}/speed")
                devices.append({
                    "device": entry,
                    "vendor_id": vendor or "",
                    "product_id": product or "",
                    "manufacturer": manufacturer or "",
                    "product": product_name or "",
                    "speed": speed or "",
                })
        except OSError:
            pass
        return devices

    def get_module_parameters(self, module: str) -> dict[str, str]:
        params = {}
        param_path = os.path.join(self._sys_path, "module", module, "parameters")
        try:
            for entry in os.listdir(param_path):
                value = self.read_sysfs(f"module/{module}/parameters/{entry}")
                if value is not None:
                    params[entry] = value
        except OSError:
            pass
        return params

    def list_modules(self) -> list[str]:
        modules = []
        mod_path = os.path.join(self._sys_path, "module")
        try:
            for entry in os.listdir(mod_path):
                if os.path.isdir(os.path.join(mod_path, entry)):
                    modules.append(entry)
        except OSError:
            pass
        return sorted(modules)

    def get_kernel_parameter(self, param: str) -> Optional[str]:
        return self.read_sysfs(f"kernel/{param}") or self.read_sysfs(f"kernel/{param.replace('.', '/')}")

    def get_virtual_devices(self) -> list[str]:
        devices = []
        virtual_path = os.path.join(self._sys_path, "devices", "virtual")
        try:
            for category in os.listdir(virtual_path):
                cat_path = os.path.join(virtual_path, category)
                if os.path.isdir(cat_path):
                    for device in os.listdir(cat_path):
                        devices.append(f"{category}/{device}")
        except OSError:
            pass
        return sorted(devices)

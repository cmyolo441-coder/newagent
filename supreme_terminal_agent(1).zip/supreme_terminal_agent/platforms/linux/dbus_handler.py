from __future__ import annotations

import subprocess
import json
from typing import Optional, Any


class DBusHandler:
    def __init__(self) -> None:
        self._busctl = self._find_busctl()

    def _find_busctl(self) -> str:
        for path in ("/usr/bin/busctl", "/bin/busctl"):
            if __import__("os").path.isfile(path):
                return path
        return "busctl"

    def _run(self, args: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [self._busctl] + args,
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise RuntimeError(f"busctl not found: {e}") from e

    def list_services(self, bus: str = "system") -> list[str]:
        result = self._run(["list", "--bus", bus])
        services = []
        for i, line in enumerate(result.stdout.strip().split("\n")):
            if i < 2:
                continue
            parts = line.split()
            if parts:
                services.append(parts[0])
        return services

    def list_objects(self, service: str, bus: str = "system") -> list[str]:
        result = self._run(["--bus", bus, "tree", service])
        objects = []
        for line in result.stdout.strip().split("\n"):
            obj = line.strip().strip("/")
            if obj:
                objects.append("/" + obj if not obj.startswith("/") else obj)
        return objects

    def list_interfaces(self, service: str, path: str, bus: str = "system") -> list[str]:
        result = self._run(["--bus", bus, "introspect", service, path])
        interfaces = []
        in_interface = False
        for line in result.stdout.strip().split("\n"):
            stripped = line.strip()
            if stripped.startswith("interface "):
                iface_name = stripped.split()[1].strip(".")
                interfaces.append(iface_name)
        return interfaces

    def get_property(self, service: str, path: str, interface: str, property_name: str, bus: str = "system") -> Optional[str]:
        result = self._run(["--bus", bus, "get-property", service, path, interface, property_name])
        if result.returncode == 0:
            return result.stdout.strip()
        return None

    def call_method(self, service: str, path: str, interface: str, method: str, *args: str, bus: str = "system") -> str:
        cmd = ["--bus", bus, "call", service, path, interface, method] + list(args)
        result = self._run(cmd)
        if result.returncode != 0:
            raise RuntimeError(f"DBus method call failed: {result.stderr}")
        return result.stdout

    def monitor(self, bus: str = "system", timeout: int = 5) -> str:
        result = self._run(["monitor", "--bus", bus, "--timeout=" + str(timeout)])
        return result.stdout + result.stderr

    def send_signal(self, service: str, path: str, interface: str, signal_name: str, bus: str = "system") -> bool:
        try:
            result = self._run(["--bus", bus, "emit", service, path, interface, signal_name])
            return result.returncode == 0
        except RuntimeError:
            return False

    def get_service_info(self, service: str, bus: str = "system") -> Optional[dict[str, Any]]:
        info: dict[str, Any] = {"name": service}
        objects = self.list_objects(service, bus)
        info["objects"] = objects
        if objects:
            info["interfaces"] = self.list_interfaces(service, objects[0], bus)
        return info

    def introspect(self, service: str, path: str, bus: str = "system") -> str:
        result = self._run(["--bus", bus, "introspect", service, path])
        return result.stdout + result.stderr

    def get_owner(self, service: str, bus: str = "system") -> Optional[str]:
        result = self._run(["--bus", bus, "status", service])
        for line in result.stdout.strip().split("\n"):
            if "owner" in line.lower():
                parts = line.split()
                if len(parts) >= 2:
                    return parts[-1]
        return None

    def list_activatable_services(self, bus: str = "system") -> list[str]:
        return self.list_services(bus)

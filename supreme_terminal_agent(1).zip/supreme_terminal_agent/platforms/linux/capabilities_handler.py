from __future__ import annotations

import os
import subprocess
from typing import Optional, Any


CAPABILITIES = [
    "cap_chown", "cap_dac_override", "cap_dac_read_search", "cap_fowner",
    "cap_fsetid", "cap_kill", "cap_setgid", "cap_setuid", "cap_setpcap",
    "cap_linux_immutable", "cap_net_bind_service", "cap_net_broadcast",
    "cap_net_admin", "cap_net_raw", "cap_ipc_lock", "cap_ipc_owner",
    "cap_sys_module", "cap_sys_rawio", "cap_sys_chroot", "cap_sys_ptrace",
    "cap_sys_pacct", "cap_sys_admin", "cap_sys_boot", "cap_sys_nice",
    "cap_sys_resource", "cap_sys_time", "cap_sys_tty_config", "cap_mknod",
    "cap_lease", "cap_audit_write", "cap_audit_control", "cap_setfcap",
    "cap_mac_override", "cap_mac_admin", "cap_syslog", "cap_wake_alarm",
    "cap_block_suspend", "cap_audit_read", "cap_perfmon", "cap_bpf",
    "cap_checkpoint_restore",
]


class CapabilitiesHandler:
    def __init__(self) -> None:
        self._proc_path = "/proc/self/status"

    def get_process_capabilities(self, pid: Optional[int] = None) -> dict[str, Any]:
        path = f"/proc/{pid}/status" if pid else self._proc_path
        caps = {
            "cap_inheritable": "",
            "cap_permitted": "",
            "cap_effective": "",
            "cap_bounding": "",
            "cap_ambient": "",
        }
        try:
            with open(path) as f:
                for line in f:
                    for key in caps:
                        if line.startswith(key + ":"):
                            caps[key] = line.strip().split("\t")[-1]
        except OSError:
            pass
        return caps

    def get_file_capabilities(self, path: str) -> Optional[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["getcap", path],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                parts = result.stdout.strip().split()
                if len(parts) >= 2:
                    return {"file": parts[0].rstrip("="), "capabilities": parts[1]}
            return None
        except (FileNotFoundError, subprocess.SubprocessError):
            return None

    def set_file_capabilities(self, path: str, caps: str) -> bool:
        try:
            result = subprocess.run(
                ["setcap", caps, path],
                capture_output=True, text=True, timeout=10,
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.SubprocessError):
            return False

    def drop_capability(self, cap: str) -> bool:
        if cap not in CAPABILITIES and not cap.startswith("cap_"):
            cap = f"cap_{cap}"
        try:
            import ctypes
            libc = ctypes.CDLL("libc.so.6")
            cap_value = CAPABILITIES.index(cap) if cap in CAPABILITIES else -1
            if cap_value < 0:
                return False
            ret = libc.prctl(0x7FFFFFFF, cap_value, 0, 0, 0)
            return ret == 0
        except (OSError, AttributeError, ValueError):
            return False

    def get_supported_capabilities(self) -> list[str]:
        return list(CAPABILITIES)

    def has_capability(self, cap: str, pid: Optional[int] = None) -> bool:
        caps = self.get_process_capabilities(pid)
        effective = caps.get("cap_effective", "")
        if not effective:
            return False
        try:
            bits = int(effective, 16)
            cap_index = CAPABILITIES.index(cap) if cap in CAPABILITIES else -1
            if cap_index >= 0:
                return bool(bits & (1 << cap_index))
        except (ValueError, IndexError):
            pass
        return False

    def list_capabilities(self) -> list[str]:
        return list(CAPABILITIES)

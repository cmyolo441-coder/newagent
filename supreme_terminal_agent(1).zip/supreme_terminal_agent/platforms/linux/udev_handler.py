from __future__ import annotations

import subprocess
from typing import Optional, Any


class UDevHandler:
    def __init__(self) -> None:
        self._udevadm = self._find_udevadm()

    def _find_udevadm(self) -> str:
        for path in ("/usr/bin/udevadm", "/bin/udevadm", "/sbin/udevadm"):
            if __import__("os").path.isfile(path):
                return path
        return "udevadm"

    def _run(self, args: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [self._udevadm] + args,
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise RuntimeError(f"udevadm not found: {e}") from e

    def query_device(self, path: str) -> Optional[dict[str, str]]:
        result = self._run(["info", "--query=all", "--path=" + path])
        if result.returncode != 0:
            return None
        info: dict[str, str] = {}
        for line in result.stdout.strip().split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                info[key.strip()] = value.strip()
        return info if info else None

    def query_subsystem(self, subsystem: str) -> list[str]:
        result = self._run(["info", "--export-db", f"--subsystem-match={subsystem}"])
        devices = []
        current_device = ""
        for line in result.stdout.strip().split("\n"):
            if line.startswith("P:"):
                current_device = line[2:].strip()
                devices.append(current_device)
        return devices

    def trigger(self, subsystem: Optional[str] = None, action: str = "change") -> bool:
        args = ["trigger", f"--action={action}"]
        if subsystem:
            args.append(f"--subsystem-match={subsystem}")
        result = self._run(args)
        return result.returncode == 0

    def settle(self, timeout: int = 30) -> bool:
        result = self._run(["settle", f"--timeout={timeout}"])
        return result.returncode == 0

    def monitor(self, timeout: int = 5) -> str:
        result = self._run(["monitor", "--property", f"--timeout={timeout}"])
        return result.stdout + result.stderr

    def get_device_info(self, device_path: str) -> Optional[dict[str, Any]]:
        result = self._run(["info", f"--device-id-of-file={device_path}"])
        if result.returncode != 0:
            return None
        device_id = result.stdout.strip()
        if not device_id:
            return None
        info_result = self._run(["info", f"--query=all", f"--name={device_id}"])
        if info_result.returncode != 0:
            return None
        info: dict[str, Any] = {"device_id": device_id}
        for line in info_result.stdout.strip().split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                info[key.strip().replace(" ", "_").lower()] = value.strip()
        return info

    def get_device_by_syspath(self, syspath: str) -> Optional[dict[str, str]]:
        return self.query_device(syspath)

    def list_subsystems(self) -> list[str]:
        result = self._run(["info", "--export-db"])
        subsystems = set()
        for line in result.stdout.strip().split("\n"):
            if line.startswith("E:SUBSYSTEM="):
                subsystems.add(line.split("=", 1)[1])
        return sorted(subsystems)

    def get_device_property(self, device_path: str, property_name: str) -> Optional[str]:
        result = self._run(["info", f"--query=property", f"--name={device_path}", f"--property={property_name}"])
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
        return None

    def reload_rules(self) -> bool:
        result = self._run(["control", "--reload-rules"])
        return result.returncode == 0

    def test_rule(self, rule_file: str, device_path: str) -> str:
        result = self._run(["test", device_path, f"--rules-file={rule_file}"])
        return result.stdout + result.stderr

    def get_device_from_subsystem(self, subsystem: str) -> list[dict[str, str]]:
        devices = []
        result = self._run(["info", "--export-db", f"--subsystem-match={subsystem}"])
        current: dict[str, str] = {}
        for line in result.stdout.strip().split("\n"):
            if line.startswith("P:"):
                if current:
                    devices.append(current)
                current = {"path": line[2:].strip()}
            elif line.startswith("E:") and current is not None:
                if "=" in line:
                    key, _, value = line[2:].partition("=")
                    current[key.strip()] = value.strip()
            elif line.startswith("S:") and current is not None:
                current.setdefault("symlinks", "")
                current["symlinks"] += line[2:].strip() + " "
        if current:
            devices.append(current)
        return devices

from __future__ import annotations

import os
import sys
import pty
import tty
import termios
import fcntl
import struct
import signal
import subprocess
import select
import errno
from typing import Optional, Any, Callable
from exceptions.terminal_exceptions import TerminalError


class LinuxTerminal:
    def __init__(
        self,
        shell_path: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
        rows: int = 24,
        cols: int = 80,
    ) -> None:
        self.shell_path = shell_path or os.environ.get("SHELL", "/bin/bash")
        self.env = env or os.environ.copy()
        self.rows = rows
        self.cols = cols
        self.master_fd: Optional[int] = None
        self.slave_fd: Optional[int] = None
        self.child_pid: Optional[int] = None
        self._is_open = False

    def open(self) -> None:
        if self._is_open:
            return
        try:
            self.master_fd, self.slave_fd = pty.openpty()
            self._set_winsize(self.rows, self.cols)
            tty.setraw(self.slave_fd)
            self.child_pid = os.fork()
            if self.child_pid == 0:
                os.close(self.master_fd)
                os.setsid()
                os.dup2(self.slave_fd, 0)
                os.dup2(self.slave_fd, 1)
                os.dup2(self.slave_fd, 2)
                if self.slave_fd > 2:
                    os.close(self.slave_fd)
                os.execve(self.shell_path, [self.shell_path, "-i"], self.env)
                os._exit(1)
            else:
                os.close(self.slave_fd)
                self._is_open = True
        except OSError as e:
            raise TerminalError(f"Failed to open terminal: {e}") from e

    def close(self) -> None:
        if self.child_pid:
            try:
                os.kill(self.child_pid, signal.SIGHUP)
                os.waitpid(self.child_pid, 0)
            except OSError:
                pass
            self.child_pid = None
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None
        self._is_open = False

    def write(self, data: str) -> int:
        if not self._is_open or self.master_fd is None:
            raise TerminalError("Terminal is not open")
        try:
            return os.write(self.master_fd, data.encode("utf-8", errors="replace"))
        except OSError as e:
            raise TerminalError(f"Failed to write to terminal: {e}") from e

    def read(self, timeout: float = 1.0) -> str:
        if not self._is_open or self.master_fd is None:
            raise TerminalError("Terminal is not open")
        try:
            r, _, _ = select.select([self.master_fd], [], [], timeout)
            if r:
                data = os.read(self.master_fd, 4096)
                return data.decode("utf-8", errors="replace")
            return ""
        except OSError as e:
            if e.errno == errno.EIO:
                return ""
            raise TerminalError(f"Failed to read from terminal: {e}") from e

    def resize(self, rows: int, cols: int) -> None:
        self.rows = rows
        self.cols = cols
        if self.master_fd is not None:
            self._set_winsize(rows, cols)

    def _set_winsize(self, rows: int, cols: int) -> None:
        if self.master_fd is not None:
            try:
                packed = struct.pack("HHHH", rows, cols, 0, 0)
                fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, packed)
            except OSError:
                pass

    def execute_command(self, command: str, timeout: Optional[float] = None) -> str:
        try:
            result = subprocess.run(
                [self.shell_path, "-c", command],
                capture_output=True,
                text=True,
                timeout=timeout,
                env=self.env,
            )
            output = result.stdout
            if result.stderr:
                output += result.stderr
            return output
        except subprocess.TimeoutExpired as e:
            raise TerminalError(f"Command timed out: {command}") from e
        except OSError as e:
            raise TerminalError(f"Failed to execute command: {e}") from e

    def is_alive(self) -> bool:
        if self.child_pid is None:
            return False
        try:
            pid, status = os.waitpid(self.child_pid, os.WNOHANG)
            return pid == 0
        except OSError:
            return False

    @property
    def is_open(self) -> bool:
        return self._is_open

    def __enter__(self) -> LinuxTerminal:
        self.open()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

from __future__ import annotations

import sys
import abc
import os
import signal
import subprocess
from typing import Optional, Any
from platforms.platform_detector import PlatformDetector, PlatformType


class PlatformAdapter(abc.ABC):
    def __init__(self) -> None:
        self.platform_type: PlatformType = PlatformDetector.detect_platform()

    @abc.abstractmethod
    def create_terminal(self, **kwargs: Any) -> Any:
        ...

    @abc.abstractmethod
    def create_process_manager(self) -> Any:
        ...

    @abc.abstractmethod
    def create_filesystem(self) -> Any:
        ...

    @abc.abstractmethod
    def create_network_manager(self) -> Any:
        ...

    @abc.abstractmethod
    def create_security_manager(self) -> Any:
        ...

    @abc.abstractmethod
    def get_shell_path(self) -> str:
        ...

    @abc.abstractmethod
    def get_default_encoding(self) -> str:
        ...

    @abc.abstractmethod
    def get_line_separator(self) -> str:
        ...

    @abc.abstractmethod
    def get_path_separator(self) -> str:
        ...

    @abc.abstractmethod
    def get_env_var(self, name: str, default: Optional[str] = None) -> Optional[str]:
        ...

    @abc.abstractmethod
    def set_env_var(self, name: str, value: str) -> None:
        ...

    @abc.abstractmethod
    def unset_env_var(self, name: str) -> None:
        ...

    @abc.abstractmethod
    def is_admin(self) -> bool:
        ...

    @abc.abstractmethod
    def get_pid(self) -> int:
        ...

    @abc.abstractmethod
    def kill_process(self, pid: int, force: bool = False) -> bool:
        ...

    @abc.abstractmethod
    def send_signal(self, pid: int, sig: signal.Signals) -> bool:
        ...

    @staticmethod
    def get_adapter() -> PlatformAdapter:
        platform = PlatformDetector.detect_platform()
        if platform == PlatformType.LINUX:
            from platforms.linux import LinuxAdapter
            return LinuxAdapter()
        elif platform == PlatformType.MACOS:
            from platforms.macos import MacOSAdapter
            return MacOSAdapter()
        elif platform == PlatformType.WINDOWS:
            from platforms.windows import WindowsAdapter
            return WindowsAdapter()
        raise RuntimeError(f"No adapter available for platform: {platform.value}")

    def run_command(self, command: str, **kwargs: Any) -> subprocess.CompletedProcess:
        kwargs.setdefault("shell", True)
        kwargs.setdefault("capture_output", True)
        kwargs.setdefault("text", True)
        return subprocess.run(command, **kwargs)

    def os_name(self) -> str:
        return os.name

    def sys_platform(self) -> str:
        return sys.platform


class LinuxAdapter(PlatformAdapter):
    def create_terminal(self, **kwargs: Any) -> Any:
        from platforms.linux.linux_terminal import LinuxTerminal
        return LinuxTerminal(**kwargs)

    def create_process_manager(self) -> Any:
        from platforms.linux.linux_process import LinuxProcessManager
        return LinuxProcessManager()

    def create_filesystem(self) -> Any:
        from platforms.linux.linux_filesystem import LinuxFileSystem
        return LinuxFileSystem()

    def create_network_manager(self) -> Any:
        from platforms.linux.linux_network import LinuxNetworkManager
        return LinuxNetworkManager()

    def create_security_manager(self) -> Any:
        from platforms.linux.linux_security import LinuxSecurityManager
        return LinuxSecurityManager()

    def get_shell_path(self) -> str:
        return os.environ.get("SHELL", "/bin/bash")

    def get_default_encoding(self) -> str:
        return "utf-8"

    def get_line_separator(self) -> str:
        return "\n"

    def get_path_separator(self) -> str:
        return "/"

    def get_env_var(self, name: str, default: Optional[str] = None) -> Optional[str]:
        return os.environ.get(name, default)

    def set_env_var(self, name: str, value: str) -> None:
        os.environ[name] = value

    def unset_env_var(self, name: str) -> None:
        os.environ.pop(name, None)

    def is_admin(self) -> bool:
        return os.geteuid() == 0

    def get_pid(self) -> int:
        return os.getpid()

    def kill_process(self, pid: int, force: bool = False) -> bool:
        sig = signal.SIGKILL if force else signal.SIGTERM
        return self.send_signal(pid, sig)

    def send_signal(self, pid: int, sig: signal.Signals) -> bool:
        try:
            os.kill(pid, sig)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return False


class MacOSAdapter(PlatformAdapter):
    def create_terminal(self, **kwargs: Any) -> Any:
        from platforms.macos.macos_terminal import MacOSTerminal
        return MacOSTerminal(**kwargs)

    def create_process_manager(self) -> Any:
        from platforms.macos.macos_process import MacOSProcessManager
        return MacOSProcessManager()

    def create_filesystem(self) -> Any:
        from platforms.macos.macos_filesystem import MacOSFileSystem
        return MacOSFileSystem()

    def create_network_manager(self) -> Any:
        from platforms.macos.macos_network import MacOSNetworkManager
        return MacOSNetworkManager()

    def create_security_manager(self) -> Any:
        from platforms.macos.macos_security import MacOSSecurityManager
        return MacOSSecurityManager()

    def get_shell_path(self) -> str:
        return os.environ.get("SHELL", "/bin/zsh")

    def get_default_encoding(self) -> str:
        return "utf-8"

    def get_line_separator(self) -> str:
        return "\n"

    def get_path_separator(self) -> str:
        return "/"

    def get_env_var(self, name: str, default: Optional[str] = None) -> Optional[str]:
        return os.environ.get(name, default)

    def set_env_var(self, name: str, value: str) -> None:
        os.environ[name] = value

    def unset_env_var(self, name: str) -> None:
        os.environ.pop(name, None)

    def is_admin(self) -> bool:
        return os.geteuid() == 0

    def get_pid(self) -> int:
        return os.getpid()

    def kill_process(self, pid: int, force: bool = False) -> bool:
        sig = signal.SIGKILL if force else signal.SIGTERM
        return self.send_signal(pid, sig)

    def send_signal(self, pid: int, sig: signal.Signals) -> bool:
        try:
            os.kill(pid, sig)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return False


class WindowsAdapter(PlatformAdapter):
    def create_terminal(self, **kwargs: Any) -> Any:
        from platforms.windows.windows_terminal import WindowsTerminal
        return WindowsTerminal(**kwargs)

    def create_process_manager(self) -> Any:
        from platforms.windows.windows_process import WindowsProcessManager
        return WindowsProcessManager()

    def create_filesystem(self) -> Any:
        from platforms.windows.windows_filesystem import WindowsFileSystem
        return WindowsFileSystem()

    def create_network_manager(self) -> Any:
        from platforms.windows.windows_network import WindowsNetworkManager
        return WindowsNetworkManager()

    def create_security_manager(self) -> Any:
        from platforms.windows.windows_security import WindowsSecurityManager
        return WindowsSecurityManager()

    def get_shell_path(self) -> str:
        return os.environ.get("COMSPEC", "cmd.exe")

    def get_default_encoding(self) -> str:
        return "utf-8"

    def get_line_separator(self) -> str:
        return "\r\n"

    def get_path_separator(self) -> str:
        return "\\"

    def get_env_var(self, name: str, default: Optional[str] = None) -> Optional[str]:
        return os.environ.get(name, default)

    def set_env_var(self, name: str, value: str) -> None:
        os.environ[name] = value

    def unset_env_var(self, name: str) -> None:
        os.environ.pop(name, None)

    def is_admin(self) -> bool:
        import ctypes
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except (AttributeError, OSError):
            return False

    def get_pid(self) -> int:
        return os.getpid()

    def kill_process(self, pid: int, force: bool = False) -> bool:
        sig = signal.SIGTERM
        return self.send_signal(pid, sig)

    def send_signal(self, pid: int, sig: signal.Signals) -> bool:
        try:
            os.kill(pid, sig)
            return True
        except (ProcessLookupError, OSError):
            return False

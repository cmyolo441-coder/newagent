from __future__ import annotations

import subprocess
from typing import Optional, Any


class PowerShellHandler:
    def __init__(self) -> None:
        self._powershell = self._find_powershell()

    def _find_powershell(self) -> str:
        for path in (
            r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
            r"C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe",
            "powershell",
            "pwsh",
        ):
            if __import__("os").path.isfile(path) or path in ("powershell", "pwsh"):
                return path
        return "powershell.exe"

    def run(self, command: str, timeout: int = 30) -> dict[str, Any]:
        try:
            result = subprocess.run(
                [self._powershell, "-NoProfile", "-Command", command],
                capture_output=True, text=True, timeout=timeout,
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": "Command timed out", "returncode": -1}
        except FileNotFoundError as e:
            raise RuntimeError(f"PowerShell not found: {e}") from e

    def run_script(self, script_path: str, args: Optional[list[str]] = None) -> dict[str, Any]:
        cmd = [self._powershell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script_path]
        if args:
            cmd.extend(args)
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": "Script timed out", "returncode": -1}
        except FileNotFoundError as e:
            raise RuntimeError(f"PowerShell not found: {e}") from e

    def execute_encoded(self, command: str) -> dict[str, Any]:
        import base64
        encoded = base64.b64encode(command.encode("utf-16le")).decode("ascii")
        return self.run_encoded(encoded)

    def run_encoded(self, encoded_command: str) -> dict[str, Any]:
        try:
            result = subprocess.run(
                [self._powershell, "-NoProfile", "-EncodedCommand", encoded_command],
                capture_output=True, text=True, timeout=30,
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": "Command timed out", "returncode": -1}

    def invoke_cim(self, namespace: str, class_name: str, **props: Any) -> dict[str, Any]:
        cmd = f"Get-CimInstance -Namespace '{namespace}' -ClassName '{class_name}'"
        cmd += " | Select-Object * | ConvertTo-Json"
        return self.run(cmd)

    def invoke_wmi(self, class_name: str, **props: Any) -> dict[str, Any]:
        cmd = f"Get-WmiObject -Class '{class_name}' | Select-Object * | ConvertTo-Json"
        return self.run(cmd)

    def invoke_method(self, class_name: str, method: str, **params: Any) -> dict[str, Any]:
        param_str = " -Arguments @{" + "; ".join(f"'{k}'='{v}'" for k, v in params.items()) + "}"
        cmd = f"Invoke-CimMethod -ClassName '{class_name}' -MethodName '{method}'{param_str} | ConvertTo-Json"
        return self.run(cmd)

    def get_command(self, name: str) -> dict[str, Any]:
        return self.run(f"Get-Command {name} | Select-Object * | ConvertTo-Json")

    def invoke_expression(self, expression: str) -> dict[str, Any]:
        return self.run(f"Invoke-Expression '{expression.replace(chr(39), chr(39)*2)}'")

    def get_service(self, name: Optional[str] = None) -> dict[str, Any]:
        cmd = "Get-Service"
        if name:
            cmd += f" -Name '{name}'"
        cmd += " | Select-Object * | ConvertTo-Json"
        return self.run(cmd)

    def get_process(self, name: Optional[str] = None) -> dict[str, Any]:
        cmd = "Get-Process"
        if name:
            cmd += f" -Name '{name}'"
        cmd += " | Select-Object * | ConvertTo-Json"
        return self.run(cmd)

    def get_event_log(self, log_name: str, max_events: int = 100) -> dict[str, Any]:
        cmd = f"Get-EventLog -LogName '{log_name}' -Newest {max_events} | ConvertTo-Json"
        return self.run(cmd)

    def invoke_rest_method(self, uri: str, method: str = "GET", body: Optional[str] = None) -> dict[str, Any]:
        cmd = f"Invoke-RestMethod -Uri '{uri}' -Method {method}"
        if body:
            cmd += f" -Body '{body}'"
        cmd += " | ConvertTo-Json -Depth 10"
        return self.run(cmd)

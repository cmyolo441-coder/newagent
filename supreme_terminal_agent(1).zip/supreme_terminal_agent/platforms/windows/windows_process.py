from __future__ import annotations

import os
import signal
import subprocess
from typing import Optional, Any
from exceptions.execution_exceptions import ProcessError


class WindowsProcessManager:
    def __init__(self) -> None:
        pass

    def list_processes(self) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["tasklist", "/FO", "CSV", "/NH"],
                capture_output=True, text=True, timeout=30,
            )
            processes = []
            for line in result.stdout.strip().split("\n"):
                parts = line.strip().split(",")
                if len(parts) >= 5:
                    processes.append({
                        "name": parts[0].strip('"'),
                        "pid": int(parts[1].strip('"')),
                        "session_name": parts[2].strip('"'),
                        "session_num": int(parts[3].strip('"')),
                        "mem_usage": parts[4].strip('"'),
                    })
            return processes
        except (subprocess.SubprocessError, ValueError) as e:
            raise ProcessError(f"Failed to list processes: {e}") from e

    def get_process(self, pid: int) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                capture_output=True, text=True, timeout=15,
            )
            line = result.stdout.strip().strip('"')
            if not line:
                raise ProcessError(f"Process {pid} not found")
            parts = [p.strip('"') for p in line.split('","')]
            if len(parts) >= 5:
                return {
                    "name": parts[0],
                    "pid": int(parts[1]),
                    "session_name": parts[2],
                    "session_num": int(parts[3]),
                    "mem_usage": parts[4],
                }
            raise ProcessError(f"Process {pid} not found")
        except (subprocess.SubprocessError, ValueError, IndexError) as e:
            raise ProcessError(f"Failed to get process {pid}: {e}") from e

    def kill_process(self, pid: int, force: bool = False) -> bool:
        try:
            args = ["taskkill", "/PID", str(pid)]
            if force:
                args.append("/F")
            result = subprocess.run(args, capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except subprocess.SubprocessError as e:
            raise ProcessError(f"Failed to kill process {pid}: {e}") from e

    def send_signal(self, pid: int, sig: int) -> bool:
        return self.kill_process(pid, force=True)

    def suspend_process(self, pid: int) -> bool:
        import ctypes
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            PROCESS_SUSPEND_RESUME = 0x0800
            handle = kernel32.OpenProcess(PROCESS_SUSPEND_RESUME, False, pid)
            if not handle:
                return False
            result = kernel32.SuspendThread(handle)
            kernel32.CloseHandle(handle)
            return True
        except (AttributeError, OSError):
            return False

    def resume_process(self, pid: int) -> bool:
        import ctypes
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            PROCESS_SUSPEND_RESUME = 0x0800
            handle = kernel32.OpenProcess(PROCESS_SUSPEND_RESUME, False, pid)
            if not handle:
                return False
            result = kernel32.ResumeThread(handle)
            kernel32.CloseHandle(handle)
            return True
        except (AttributeError, OSError):
            return False

    def get_process_by_name(self, name: str) -> list[dict[str, Any]]:
        processes = self.list_processes()
        return [p for p in processes if p["name"].lower() == name.lower()]

    def get_process_by_port(self, port: int) -> Optional[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["netstat", "-ano"],
                capture_output=True, text=True, timeout=15,
            )
            for line in result.stdout.strip().split("\n"):
                parts = line.split()
                if len(parts) >= 5:
                    if f":{port}" in parts[1]:
                        pid = int(parts[-1])
                        return self.get_process(pid)
            return None
        except (subprocess.SubprocessError, ValueError):
            return None

    def get_system_stats(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["wmic", "OS", "get", "TotalVisibleMemorySize,FreePhysicalMemory,LoadPercentage", "/FORMAT:CSV"],
                capture_output=True, text=True, timeout=15,
            )
            stats: dict[str, Any] = {}
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                parts = lines[1].split(",")
                if len(parts) >= 3:
                    stats["total_memory_kb"] = int(parts[-3])
                    stats["free_memory_kb"] = int(parts[-2])
                    stats["load_percent"] = int(parts[-1])
            cpu_result = subprocess.run(
                ["wmic", "CPU", "get", "LoadPercentage", "/FORMAT:CSV"],
                capture_output=True, text=True, timeout=15,
            )
            cpu_lines = cpu_result.stdout.strip().split("\n")
            if len(cpu_lines) >= 2:
                cpu_parts = cpu_lines[1].split(",")
                if cpu_parts and cpu_parts[-1].isdigit():
                    stats["cpu_load"] = int(cpu_parts[-1])
            return stats
        except (subprocess.SubprocessError, ValueError) as e:
            raise ProcessError(f"Failed to get system stats: {e}") from e

    def get_process_tree(self, pid: int) -> list[dict[str, Any]]:
        processes = self.list_processes()
        tree = []
        for p in processes:
            if p["pid"] == pid:
                tree.append(p)
                tree.extend(self._find_children(processes, pid))
        return tree

    def _find_children(self, processes: list[dict[str, Any]], parent_pid: int) -> list[dict[str, Any]]:
        children = []
        try:
            result = subprocess.run(
                ["wmic", "PROCESS", "where", f"ParentProcessId={parent_pid}", "get", "ProcessId", "/FORMAT:CSV"],
                capture_output=True, text=True, timeout=15,
            )
            for line in result.stdout.strip().split("\n")[1:]:
                parts = line.split(",")
                if len(parts) >= 2 and parts[1].isdigit():
                    child_pid = int(parts[1])
                    for p in processes:
                        if p["pid"] == child_pid:
                            children.append(p)
                            children.extend(self._find_children(processes, child_pid))
        except (subprocess.SubprocessError, ValueError):
            pass
        return children

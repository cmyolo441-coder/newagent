from __future__ import annotations

import os
import sys
import subprocess
from typing import Optional, Any
from exceptions.terminal_exceptions import TerminalError
from platforms.windows.conpty_handler import ConPtyHandler


class WindowsTerminal:
    def __init__(
        self,
        shell_path: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
        rows: int = 24,
        cols: int = 80,
        use_conpty: bool = True,
    ) -> None:
        self.shell_path = shell_path or os.environ.get("COMSPEC", "cmd.exe")
        self.env = env or os.environ.copy()
        self.rows = rows
        self.cols = cols
        self._conpty = ConPtyHandler() if use_conpty else None
        self._process: Optional[subprocess.Popen] = None
        self._is_open = False

    def open(self) -> None:
        if self._is_open:
            return
        if self._conpty:
            self._conpty.open(
                self.shell_path,
                self.rows,
                self.cols,
                self.env,
            )
            self._is_open = True
        else:
            try:
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESTDHANDLES
                self._process = subprocess.Popen(
                    self.shell_path,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    env=self.env,
                    startupinfo=startupinfo,
                    bufsize=0,
                )
                self._is_open = True
            except OSError as e:
                raise TerminalError(f"Failed to open terminal: {e}") from e

    def close(self) -> None:
        if self._conpty and self._conpty.is_open:
            self._conpty.close()
        if self._process:
            try:
                self._process.terminate()
                self._process.wait(timeout=5)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    self._process.kill()
                except OSError:
                    pass
            self._process = None
        self._is_open = False

    def write(self, data: str) -> int:
        if not self._is_open:
            raise TerminalError("Terminal is not open")
        if self._conpty and self._conpty.is_open:
            return self._conpty.write(data)
        if self._process and self._process.stdin:
            return self._process.stdin.write(data.encode("utf-8", errors="replace"))
        raise TerminalError("No available output stream")

    def read(self, timeout: float = 1.0) -> str:
        if not self._is_open:
            raise TerminalError("Terminal is not open")
        if self._conpty and self._conpty.is_open:
            return self._conpty.read(timeout)
        if self._process and self._process.stdout:
            import select as _select
            if _select.select([self._process.stdout], [], [], timeout)[0]:
                data = self._process.stdout.read(4096)
                return data.decode("utf-8", errors="replace") if isinstance(data, bytes) else data
        return ""

    def resize(self, rows: int, cols: int) -> None:
        self.rows = rows
        self.cols = cols
        if self._conpty and self._conpty.is_open:
            self._conpty.resize(rows, cols)

    def execute_command(self, command: str, timeout: Optional[float] = None) -> str:
        try:
            result = subprocess.run(
                [self.shell_path, "/c", command] if self.shell_path.endswith("cmd.exe")
                else [self.shell_path, "-c", command],
                capture_output=True,
                text=True,
                timeout=timeout,
                env=self.env,
            )
            output = result.stdout
            if result.stderr:
                output += result.stderr
            return output
        except subprocess.TimeoutExpired as e:
            raise TerminalError(f"Command timed out: {command}") from e
        except OSError as e:
            raise TerminalError(f"Failed to execute: {e}") from e

    def is_alive(self) -> bool:
        if self._process:
            return self._process.poll() is None
        if self._conpty:
            return self._conpty.is_open
        return False

    @property
    def is_open(self) -> bool:
        return self._is_open

    def __enter__(self) -> WindowsTerminal:
        self.open()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

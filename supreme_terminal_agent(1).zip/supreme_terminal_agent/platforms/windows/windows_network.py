from __future__ import annotations

import os
import socket
import subprocess
import ipaddress
from typing import Optional, Any
from exceptions.network_exceptions import NetworkError, DNSResolutionError


class WindowsNetworkManager:
    def __init__(self) -> None:
        pass

    def get_interfaces(self) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["ipconfig", "/all"],
                capture_output=True, text=True, timeout=15,
            )
            interfaces = []
            current: dict[str, Any] = {}
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if not line:
                    if current:
                        interfaces.append(current)
                        current = {}
                    continue
                if line.startswith("Ethernet adapter") or line.startswith("Wireless LAN adapter") or line.startswith("Unknown adapter"):
                    if current:
                        interfaces.append(current)
                    current = {"name": line.rstrip(":")}
                elif ":" in line and current:
                    key, _, value = line.partition(":")
                    key = key.strip()
                    value = value.strip()
                    if key.lower().startswith("ipv4"):
                        current.setdefault("addresses", [])
                        current["addresses"].append({"address": value.split("(")[0].strip(), "family": "IPv4"})
                    elif key.lower().startswith("ipv6"):
                        current.setdefault("addresses", [])
                        current["addresses"].append({"address": value.split("%")[0].strip(), "family": "IPv6"})
                    elif "physical address" in key.lower():
                        current["mac"] = value
                    elif "subnet mask" in key.lower():
                        current["netmask"] = value
                    elif "default gateway" in key.lower():
                        current["gateway"] = value
                    elif "dns servers" in key.lower():
                        current.setdefault("dns_servers", [])
                        current["dns_servers"].append(value)
            if current:
                interfaces.append(current)
            return interfaces
        except subprocess.SubprocessError as e:
            raise NetworkError(f"Failed to get interfaces: {e}") from e

    def resolve_hostname(self, hostname: str) -> list[str]:
        try:
            result = socket.getaddrinfo(hostname, None)
            return list(set(addr[4][0] for addr in result))
        except socket.gaierror as e:
            raise DNSResolutionError(f"Failed to resolve: {hostname}: {e}") from e

    def reverse_lookup(self, ip: str) -> str:
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)
            return hostname
        except socket.herror as e:
            raise DNSResolutionError(f"Failed reverse lookup: {ip}: {e}") from e

    def ping(self, host: str, count: int = 4) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["ping", "-n", str(count), host],
                capture_output=True, text=True, timeout=30,
            )
            return {
                "host": host,
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr,
            }
        except subprocess.TimeoutExpired:
            return {"host": host, "success": False, "output": "", "error": "Ping timed out"}
        except FileNotFoundError:
            raise NetworkError("ping command not found")

    def check_port(self, host: str, port: int, timeout: float = 5.0) -> bool:
        try:
            sock = socket.create_connection((host, port), timeout=timeout)
            sock.close()
            return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False

    def get_public_ip(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["curl", "-s", "https://api.ipify.org"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except subprocess.SubprocessError:
            pass
        try:
            result = subprocess.run(
                ["powershell", "-Command", "(Invoke-WebRequest -Uri https://api.ipify.org).Content"],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except subprocess.SubprocessError:
            pass
        return None

    def is_valid_ip(self, ip: str) -> bool:
        try:
            ipaddress.ip_address(ip)
            return True
        except ValueError:
            return False

    def get_connections(self) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["netstat", "-ano"],
                capture_output=True, text=True, timeout=15,
            )
            connections = []
            for line in result.stdout.strip().split("\n"):
                parts = line.split()
                if len(parts) >= 5:
                    proto = parts[0]
                    local = parts[1]
                    remote = parts[2]
                    state = parts[3] if len(parts) >= 4 else ""
                    pid = parts[-1]
                    connections.append({
                        "protocol": proto,
                        "local_address": local,
                        "remote_address": remote,
                        "state": state,
                        "pid": pid,
                    })
            return connections
        except subprocess.SubprocessError as e:
            raise NetworkError(f"Failed to get connections: {e}") from e

    def get_dns_servers(self) -> list[str]:
        try:
            result = subprocess.run(
                ["nslookup", "localhost"],
                capture_output=True, text=True, timeout=10,
            )
            servers = []
            for line in result.stdout.strip().split("\n"):
                if "Address:" in line and ":" not in line.split("Address:")[-1].strip():
                    addr = line.split("Address:")[-1].strip()
                    if addr and not addr.startswith("::"):
                        servers.append(addr)
            return servers
        except subprocess.SubprocessError:
            return []

    def get_network_stats(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["netstat", "-e"],
                capture_output=True, text=True, timeout=10,
            )
            stats: dict[str, Any] = {}
            for line in result.stdout.strip().split("\n"):
                if ":" in line:
                    key, _, value = line.partition(":")
                    stats[key.strip()] = value.strip()
            return stats
        except subprocess.SubprocessError:
            return {}

from __future__ import annotations

import subprocess
from typing import Optional, Any


REGISTRY_HIVES = {
    "HKCR": "HKEY_CLASSES_ROOT",
    "HKCU": "HKEY_CURRENT_USER",
    "HKLM": "HKEY_LOCAL_MACHINE",
    "HKU": "HKEY_USERS",
    "HKCC": "HKEY_CURRENT_CONFIG",
}


class RegistryHandler:
    def __init__(self) -> None:
        self._reg = "reg"

    def _run(self, args: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [self._reg] + args,
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise RuntimeError(f"reg command not found: {e}") from e

    def _parse_hive(self, key: str) -> str:
        for short, full in REGISTRY_HIVES.items():
            if key.startswith(short + "\\") or key == short:
                return key.replace(short, full, 1)
        return key

    def query(self, key: str, value: Optional[str] = None) -> list[dict[str, str]]:
        full_key = self._parse_hive(key)
        args = ["query", full_key]
        if value:
            args.extend(["/v", value])
        args.extend(["/s"])
        result = self._run(args)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to query registry: {result.stderr}")
        entries = []
        current_key = ""
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if line.startswith(full_key) or (current_key and line.startswith(" ")):
                if line.startswith(full_key):
                    current_key = line.rstrip()
                elif current_key and line:
                    parts = line.split()
                    if len(parts) >= 3:
                        entries.append({
                            "key": current_key,
                            "name": parts[0],
                            "type": parts[1],
                            "data": " ".join(parts[2:]),
                        })
                    elif len(parts) >= 1:
                        entries.append({
                            "key": current_key,
                            "name": parts[0],
                            "type": "",
                            "data": "",
                        })
        return entries

    def get_value(self, key: str, value: str = "") -> Optional[str]:
        full_key = self._parse_hive(key)
        args = ["query", full_key, "/v", value]
        result = self._run(args)
        if result.returncode != 0:
            return None
        for line in result.stdout.strip().split("\n"):
            parts = line.strip().split()
            if len(parts) >= 4 and parts[0] == value:
                return " ".join(parts[3:])
        return None

    def set_value(self, key: str, value: str, data: str, type: str = "REG_SZ") -> bool:
        full_key = self._parse_hive(key)
        args = ["add", full_key, "/v", value, "/t", type, "/d", data, "/f"]
        result = self._run(args)
        return result.returncode == 0

    def delete_value(self, key: str, value: str) -> bool:
        full_key = self._parse_hive(key)
        args = ["delete", full_key, "/v", value, "/f"]
        result = self._run(args)
        return result.returncode == 0

    def create_key(self, key: str) -> bool:
        full_key = self._parse_hive(key)
        args = ["add", full_key, "/f"]
        result = self._run(args)
        return result.returncode == 0

    def delete_key(self, key: str) -> bool:
        full_key = self._parse_hive(key)
        args = ["delete", full_key, "/f"]
        result = self._run(args)
        return result.returncode == 0

    def copy_key(self, source: str, destination: str) -> bool:
        src = self._parse_hive(source)
        dst = self._parse_hive(destination)
        args = ["copy", src, dst, "/s", "/f"]
        result = self._run(args)
        return result.returncode == 0

    def export(self, key: str, file_path: str) -> bool:
        full_key = self._parse_hive(key)
        args = ["export", full_key, file_path, "/y"]
        result = self._run(args)
        return result.returncode == 0

    def import_file(self, file_path: str) -> bool:
        args = ["import", file_path]
        result = self._run(args)
        return result.returncode == 0

    def list_keys(self, key: str) -> list[str]:
        full_key = self._parse_hive(key)
        args = ["query", full_key]
        result = self._run(args)
        keys = []
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if line.startswith(full_key + "\\"):
                keys.append(line)
        return keys

    def compare(self, key1: str, key2: str) -> dict[str, Any]:
        k1 = self._parse_hive(key1)
        k2 = self._parse_hive(key2)
        args = ["compare", k1, k2, "/s"]
        result = self._run(args)
        return {
            "key1": key1,
            "key2": key2,
            "identical": result.returncode == 0,
            "output": result.stdout,
            "error": result.stderr,
        }

    def restore(self, key: str, file_path: str) -> bool:
        full_key = self._parse_hive(key)
        args = ["restore", full_key, file_path]
        result = self._run(args)
        return result.returncode == 0

    def save(self, key: str, file_path: str) -> bool:
        full_key = self._parse_hive(key)
        args = ["save", full_key, file_path, "/y"]
        result = self._run(args)
        return result.returncode == 0

    def load_hive(self, key: str, file_path: str) -> bool:
        args = ["load", key, file_path]
        result = self._run(args)
        return result.returncode == 0

    def unload_hive(self, key: str) -> bool:
        args = ["unload", key]
        result = self._run(args)
        return result.returncode == 0

    def get_hives(self) -> dict[str, str]:
        return dict(REGISTRY_HIVES)

from __future__ import annotations

import subprocess
from typing import Optional, Any


class ServiceHandler:
    def __init__(self) -> None:
        self._sc = "sc"

    def _run(self, args: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [self._sc] + args,
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise RuntimeError(f"sc command not found: {e}") from e

    def list_services(self) -> list[dict[str, str]]:
        result = self._run(["query", "state=", "all"])
        services = []
        current: dict[str, str] = {}
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if ":" in line:
                key, _, value = line.partition(":")
                key = key.strip()
                value = value.strip()
                if key == "SERVICE_NAME":
                    if current:
                        services.append(current)
                    current = {"service_name": value}
                elif key in ("DISPLAY_NAME", "STATE", "WIN32_EXIT_CODE", "SERVICE_EXIT_CODE", "PID", "FLAGS"):
                    current[key.lower()] = value
        if current:
            services.append(current)
        return services

    def get_service(self, name: str) -> Optional[dict[str, str]]:
        result = self._run(["query", name])
        if result.returncode != 0:
            return None
        info: dict[str, str] = {}
        for line in result.stdout.strip().split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                info[key.strip().lower()] = value.strip()
        return info if info else None

    def start_service(self, name: str) -> bool:
        result = self._run(["start", name])
        return result.returncode == 0

    def stop_service(self, name: str) -> bool:
        result = self._run(["stop", name])
        return result.returncode == 0

    def restart_service(self, name: str) -> bool:
        self.stop_service(name)
        import time
        time.sleep(1)
        return self.start_service(name)

    def pause_service(self, name: str) -> bool:
        result = self._run(["pause", name])
        return result.returncode == 0

    def resume_service(self, name: str) -> bool:
        result = self._run(["continue", name])
        return result.returncode == 0

    def create_service(self, name: str, bin_path: str, display_name: Optional[str] = None,
                       description: Optional[str] = None, start_type: str = "auto") -> bool:
        args = ["create", name, f"binPath={bin_path}", f"start={start_type}"]
        if display_name:
            args.append(f"displayName={display_name}")
        result = self._run(args)
        if description and result.returncode == 0:
            self._run(["description", name, description])
        return result.returncode == 0

    def delete_service(self, name: str) -> bool:
        result = self._run(["delete", name])
        return result.returncode == 0

    def set_service_config(self, name: str, **kwargs: str) -> bool:
        args = ["config", name]
        for key, value in kwargs.items():
            args.append(f"{key}={value}")
        result = self._run(args)
        return result.returncode == 0

    def get_service_config(self, name: str) -> Optional[dict[str, str]]:
        result = self._run(["qc", name])
        if result.returncode != 0:
            return None
        info: dict[str, str] = {}
        for line in result.stdout.strip().split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                info[key.strip().lower()] = value.strip()
        return info

    def get_service_dependencies(self, name: str) -> list[str]:
        result = self._run(["EnumDepend", name])
        deps = []
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if line.startswith("SERVICE_NAME:"):
                deps.append(line.split(":")[1].strip())
        return deps

    def get_service_group_members(self, group: str) -> list[str]:
        members = []
        for svc in self.list_services():
            svc_name = svc.get("service_name", "")
            if svc_name:
                config = self.get_service_config(svc_name)
                if config and config.get("group", "").lower() == group.lower():
                    members.append(svc_name)
        return members

    def set_service_failure_actions(self, name: str, actions: list[str]) -> bool:
        action_str = "/".join(actions)
        result = self._run(["failure", name, f"actions={action_str}", "reset=86400"])
        return result.returncode == 0

    def get_service_status(self, name: str) -> str:
        info = self.get_service(name)
        if info:
            state = info.get("state", "")
            if "RUNNING" in state.upper():
                return "running"
            elif "STOPPED" in state.upper():
                return "stopped"
            elif "PAUSED" in state.upper():
                return "paused"
            elif "START_PENDING" in state.upper():
                return "starting"
            elif "STOP_PENDING" in state.upper():
                return "stopping"
        return "unknown"

    def wait_for_status(self, name: str, status: str, timeout: int = 30) -> bool:
        import time
        start = time.time()
        while time.time() - start < timeout:
            if self.get_service_status(name) == status:
                return True
            time.sleep(0.5)
        return False

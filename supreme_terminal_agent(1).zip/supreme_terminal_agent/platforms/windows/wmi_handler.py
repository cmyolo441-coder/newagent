from __future__ import annotations

import subprocess
from typing import Optional, Any


class WMIHandler:
    def __init__(self) -> None:
        self._wmic = "wmic"

    def _run(self, args: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [self._wmic] + args,
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise RuntimeError(f"wmic not found: {e}") from e

    def _parse_csv(self, output: str) -> list[dict[str, str]]:
        lines = output.strip().split("\n")
        if len(lines) < 2:
            return []
        headers = [h.strip().strip('"') for h in lines[0].split(",")]
        items = []
        for line in lines[1:]:
            values = [v.strip().strip('"') for v in line.split(",")]
            if len(values) == len(headers):
                items.append(dict(zip(headers, values)))
            elif len(values) < len(headers):
                item = {}
                for i, header in enumerate(headers):
                    item[header] = values[i] if i < len(values) else ""
                items.append(item)
        return items

    def query(self, wql: str) -> list[dict[str, str]]:
        result = self._run(wql.split())
        if result.returncode != 0:
            raise RuntimeError(f"WMI query failed: {result.stderr}")
        return self._parse_csv(result.stdout)

    def get_os_info(self) -> list[dict[str, str]]:
        return self.query("OS get /FORMAT:CSV")

    def get_cpu_info(self) -> list[dict[str, str]]:
        return self.query("CPU get /FORMAT:CSV")

    def get_memory_info(self) -> list[dict[str, str]]:
        return self.query("MEMORYCHIP get /FORMAT:CSV")

    def get_disk_info(self) -> list[dict[str, str]]:
        return self.query("DISKDRIVE get /FORMAT:CSV")

    def get_logical_disks(self) -> list[dict[str, str]]:
        return self.query("LOGICALDISK get /FORMAT:CSV")

    def get_network_adapters(self) -> list[dict[str, str]]:
        return self.query("NIC get /FORMAT:CSV")

    def get_services(self) -> list[dict[str, str]]:
        return self.query("SERVICE get /FORMAT:CSV")

    def get_processes(self) -> list[dict[str, str]]:
        return self.query("PROCESS get /FORMAT:CSV")

    def get_products(self) -> list[dict[str, str]]:
        return self.query("PRODUCT get /FORMAT:CSV")

    def get_system_accounts(self) -> list[dict[str, str]]:
        return self.query("USERACCOUNT get /FORMAT:CSV")

    def get_environment_variables(self) -> list[dict[str, str]]:
        return self.query("ENVIRONMENT get /FORMAT:CSV")

    def get_event_logs(self, log_name: str = "Application", max_entries: int = 100) -> list[dict[str, str]]:
        return self.query(f"NTEVENTLOG where LogFile={log_name} get /FORMAT:CSV")

    def get_bios_info(self) -> list[dict[str, str]]:
        return self.query("BIOS get /FORMAT:CSV")

    def get_video_controllers(self) -> list[dict[str, str]]:
        return self.query("VIDEOCONTROLLER get /FORMAT:CSV")

    def get_printers(self) -> list[dict[str, str]]:
        return self.query("PRINTER get /FORMAT:CSV")

    def get_startup_commands(self) -> list[dict[str, str]]:
        return self.query("STARTUP get /FORMAT:CSV")

    def get_shares(self) -> list[dict[str, str]]:
        return self.query("SHARE get /FORMAT:CSV")

    def get_volume_quotas(self) -> list[dict[str, str]]:
        return self.query("VOLUMEQUOTA get /FORMAT:CSV")

    def get_timezone(self) -> list[dict[str, str]]:
        return self.query("TIMEZONE get /FORMAT:CSV")

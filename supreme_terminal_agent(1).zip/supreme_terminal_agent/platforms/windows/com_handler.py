from __future__ import annotations

import subprocess
from typing import Optional, Any


class COMHandler:
    def __init__(self) -> None:
        self._powershell_handler = None

    def _get_ps(self):
        if self._powershell_handler is None:
            from platforms.windows.powershell_handler import PowerShellHandler
            self._powershell_handler = PowerShellHandler()
        return self._powershell_handler

    def create_object(self, prog_id: str) -> dict[str, Any]:
        ps = self._get_ps()
        return ps.run(f"$obj = New-Object -ComObject '{prog_id}'; $obj | ConvertTo-Json")

    def get_object_properties(self, prog_id: str) -> dict[str, Any]:
        ps = self._get_ps()
        cmd = (
            f"$obj = New-Object -ComObject '{prog_id}'; "
            f"$obj.PSObject.Properties | "
            f"Select-Object Name, Value, TypeNameOfValue | "
            f"ConvertTo-Json"
        )
        return ps.run(cmd)

    def get_object_methods(self, prog_id: str) -> dict[str, Any]:
        ps = self._get_ps()
        cmd = (
            f"$obj = New-Object -ComObject '{prog_id}'; "
            f"$obj.PSObject.Methods | "
            f"Select-Object Name, MemberType | "
            f"ConvertTo-Json"
        )
        return ps.run(cmd)

    def invoke_method(self, prog_id: str, method: str, *args: Any) -> dict[str, Any]:
        ps = self._get_ps()
        arg_str = ", ".join(repr(a) for a in args)
        cmd = (
            f"$obj = New-Object -ComObject '{prog_id}'; "
            f"$result = $obj.{method}({arg_str}); "
            f"if ($result -ne $null) {{ $result | ConvertTo-Json }} else {{ 'null' }}"
        )
        return ps.run(cmd)

    def get_wmi_object(self, class_name: str) -> dict[str, Any]:
        ps = self._get_ps()
        cmd = f"Get-WmiObject -Class '{class_name}' | Select-Object * -First 1 | ConvertTo-Json"
        return ps.run(cmd)

    def get_cim_instance(self, class_name: str, namespace: str = "root/cimv2") -> dict[str, Any]:
        ps = self._get_ps()
        cmd = (
            f"Get-CimInstance -ClassName '{class_name}' "
            f"-Namespace '{namespace}' | "
            f"Select-Object * -First 1 | ConvertTo-Json"
        )
        return ps.run(cmd)

    def list_com_objects(self) -> dict[str, Any]:
        ps = self._get_ps()
        cmd = (
            "Get-ChildItem HKLM:\\SOFTWARE\\Classes\\CLSID -ErrorAction SilentlyContinue | "
            "ForEach-Object { "
            "$name = (Get-ItemProperty -Path $_.PSPath -Name '(default)' -ErrorAction SilentlyContinue).'(default)'; "
            "if ($name) { [PSCustomObject]@{ CLSID = $_.PSChildName; Name = $name } } "
            "} | ConvertTo-Json"
        )
        return ps.run(cmd)

    def get_clsid_from_progid(self, prog_id: str) -> Optional[str]:
        ps = self._get_ps()
        cmd = (
            f"$clsid = (Get-ItemProperty "
            f"'HKLM:\\SOFTWARE\\Classes\\{prog_id}\\CLSID' -ErrorAction SilentlyContinue).'(default)'; "
            f"if ($clsid) {{ $clsid }} else {{ '' }}"
        )
        result = ps.run(cmd)
        if result["success"] and result["stdout"].strip():
            return result["stdout"].strip()
        return None

    def get_progid_from_clsid(self, clsid: str) -> Optional[str]:
        ps = self._get_ps()
        cmd = (
            f"$progid = (Get-ItemProperty "
            f"'HKLM:\\SOFTWARE\\Classes\\CLSID\\{{{clsid}}}' -ErrorAction SilentlyContinue).'(default)'; "
            f"if ($progid) {{ $progid }} else {{ '' }}"
        )
        result = ps.run(cmd)
        if result["success"] and result["stdout"].strip():
            return result["stdout"].strip()
        return None

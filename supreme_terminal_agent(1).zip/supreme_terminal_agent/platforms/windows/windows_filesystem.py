from __future__ import annotations

import os
import shutil
import stat
import subprocess
from typing import Optional, Any
from exceptions.filesystem_exceptions import (
    FileNotFoundError as FSFileNotFound,
    PermissionDeniedError,
    DiskError,
)


class FileInfo:
    def __init__(self, path: str) -> None:
        self.path = os.path.abspath(path)
        self.name = os.path.basename(self.path)
        self.extension = os.path.splitext(self.name)[1]
        self.is_dir = os.path.isdir(self.path)
        self.is_file = os.path.isfile(self.path)
        self.is_link = os.path.islink(self.path)
        self.size: int = 0
        self.permissions: str = ""
        self.owner: str = ""
        self.modified_time: float = 0.0
        self.access_time: float = 0.0
        self.created_time: float = 0.0
        self.attributes: str = ""
        self._load()

    def _load(self) -> None:
        try:
            st = os.stat(self.path, follow_symlinks=False)
            self.size = st.st_size
            self.modified_time = st.st_mtime
            self.access_time = st.st_atime
            self.created_time = st.st_ctime
            self.permissions = stat.filemode(st.st_mode) if hasattr(stat, "filemode") else ""
            if os.name == "nt":
                attrs = []
                if st.st_file_attributes & 0x0001:
                    attrs.append("READONLY")
                if st.st_file_attributes & 0x0002:
                    attrs.append("HIDDEN")
                if st.st_file_attributes & 0x0004:
                    attrs.append("SYSTEM")
                if st.st_file_attributes & 0x0010:
                    attrs.append("DIRECTORY")
                if st.st_file_attributes & 0x0020:
                    attrs.append("ARCHIVE")
                if st.st_file_attributes & 0x0040:
                    attrs.append("DEVICE")
                if st.st_file_attributes & 0x0080:
                    attrs.append("NORMAL")
                if st.st_file_attributes & 0x0100:
                    attrs.append("TEMPORARY")
                if st.st_file_attributes & 0x0200:
                    attrs.append("SPARSE_FILE")
                if st.st_file_attributes & 0x0400:
                    attrs.append("REPARSE_POINT")
                if st.st_file_attributes & 0x0800:
                    attrs.append("COMPRESSED")
                if st.st_file_attributes & 0x1000:
                    attrs.append("OFFLINE")
                self.attributes = ", ".join(attrs)
        except FileNotFoundError:
            raise FSFileNotFound(f"File not found: {self.path}")
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {self.path}: {e}") from e

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}


class WindowsFileSystem:
    def __init__(self) -> None:
        self._current_dir = os.getcwd()

    def list_directory(self, path: str = ".") -> list[FileInfo]:
        try:
            entries = os.listdir(path)
            return [FileInfo(os.path.join(path, e)) for e in sorted(entries)]
        except FileNotFoundError as e:
            raise FSFileNotFound(f"Directory not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e

    def get_file_info(self, path: str) -> FileInfo:
        return FileInfo(path)

    def read_file(self, path: str, encoding: str = "utf-8") -> str:
        try:
            with open(path, "r", encoding=encoding) as f:
                return f.read()
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except UnicodeDecodeError as e:
            raise FSFileNotFound(f"Cannot decode: {path}: {e}") from e

    def read_binary(self, path: str) -> bytes:
        try:
            with open(path, "rb") as f:
                return f.read()
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e

    def write_file(self, path: str, content: str, encoding: str = "utf-8") -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "w", encoding=encoding) as f:
                f.write(content)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to write: {path}: {e}") from e

    def write_binary(self, path: str, content: bytes) -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "wb") as f:
                f.write(content)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to write: {path}: {e}") from e

    def create_directory(self, path: str) -> None:
        try:
            os.makedirs(path, exist_ok=True)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to create dir: {path}: {e}") from e

    def remove_file(self, path: str) -> None:
        try:
            os.remove(path)
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to remove: {path}: {e}") from e

    def remove_directory(self, path: str, recursive: bool = False) -> None:
        try:
            if recursive:
                shutil.rmtree(path)
            else:
                os.rmdir(path)
        except FileNotFoundError as e:
            raise FSFileNotFound(f"Dir not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to remove dir: {path}: {e}") from e

    def copy(self, src: str, dst: str, recursive: bool = False) -> None:
        try:
            if recursive and os.path.isdir(src):
                shutil.copytree(src, dst, symlinks=True)
            else:
                shutil.copy2(src, dst)
        except OSError as e:
            raise DiskError(f"Failed to copy {src} to {dst}: {e}") from e

    def move(self, src: str, dst: str) -> None:
        try:
            shutil.move(src, dst)
        except OSError as e:
            raise DiskError(f"Failed to move {src} to {dst}: {e}") from e

    def get_disk_usage(self, path: str = "C:\\") -> dict[str, Any]:
        try:
            usage = shutil.disk_usage(path)
            return {
                "total": usage.total,
                "used": usage.used,
                "free": usage.free,
                "percent": usage.used / usage.total * 100 if usage.total > 0 else 0,
                "path": path,
            }
        except OSError as e:
            raise DiskError(f"Failed to get disk usage: {path}: {e}") from e

    def get_drives(self) -> list[str]:
        drives = []
        try:
            result = subprocess.run(
                ["wmic", "LOGICALDISK", "get", "Name", "/FORMAT:CSV"],
                capture_output=True, text=True, timeout=15,
            )
            for line in result.stdout.strip().split("\n")[1:]:
                name = line.strip().strip('"')
                if name and ":" in name:
                    drives.append(name)
        except subprocess.SubprocessError:
            for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
                drive = f"{letter}:\\"
                if os.path.exists(drive):
                    drives.append(drive)
        return drives

    def get_volume_info(self, path: str = "C:\\") -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["fsutil", "volume", "diskfree", path],
                capture_output=True, text=True, timeout=15,
            )
            info: dict[str, Any] = {}
            for line in result.stdout.strip().split("\n"):
                if ":" in line:
                    key, _, value = line.partition(":")
                    info[key.strip()] = value.strip()
            return info
        except (subprocess.SubprocessError, FileNotFoundError):
            return {}

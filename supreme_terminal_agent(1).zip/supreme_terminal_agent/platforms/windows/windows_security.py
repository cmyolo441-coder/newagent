from __future__ import annotations

import os
import subprocess
from typing import Optional, Any
from exceptions.security_exceptions import SecurityError, PermissionError as SecPermissionError


class WindowsSecurityManager:
    def __init__(self) -> None:
        pass

    def get_current_user(self) -> dict[str, Any]:
        return {
            "name": os.environ.get("USERNAME", "unknown"),
            "domain": os.environ.get("USERDOMAIN", ""),
            "profile": os.environ.get("USERPROFILE", ""),
        }

    def is_admin(self) -> bool:
        import ctypes
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except (AttributeError, OSError):
            return False

    def list_users(self) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["net", "user"],
                capture_output=True, text=True, timeout=15,
            )
            users = []
            capturing = False
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if "-----" in line:
                    capturing = not capturing
                    continue
                if capturing:
                    for part in line.split():
                        if part:
                            users.append({"name": part})
            return users
        except subprocess.SubprocessError as e:
            raise SecurityError(f"Failed to list users: {e}") from e

    def list_groups(self) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["net", "localgroup"],
                capture_output=True, text=True, timeout=15,
            )
            groups = []
            capturing = False
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if "-----" in line:
                    capturing = not capturing
                    continue
                if capturing and line:
                    groups.append({"name": line})
            return groups
        except subprocess.SubprocessError as e:
            raise SecurityError(f"Failed to list groups: {e}") from e

    def check_path_permissions(self, path: str) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["icacls", path],
                capture_output=True, text=True, timeout=15,
            )
            return {
                "path": path,
                "permissions": result.stdout.strip(),
                "error": result.stderr.strip(),
                "can_read": os.access(path, os.R_OK),
                "can_write": os.access(path, os.W_OK),
                "can_execute": os.access(path, os.X_OK),
            }
        except subprocess.SubprocessError as e:
            raise SecPermissionError(f"Cannot check permissions: {path}: {e}") from e

    def check_firewall_status(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["netsh", "advfirewall", "show", "allprofiles"],
                capture_output=True, text=True, timeout=15,
            )
            return {
                "output": result.stdout.strip(),
                "error": result.stderr.strip(),
            }
        except subprocess.SubprocessError as e:
            raise SecurityError(f"Failed to check firewall: {e}") from e

    def get_user_privileges(self) -> list[str]:
        try:
            result = subprocess.run(
                ["whoami", "/priv"],
                capture_output=True, text=True, timeout=10,
            )
            privileges = []
            for line in result.stdout.strip().split("\n"):
                parts = line.split()
                if len(parts) >= 2 and parts[0] not in ("PRIVILEGES", "--------"):
                    privileges.append(parts[0])
            return privileges
        except subprocess.SubprocessError:
            return []

    def get_logged_on_users(self) -> list[dict[str, str]]:
        try:
            result = subprocess.run(
                ["query", "user"],
                capture_output=True, text=True, timeout=10,
            )
            users = []
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                for line in lines[1:]:
                    parts = line.split()
                    if len(parts) >= 4:
                        users.append({
                            "username": parts[0],
                            "session": parts[1],
                            "id": parts[2],
                            "state": parts[3],
                        })
            return users
        except subprocess.SubprocessError:
            return []

    def verify_integrity(self, path: str, checksum: str, algorithm: str = "sha256") -> bool:
        import hashlib
        h = hashlib.new(algorithm)
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest() == checksum
        except OSError as e:
            raise SecurityError(f"Failed to verify integrity: {path}: {e}") from e

    def get_audit_policy(self) -> list[dict[str, str]]:
        try:
            result = subprocess.run(
                ["auditpol", "/get", "/category:*"],
                capture_output=True, text=True, timeout=15,
            )
            policies = []
            for line in result.stdout.strip().split("\n"):
                if ":" in line and ">" not in line:
                    parts = line.split()
                    if len(parts) >= 2:
                        policies.append({
                            "subcategory": parts[0],
                            "setting": parts[-1],
                        })
            return policies
        except subprocess.SubprocessError:
            return []

    def check_bitlocker_status(self) -> list[dict[str, str]]:
        try:
            result = subprocess.run(
                ["manage-bde", "-status"],
                capture_output=True, text=True, timeout=15,
            )
            drives = []
            current: dict[str, str] = {}
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if ":" in line and " " not in line[line.index(":")-1:line.index(":")+2]:
                    if current:
                        drives.append(current)
                    current = {"drive": line.rstrip(":")}
                elif ":" in line and current:
                    key, _, value = line.partition(":")
                    current[key.strip()] = value.strip()
            if current:
                drives.append(current)
            return drives
        except (subprocess.SubprocessError, FileNotFoundError):
            return []

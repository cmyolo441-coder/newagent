from __future__ import annotations

import os
import sys
import ctypes
import struct
from typing import Optional, Any
from exceptions.terminal_exceptions import TerminalError


class ConPtyHandler:
    def __init__(self) -> None:
        self._handle: Optional[int] = None
        self._process_handle: Optional[int] = None
        self._thread_handle: Optional[int] = None
        self._is_open = False
        self._buffer_size = 4096

    def open(
        self,
        shell_path: str,
        rows: int = 24,
        cols: int = 80,
        env: Optional[dict[str, str]] = None,
    ) -> None:
        if sys.platform != "win32":
            raise TerminalError("ConPTY is only supported on Windows")
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

            PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE = 0x20016
            EXTENDED_STARTUPINFO_PRESENT = 0x00080000

            size = struct.pack("HH", rows, cols)
            phPC = ctypes.c_void_p()
            if not kernel32.CreatePseudoConsole(
                size, ctypes.c_void_p(), ctypes.c_void_p(), 0, ctypes.byref(phPC)
            ):
                raise TerminalError("Failed to create pseudo console")

            self._handle = phPC.value

            si = ctypes.create_string_buffer(4096)
            si_startup = ctypes.cast(si, ctypes.POINTER(ctypes.c_byte * 4096))
            startup_info = ctypes.cast(si, ctypes.c_void_p)

            si_ex = ctypes.create_string_buffer(4096)
            PROC_THREAD_ATTRIBUTE_LIST = ctypes.c_void_p()

            kernel32.InitializeProcThreadAttributeList(
                None, 1, 0, ctypes.byref(ctypes.c_size_t(4096))
            )
            kernel32.InitializeProcThreadAttributeList(
                si_ex, 1, 0, ctypes.byref(ctypes.c_size_t(4096))
            )

            pi = ctypes.create_string_buffer(24)
            process_info = ctypes.cast(pi, ctypes.POINTER(ctypes.c_byte * 24))

            env_block = None
            if env:
                env_block = "\0".join(f"{k}={v}" for k, v in env.items()) + "\0\0"

            if not kernel32.CreateProcess(
                None, shell_path, None, None, False,
                EXTENDED_STARTUPINFO_PRESENT,
                env_block, None, startup_info, process_info,
            ):
                kernel32.ClosePseudoConsole(phPC)
                raise TerminalError(f"Failed to create process: {shell_path}")

            self._process_handle = ctypes.c_void_p()
            self._thread_handle = ctypes.c_void_p()
            self._is_open = True
        except (OSError, AttributeError, ctypes.WinError) as e:
            raise TerminalError(f"ConPTY init failed: {e}") from e

    def close(self) -> None:
        if self._handle:
            try:
                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel32.ClosePseudoConsole(self._handle)
            except (OSError, AttributeError):
                pass
            self._handle = None
        if self._process_handle:
            try:
                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel32.TerminateProcess(self._process_handle, 0)
                kernel32.CloseHandle(self._process_handle)
            except (OSError, AttributeError):
                pass
            self._process_handle = None
        if self._thread_handle:
            try:
                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel32.CloseHandle(self._thread_handle)
            except (OSError, AttributeError):
                pass
            self._thread_handle = None
        self._is_open = False

    def write(self, data: str) -> int:
        if not self._is_open or not self._handle:
            raise TerminalError("ConPTY is not open")
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            encoded = data.encode("utf-8")
            written = ctypes.c_ulong()
            if not kernel32.WriteFile(
                self._handle, encoded, len(encoded), ctypes.byref(written), None
            ):
                raise TerminalError("Failed to write to ConPTY")
            return written.value
        except (OSError, AttributeError) as e:
            raise TerminalError(f"ConPTY write failed: {e}") from e

    def read(self, timeout: float = 1.0) -> str:
        if not self._is_open or not self._handle:
            raise TerminalError("ConPTY is not open")
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            buf = ctypes.create_string_buffer(self._buffer_size)
            read = ctypes.c_ulong()
            if not kernel32.ReadFile(
                self._handle, buf, self._buffer_size, ctypes.byref(read), None
            ):
                return ""
            return buf.raw[:read.value].decode("utf-8", errors="replace")
        except (OSError, AttributeError):
            return ""

    def resize(self, rows: int, cols: int) -> None:
        if not self._is_open or not self._handle:
            return
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            size = struct.pack("HH", rows, cols)
            kernel32.ResizePseudoConsole(self._handle, size)
        except (OSError, AttributeError):
            pass

    @property
    def is_open(self) -> bool:
        return self._is_open

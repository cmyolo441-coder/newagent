from __future__ import annotations

import subprocess
from typing import Optional, Any


class KeychainHandler:
    def __init__(self) -> None:
        self._security = "/usr/bin/security"

    def _run(self, args: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [self._security] + args,
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise RuntimeError(f"security command not found: {e}") from e

    def list_keychains(self) -> list[str]:
        result = self._run(["list-keychains"])
        keychains = []
        for line in result.stdout.strip().split("\n"):
            line = line.strip().strip('"')
            if line:
                keychains.append(line)
        return keychains

    def list_items(self, keychain: Optional[str] = None) -> list[dict[str, Any]]:
        args = ["dump-keychain", "-a"]
        if keychain:
            args.append(keychain)
        result = self._run(args)
        items = []
        current: dict[str, Any] = {}
        for line in result.stdout.strip().split("\n"):
            line = line.strip()
            if '"' in line:
                key_part, _, value_part = line.partition("=")
                key = key_part.strip().strip('"')
                value = value_part.strip().strip('"')
                if key == "class":
                    if current:
                        items.append(current)
                    current = {"class": value}
                else:
                    current[key] = value
        if current:
            items.append(current)
        return items

    def find_internet_password(self, service: str, account: Optional[str] = None, keychain: Optional[str] = None) -> Optional[dict[str, Any]]:
        args = ["find-internet-password", "-s", service]
        if account:
            args.extend(["-a", account])
        if keychain:
            args.append(keychain)
        args.append("-g")
        result = self._run(args)
        if result.returncode != 0:
            return None
        info: dict[str, Any] = {}
        for line in result.stdout.strip().split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                info[key.strip()] = value.strip()
        password = None
        for line in result.stderr.strip().split("\n"):
            if "password:" in line.lower():
                _, _, password = line.partition('"')
                password = password.rstrip('"')
        if password:
            info["password"] = password
        return info

    def find_generic_password(self, service: str, account: Optional[str] = None, keychain: Optional[str] = None) -> Optional[dict[str, Any]]:
        args = ["find-generic-password", "-s", service]
        if account:
            args.extend(["-a", account])
        if keychain:
            args.append(keychain)
        args.append("-g")
        result = self._run(args)
        if result.returncode != 0:
            return None
        info: dict[str, Any] = {}
        for line in result.stdout.strip().split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                info[key.strip()] = value.strip()
        password = None
        for line in result.stderr.strip().split("\n"):
            if "password:" in line.lower():
                _, _, password = line.partition('"')
                password = password.rstrip('"')
        if password:
            info["password"] = password
        return info

    def add_internet_password(self, service: str, account: str, password: str, keychain: Optional[str] = None) -> bool:
        args = ["add-internet-password", "-s", service, "-a", account, "-w", password]
        if keychain:
            args.append(keychain)
        result = self._run(args)
        return result.returncode == 0

    def add_generic_password(self, service: str, account: str, password: str, keychain: Optional[str] = None) -> bool:
        args = ["add-generic-password", "-s", service, "-a", account, "-w", password]
        if keychain:
            args.append(keychain)
        result = self._run(args)
        return result.returncode == 0

    def delete_item(self, service: str, account: Optional[str] = None) -> bool:
        args = ["delete-internet-password", "-s", service]
        if account:
            args.extend(["-a", account])
        result = self._run(args)
        if result.returncode != 0:
            args = ["delete-generic-password", "-s", service]
            if account:
                args.extend(["-a", account])
            result = self._run(args)
        return result.returncode == 0

    def lock_keychain(self, keychain: Optional[str] = None) -> bool:
        args = ["lock-keychain"]
        if keychain:
            args.append(keychain)
        result = self._run(args)
        return result.returncode == 0

    def unlock_keychain(self, keychain: Optional[str] = None) -> bool:
        args = ["unlock-keychain"]
        if keychain:
            args.append(keychain)
        result = self._run(args)
        return result.returncode == 0

    def set_keychain_settings(self, keychain: str, timeout: int = 3600) -> bool:
        args = ["set-keychain-settings", "-t", str(timeout), keychain]
        result = self._run(args)
        return result.returncode == 0

    def get_default_keychain(self) -> Optional[str]:
        result = self._run(["default-keychain"])
        if result.returncode == 0:
            return result.stdout.strip().strip('"')
        return None

    def set_default_keychain(self, keychain: str) -> bool:
        result = self._run(["default-keychain", "-s", keychain])
        return result.returncode == 0

    def create_keychain(self, name: str, password: Optional[str] = None) -> bool:
        args = ["create-keychain", "-p"]
        if password:
            args.append(password)
        else:
            args.append("")
        args.append(name)
        result = self._run(args)
        return result.returncode == 0

    def delete_keychain(self, name: str) -> bool:
        result = self._run(["delete-keychain", name])
        return result.returncode == 0

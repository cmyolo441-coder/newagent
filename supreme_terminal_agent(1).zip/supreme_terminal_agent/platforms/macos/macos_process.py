from __future__ import annotations

import os
import signal
import subprocess
from typing import Optional, Any
from exceptions.execution_exceptions import ProcessError


class MacOSProcessManager:
    def __init__(self) -> None:
        pass

    def list_processes(self) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["ps", "aux"],
                capture_output=True, text=True, timeout=30,
            )
            processes = []
            lines = result.stdout.strip().split("\n")
            if not lines:
                return []
            for line in lines[1:]:
                parts = line.split(None, 10)
                if len(parts) >= 11:
                    processes.append({
                        "user": parts[0],
                        "pid": int(parts[1]),
                        "cpu": float(parts[2]),
                        "mem": float(parts[3]),
                        "vsz": int(parts[4]),
                        "rss": int(parts[5]),
                        "tty": parts[6],
                        "stat": parts[7],
                        "start": parts[8],
                        "time": parts[9],
                        "command": parts[10],
                    })
            return processes
        except (subprocess.SubprocessError, ValueError) as e:
            raise ProcessError(f"Failed to list processes: {e}") from e

    def get_process(self, pid: int) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["ps", "-p", str(pid), "-o", "pid,ppid,user,%cpu,%mem,vsz,rss,tty,stat,etime,comm"],
                capture_output=True, text=True, timeout=10,
            )
            lines = result.stdout.strip().split("\n")
            if len(lines) < 2:
                raise ProcessError(f"Process {pid} not found")
            parts = lines[1].split(None, 10)
            return {
                "pid": int(parts[0]) if len(parts) > 0 else 0,
                "ppid": int(parts[1]) if len(parts) > 1 else 0,
                "user": parts[2] if len(parts) > 2 else "",
                "cpu": float(parts[3]) if len(parts) > 3 else 0.0,
                "mem": float(parts[4]) if len(parts) > 4 else 0.0,
                "vsz": int(parts[5]) if len(parts) > 5 else 0,
                "rss": int(parts[6]) if len(parts) > 6 else 0,
                "tty": parts[7] if len(parts) > 7 else "",
                "stat": parts[8] if len(parts) > 8 else "",
                "etime": parts[9] if len(parts) > 9 else "",
                "command": parts[10] if len(parts) > 10 else "",
            }
        except (subprocess.SubprocessError, ValueError, IndexError) as e:
            raise ProcessError(f"Failed to get process {pid}: {e}") from e

    def kill_process(self, pid: int, force: bool = False) -> bool:
        sig = signal.SIGKILL if force else signal.SIGTERM
        try:
            os.kill(pid, sig)
            return True
        except ProcessLookupError:
            return False
        except PermissionError as e:
            raise ProcessError(f"Permission denied to kill process {pid}: {e}") from e

    def send_signal(self, pid: int, sig: int) -> bool:
        try:
            os.kill(pid, sig)
            return True
        except ProcessLookupError:
            return False
        except PermissionError as e:
            raise ProcessError(f"Permission denied to signal process {pid}: {e}") from e

    def suspend_process(self, pid: int) -> bool:
        return self.send_signal(pid, signal.SIGSTOP)

    def resume_process(self, pid: int) -> bool:
        return self.send_signal(pid, signal.SIGCONT)

    def get_process_by_name(self, name: str) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["pgrep", "-f", name],
                capture_output=True, text=True, timeout=10,
            )
            pids = [int(p) for p in result.stdout.strip().split("\n") if p.strip()]
            return [self.get_process(pid) for pid in pids]
        except (subprocess.SubprocessError, ValueError) as e:
            raise ProcessError(f"Failed to find process by name: {name}: {e}") from e

    def get_system_stats(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["vm_stat"],
                capture_output=True, text=True, timeout=10,
            )
            vm_stats = {}
            for line in result.stdout.strip().split("\n"):
                if ":" in line:
                    key, _, value = line.partition(":")
                    vm_stats[key.strip()] = value.strip().rstrip(".")
            load_result = subprocess.run(
                ["sysctl", "-n", "vm.loadavg"],
                capture_output=True, text=True, timeout=10,
            )
            loadavg = load_result.stdout.strip()
            uptime_result = subprocess.run(
                ["sysctl", "-n", "kern.boottime"],
                capture_output=True, text=True, timeout=10,
            )
            return {
                "vm_stats": vm_stats,
                "load_avg": loadavg,
                "boottime": uptime_result.stdout.strip(),
            }
        except subprocess.SubprocessError as e:
            raise ProcessError(f"Failed to get system stats: {e}") from e

    def get_process_tree(self, pid: int) -> list[dict[str, Any]]:
        processes = self.list_processes()
        tree = []
        for p in processes:
            if p["pid"] == pid:
                tree.append(p)
                for child in self._find_children(processes, pid):
                    tree.append(child)
                break
        return tree

    def _find_children(self, processes: list[dict[str, Any]], parent_pid: int) -> list[dict[str, Any]]:
        children = []
        for p in processes:
            if "ppid" in p and p["ppid"] == parent_pid:
                children.append(p)
                children.extend(self._find_children(processes, p["pid"]))
        return children

from __future__ import annotations

import os
import pwd
import grp
import stat
import subprocess
from typing import Optional, Any
from exceptions.security_exceptions import SecurityError, PermissionError as SecPermissionError
from platforms.macos.keychain_handler import KeychainHandler
from platforms.macos.sandbox_handler import SandboxHandler


class MacOSSecurityManager:
    def __init__(self) -> None:
        self.keychain = KeychainHandler()
        self.sandbox = SandboxHandler()

    def get_current_user(self) -> dict[str, Any]:
        try:
            pw = pwd.getpwuid(os.getuid())
            return {
                "name": pw.pw_name,
                "uid": pw.pw_uid,
                "gid": pw.pw_gid,
                "home": pw.pw_dir,
                "shell": pw.pw_shell,
                "gecos": pw.pw_gecos,
            }
        except KeyError as e:
            raise SecurityError(f"Failed to get current user: {e}") from e

    def list_users(self) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["dscl", ".", "list", "/Users"],
                capture_output=True, text=True, timeout=15,
            )
            users = []
            for name in result.stdout.strip().split("\n"):
                if name and not name.startswith("_"):
                    try:
                        pw = pwd.getpwnam(name)
                        users.append({
                            "name": pw.pw_name,
                            "uid": pw.pw_uid,
                            "gid": pw.pw_gid,
                            "home": pw.pw_dir,
                            "shell": pw.pw_shell,
                        })
                    except KeyError:
                        pass
            return users
        except subprocess.SubprocessError as e:
            raise SecurityError(f"Failed to list users: {e}") from e

    def check_path_permissions(self, path: str) -> dict[str, Any]:
        try:
            st = os.stat(path)
            return {
                "path": path,
                "owner": pwd.getpwuid(st.st_uid).pw_name,
                "group": grp.getgrgid(st.st_gid).gr_name,
                "mode_str": stat.filemode(st.st_mode),
                "mode_oct": oct(st.st_mode),
                "can_read": os.access(path, os.R_OK),
                "can_write": os.access(path, os.W_OK),
                "can_execute": os.access(path, os.X_OK),
            }
        except OSError as e:
            raise SecPermissionError(f"Cannot check permissions: {path}: {e}") from e

    def is_running_as_root(self) -> bool:
        return os.geteuid() == 0

    def check_gatekeeper_status(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["spctl", "--status"],
                capture_output=True, text=True, timeout=10,
            )
            return {
                "enabled": "assessments enabled" in result.stdout.lower(),
                "output": result.stdout.strip(),
            }
        except FileNotFoundError:
            return {"enabled": False, "error": "spctl not found"}

    def check_sip_status(self) -> bool:
        try:
            result = subprocess.run(
                ["csrutil", "status"],
                capture_output=True, text=True, timeout=10,
            )
            return "enabled" in result.stdout.lower()
        except FileNotFoundError:
            return False

    def check_firewall_status(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["/usr/libexec/ApplicationFirewall/socketfilterfw", "--getglobalstate"],
                capture_output=True, text=True, timeout=10,
            )
            return {
                "enabled": "enabled" in result.stdout.lower(),
                "output": result.stdout.strip(),
            }
        except FileNotFoundError:
            return {"enabled": False, "error": "socketfilterfw not found"}

    def check_filevault_status(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["fdesetup", "status"],
                capture_output=True, text=True, timeout=15,
            )
            return {
                "enabled": "on" in result.stdout.lower(),
                "output": result.stdout.strip(),
            }
        except FileNotFoundError:
            return {"enabled": False, "error": "fdesetup not found"}

    def verify_integrity(self, path: str, checksum: str, algorithm: str = "sha256") -> bool:
        import hashlib
        h = hashlib.new(algorithm)
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest() == checksum
        except OSError as e:
            raise SecurityError(f"Failed to verify integrity: {path}: {e}") from e

    def codesign_check(self, path: str) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["codesign", "-dv", path],
                capture_output=True, text=True, timeout=10,
            )
            return {
                "signed": result.returncode == 0,
                "output": result.stderr if result.stderr else result.stdout,
            }
        except FileNotFoundError:
            return {"signed": False, "error": "codesign not found"}

    def xattr_check(self, path: str) -> list[str]:
        try:
            result = subprocess.run(
                ["xattr", path],
                capture_output=True, text=True, timeout=10,
            )
            if result.stdout.strip():
                return result.stdout.strip().split("\n")
            return []
        except FileNotFoundError:
            return []

    def quarantine_check(self, path: str) -> Optional[str]:
        attrs = self.xattr_check(path)
        for attr in attrs:
            if "quarantine" in attr:
                return attr
        return None

    def verify_checksum(self, path: str) -> dict[str, str]:
        import hashlib
        info: dict[str, str] = {}
        for algo in ("md5", "sha1", "sha256"):
            h = hashlib.new(algo)
            try:
                with open(path, "rb") as f:
                    for chunk in iter(lambda: f.read(65536), b""):
                        h.update(chunk)
                info[algo] = h.hexdigest()
            except OSError:
                info[algo] = "error"
        return info

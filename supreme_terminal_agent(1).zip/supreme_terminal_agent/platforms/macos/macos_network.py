from __future__ import annotations

import os
import socket
import subprocess
import ipaddress
from typing import Optional, Any
from exceptions.network_exceptions import NetworkError, DNSResolutionError


class MacOSNetworkManager:
    def __init__(self) -> None:
        pass

    def get_interfaces(self) -> list[dict[str, Any]]:
        interfaces = []
        try:
            result = subprocess.run(
                ["ifconfig", "-l"],
                capture_output=True, text=True, timeout=10,
            )
            names = result.stdout.strip().split()
            for name in names:
                info = self.get_interface(name)
                if info:
                    interfaces.append(info)
            return interfaces
        except subprocess.SubprocessError as e:
            raise NetworkError(f"Failed to get interfaces: {e}") from e

    def get_interface(self, name: str) -> Optional[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["ifconfig", name],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode != 0:
                return None
            info: dict[str, Any] = {"name": name, "addresses": []}
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if line.startswith("inet "):
                    parts = line.split()
                    info["addresses"].append({
                        "family": "inet",
                        "address": parts[1],
                        "netmask": parts[3] if len(parts) > 3 else "",
                    })
                elif line.startswith("inet6 "):
                    parts = line.split()
                    info["addresses"].append({
                        "family": "inet6",
                        "address": parts[1],
                        "prefixlen": parts[3] if len(parts) > 3 else "",
                    })
                elif line.startswith("ether "):
                    info["mac"] = line.split()[1]
                elif "mtu" in line:
                    mtu_part = [p for p in line.split() if p.startswith("mtu")]
                    if mtu_part:
                        info["mtu"] = int(mtu_part[0].replace("mtu", ""))
                elif "status:" in line:
                    info["status"] = line.split()[1]
            return info
        except subprocess.SubprocessError:
            return None

    def get_connections(self) -> list[dict[str, Any]]:
        try:
            result = subprocess.run(
                ["lsof", "-i", "-n", "-P"],
                capture_output=True, text=True, timeout=30,
            )
            connections = []
            lines = result.stdout.strip().split("\n")
            if len(lines) < 2:
                return []
            for line in lines[1:]:
                parts = line.split()
                if len(parts) >= 9:
                    connections.append({
                        "command": parts[0],
                        "pid": int(parts[1]),
                        "user": parts[2],
                        "fd": parts[3],
                        "type": parts[4],
                        "device": parts[5],
                        "size": parts[6],
                        "node": parts[7],
                        "name": parts[8],
                    })
            return connections
        except (subprocess.SubprocessError, ValueError):
            return []

    def resolve_hostname(self, hostname: str) -> list[str]:
        try:
            result = socket.getaddrinfo(hostname, None)
            return list(set(addr[4][0] for addr in result))
        except socket.gaierror as e:
            raise DNSResolutionError(f"Failed to resolve: {hostname}: {e}") from e

    def reverse_lookup(self, ip: str) -> str:
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)
            return hostname
        except socket.herror as e:
            raise DNSResolutionError(f"Failed reverse lookup: {ip}: {e}") from e

    def ping(self, host: str, count: int = 4) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["ping", "-c", str(count), host],
                capture_output=True, text=True, timeout=30,
            )
            return {
                "host": host,
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr,
            }
        except subprocess.TimeoutExpired:
            return {"host": host, "success": False, "output": "", "error": "Ping timed out"}
        except FileNotFoundError:
            raise NetworkError("ping command not found")

    def check_port(self, host: str, port: int, timeout: float = 5.0) -> bool:
        try:
            sock = socket.create_connection((host, port), timeout=timeout)
            sock.close()
            return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False

    def get_public_ip(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["curl", "-s", "https://api.ipify.org"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except (subprocess.SubprocessError, OSError):
            pass
        return None

    def is_valid_ip(self, ip: str) -> bool:
        try:
            ipaddress.ip_address(ip)
            return True
        except ValueError:
            return False

    def get_dns_servers(self) -> list[str]:
        servers = []
        try:
            result = subprocess.run(
                ["scutil", "--dns"],
                capture_output=True, text=True, timeout=10,
            )
            for line in result.stdout.strip().split("\n"):
                if "nameserver" in line.lower() and "[" not in line:
                    parts = line.split()
                    if len(parts) >= 3:
                        servers.append(parts[-1])
        except subprocess.SubprocessError:
            pass
        return servers

    def get_network_stats(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["netstat", "-ib"],
                capture_output=True, text=True, timeout=10,
            )
            stats: dict[str, Any] = {}
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                headers = lines[0].split()
                for line in lines[1:]:
                    parts = line.split()
                    if len(parts) >= 8:
                        name = parts[0]
                        stats[name] = {
                            "packets_in": int(parts[2]) if parts[2].isdigit() else 0,
                            "packets_out": int(parts[5]) if parts[5].isdigit() else 0,
                            "bytes_in": int(parts[6]) if parts[6].isdigit() else 0,
                            "bytes_out": int(parts[7]) if parts[7].isdigit() else 0,
                        }
            return stats
        except (subprocess.SubprocessError, ValueError):
            return {}

from __future__ import annotations

import os
import shutil
import stat
import grp
import pwd
import subprocess
from typing import Optional, Any
from exceptions.filesystem_exceptions import (
    FileNotFoundError as FSFileNotFound,
    PermissionDeniedError,
    DiskError,
)


class FileInfo:
    def __init__(self, path: str) -> None:
        self.path = os.path.abspath(path)
        self.name = os.path.basename(self.path)
        self.extension = os.path.splitext(self.name)[1]
        self.is_dir = os.path.isdir(self.path)
        self.is_file = os.path.isfile(self.path)
        self.is_link = os.path.islink(self.path)
        self.size: int = 0
        self.permissions: int = 0
        self.permissions_str: str = ""
        self.owner: str = ""
        self.group: str = ""
        self.owner_uid: int = 0
        self.group_gid: int = 0
        self.modified_time: float = 0.0
        self.access_time: float = 0.0
        self.created_time: float = 0.0
        self.bsd_flags: str = ""
        self._load()

    def _load(self) -> None:
        try:
            st = os.stat(self.path, follow_symlinks=False)
            self.size = st.st_size
            self.permissions = st.st_mode
            self.permissions_str = stat.filemode(st.st_mode)
            try:
                self.owner = pwd.getpwuid(st.st_uid).pw_name
            except KeyError:
                self.owner = str(st.st_uid)
            try:
                self.group = grp.getgrgid(st.st_gid).gr_name
            except KeyError:
                self.group = str(st.st_gid)
            self.owner_uid = st.st_uid
            self.group_gid = st.st_gid
            self.modified_time = st.st_mtime
            self.access_time = st.st_atime
            self.created_time = st.st_ctime
        except FileNotFoundError:
            raise FSFileNotFound(f"File not found: {self.path}")
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {self.path}: {e}") from e

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}


class MacOSFileSystem:
    def __init__(self) -> None:
        self._current_dir = os.getcwd()

    def list_directory(self, path: str = ".") -> list[FileInfo]:
        try:
            entries = os.listdir(path)
            return [FileInfo(os.path.join(path, e)) for e in sorted(entries)]
        except FileNotFoundError as e:
            raise FSFileNotFound(f"Directory not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e

    def get_file_info(self, path: str) -> FileInfo:
        return FileInfo(path)

    def read_file(self, path: str, encoding: str = "utf-8") -> str:
        try:
            with open(path, "r", encoding=encoding) as f:
                return f.read()
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except UnicodeDecodeError as e:
            raise FSFileNotFound(f"Cannot decode: {path}: {e}") from e

    def read_binary(self, path: str) -> bytes:
        try:
            with open(path, "rb") as f:
                return f.read()
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e

    def write_file(self, path: str, content: str, encoding: str = "utf-8") -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "w", encoding=encoding) as f:
                f.write(content)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to write: {path}: {e}") from e

    def write_binary(self, path: str, content: bytes) -> None:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "wb") as f:
                f.write(content)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to write: {path}: {e}") from e

    def create_directory(self, path: str, mode: int = 0o755) -> None:
        try:
            os.makedirs(path, mode=mode, exist_ok=True)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to create dir: {path}: {e}") from e

    def remove_file(self, path: str) -> None:
        try:
            os.remove(path)
        except FileNotFoundError as e:
            raise FSFileNotFound(f"File not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to remove: {path}: {e}") from e

    def remove_directory(self, path: str, recursive: bool = False) -> None:
        try:
            if recursive:
                shutil.rmtree(path)
            else:
                os.rmdir(path)
        except FileNotFoundError as e:
            raise FSFileNotFound(f"Dir not found: {path}: {e}") from e
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except OSError as e:
            raise DiskError(f"Failed to remove dir: {path}: {e}") from e

    def copy(self, src: str, dst: str, recursive: bool = False) -> None:
        try:
            if recursive and os.path.isdir(src):
                shutil.copytree(src, dst, symlinks=True)
            else:
                shutil.copy2(src, dst)
        except (FileNotFoundError, PermissionError, OSError) as e:
            raise DiskError(f"Failed to copy {src} to {dst}: {e}") from e

    def move(self, src: str, dst: str) -> None:
        try:
            shutil.move(src, dst)
        except (FileNotFoundError, PermissionError, OSError) as e:
            raise DiskError(f"Failed to move {src} to {dst}: {e}") from e

    def chmod(self, path: str, mode: int) -> None:
        try:
            os.chmod(path, mode)
        except PermissionError as e:
            raise PermissionDeniedError(f"Permission denied: {path}: {e}") from e
        except FileNotFoundError as e:
            raise FSFileNotFound(f"Not found: {path}: {e}") from e

    def chown(self, path: str, user: Optional[str] = None, group: Optional[str] = None) -> None:
        try:
            uid = -1
            gid = -1
            if user is not None:
                uid = int(user) if user.isdigit() else pwd.getpwnam(user).pw_uid
            if group is not None:
                gid = int(group) if group.isdigit() else grp.getgrnam(group).gr_gid
            os.chown(path, uid, gid)
        except (PermissionError, KeyError, OSError) as e:
            raise PermissionDeniedError(f"Failed to chown {path}: {e}") from e

    def symlink(self, src: str, dst: str) -> None:
        try:
            os.symlink(src, dst)
        except OSError as e:
            raise DiskError(f"Failed to symlink {dst} -> {src}: {e}") from e

    def get_disk_usage(self, path: str = "/") -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["df", "-k", path],
                capture_output=True, text=True, timeout=10,
            )
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                parts = lines[1].split()
                if len(parts) >= 6:
                    return {
                        "total": int(parts[1]) * 1024,
                        "used": int(parts[2]) * 1024,
                        "free": int(parts[3]) * 1024,
                        "percent": parts[4],
                        "mount": parts[5],
                    }
            usage = shutil.disk_usage(path)
            return {
                "total": usage.total,
                "used": usage.used,
                "free": usage.free,
                "percent": f"{usage.used / usage.total * 100:.1f}%" if usage.total > 0 else "0%",
                "mount": path,
            }
        except (subprocess.SubprocessError, OSError) as e:
            raise DiskError(f"Failed to get disk usage: {e}") from e

    def get_mounts(self) -> list[dict[str, str]]:
        mounts = []
        try:
            result = subprocess.run(
                ["mount"],
                capture_output=True, text=True, timeout=10,
            )
            for line in result.stdout.strip().split("\n"):
                parts = line.split()
                if len(parts) >= 3:
                    mounts.append({
                        "device": parts[0],
                        "mountpoint": parts[2],
                        "type": parts[4] if len(parts) > 4 else "unknown",
                    })
        except subprocess.SubprocessError:
            pass
        return mounts

    def get_file_extended_attributes(self, path: str) -> list[str]:
        import xattr
        try:
            return list(xattr.listxattr(path))
        except OSError:
            return []

from __future__ import annotations

import os
import subprocess
import plistlib
from typing import Optional, Any


class LaunchdHandler:
    def __init__(self) -> None:
        self._launchctl = "/bin/launchctl"

    def _run(self, args: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                [self._launchctl] + args,
                capture_output=True, text=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise RuntimeError(f"launchctl not found: {e}") from e

    def list_services(self) -> list[dict[str, str]]:
        result = self._run(["list"])
        services = []
        for line in result.stdout.strip().split("\n"):
            parts = line.split()
            if len(parts) >= 3:
                services.append({
                    "pid": parts[0] if parts[0] != "-" else "",
                    "status": parts[1],
                    "label": parts[2],
                })
        return services

    def start_service(self, label: str) -> bool:
        result = self._run(["start", label])
        return result.returncode == 0

    def stop_service(self, label: str) -> bool:
        result = self._run(["stop", label])
        return result.returncode == 0

    def load_plist(self, path: str) -> bool:
        result = self._run(["load", path])
        return result.returncode == 0

    def unload_plist(self, path: str) -> bool:
        result = self._run(["unload", path])
        return result.returncode == 0

    def get_service_info(self, label: str) -> Optional[dict[str, Any]]:
        result = self._run(["list", label])
        if result.returncode != 0:
            return None
        info: dict[str, Any] = {"label": label}
        for line in result.stdout.strip().split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                info[key.strip()] = value.strip()
        return info

    def get_service_plist(self, label: str) -> Optional[dict[str, Any]]:
        paths = [
            os.path.join("/System/Library/LaunchDaemons", f"{label}.plist"),
            os.path.join("/Library/LaunchDaemons", f"{label}.plist"),
            os.path.join(os.path.expanduser("~/Library/LaunchAgents"), f"{label}.plist"),
            os.path.join("/Library/LaunchAgents", f"{label}.plist"),
        ]
        for path in paths:
            if os.path.isfile(path):
                try:
                    with open(path, "rb") as f:
                        return plistlib.load(f)
                except (plistlib.InvalidFileException, OSError):
                    pass
        return None

    def bootstrap(self, service_path: str) -> bool:
        result = self._run(["bootstrap", "gui/$(id -u)", service_path])
        return result.returncode == 0

    def bootout(self, service_path: str) -> bool:
        result = self._run(["bootout", "gui/$(id -u)", service_path])
        return result.returncode == 0

    def enable_service(self, label: str) -> bool:
        result = self._run(["enable", label])
        return result.returncode == 0

    def disable_service(self, label: str) -> bool:
        result = self._run(["disable", label])
        return result.returncode == 0

    def kickstart(self, label: str) -> bool:
        result = self._run(["kickstart", "-kp", label])
        return result.returncode == 0

    def print_domain(self, domain: str = "system") -> str:
        result = self._run(["print", domain])
        return result.stdout + result.stderr

    def get_user_agents(self) -> list[dict[str, str]]:
        services = self.list_services()
        return [s for s in services if "gui" in s.get("label", "").lower() or os.path.exists(
            os.path.join(os.path.expanduser("~/Library/LaunchAgents"), f"{s.get('label', '')}.plist")
        )]

    def get_system_agents(self) -> list[dict[str, str]]:
        return self.list_services()

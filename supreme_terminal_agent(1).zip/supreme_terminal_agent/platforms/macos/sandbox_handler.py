from __future__ import annotations

import subprocess
from typing import Optional, Any


class SandboxHandler:
    def __init__(self) -> None:
        self._sandbox_exec = "/usr/bin/sandbox-exec"
        self._sandbox_expand = "/usr/bin/sandbox-expand"

    def _run(self, cmd: list[str], timeout: int = 15) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except FileNotFoundError as e:
            raise RuntimeError(f"Sandbox command not found: {e}") from e

    def check_status(self) -> dict[str, Any]:
        try:
            result = subprocess.run(
                ["sandbox-exec", "-p", "(version 1)", "echo", "sandbox_available"],
                capture_output=True, text=True, timeout=10,
            )
            return {"available": result.returncode == 0}
        except FileNotFoundError:
            return {"available": False}

    def compile_profile(self, profile_path: str) -> Optional[str]:
        try:
            result = subprocess.run(
                ["sandbox-compile", profile_path],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0:
                return result.stdout.strip()
            return None
        except FileNotFoundError:
            return None

    def expand_profile(self, profile_path: str) -> Optional[str]:
        try:
            result = self._run([self._sandbox_expand, profile_path])
            if result.returncode == 0:
                return result.stdout
            return None
        except (FileNotFoundError, RuntimeError):
            return None

    def run_sandboxed(self, command: list[str], profile: Optional[str] = None) -> dict[str, Any]:
        args = [self._sandbox_exec]
        if profile:
            args.extend(["-p", profile] if profile.startswith("(") else ["-f", profile])
        args.extend(command)
        result = self._run(args)
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
        }

    def list_profiles(self) -> list[str]:
        profiles = []
        search_paths = [
            "/usr/share/sandbox",
            "/System/Library/Sandbox/Profiles",
        ]
        for base in search_paths:
            try:
                import os as _os
                if _os.path.isdir(base):
                    for f in _os.listdir(base):
                        if f.endswith(".sb"):
                            profiles.append(_os.path.join(base, f))
            except OSError:
                pass
        return profiles

    def get_system_containers(self) -> list[dict[str, str]]:
        containers = []
        import os as _os
        base = _os.path.expanduser("~/Library/Containers")
        try:
            for entry in _os.listdir(base):
                container_path = _os.path.join(base, entry)
                if _os.path.isdir(container_path):
                    metadata_path = _os.path.join(container_path, "Container.plist")
                    if _os.path.isfile(metadata_path):
                        containers.append({
                            "name": entry,
                            "path": container_path,
                            "metadata": metadata_path,
                        })
                    else:
                        containers.append({
                            "name": entry,
                            "path": container_path,
                            "metadata": "",
                        })
        except OSError:
            pass
        return containers

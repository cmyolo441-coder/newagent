# Glossary

Definitions of terms used throughout the Supreme Terminal AI Agent documentation and codebase.

## A

**Agent**
The Supreme Terminal AI Agent itself. The main entity that interacts with users, manages subsystems, and executes tasks.

**AI Engine**
The subsystem responsible for communicating with AI providers (OpenAI, Anthropic, etc.), managing prompts, caching responses, rate limiting, and cost tracking.

**Audit Logging**
Immutable log of all security-relevant actions including commands executed, file access, authentication attempts, and configuration changes.

**Authentication**
The process of verifying a user's identity through passwords, SSH keys, MFA, or SSO.

**Authorization**
The process of determining what actions a verified user is allowed to perform, typically managed through RBAC.

## B

**Brain**
The core decision-making component that coordinates cognition, reasoning, and planning to process user input and generate responses.

## C

**Chain-of-Thought**
A reasoning strategy where the agent breaks down a problem into intermediate steps, explaining its reasoning process before arriving at a conclusion.

**Cognition**
The subsystem responsible for initial input processing, concept extraction, and building an understanding of user requests.

**Command Engine**
The subsystem that parses, validates, and executes shell commands and custom command handlers.

**Configuration Manager**
The subsystem that loads, validates, and provides access to configuration from YAML files, environment variables, and command-line flags.

**Consciousness**
A component that provides self-awareness, tracks internal state, and manages the agent's awake/sleep cycle.

**Coordinator**
A component that registers and manages all agent subsystems, providing component lookup and inter-component communication.

## D

**Daemon Mode**
An operating mode where the agent runs as a background service, accepting connections from client sessions.

## E

**Episodic Memory**
A type of memory that stores past interactions and their outcomes, used for learning from experience.

**Event Bus**
A publish-subscribe messaging system that allows components to communicate asynchronously through events.

**Executor**
A component that runs tasks asynchronously, tracking their status through running, completed, and failed states.

## F

**Failover**
The ability to automatically switch to a backup provider or component when the primary one fails.

**Firewall**
Network access control that manages which hosts and ports the agent can connect to.

## G

**Goal-Oriented Action Planning (GOAP)**
A planning algorithm that determines a sequence of actions to achieve a desired goal state.

## H

**Heartbeat**
A periodic signal used to monitor the health of the agent and its components.

**Hierarchical Planner**
A planning algorithm that breaks down complex goals into sub-goals and tasks in a hierarchical structure.

**Hook**
An extension point in the agent's lifecycle where plugins can inject custom behavior (e.g., pre-command, post-command).

## I

**Inference Engine**
A rule-based system that applies logical rules to a knowledge base to derive conclusions.

**Interactive Mode**
The default operating mode where the agent presents a REPL (Read-Eval-Print Loop) for direct user interaction.

## L

**Lifecycle Manager**
The component that manages the agent's state transitions through its lifecycle: INIT, IDLE, PROCESSING, ERROR, SHUTDOWN.

**Long-Term Memory**
Persistent memory that survives agent restarts, used for storing user preferences, learned patterns, and important information.

## M

**Metacognition**
The ability to monitor and regulate one's own cognitive processes. The agent uses metacognition for self-reflection, self-critique, and confidence estimation.

**Middleware**
A processing layer in the command pipeline that can inspect, modify, or block commands before execution.

**Model Registry**
A catalog of available AI models with their capabilities, costs, and configuration.

## O

**Orchestrator**
The central task scheduler that manages concurrent task execution, component coordination, and overall system operation.

## P

**Pipeline**
A sequence of automated steps executed in order, typically used for deployment, testing, or data processing workflows.

**Planning**
The subsystem that generates execution plans using various planning algorithms (strategic, tactical, hierarchical, GOAP, etc.).

**Plugin**
An extensible package that adds functionality to the agent through a well-defined API, supporting lifecycle hooks, custom commands, and tools.

**Priority Engine**
A priority-based task queue that ensures high-priority tasks are processed before lower-priority ones.

**PTY (Pseudo-Terminal)**
A pseudo-terminal device that provides terminal I/O to a child process, enabling the agent to interact with shells as if they were running in a real terminal.

## R

**RAG (Retrieval-Augmented Generation)**
A technique that enhances AI responses by retrieving relevant information from a knowledge base or vector store before generating a response.

**RBAC (Role-Based Access Control)**
An authorization model where permissions are assigned to roles, and users are assigned to roles.

**Reasoning**
The subsystem that applies logical reasoning strategies (chain-of-thought, tree-of-thought, deductive, inductive, etc.) to derive conclusions from concepts.

**Recovery Manager**
A component that saves state checkpoints and can restore the agent to a previous known-good state.

## S

**Sandbox**
An isolated execution environment (Docker, subprocess, Firejail) that restricts what commands can access on the host system.

**Secrets Manager**
A subsystem for securely storing and retrieving sensitive values like API keys, passwords, and encryption keys.

**Self-Healer**
A component that automatically recovers from common errors using registered recovery procedures.

**Self-Monitor**
A component that tracks runtime metrics including performance, resource usage, and error rates.

**Session**
An isolated terminal environment with its own shell, history, context, and state. Sessions can persist in the background when detached.

**Short-Term Memory**
Ephemeral memory that holds the current conversation context and is automatically cleared when a session ends.

**State Machine**
A finite state machine that manages the agent's lifecycle states and valid transitions between them.

## T

**Task Decomposer**
A component that breaks high-level goals into hierarchical trees of subtasks.

**Tool**
A registered, reusable capability that can be invoked by the agent, plugins, or users. Tools have defined parameters and return structured results.

**Tree-of-Thought**
A reasoning strategy that explores multiple reasoning paths simultaneously, branching at decision points to find the best solution.

**Trigger**
An event-driven automation rule that executes an action when a specified event occurs (file change, timer, command failure, etc.).

## V

**Vector Memory**
Memory that stores text as embedding vectors, enabling semantic similarity search across stored information.

## W

**Watchdog**
A safety mechanism that monitors for system hangs or failures and triggers recovery when the system becomes unresponsive.

**Workflow**
A YAML-defined sequence of steps with conditions, parallel execution, error handling, and external integrations for complex automation.

**WebSocket**
A protocol for real-time, bidirectional communication between the agent and connected clients.

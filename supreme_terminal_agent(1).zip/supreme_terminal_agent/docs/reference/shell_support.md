# Shell Support Reference

Supported shells and their integration features.

## Supported Shells

| Shell | Support Level | Features |
|---|---|---|
| Bash | Full | All features |
| Zsh | Full | All features |
| Fish | Full | All features |
| Dash | Basic | Command execution |
| Sh (POSIX) | Basic | Command execution |
| PowerShell | Full | All features (Windows) |
| NuShell | Partial | Basic support |
| Elvish | Partial | Basic support |
| TCSH | Basic | Command execution |
| Ksh | Basic | Command execution |

## Shell Integration Features

### Bash

```yaml
terminal:
  shell: /bin/bash
```

- Command history integration
- Tab completion
- Prompt customization
- Directory tracking
- Job control support
- Conditional integration in `.bashrc`:

```bash
# Add to ~/.bashrc
if command -v terminal-agent &> /dev/null; then
  eval "$(terminal-agent shell-integration bash)"
fi
```

### Zsh

```yaml
terminal:
  shell: /bin/zsh
```

- Full Oh My Zsh compatibility
- Theme support
- Plugin compatibility
- Completion system integration

```zsh
# Add to ~/.zshrc
if (( $+commands[terminal-agent] )); then
  eval "$(terminal-agent shell-integration zsh)"
fi
```

### Fish

```yaml
terminal:
  shell: /usr/bin/fish
```

- Native syntax highlighting
- Autosuggestions
- Web-based configuration

```fish
# Add to ~/.config/fish/config.fish
if command -v terminal-agent > /dev/null
  terminal-agent shell-integration fish | source
end
```

## Shell Detection

The agent automatically detects the user's shell:

```yaml
terminal:
  shell: auto  # Automatically detected
```

Detection priority: `SHELL` env var -> `/etc/passwd` -> `/bin/bash`

## Custom Shells

For unsupported shells, configure manually:

```yaml
terminal:
  shell: /usr/bin/myshell
  shell_args: ["--login", "-i"]
  shell_env:
    MY_SHELL_OPT: "true"
```

## Shell Configuration

### Environment Variables

```yaml
terminal:
  env:
    EDITOR: vim
    PAGER: less
    LANG: en_US.UTF-8
    LC_ALL: en_US.UTF-8
```

### Start-up Commands

```yaml
terminal:
  init_commands:
    - "alias ll='ls -la'"
    - "export PS1='\\w \\$ '"
```

## PTY Configuration

```yaml
terminal:
  pty:
    echo: false
    icanon: false
    isig: true
    rows: 24
    cols: 80
```

## Known Limitations

| Shell | Limitation |
|---|---|
| Dash | No job control, limited prompt features |
| Sh | No command history integration |
| TCSH | Limited escape sequence support |
| NuShell | No PTY passthrough |

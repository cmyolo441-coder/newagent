# Configuration Options Reference

Complete reference of all configuration options for the Supreme Terminal AI Agent.

## Agent

```yaml
agent:
  name: SupremeTerminalAI
  debug: false
  version: "1.0.0"
  data_dir: data/
  log_level: INFO
  config_dir: config/
  plugins_dir: plugins/
```

| Option | Type | Default | Description |
|---|---|---|---|
| `name` | string | `SupremeTerminalAI` | Agent display name |
| `debug` | bool | `false` | Enable debug mode |
| `version` | string | auto | Agent version |
| `data_dir` | string | `data/` | Data storage directory |
| `log_level` | string | `INFO` | Logging level |
| `config_dir` | string | `config/` | Configuration directory |
| `plugins_dir` | string | `plugins/` | Plugin directory |

## Terminal

```yaml
terminal:
  shell: /bin/bash
  emulator: xterm-256color
  scrollback: 100000
  max_processes: 500
  max_sessions: 100
  default_rows: 24
  default_cols: 80
  cursor_style: block
  bell_style: visual
  idle_timeout: 3600
  render_interval_ms: 16
  color_depth: truecolor
```

| Option | Type | Default | Description |
|---|---|---|---|
| `shell` | string | `/bin/bash` | Shell executable path |
| `emulator` | string | `xterm-256color` | Terminal emulator type |
| `scrollback` | int | `100000` | Scrollback buffer size |
| `max_processes` | int | `500` | Max concurrent processes |
| `max_sessions` | int | `100` | Max concurrent sessions |
| `default_rows` | int | `24` | Default terminal rows |
| `default_cols` | int | `80` | Default terminal columns |
| `idle_timeout` | int | `3600` | Session idle timeout (s) |

## AI

```yaml
ai:
  provider: openai
  model: gpt-4
  api_key: "${OPENAI_API_KEY}"
  temperature: 0.7
  max_tokens: 2048
  top_p: 0.95
  fallback_provider: anthropic
  timeout: 30

  providers:
    primary:
      provider: openai
      model: gpt-4
    fallback:
      provider: anthropic
      model: claude-3-opus

  routing:
    strategy: latency
    latency_window: 60

  cache:
    enabled: true
    size: 10000
    ttl: 3600
    strategy: exact

  rate_limiter:
    requests_per_minute: 60
    requests_per_hour: 1000
    concurrency: 5

  cost_tracker:
    enabled: true
    budget_daily: 10.00
    budget_monthly: 200.00
```

| Option | Type | Default | Description |
|---|---|---|---|
| `provider` | string | `openai` | Default AI provider |
| `model` | string | `gpt-4` | Default model |
| `temperature` | float | `0.7` | Generation temperature |
| `max_tokens` | int | `2048` | Max tokens per response |
| `top_p` | float | `0.95` | Nucleus sampling |
| `timeout` | int | `30` | Request timeout (s) |
| `cache.enabled` | bool | `true` | Enable response caching |

## Security

```yaml
security:
  sandbox: true
  sandbox_type: docker
  sandbox_timeout: 30
  sandbox_memory_limit: 512m
  audit: true
  audit_log: data/logs/audit/audit.log
  audit_retention_days: 90
  encryption: true
  encryption_algorithm: AES-256-GCM

  authentication:
    enabled: true
    session_timeout: 3600
    max_attempts: 5

  authorization:
    enabled: true
    default_role: viewer

  validation:
    mode: strict
```

| Option | Type | Default | Description |
|---|---|---|---|
| `sandbox` | bool | `true` | Enable sandboxing |
| `sandbox_type` | string | `docker` | Sandbox type |
| `audit` | bool | `true` | Enable audit logging |
| `encryption` | bool | `true` | Enable encryption |
| `validation.mode` | string | `strict` | Validation strictness |

## Execution

```yaml
execution:
  timeout: 30
  max_processes: 100
  max_memory_mb: 1024
  max_concurrent_tasks: 20
  working_dir: /tmp
  env_whitelist:
    - PATH
    - HOME
    - USER
  env_blacklist:
    - SECRET_KEY
    - API_KEY
  confirm_destructive: true
  prewarm_processes: false
  process_pool_size: 10
  thread_pool_size: 20
```

## Logging

```yaml
logging:
  level: INFO
  format: json
  file: data/logs/agent/agent.log
  max_size_mb: 100
  backup_count: 10
  compress: true
  components:
    supreme_terminal_agent.ai: DEBUG
    supreme_terminal_agent.security: INFO
```

## Monitoring

```yaml
monitoring:
  metrics:
    enabled: true
    export_interval: 15
    exporter: prometheus
    prometheus_port: 9090

  health:
    endpoint: /health
    interval: 30
    timeout: 5

  tracing:
    enabled: false
    provider: jaeger

  alerting:
    enabled: false
    slack_webhook: ""
    pagerduty_key: ""
```

## Network

```yaml
network:
  timeout: 30
  max_connections: 100
  bind_address: 127.0.0.1
  tls_verify: true
  rest_port: 8080
  grpc_port: 50051
  ws_port: 8766
  ssh_port: 22

  tls:
    enabled: false
    cert_file: ""
    key_file: ""
```

## Memory

```yaml
memory:
  storage: sqlite
  sqlite_path: data/memory/memory.db

  short_term:
    capacity: 1000
    ttl: 3600

  long_term:
    enabled: true
    max_entries: 100000

  vector:
    enabled: true
    dimension: 384
    index_type: IVF
```

## Automation

```yaml
automation:
  pipelines_dir: data/automation/pipelines/
  workflows_dir: data/automation/workflows/
  triggers_dir: data/automation/triggers/

  pipeline:
    max_steps: 50
    timeout: 3600
    stop_on_failure: true

  triggers:
    max_triggers: 100
    cooldown: 5
```

## Database

```yaml
database:
  url: sqlite:///data/database/db.sqlite
  pool_size: 10
  max_overflow: 5
  pool_timeout: 5
  pool_recycle: 1800
```

## Plugins

```yaml
plugins:
  directories:
    - data/plugins
  auto_load: true
  sandbox:
    enabled: true
    network_access: false
    max_memory_mb: 128
```

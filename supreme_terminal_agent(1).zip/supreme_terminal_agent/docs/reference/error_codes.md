# Error Codes Reference

Reference of all error codes used by the Supreme Terminal AI Agent.

## Error Code Format

Errors are returned in the format:

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable description",
    "details": {}
  }
}
```

## Core Errors

| Code | HTTP Status | Description |
|---|---|---|
| `UNKNOWN_ERROR` | 500 | An unexpected error occurred |
| `NOT_IMPLEMENTED` | 501 | Feature not yet implemented |
| `INVALID_CONFIGURATION` | 500 | Invalid configuration detected |
| `INITIALIZATION_FAILED` | 500 | Agent initialization failed |
| `SHUTDOWN_ERROR` | 500 | Error during shutdown |
| `INTERNAL_ERROR` | 500 | Internal system error |

## AI Engine Errors

| Code | HTTP Status | Description |
|---|---|---|
| `AI_ENGINE_NOT_ACTIVE` | 503 | AI engine is not running |
| `AI_PROVIDER_ERROR` | 502 | AI provider returned an error |
| `AI_RATE_LIMIT_EXCEEDED` | 429 | Rate limit exceeded for AI requests |
| `AI_MODEL_NOT_FOUND` | 404 | Specified model not found |
| `AI_AUTHENTICATION_FAILED` | 401 | AI provider authentication failed |
| `AI_TIMEOUT` | 504 | AI provider request timed out |
| `AI_INVALID_RESPONSE` | 502 | Invalid response from AI provider |
| `AI_CONTEXT_LENGTH_EXCEEDED` | 400 | Context length exceeds model limit |
| `AI_CONTENT_FILTERED` | 400 | Response filtered by content policy |
| `AI_CACHE_MISS` | 404 | Cache miss |
| `AI_FALLBACK_EXHAUSTED` | 502 | All fallback providers exhausted |
| `AI_QUOTA_EXCEEDED` | 429 | API quota exceeded |
| `AI_INVALID_PROMPT` | 400 | Invalid prompt format |

## Terminal Errors

| Code | HTTP Status | Description |
|---|---|---|
| `TERMINAL_INIT_FAILED` | 500 | Terminal initialization failed |
| `TERMINAL_NOT_INITIALIZED` | 400 | Terminal not yet initialized |
| `TERMINAL_ALREADY_INITIALIZED` | 400 | Terminal already initialized |
| `TERMINAL_CLOSED` | 400 | Terminal is closed |
| `TERMINAL_PTY_ERROR` | 500 | PTY allocation failed |
| `TERMINAL_FORK_FAILED` | 500 | Process fork failed |
| `TERMINAL_RESIZE_FAILED` | 500 | Terminal resize failed |
| `TERMINAL_WRITE_ERROR` | 500 | Terminal write failed |
| `TERMINAL_READ_ERROR` | 500 | Terminal read failed |
| `TERMINAL_SESSION_NOT_FOUND` | 404 | Session not found |
| `TERMINAL_SESSION_LIMIT` | 429 | Max sessions reached |
| `TERMINAL_SHELL_NOT_FOUND` | 404 | Shell executable not found |
| `TERMINAL_INVALID_STATE` | 400 | Invalid terminal state transition |

## Command Errors

| Code | HTTP Status | Description |
|---|---|---|
| `COMMAND_EMPTY` | 400 | Empty command |
| `COMMAND_NOT_FOUND` | 404 | Command not found |
| `COMMAND_INVALID` | 400 | Invalid command syntax |
| `COMMAND_TIMEOUT` | 504 | Command execution timed out |
| `COMMAND_FAILED` | 500 | Command execution failed |
| `COMMAND_FORBIDDEN` | 403 | Command blocked by security policy |
| `COMMAND_SANDBOX_ERROR` | 500 | Sandbox execution error |
| `COMMAND_INVALID_ARGUMENTS` | 400 | Invalid command arguments |
| `COMMAND_HANDLER_ERROR` | 500 | Custom handler execution error |
| `COMMAND_PERMISSION_DENIED` | 403 | Permission denied for command |

## Security Errors

| Code | HTTP Status | Description |
|---|---|---|
| `SECURITY_VIOLATION` | 403 | Security policy violation |
| `SECURITY_SANDBOX_ESCAPE` | 403 | Attempted sandbox escape |
| `SECURITY_AUTHENTICATION_FAILED` | 401 | Authentication failed |
| `SECURITY_AUTHORIZATION_FAILED` | 403 | Authorization denied |
| `SECURITY_SESSION_EXPIRED` | 401 | Session has expired |
| `SECURITY_INVALID_TOKEN` | 401 | Invalid or malformed token |
| `SECURITY_MFA_REQUIRED` | 401 | Multi-factor authentication required |
| `SECURITY_MFA_FAILED` | 401 | MFA verification failed |
| `SECURITY_ENCRYPTION_FAILED` | 500 | Encryption operation failed |
| `SECURITY_DECRYPTION_FAILED` | 500 | Decryption operation failed |
| `SECURITY_SECRET_NOT_FOUND` | 404 | Secret not found |
| `SECURITY_INVALID_CERTIFICATE` | 400 | Invalid TLS certificate |
| `SECURITY_RATE_LIMITED` | 429 | Rate limited for security reasons |

## Network Errors

| Code | HTTP Status | Description |
|---|---|---|
| `NETWORK_CONNECTION_FAILED` | 502 | Network connection failed |
| `NETWORK_TIMEOUT` | 504 | Network request timed out |
| `NETWORK_DNS_FAILED` | 502 | DNS resolution failed |
| `NETWORK_SSL_ERROR` | 502 | SSL/TLS error |
| `NETWORK_PROXY_ERROR` | 502 | Proxy connection failed |
| `NETWORK_SSH_FAILED` | 502 | SSH connection failed |
| `NETWORK_SSH_AUTH_FAILED` | 401 | SSH authentication failed |
| `NETWORK_HTTP_ERROR` | 502 | HTTP request failed |
| `NETWORK_WS_DISCONNECTED` | 500 | WebSocket disconnected |
| `NETWORK_CONNECTION_REFUSED` | 502 | Connection refused |
| `NETWORK_HOST_UNREACHABLE` | 502 | Host unreachable |

## Filesystem Errors

| Code | HTTP Status | Description |
|---|---|---|
| `FS_FILE_NOT_FOUND` | 404 | File not found |
| `FS_DIR_NOT_FOUND` | 404 | Directory not found |
| `FS_PERMISSION_DENIED` | 403 | Permission denied |
| `FS_READ_ERROR` | 500 | File read error |
| `FS_WRITE_ERROR` | 500 | File write error |
| `FS_DELETE_ERROR` | 500 | File delete error |
| `FS_DISK_FULL` | 507 | Disk full |
| `FS_PATH_TRAVERSAL` | 403 | Path traversal detected |
| `FS_FILE_TOO_LARGE` | 413 | File exceeds size limit |
| `FS_ALREADY_EXISTS` | 409 | File or directory already exists |
| `FS_NOT_EMPTY` | 409 | Directory not empty |
| `FS_INVALID_PATH` | 400 | Invalid path |

## Plugin Errors

| Code | HTTP Status | Description |
|---|---|---|
| `PLUGIN_NOT_FOUND` | 404 | Plugin not found |
| `PLUGIN_LOAD_FAILED` | 500 | Plugin loading failed |
| `PLUGIN_ENABLE_FAILED` | 500 | Plugin enabling failed |
| `PLUGIN_DISABLE_FAILED` | 500 | Plugin disabling failed |
| `PLUGIN_INSTALL_FAILED` | 500 | Plugin installation failed |
| `PLUGIN_UNINSTALL_FAILED` | 500 | Plugin uninstallation failed |
| `PLUGIN_UPDATE_FAILED` | 500 | Plugin update failed |
| `PLUGIN_INCOMPATIBLE` | 400 | Plugin version incompatible |
| `PLUGIN_DEPENDENCY_MISSING` | 400 | Plugin dependency missing |
| `PLUGIN_DEPENDENCY_CONFLICT` | 400 | Plugin dependency conflict |
| `PLUGIN_SANDBOX_VIOLATION` | 403 | Plugin sandbox violation |
| `PLUGIN_INVALID_MANIFEST` | 400 | Invalid plugin manifest |

## Tool Errors

| Code | HTTP Status | Description |
|---|---|---|
| `TOOL_NOT_FOUND` | 404 | Tool not found |
| `TOOL_EXECUTION_FAILED` | 500 | Tool execution failed |
| `TOOL_INVALID_PARAMETERS` | 400 | Invalid tool parameters |
| `TOOL_TIMEOUT` | 504 | Tool execution timed out |
| `TOOL_VALIDATION_FAILED` | 400 | Tool parameter validation failed |
| `TOOL_ALREADY_REGISTERED` | 409 | Tool already registered |

## Execution Errors

| Code | HTTP Status | Description |
|---|---|---|
| `EXECUTION_FAILED` | 500 | Execution failed |
| `EXECUTION_TIMEOUT` | 504 | Execution timed out |
| `EXECUTION_CANCELLED` | 499 | Execution cancelled |
| `EXECUTION_RESOURCE_EXHAUSTED` | 507 | System resources exhausted |
| `EXECUTION_MAX_PROCESSES` | 429 | Max concurrent processes reached |
| `EXECUTION_INVALID_STATE` | 400 | Invalid execution state |

## Database Errors

| Code | HTTP Status | Description |
|---|---|---|
| `DB_CONNECTION_FAILED` | 500 | Database connection failed |
| `DB_QUERY_FAILED` | 500 | Database query failed |
| `DB_MIGRATION_FAILED` | 500 | Migration failed |
| `DB_CONNECTION_POOL_EXHAUSTED` | 503 | Connection pool exhausted |
| `DB_INTEGRITY_ERROR` | 500 | Database integrity error |
| `DB_TIMEOUT` | 504 | Database query timed out |

## Memory Errors

| Code | HTTP Status | Description |
|---|---|---|
| `MEMORY_STORE_FAILED` | 500 | Memory store operation failed |
| `MEMORY_RECALL_FAILED` | 500 | Memory recall failed |
| `MEMORY_SEARCH_FAILED` | 500 | Memory search failed |
| `MEMORY_VECTOR_INDEX_FAILED` | 500 | Vector index operation failed |
| `MEMORY_STORAGE_FULL` | 507 | Memory storage full |

## Automation Errors

| Code | HTTP Status | Description |
|---|---|---|
| `PIPELINE_NOT_FOUND` | 404 | Pipeline not found |
| `PIPELINE_EXECUTION_FAILED` | 500 | Pipeline execution failed |
| `PIPELINE_STEP_FAILED` | 500 | Pipeline step failed |
| `TRIGGER_NOT_FOUND` | 404 | Trigger not found |
| `TRIGGER_EXECUTION_FAILED` | 500 | Trigger execution failed |
| `WORKFLOW_INVALID` | 400 | Invalid workflow file |
| `WORKFLOW_EXECUTION_FAILED` | 500 | Workflow execution failed |
| `SCHEDULE_INVALID` | 400 | Invalid schedule expression |

## Event Errors

| Code | HTTP Status | Description |
|---|---|---|
| `EVENT_BUS_FULL` | 507 | Event bus queue full |
| `EVENT_HANDLER_FAILED` | 500 | Event handler execution failed |
| `EVENT_INVALID_TYPE` | 400 | Invalid event type |
| `EVENT_SOURCING_FAILED` | 500 | Event sourcing failed |

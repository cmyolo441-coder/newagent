# Escape Sequences Reference

Reference of supported terminal escape sequences and control codes in the Supreme Terminal AI Agent.

## Control Characters

| Code | Name | Description |
|---|---|---|
| `^@` (0x00) | NUL | Null |
| `^A` (0x01) | SOH | Start of heading |
| `^B` (0x02) | STX | Start of text |
| `^C` (0x03) | ETX | Break / SIGINT |
| `^D` (0x04) | EOT | End of transmission |
| `^E` (0x05) | ENQ | Enquiry |
| `^F` (0x06) | ACK | Acknowledge |
| `^G` (0x07) | BEL | Bell |
| `^H` (0x08) | BS | Backspace |
| `^I` (0x09) | HT | Horizontal tab |
| `^J` (0x0A) | LF | Line feed |
| `^K` (0x0B) | VT | Vertical tab |
| `^L` (0x0C) | FF | Form feed |
| `^M` (0x0D) | CR | Carriage return |
| `^N` (0x0E) | SO | Shift out |
| `^O` (0x0F) | SI | Shift in |
| `^Q` (0x11) | XON | Resume transmission |
| `^R` (0x12) | DC2 | Device control 2 |
| `^S` (0x13) | XOFF | Pause transmission |
| `^U` (0x15) | NAK | Negative acknowledge |
| `^V` (0x16) | SYN | Synchronous idle |
| `^W` (0x17) | ETB | End transmission block |
| `^X` (0x18) | CAN | Cancel |
| `^Y` (0x19) | EM | End of medium |
| `^Z` (0x1A) | SUB | Substitute / Suspend |
| `^[` (0x1B) | ESC | Escape |
| `^\` (0x1C) | FS | File separator |
| `^]` (0x1D) | GS | Group separator |
| `^^` (0x1E) | RS | Record separator |
| `^_` (0x1F) | US | Unit separator |
| `^?` (0x7F) | DEL | Delete |

## CSI Sequences (Control Sequence Introducer)

CSI sequences start with `ESC [` (0x1B 0x5B).

### Cursor Control

| Sequence | Description |
|---|---|
| `CSI A` | Cursor up |
| `CSI B` | Cursor down |
| `CSI C` | Cursor forward |
| `CSI D` | Cursor back |
| `CSI E` | Cursor next line |
| `CSI F` | Cursor previous line |
| `CSI G` | Cursor horizontal absolute |
| `CSI H` | Cursor position |
| `CSI J` | Erase display |
| `CSI K` | Erase line |
| `CSI L` | Insert lines |
| `CSI M` | Delete lines |
| `CSI P` | Delete characters |
| `CSI S` | Scroll up |
| `CSI T` | Scroll down |
| `CSI X` | Erase characters |
| `CSI a` | Cursor forward tabulation |
| `CSI c` | Send device attributes |
| `CSI d` | Vertical position absolute |
| `CSI e` | Vertical position relative |
| `CSI f` | Horizontal and vertical position |
| `CSI g` | Tab clear |
| `CSI h` | Set mode |
| `CSI l` | Reset mode |
| `CSI m` | Character attributes (SGR) |
| `CSI n` | Device status report |
| `CSI p` | Reset |
| `CSI r` | Set scroll region |
| `CSI s` | Save cursor position |
| `CSI u` | Restore cursor position |

### Cursor Position Parameters

```
CSI <row> ; <col> H    # Move cursor to row, col (1-indexed)
CSI <n> A              # Move cursor up n rows
CSI <n> B              # Move cursor down n rows
CSI <n> C              # Move cursor forward n columns
CSI <n> D              # Move cursor back n columns
```

### Erase Parameters

```
CSI 0 J    # Erase from cursor to end of screen
CSI 1 J    # Erase from start to cursor
CSI 2 J    # Erase entire screen
CSI 3 J    # Erase entire screen and scrollback

CSI 0 K    # Erase from cursor to end of line
CSI 1 K    # Erase from start of line to cursor
CSI 2 K    # Erase entire line
```

## SGR (Select Graphic Rendition) Parameters

### Text Attributes

| Code | Attribute |
|---|---|
| 0 | Reset / Normal |
| 1 | Bold / Bright |
| 2 | Dim |
| 3 | Italic |
| 4 | Underline single |
| 5 | Slow blink |
| 6 | Rapid blink |
| 7 | Reverse video |
| 8 | Conceal |
| 9 | Crossed-out |
| 21 | Underline double |
| 22 | Normal intensity |
| 23 | Not italic |
| 24 | Not underlined |
| 25 | Not blinking |
| 27 | Not reversed |
| 28 | Reveal |
| 29 | Not crossed-out |

### Foreground Colors

| Code | Color | Code | Bright Color |
|---|---|---|---|
| 30 | Black | 90 | Bright Black |
| 31 | Red | 91 | Bright Red |
| 32 | Green | 92 | Bright Green |
| 33 | Yellow | 93 | Bright Yellow |
| 34 | Blue | 94 | Bright Blue |
| 35 | Magenta | 95 | Bright Magenta |
| 36 | Cyan | 96 | Bright Cyan |
| 37 | White | 97 | Bright White |
| 38 | Extended color | | |
| 39 | Default | | |

### Background Colors

| Code | Color | Code | Bright Color |
|---|---|---|---|
| 40 | Black | 100 | Bright Black |
| 41 | Red | 101 | Bright Red |
| 42 | Green | 102 | Bright Green |
| 43 | Yellow | 103 | Bright Yellow |
| 44 | Blue | 104 | Bright Blue |
| 45 | Magenta | 105 | Bright Magenta |
| 46 | Cyan | 106 | Bright Cyan |
| 47 | White | 107 | Bright White |
| 48 | Extended color | | |
| 49 | Default | | |

### Extended Colors (38/48)

```
38;5;<n>    # 256-color foreground (n = 0-255)
48;5;<n>    # 256-color background (n = 0-255)
38;2;<r>;<g>;<b>  # Truecolor foreground
48;2;<r>;<g>;<b>  # Truecolor background
```

## OSC Sequences (Operating System Command)

OSC sequences start with `ESC ]` (0x1B 0x5D).

| Sequence | Description |
|---|---|
| `OSC 0 ; title BEL` | Set window title |
| `OSC 1 ; title BEL` | Set icon name |
| `OSC 2 ; title BEL` | Set window title |
| `OSC 8 ; params ; url BEL` | Hyperlink |
| `OSC 10 ; color BEL` | Set foreground color |
| `OSC 11 ; color BEL` | Set background color |
| `OSC 52 ; clipboard BEL` | Clipboard access |

## DEC Private Modes

| Mode | Description |
|---|---|
| `?1` | Application cursor keys |
| `?3` | 132-column mode |
| `?5` | Reverse video |
| `?6` | Origin mode |
| `?7` | Auto-wrap mode |
| `?8` | Auto-repeat mode |
| `?12` | Start blinking cursor |
| `?25` | Show cursor |
| `?40` | Allow 80-132 mode |
| `?47` | Alternate screen buffer |
| `?1000` | Mouse tracking (X10) |
| `?1002` | Mouse tracking (button events) |
| `?1003` | Mouse tracking (any event) |
| `?1004` | Focus in/out events |
| `?1005` | UTF-8 mouse mode |
| `?1006` | SGR mouse mode |
| `?1015` | URXVT mouse mode |
| `?1047` | Alternate screen buffer |
| `?1048` | Save/restore cursor |
| `?1049` | Alt screen buffer with save |
| `?2004` | Bracketed paste mode |

## Supported Terminal Types

- `xterm`
- `xterm-256color`
- `xterm-new`
- `vt100`
- `vt220`
- `linux`
- `screen`
- `screen-256color`
- `tmux`
- `rxvt`
- `rxvt-unicode`

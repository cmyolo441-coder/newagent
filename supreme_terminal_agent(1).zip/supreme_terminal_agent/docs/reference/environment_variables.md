# Environment Variables Reference

Complete reference of all environment variables used by the Supreme Terminal AI Agent.

## General

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_CONFIG` | Platform-specific | Configuration file path |
| `SUPREME_TERMINAL_DATA_DIR` | `data/` | Data directory |
| `SUPREME_TERMINAL_DEBUG` | `false` | Enable debug mode |
| `SUPREME_TERMINAL_LOG_LEVEL` | `INFO` | Logging level |
| `SUPREME_TERMINAL_LOG_FILE` | `agent.log` | Log file path |
| `SUPREME_TERMINAL_CONFIG_DIR` | `config/` | Configuration directory |
| `SUPREME_TERMINAL_PLUGINS_DIR` | `plugins/` | Plugin directory |
| `SUPREME_TERMINAL_NO_ENV` | `false` | Ignore env variables |

## AI Provider

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_AI_PROVIDER` | `openai` | AI provider name |
| `SUPREME_TERMINAL_AI_MODEL` | `gpt-4` | AI model name |
| `SUPREME_TERMINAL_AI_API_KEY` | `` | API key for primary provider |
| `SUPREME_TERMINAL_AI_TEMPERATURE` | `0.7` | Generation temperature |
| `SUPREME_TERMINAL_AI_MAX_TOKENS` | `2048` | Max tokens per response |
| `SUPREME_TERMINAL_AI_TOP_P` | `0.95` | Top-p sampling |
| `SUPREME_TERMINAL_AI_TIMEOUT` | `30` | Request timeout (s) |
| `SUPREME_TERMINAL_AI_FALLBACK_PROVIDER` | `anthropic` | Fallback provider |
| `SUPREME_TERMINAL_AI_CACHE_ENABLED` | `true` | Enable caching |
| `SUPREME_TERMINAL_AI_CACHE_SIZE` | `10000` | Cache size |
| `SUPREME_TERMINAL_AI_CACHE_TTL` | `3600` | Cache TTL (s) |
| `SUPREME_TERMINAL_AI_RATE_LIMIT` | `60` | Requests per minute |

### Provider-Specific

#### OpenAI
| Variable | Default | Description |
|---|---|---|
| `OPENAI_API_KEY` | `` | OpenAI API key |
| `OPENAI_ORG_ID` | `` | OpenAI organization ID |
| `OPENAI_BASE_URL` | `https://api.openai.com` | API base URL |

#### Anthropic
| Variable | Default | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | `` | Anthropic API key |
| `ANTHROPIC_BASE_URL` | `https://api.anthropic.com` | API base URL |

#### Google Gemini
| Variable | Default | Description |
|---|---|---|
| `GOOGLE_API_KEY` | `` | Google AI API key |
| `GOOGLE_MODEL` | `gemini-pro` | Model name |

#### Ollama (Local)
| Variable | Default | Description |
|---|---|---|
| `OLLAMA_HOST` | `http://localhost:11434` | Ollama server URL |
| `OLLAMA_MODEL` | `llama3` | Model name |

## Security

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_SECURITY_SANDBOX` | `true` | Enable sandboxing |
| `SUPREME_TERMINAL_SECURITY_SANDBOX_TYPE` | `docker` | Sandbox type |
| `SUPREME_TERMINAL_SECURITY_AUDIT` | `true` | Enable audit logging |
| `SUPREME_TERMINAL_SECURITY_ENCRYPTION` | `true` | Enable encryption |
| `SUPREME_TERMINAL_SECURITY_ENCRYPTION_KEY` | `` | Encryption key |
| `SUPREME_TERMINAL_SECURITY_AUDIT_LOG` | `audit.log` | Audit log path |
| `SUPREME_TERMINAL_SECURITY_AUTH_ENABLED` | `true` | Enable authentication |
| `SUPREME_TERMINAL_SECURITY_SESSION_TIMEOUT` | `3600` | Session timeout (s) |
| `SUPREME_TERMINAL_SECURITY_MAX_LOGIN_ATTEMPTS` | `5` | Max login attempts |
| `SUPREME_TERMINAL_SECURITY_VALIDATION_MODE` | `strict` | Validation mode |

## Execution

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_EXECUTION_TIMEOUT` | `30` | Command timeout (s) |
| `SUPREME_TERMINAL_EXECUTION_MAX_PROCESSES` | `100` | Max concurrent processes |
| `SUPREME_TERMINAL_EXECUTION_MAX_MEMORY_MB` | `1024` | Max memory per process |
| `SUPREME_TERMINAL_EXECUTION_WORKING_DIR` | `/tmp` | Working directory |
| `SUPREME_TERMINAL_EXECUTION_CONFIRM_DESTRUCTIVE` | `true` | Confirm dangerous commands |

## Terminal

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_TERMINAL_SHELL` | `/bin/bash` | Shell path |
| `SUPREME_TERMINAL_TERMINAL_EMULATOR` | `xterm-256color` | Terminal emulator |
| `SUPREME_TERMINAL_TERMINAL_SCROLLBACK` | `100000` | Scrollback buffer |
| `SUPREME_TERMINAL_TERMINAL_MAX_SESSIONS` | `100` | Max sessions |
| `SUPREME_TERMINAL_TERMINAL_ROWS` | `24` | Default rows |
| `SUPREME_TERMINAL_TERMINAL_COLS` | `80` | Default columns |
| `SUPREME_TERMINAL_TERMINAL_IDLE_TIMEOUT` | `3600` | Idle timeout (s) |

## Network

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_NETWORK_TIMEOUT` | `30` | Network timeout (s) |
| `SUPREME_TERMINAL_NETWORK_MAX_CONNECTIONS` | `100` | Max connections |
| `SUPREME_TERMINAL_NETWORK_BIND_ADDRESS` | `127.0.0.1` | Bind address |
| `SUPREME_TERMINAL_NETWORK_REST_PORT` | `8080` | REST API port |
| `SUPREME_TERMINAL_NETWORK_GRPC_PORT` | `50051` | gRPC port |
| `SUPREME_TERMINAL_NETWORK_WS_PORT` | `8766` | WebSocket port |
| `SUPREME_TERMINAL_NETWORK_SSH_PORT` | `22` | SSH port |
| `SUPREME_TERMINAL_NETWORK_TLS_ENABLED` | `false` | Enable TLS |
| `SUPREME_TERMINAL_NETWORK_TLS_CERT` | `` | TLS cert path |
| `SUPREME_TERMINAL_NETWORK_TLS_KEY` | `` | TLS key path |

## Database

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_DATABASE_URL` | `sqlite:///data/db.sqlite` | Database URL |
| `SUPREME_TERMINAL_DATABASE_POOL_SIZE` | `10` | Connection pool size |
| `SUPREME_TERMINAL_DATABASE_PASSWORD` | `` | Database password |

## Monitoring

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_MONITORING_METRICS_ENABLED` | `true` | Enable metrics |
| `SUPREME_TERMINAL_MONITORING_METRICS_EXPORTER` | `prometheus` | Metrics exporter |
| `SUPREME_TERMINAL_MONITORING_METRICS_PORT` | `9090` | Metrics port |
| `SUPREME_TERMINAL_MONITORING_TRACING_ENABLED` | `false` | Enable tracing |
| `SUPREME_TERMINAL_MONITORING_ALERTING_SLACK_WEBHOOK` | `` | Slack webhook URL |

## Memory

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_MEMORY_STORAGE` | `sqlite` | Memory storage backend |
| `SUPREME_TERMINAL_MEMORY_SQLITE_PATH` | `data/memory/memory.db` | SQLite path |
| `SUPREME_TERMINAL_MEMORY_VECTOR_ENABLED` | `true` | Enable vector memory |
| `SUPREME_TERMINAL_MEMORY_VECTOR_DIMENSION` | `384` | Vector dimension |

## Automation

| Variable | Default | Description |
|---|---|---|
| `SUPREME_TERMINAL_AUTOMATION_PIPELINES_DIR` | `data/automation/pipelines/` | Pipelines directory |
| `SUPREME_TERMINAL_AUTOMATION_WORKFLOWS_DIR` | `data/automation/workflows/` | Workflows directory |
| `SUPREME_TERMINAL_AUTOMATION_TRIGGERS_DIR` | `data/automation/triggers/` | Triggers directory |

## Notes

- All environment variables use the prefix `SUPREME_TERMINAL_`
- Nested config keys use underscore separation (e.g., `ai.provider` -> `SUPREME_TERMINAL_AI_PROVIDER`)
- Variables are automatically expanded in config files using `${VARIABLE}` syntax
- Boolean values accept: `true`, `false`, `1`, `0`, `yes`, `no`

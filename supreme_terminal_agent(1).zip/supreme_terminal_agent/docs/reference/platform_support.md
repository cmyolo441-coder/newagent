# Platform Support Reference

Supported platforms, architectures, and operating systems for the Supreme Terminal AI Agent.

## Operating Systems

| OS | Support | Notes |
|---|---|---|
| Linux (x86_64) | Full | Primary platform |
| Linux (aarch64) | Full | Raspberry Pi, AWS Graviton |
| Linux (armv7) | Partial | Limited testing |
| macOS (x86_64) | Full | Intel Macs |
| macOS (arm64) | Full | Apple Silicon (M1/M2/M3) |
| Windows (WSL2) | Full | Ubuntu on WSL2 |
| Windows (Native) | Partial | No PTY support |
| FreeBSD | Basic | Command execution only |

## Linux Distributions

| Distribution | Support | Notes |
|---|---|---|
| Ubuntu 22.04+ | Full | Recommended |
| Ubuntu 20.04 | Full | |
| Debian 11+ | Full | |
| Debian 10 | Supported | |
| RHEL 8+ | Full | |
| RHEL 7 | Supported | Python 3.11 from SCL |
| Fedora 37+ | Full | |
| CentOS Stream 9 | Full | |
| Rocky Linux 9 | Full | |
| AlmaLinux 9 | Full | |
| Arch Linux | Full | Rolling release |
| openSUSE Leap 15+ | Full | |
| Alpine Linux 3.18+ | Full | Docker images |
| NixOS | Supported | Community maintained |

## Python Versions

| Version | Support |
|---|---|
| 3.11 | Full |
| 3.12 | Full |
| 3.13 | Beta |

## Architectures

| Architecture | Support |
|---|---|
| x86_64 / amd64 | Full |
| aarch64 / arm64 | Full |
| armv7l (32-bit ARM) | Partial |
| i686 (32-bit x86) | Basic |
| riscv64 | Experimental |
| s390x | IBM Z |

## Container Platforms

| Platform | Support |
|---|---|
| Docker | Full |
| Podman | Full |
| containerd | Full |
| LXC/LXD | Supported |

## Orchestration

| Platform | Support |
|---|---|
| Kubernetes | Full |
| Docker Swarm | Full |
| Nomad | Supported |

## Cloud Platforms

| Platform | Support |
|---|---|
| AWS EC2 | Full |
| AWS EKS | Full |
| AWS ECS | Full |
| Google Compute Engine | Full |
| Google Kubernetes Engine | Full |
| Azure VMs | Full |
| Azure Kubernetes Service | Full |
| DigitalOcean | Full |
| Linode | Full |
| Vultr | Full |
| Hetzner | Full |
| Oracle Cloud | Full |

## AI Provider Support

| Provider | Support | Models |
|---|---|---|
| OpenAI | Full | GPT-4, GPT-3.5 |
| Anthropic | Full | Claude 3 Opus, Sonnet, Haiku |
| Google Gemini | Full | Gemini Pro, Ultra |
| Ollama | Full | Llama 3, Mistral, Codellama, etc. |
| vLLM | Full | Any HuggingFace model |
| Azure OpenAI | Full | GPT-4 via Azure |
| AWS Bedrock | Full | Claude, Llama via AWS |
| GCP Vertex AI | Full | Gemini via GCP |
| LocalAI | Supported | OpenAI-compatible API |
| llama.cpp | Supported | Local GGUF models |
| HuggingFace TGI | Supported | HF inference endpoints |

## Database Support

| Database | Support |
|---|---|
| SQLite | Full (default) |
| PostgreSQL 14+ | Full |
| MySQL 8+ | Full |
| MariaDB 10+ | Full |
| Redis 6+ | Full (caching) |
| MongoDB 6+ | Supported |
| CockroachDB | Supported |

## Browser Support (Web UI)

| Browser | Support |
|---|---|
| Chrome 100+ | Full |
| Firefox 100+ | Full |
| Safari 15+ | Full |
| Edge 100+ | Full |

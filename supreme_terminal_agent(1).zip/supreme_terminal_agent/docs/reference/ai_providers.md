# AI Providers Reference

Reference of supported AI providers, models, and configuration options.

## Provider Overview

| Provider | Type | Models | Cost | Speed |
|---|---|---|---|---|
| OpenAI | Cloud | GPT-4, GPT-4 Turbo, GPT-3.5 | $$ | Fast |
| Anthropic | Cloud | Claude 3 Opus, Sonnet, Haiku | $$$ | Medium |
| Google Gemini | Cloud | Gemini Pro, Gemini Ultra | $$ | Fast |
| Ollama | Local | Llama 3, Mistral, Codellama, etc. | Free | Variable |
| vLLM | Local/Self-hosted | Any HuggingFace model | Variable | Fast |
| Azure OpenAI | Cloud | GPT-4 via Azure | $$ | Fast |
| AWS Bedrock | Cloud | Claude, Llama, Titan | $$ | Medium |
| GCP Vertex AI | Cloud | Gemini, Claude | $$ | Medium |

## OpenAI

### Configuration

```yaml
ai:
  provider: openai
  model: gpt-4
  api_key: "${OPENAI_API_KEY}"
```

### Available Models

| Model | Max Tokens | Description |
|---|---|---|
| `gpt-4` | 8192 | Base GPT-4 |
| `gpt-4-turbo` | 128000 | GPT-4 Turbo |
| `gpt-4-32k` | 32768 | Extended context |
| `gpt-4-vision` | 128000 | Vision-capable |
| `gpt-3.5-turbo` | 16384 | Fast, cost-effective |
| `gpt-3.5-turbo-16k` | 16384 | Extended 3.5 |

### Options

```yaml
ai:
  providers:
    openai:
      api_key: "${OPENAI_API_KEY}"
      organization: "${OPENAI_ORG_ID}"
      base_url: https://api.openai.com
      timeout: 30
      max_retries: 3
```

## Anthropic

### Configuration

```yaml
ai:
  provider: anthropic
  model: claude-3-opus-20240229
  api_key: "${ANTHROPIC_API_KEY}"
```

### Available Models

| Model | Max Tokens | Description |
|---|---|---|
| `claude-3-opus-20240229` | 200000 | Most powerful |
| `claude-3-sonnet-20240229` | 200000 | Balanced |
| `claude-3-haiku-20240307` | 200000 | Fast, cost-effective |

### Options

```yaml
ai:
  providers:
    anthropic:
      api_key: "${ANTHROPIC_API_KEY}"
      base_url: https://api.anthropic.com
      timeout: 60
```

## Google Gemini

### Configuration

```yaml
ai:
  provider: gemini
  model: gemini-pro
  api_key: "${GOOGLE_API_KEY}"
```

### Available Models

| Model | Max Tokens | Description |
|---|---|---|
| `gemini-pro` | 32768 | Text and code |
| `gemini-pro-vision` | 16384 | Vision-capable |
| `gemini-ultra` | 32768 | Most capable |

## Ollama (Local)

### Configuration

```yaml
ai:
  provider: ollama
  model: llama3
  base_url: http://localhost:11434
```

### Available Models (Partial)

| Model | Size | Description |
|---|---|---|
| `llama3` | 8B | Meta Llama 3 |
| `llama3:70b` | 70B | Llama 3 large |
| `mistral` | 7B | Mistral AI |
| `mixtral` | 8x7B | Mixtral MoE |
| `codellama` | 7B/34B | Code-specialized |
| `phi3` | 3.8B/14B | Phi-3 Mini |
| `neural-chat` | 7B | Intel Neural Chat |
| `starling-lm` | 7B | RLHF tuned |
| `llama2-uncensored` | 7B | Unfiltered |
| `orca-mini` | 3B/7B | Orca fine-tuned |

### Options

```yaml
ai:
  providers:
    ollama:
      base_url: http://localhost:11434
      options:
        num_ctx: 4096
        num_gpu: 1
        num_thread: 8
        f16_kv: true
        use_mlock: true
        temperature: 0.7
        top_p: 0.9
        top_k: 40
```

## vLLM (Self-Hosted)

### Configuration

```yaml
ai:
  provider: vllm
  model: mistralai/Mistral-7B-Instruct-v0.2
  base_url: http://localhost:8000
```

## Azure OpenAI

### Configuration

```yaml
ai:
  provider: azure
  model: gpt-4
  api_key: "${AZURE_OPENAI_KEY}"
  azure_endpoint: https://your-resource.openai.azure.com
  azure_deployment: gpt-4-deployment
  api_version: 2024-02-01
```

## AWS Bedrock

### Configuration

```yaml
ai:
  provider: bedrock
  model: anthropic.claude-3-sonnet-20240229-v1:0
  aws_region: us-east-1
  aws_access_key: "${AWS_ACCESS_KEY}"
  aws_secret_key: "${AWS_SECRET_KEY}"
```

## Provider Routing

Configure routing between providers:

```yaml
ai:
  routing:
    strategy: latency  # latency, cost, random, round_robin, failover
    latency_window: 60
    cost_optimize: true

  providers:
    primary:
      provider: openai
      model: gpt-4
      weight: 3
    fallback:
      provider: anthropic
      model: claude-3-sonnet
      weight: 2
    local:
      provider: ollama
      model: mixtral
      weight: 1
```

## Cost Tracking

| Provider | Input (per 1K tokens) | Output (per 1K tokens) |
|---|---|---|
| GPT-4 | $0.03 | $0.06 |
| GPT-4 Turbo | $0.01 | $0.03 |
| GPT-3.5 Turbo | $0.001 | $0.002 |
| Claude 3 Opus | $0.015 | $0.075 |
| Claude 3 Sonnet | $0.003 | $0.015 |
| Gemini Pro | $0.0005 | $0.0015 |
| Ollama (Local) | Free | Free |

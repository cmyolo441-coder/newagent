# Contributing

Thank you for your interest in contributing to the Supreme Terminal AI Agent! We welcome contributions of all forms.

## Code of Conduct

This project adheres to a [Code of Conduct](code_of_conduct.md). By participating, you agree to uphold its terms.

## Ways to Contribute

### Reporting Bugs

1. Check the [issue tracker](https://github.com/supreme-ai/supreme-terminal-agent/issues) for existing reports
2. Use the bug report template
3. Include:
   - Agent version (`terminal-agent --version`)
   - Operating system and Python version
   - Configuration (redact sensitive values)
   - Full error messages and logs
   - Steps to reproduce

### Suggesting Features

1. Check the [roadmap](roadmap.md) for planned features
2. Search existing issues for similar requests
3. Use the feature request template
4. Describe the problem and proposed solution

### Code Contributions

#### Getting Started

```bash
git clone https://github.com/supreme-ai/supreme-terminal-agent.git
cd supreme-terminal-agent
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install -e ".[dev]"
```

#### Development Workflow

1. Create a feature branch from `main`:
   ```bash
   git checkout -b feature/my-feature
   ```

2. Make your changes following code conventions:
   - Follow existing code style and patterns
   - Add type hints to all function signatures
   - Include docstrings for public APIs
   - Write tests for new functionality
   - Update documentation as needed

3. Run tests:
   ```bash
   make test
   ```

4. Run linting:
   ```bash
   make lint
   ```

5. Run type checking:
   ```bash
   mypy supreme_terminal_agent/
   ```

6. Commit your changes:
   ```bash
   git add .
   git commit -m "feat: add my new feature"
   ```

   We follow [Conventional Commits](https://www.conventionalcommits.org/):
   - `feat:` new feature
   - `fix:` bug fix
   - `docs:` documentation changes
   - `refactor:` code restructuring
   - `test:` adding or updating tests
   - `chore:` maintenance tasks

7. Push and create a pull request:
   ```bash
   git push origin feature/my-feature
   ```

#### Pull Request Guidelines

- Keep PRs focused on a single concern
- Include a clear description of changes
- Reference related issues
- Ensure all CI checks pass
- Update documentation if APIs change
- Add tests for new functionality
- Request review from maintainers

#### Code Style

- Follow PEP 8 conventions
- Use type hints for all function signatures
- Write descriptive variable names
- Keep functions focused and small
- Prefer async/await for I/O operations
- Use f-strings for string formatting

### Documentation Contributions

Documentation improvements are always welcome:

- Fix typos and clarify existing docs
- Add examples and tutorials
- Improve API documentation
- Translate documentation

### Reviewing

Help review pull requests from other contributors:

- Check for correctness and completeness
- Verify tests are adequate
- Ensure documentation is updated
- Provide constructive feedback

## Development Setup

### Running Tests

```bash
# All tests
make test

# Specific test file
pytest tests/test_agent.py

# With coverage
pytest --cov=supreme_terminal_agent tests/
```

### Running Linters

```bash
# Ruff
ruff check .

# MyPy
mypy supreme_terminal_agent/
```

### Building Documentation

```bash
# Install docs dependencies
pip install mkdocs mkdocs-material

# Build and serve
mkdocs serve
```

## Project Structure

```
supreme-terminal-agent/
├── core/                    # Core agent intelligence
├── supreme_terminal_agent/  # Main package
│   ├── ai/                 # AI engine
│   ├── terminal/           # Terminal emulation
│   ├── commands/           # Command processing
│   ├── tools/              # Tool system
│   ├── plugins/            # Plugin system
│   ├── security/           # Security subsystem
│   ├── events/             # Event system
│   └── ...                 # Other subsystems
├── tests/                  # Test suite
├── docs/                   # Documentation
└── config/                 # Default configuration
```

## Release Process

1. Version bump in `version.py` and `pyproject.toml`
2. Update `CHANGELOG.md`
3. Create release branch `release/vX.Y.Z`
4. Run full test suite
5. Build distribution packages
6. Tag release in git
7. Publish to PyPI
8. Create GitHub release with changelog

## Questions?

- Open a [discussion](https://github.com/supreme-ai/supreme-terminal-agent/discussions)
- Join our community chat
- Email: contributors@supreme-ai.com

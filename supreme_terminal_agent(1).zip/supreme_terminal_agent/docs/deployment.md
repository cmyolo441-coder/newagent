# Deployment

This guide covers deploying the Supreme Terminal AI Agent in production and various environments.

## Deployment Options

The agent supports multiple deployment methods:

- **Standalone** – Direct installation on a server
- **Docker** – Containerized deployment
- **Kubernetes** – Orchestrated container deployment
- **Systemd** – Linux service management
- **Ansible** – Infrastructure-as-code provisioning
- **Terraform** – Cloud infrastructure deployment

## Standalone Deployment

### Prerequisites

- Python 3.11+ 
- 512 MB RAM (minimum), 2 GB (recommended)
- 1 CPU core (minimum), 4 cores (recommended)
- Linux server (Ubuntu 22.04+, Debian 12+, RHEL 9+)

### Installation

```bash
# Install system dependencies
sudo apt update
sudo apt install -y python3.11 python3.11-venv build-essential

# Create dedicated user
sudo useradd -r -s /bin/false supreme-terminal

# Create directories
sudo mkdir -p /opt/supreme-terminal
sudo mkdir -p /var/log/supreme-terminal
sudo mkdir -p /var/lib/supreme-terminal
sudo mkdir -p /etc/supreme-terminal

# Install agent
cd /opt/supreme-terminal
sudo python3.11 -m venv venv
sudo venv/bin/pip install supreme-terminal-agent

# Set permissions
sudo chown -R supreme-terminal:supreme-terminal /opt/supreme-terminal
sudo chown -R supreme-terminal:supreme-terminal /var/log/supreme-terminal
sudo chown -R supreme-terminal:supreme-terminal /var/lib/supreme-terminal
```

### Configuration

Create `/etc/supreme-terminal/config.yaml`:

```yaml
agent:
  name: production-agent
  debug: false
  data_dir: /var/lib/supreme-terminal

logging:
  level: INFO
  file: /var/log/supreme-terminal/agent.log
  format: json

security:
  sandbox: true
  audit: true
  audit_log: /var/log/supreme-terminal/audit.log

execution:
  max_processes: 50
  timeout: 60
```

## Docker Deployment

### Dockerfile

A production Dockerfile is included in the repository:

```dockerfile
FROM python:3.11-slim

RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN useradd -r -s /bin/false appuser
USER appuser

CMD ["python", "main.py"]
```

### Docker Compose

```yaml
version: '3.8'
services:
  terminal-agent:
    build: .
    container_name: supreme-terminal-agent
    restart: unless-stopped
    stdin_open: true
    tty: true
    volumes:
      - ./config:/app/config:ro
      - ./data:/app/data
      - ./logs:/app/logs
    environment:
      - SUPREME_TERMINAL_AI_API_KEY=${AI_API_KEY}
      - SUPREME_TERMINAL_SECURITY_ENCRYPTION_KEY=${ENCRYPTION_KEY}
    ports:
      - "127.0.0.1:8080:8080"
    mem_limit: 2g
    cpus: '2.0'
    security_opt:
      - no-new-privileges:true
```

## Systemd Service

Create `/etc/systemd/system/supreme-terminal.service`:

```ini
[Unit]
Description=Supreme Terminal AI Agent
After=network.target

[Service]
Type=simple
User=supreme-terminal
Group=supreme-terminal
WorkingDirectory=/opt/supreme-terminal
ExecStart=/opt/supreme-terminal/venv/bin/terminal-agent --daemon --config /etc/supreme-terminal/config.yaml
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

Environment=PYTHONUNBUFFERED=1
Environment=SUPREME_TERMINAL_CONFIG=/etc/supreme-terminal/config.yaml

[Install]
WantedBy=multi-user.target
```

## Environment Variables

Set these environment variables for production:

```bash
export SUPREME_TERMINAL_AI_API_KEY="sk-..."
export SUPREME_TERMINAL_SECURITY_ENCRYPTION_KEY="..."
export SUPREME_TERMINAL_DB_PASSWORD="..."
export SUPREME_TERMINAL_LOG_LEVEL="INFO"
export SUPREME_TERMINAL_DEBUG="false"
```

## Production Checklist

- [ ] Create dedicated system user with restricted privileges
- [ ] Configure firewall to restrict access to API ports
- [ ] Enable TLS for all network communication
- [ ] Set up audit logging with log rotation
- [ ] Configure resource limits (memory, CPU, processes)
- [ ] Enable sandbox mode for command execution
- [ ] Set up monitoring and alerting
- [ ] Configure regular log rotation
- [ ] Set up backup strategy for data and configuration
- [ ] Use secrets management for sensitive values
- [ ] Configure health checks and auto-restart
- [ ] Set up reverse proxy (nginx) for API endpoints
- [ ] Enable read-only filesystem where possible
- [ ] Configure network access controls

## Health Checks

Configure health check endpoints:

```yaml
monitoring:
  health:
    endpoint: /health
    interval: 30
    timeout: 5
    checks:
      - agent_status
      - ai_engine
      - terminal_sessions
      - memory_usage
      - disk_space
```

## Backup

Back up the following directories:

- `/etc/supreme-terminal/` – Configuration
- `/var/lib/supreme-terminal/` – Data, memory, sessions
- Audit logs (store separately for compliance)

## Scaling

For high-availability deployments, see the [Scaling Guide](scaling.md). For Kubernetes-specific deployments, see the [Kubernetes Deployment Guide](guides/kubernetes_deployment.md).

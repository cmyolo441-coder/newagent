# API Reference

The Supreme Terminal AI Agent provides multiple API interfaces for programmatic access: Python API, REST API, gRPC API, and WebSocket API.

## Python API

The primary API for embedding the agent into applications.

### SupremeTerminalAgent

```python
from supreme_terminal_agent import SupremeTerminalAgent

agent = SupremeTerminalAgent()
await agent.initialize()
await agent.run()
```

#### Constructor

```python
SupremeTerminalAgent(config: Optional[Config] = None)
```

Creates a new agent instance. If no config is provided, defaults are loaded.

#### Methods

| Method | Description |
|---|---|
| `async initialize()` | Initializes brain, consciousness, and orchestrator |
| `async run()` | Starts the agent orchestrator |
| `async shutdown()` | Gracefully stops all subsystems |
| `async process(input: str)` | Processes natural language input |
| `async execute(command: str)` | Executes a direct shell command |
| `get_status()` | Returns current agent status |

### Brain API

```python
from supreme_terminal_agent.core import Brain

brain = Brain()
await brain.initialize()
plan = await brain.process("list files")
```

### AIEngine API

```python
from supreme_terminal_agent.ai import AIEngine

engine = AIEngine()
engine.start()
response = engine.generate("Hello", model_id="gpt-4")
engine.stop()
```

#### Methods

| Method | Description |
|---|---|
| `generate(prompt, model_id, ...)` | Synchronous text generation |
| `async generate_async(prompt, ...)` | Asynchronous text generation |
| `generate_stream(prompt, ...)` | Streaming text generation |
| `async generate_stream_async(prompt, ...)` | Async streaming generation |
| `process_task(task, context)` | Process a high-level task |
| `get_statistics()` | Get engine performance metrics |
| `reset()` | Reset internal state |

### TerminalController API

```python
from supreme_terminal_agent.terminal import TerminalController

term = TerminalController(rows=24, cols=80)
term.initialize(shell="/bin/bash")
term.write(b"ls -la\n")
output = term.read()
term.close()
```

### CommandEngine API

```python
from supreme_terminal_agent.commands import CommandEngine

engine = CommandEngine()
result = engine.execute("ls -la")
result = engine.execute_async("tail -f log.txt")
```

### ToolEngine API

```python
from supreme_terminal_agent.tools import ToolEngine

tools = ToolEngine()
tools.register("my_tool", MyTool())
result = await tools.execute("my_tool", arg1="value")
```

### PluginEngine API

```python
from supreme_terminal_agent.plugins import PluginEngine

plugins = PluginEngine()
plugins.load_all()
plugins.enable("my-plugin")
```

### MemoryEngine API

```python
from supreme_terminal_agent.memory import MemoryEngine

memory = MemoryEngine()
await memory.store("key", "value")
result = await memory.recall("key")
results = await memory.search("query")
```

### SecurityEngine API

```python
from supreme_terminal_agent.security import SecurityEngine

security = SecurityEngine()
security.validate_command("rm -rf /")
security.audit_log("user", "command", "result")
```

### AutomationEngine API

```python
from supreme_terminal_agent.automation import AutomationEngine

auto = AutomationEngine()
auto.create_pipeline("deploy", ["build", "test", "deploy"])
auto.run_pipeline("deploy")
```

### EventEngine API

```python
from supreme_terminal_agent.events import EventEngine

events = EventEngine()
events.subscribe("command.executed", my_handler)
events.emit("command.executed", {"command": "ls"})
```

### Database API

```python
from supreme_terminal_agent.database import DatabaseManager

db = DatabaseManager()
await db.connect()
results = await db.query("SELECT * FROM tasks")
await db.disconnect()
```

For detailed API documentation of each subsystem, see the [API subpages](api/core_api.md).

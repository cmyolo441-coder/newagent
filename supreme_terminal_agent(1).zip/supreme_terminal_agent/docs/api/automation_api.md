# Automation API

The Automation API provides workflow automation, pipelines, event triggers, task scheduling, and external integrations.

## AutomationEngine

Central automation engine that manages all automation components.

```python
from supreme_terminal_agent.automation import AutomationEngine
```

### Methods

#### `create_pipeline(name: str, steps: List[str], **kwargs) -> Pipeline`
Creates a new automation pipeline with named steps.

```python
pipeline = engine.create_pipeline("deploy", ["build", "test", "package", "deploy"])
```

#### `run_pipeline(name: str, **kwargs) -> PipelineResult`
Executes a pipeline by name.

```python
result = engine.run_pipeline("deploy", version="1.2.3")
```

#### `create_trigger(name: str, event: str, action: str, **kwargs) -> Trigger`
Creates an event-driven trigger.

```python
trigger = engine.create_trigger(
    "watch-src",
    event="file.change",
    action="run: make test",
    path="./src"
)
```

#### `list_pipelines() -> List[Pipeline]`
Lists all defined pipelines.

#### `list_triggers() -> List[Trigger]`
Lists all defined triggers.

## Pipeline System

### Pipeline

Defines a sequence of automation steps.

```python
from supreme_terminal_agent.automation.pipelines import Pipeline
```

### Methods

#### `add_step(name: str, action: str, **kwargs)`
Adds a step to the pipeline.

#### `remove_step(name: str)`
Removes a step from the pipeline.

#### `run(context: Optional[Dict] = None) -> PipelineResult`
Executes all pipeline steps in order.

#### `get_status() -> str`
Returns the pipeline status.

### Step Types

| Step | Description |
|---|---|
| `command` | Execute a shell command |
| `tool` | Execute a registered tool |
| `pipeline` | Execute a sub-pipeline |
| `function` | Execute a Python function |
| `http` | Make an HTTP request |
| `ssh` | Execute a remote command |
| `wait` | Wait for a condition |
| `condition` | Conditional branching |

### Pipeline Result

```python
@dataclass
class PipelineResult:
    success: bool
    pipeline_name: str
    steps: List[StepResult]
    duration: float
    error: Optional[str] = None
```

## Event Triggers

### Trigger

Event-driven automation trigger.

```python
from supreme_terminal_agent.automation.triggers import Trigger
```

### Methods

#### `enable()`
Enables the trigger.

#### `disable()`
Disables the trigger.

#### `get_status() -> str`
Returns the trigger status.

#### `get_event_count() -> int`
Returns the number of times the trigger has fired.

### Event Types

| Event | Description |
|---|---|
| `file.change` | File or directory change |
| `file.create` | New file created |
| `file.delete` | File deleted |
| `command.execute` | Command executed |
| `command.fail` | Command failed |
| `session.create` | Session created |
| `session.destroy` | Session destroyed |
| `timer.interval` | Interval timer |
| `timer.cron` | Cron schedule |
| `system.high_cpu` | High CPU usage |
| `system.low_memory` | Low memory |
| `custom.event` | Custom event |

## Task Scheduling

### TaskScheduler

Scheduled task execution.

```python
from supreme_terminal_agent.automation.tasks import TaskScheduler
```

### Methods

#### `schedule(name: str, expression: str, action: str)`
Schedules a task with a cron expression.

```python
scheduler.schedule("daily-cleanup", "0 3 * * *", "run: cleanup.sh")
```

#### `unschedule(name: str)`
Removes a scheduled task.

#### `list() -> List[ScheduledTask]`
Lists all scheduled tasks.

#### `pause(name: str)`
Pauses a scheduled task.

#### `resume(name: str)`
Resumes a paused task.

## Workflows

### WorkflowEngine

Executes workflow files (YAML/JSON).

```python
from supreme_terminal_agent.automation.workflows import WorkflowEngine
```

### Methods

#### `run(workflow_file: str, **kwargs) -> WorkflowResult`
Executes a workflow from a file.

#### `validate(workflow_file: str) -> bool`
Validates a workflow file.

#### `list() -> List[str]`
Lists available workflows.

### Workflow File Format

```yaml
name: deploy-app
version: "1.0"
description: Deploy application to production

variables:
  version: "1.2.3"
  environment: production

steps:
  - name: build
    type: command
    command: docker build -t app:${version} .

  - name: test
    type: pipeline
    pipeline: run-tests

  - name: deploy
    type: ssh
    host: prod-server
    command: ./deploy.sh ${version}

  - name: health-check
    type: http
    url: https://app.example.com/health
    method: GET
    timeout: 30

triggers:
  - event: timer.cron
    expression: "0 2 * * *"
    action: deploy-app

on_success:
  - notify: slack
    message: "Deployment ${version} successful"

on_failure:
  - notify: pagerduty
    severity: critical
  - rollback: true
```

## Integrations

### IntegrationManager

Manages external service integrations.

```python
from supreme_terminal_agent.automation.integrations import IntegrationManager
```

### Supported Integrations

| Integration | Description |
|---|---|
| `slack` | Slack messaging |
| `discord` | Discord webhooks |
| `pagerduty` | Incident management |
| `jira` | Issue tracking |
| `github` | GitHub Actions/API |
| `gitlab` | GitLab CI/API |
| `docker` | Docker Hub/Registry |
| `kubernetes` | Kubernetes API |
| `aws` | AWS services |
| `gcp` | GCP services |
| `azure` | Azure services |
| `webhook` | Custom webhooks |

## Scripts

### ScriptEngine

Executes automation scripts.

```python
from supreme_terminal_agent.automation.scripts import ScriptEngine
```

### Supported Languages

- Python, Shell, JavaScript, Lua

## Configuration

```yaml
automation:
  pipelines_dir: data/automation/pipelines/
  workflows_dir: data/automation/workflows/
  triggers_dir: data/automation/triggers/
  scripts_dir: data/automation/scripts/

  pipeline:
    max_steps: 50
    timeout: 3600
    parallel: false
    stop_on_failure: true

  triggers:
    max_triggers: 100
    cooldown: 5

  scheduling:
    enabled: true
    timezone: UTC

  integrations:
    slack_webhook: "${SLACK_WEBHOOK}"
    pagerduty_key: "${PAGERDUTY_KEY}"
```

# AI API

The AI API provides the multi-provider AI orchestration engine with routing, caching, rate limiting, cost tracking, and fallback support.

## AIEngine

The core AI engine that orchestrates the complete AI pipeline.

```python
from supreme_terminal_agent.ai import AIEngine
```

### Constructor

```python
AIEngine(
    config: Optional[ConfigManager] = None,
    registry: Optional[ModelRegistry] = None,
    llm_engine: Optional[LLMEngine] = None,
    controller: Optional[AIController] = None,
    coordinator: Optional[AICoordinator] = None,
    router: Optional[AIRouter] = None,
    fallback: Optional[AIFallback] = None,
    cache: Optional[AICache] = None,
    rate_limiter: Optional[AIRateLimiter] = None,
    cost_tracker: Optional[AICostTracker] = None,
)
```

### Methods

#### `start()` / `stop()`
Starts or stops the AI engine.

#### `generate(prompt, model_id, max_tokens, temperature, top_p, stop, use_cache, **kwargs) -> str`
Generates a response using the full AI pipeline with caching, rate limiting, and fallback.

```python
response = engine.generate(
    "Explain what ls -la does",
    model_id="gpt-4",
    max_tokens=500,
    temperature=0.7,
)
```

#### `async generate_async(prompt, model_id, max_tokens, temperature, **kwargs) -> str`
Asynchronous text generation.

#### `generate_stream(prompt, model_id, max_tokens, temperature, **kwargs) -> Iterator[str]`
Streaming text generation, yielding tokens one by one.

```python
for token in engine.generate_stream("Write a poem"):
    print(token, end="", flush=True)
```

#### `async generate_stream_async(prompt, **kwargs) -> AsyncIterator[str]`
Async streaming generation.

#### `process_task(task, context, **kwargs) -> Dict`
Processes a high-level task through the AI coordinator.

#### `get_statistics() -> Dict`
Returns engine performance statistics including cache stats, rate limiter state, cost data, and LLM benchmarks.

#### `reset()`
Resets all internal state including cache, rate limiter, and cost tracker.

## AIController

Controls AI generation parameters and behavior.

```python
from supreme_terminal_agent.ai import AIController
```

## AICoordinator

Coordinates multi-step AI tasks and manages context.

```python
from supreme_terminal_agent.ai import AICoordinator
```

### Methods

#### `process(task, context) -> Dict`
Processes a high-level task by breaking it into sub-tasks and coordinating their execution.

## AIRouter

Routes requests to the appropriate AI model based on strategy.

```python
from supreme_terminal_agent.ai import AIRouter
```

### Methods

#### `select_model(prompt) -> str`
Selects the best model for the given prompt based on configured routing strategy.

### Routing Strategies

| Strategy | Description |
|---|---|
| `latency` | Route to fastest provider |
| `cost` | Route to cheapest provider |
| `random` | Random distribution |
| `round_robin` | Even distribution |
| `failover` | Try primary, fall back on failure |

## AIFallback

Handles graceful degradation when primary AI providers fail.

```python
from supreme_terminal_agent.ai import AIFallback
```

### Methods

#### `generate(prompt, **kwargs) -> str`
Tries alternative providers/models when primary generation fails.

#### `reset()`
Resets fallback state.

## AICache

Caches AI responses for improved performance and reduced costs.

```python
from supreme_terminal_agent.ai import AICache
```

### Methods

#### `get(key: str) -> Optional[str]`
Returns cached response or None.

#### `set(key: str, value: str)`
Caches a response.

#### `clear()`
Clears all cached responses.

#### `get_stats() -> Dict`
Returns cache statistics (hits, misses, size).

## AIRateLimiter

Enforces rate limits on AI requests.

```python
from supreme_terminal_agent.ai import AIRateLimiter
```

### Methods

#### `allow_request() -> bool`
Returns True if the request is within rate limits.

#### `get_stats() -> Dict`
Returns rate limiter statistics.

#### `reset()`
Resets rate limit counters.

## AICostTracker

Tracks AI usage costs across providers.

```python
from supreme_terminal_agent.ai import AICostTracker
```

### Methods

#### `record(model_id, tokens_input, tokens_output, latency)`
Records a usage event.

#### `get_stats() -> Dict`
Returns cost statistics.

#### `reset()`
Resets cost tracking.

## LLMEngine

Low-level LLM interaction engine.

```python
from supreme_terminal_agent.ai.llm import LLMEngine
```

### Methods

#### `generate(prompt, **kwargs) -> str`
Sends a prompt to the LLM and returns the response.

#### `generate_async(prompt, **kwargs) -> str`
Async LLM generation.

#### `generate_stream(prompt, **kwargs) -> Iterator[str]`
Streaming LLM generation.

#### `generate_stream_async(prompt, **kwargs) -> AsyncIterator[str]`
Async streaming LLM generation.

## ModelRegistry

Manages available AI models and their configurations.

```python
from supreme_terminal_agent.ai.llm import ModelRegistry
```

## AI Configuration

```yaml
ai:
  provider: openai
  model: gpt-4
  api_key: "${OPENAI_API_KEY}"
  temperature: 0.7
  max_tokens: 2048
  top_p: 0.95
  fallback_provider: anthropic
  rate_limit: 60
  cache_enabled: true
  cache_size: 10000
  cache_ttl: 3600

  providers:
    primary:
      provider: openai
      model: gpt-4
    fallback:
      provider: anthropic
      model: claude-3-opus
    local:
      provider: ollama
      model: llama3
```

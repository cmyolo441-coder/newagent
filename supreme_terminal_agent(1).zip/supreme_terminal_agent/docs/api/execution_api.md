# Execution API

The Execution API manages process execution, resource control, scheduling, and reliability.

## ExecutionEngine

Core execution engine that manages process lifecycle and resource allocation.

```python
from supreme_terminal_agent.execution import ExecutionEngine
```

### Methods

#### `execute(command, **kwargs) -> ExecutionResult`
Executes a command or task with resource controls.

#### `async execute_async(command, **kwargs) -> ExecutionResult`
Async execution with non-blocking I/O.

#### `get_status(task_id: str) -> str`
Returns the status of a task (running, completed, failed, pending).

#### `cancel(task_id: str)`
Cancels a running task.

## ExecutionController

Controls execution parameters and policies.

```python
from supreme_terminal_agent.execution import ExecutionController
```

### Methods

#### `set_timeout(seconds: int)`
Sets the default execution timeout.

#### `set_max_processes(count: int)`
Sets the maximum number of concurrent processes.

## ExecutionCoordinator

Coordinates multi-step execution workflows.

```python
from supreme_terminal_agent.execution import ExecutionCoordinator
```

## ExecutionScheduler

Schedules task execution with cron-like syntax.

```python
from supreme_terminal_agent.execution import ExecutionScheduler
```

### Methods

#### `schedule(name, expression, task)`
Schedules a task with a cron expression.

#### `unschedule(name)`
Removes a scheduled task.

#### `list() -> List`
Lists all scheduled tasks.

## Process Management

### ProcessManager

Manages child processes with resource controls.

```python
from supreme_terminal_agent.execution.process import ProcessManager
```

### Methods

#### `start(command, **kwargs) -> int`
Starts a new process and returns its PID.

#### `stop(pid, signal=SIGTERM)`
Stops a process by PID.

#### `list() -> List[ProcessInfo]`
Lists all managed processes.

#### `get(pid) -> ProcessInfo`
Returns process information.

## Resource Controls

### ResourceManager

Controls CPU, memory, and I/O limits for processes.

```python
from supreme_terminal_agent.execution.resources import ResourceManager
```

### Configuration

```yaml
execution:
  max_processes: 100
  max_memory_mb: 2048
  max_cpu_percent: 100
  default_timeout: 30
  working_dir: /tmp
  env_whitelist:
    - PATH
    - HOME
    - USER
  env_blacklist:
    - SECRET_KEY
    - API_KEY
```

## Reliability

### ReliabilityManager

Ensures execution reliability with retries and circuit breakers.

```python
from supreme_terminal_agent.execution.reliability import ReliabilityManager
```

### Methods

#### `with_retry(fn, max_retries=3, delay=1)`
Executes a function with retry logic.

#### `with_circuit_breaker(fn, name, threshold=5, reset_timeout=30)`
Executes with circuit breaker pattern.

## Signals

### SignalManager

Manages signal handling for child processes.

```python
from supreme_terminal_agent.execution.signals import SignalManager
```

## Transactions

### TransactionManager

Manages transactional execution with rollback support.

```python
from supreme_terminal_agent.execution.transactions import TransactionManager
```

### Methods

#### `begin() -> Transaction`
Begins a new transaction.

#### `commit(transaction)`
Commits a transaction.

#### `rollback(transaction)`
Rolls back a transaction.

## I/O Management

### IOManager

Manages stdin/stdout/stderr streams for executed processes.

```python
from supreme_terminal_agent.execution.io import IOManager
```

## Runners

### BaseRunner

Abstract base class for execution runners.

```python
from supreme_terminal_agent.execution.runners import BaseRunner
```

### Available Runners

| Runner | Description |
|---|---|
| `SubprocessRunner` | Direct subprocess execution |
| `DockerRunner` | Docker container execution |
| `SSHRunner` | Remote SSH execution |
| `SandboxRunner` | Sandboxed execution |

## Configuration

```yaml
execution:
  timeout: 30
  max_processes: 100
  max_memory_mb: 2048
  max_cpu_percent: 100
  working_dir: /tmp
  prewarm_processes: true
  process_pool_size: 10
  thread_pool_size: 20
  env_whitelist:
    - PATH
    - HOME
    - USER
  env_blacklist:
    - SECRET_KEY
    - API_KEY
  runners:
    default: subprocess
    sandbox:
      enabled: true
      type: docker
```

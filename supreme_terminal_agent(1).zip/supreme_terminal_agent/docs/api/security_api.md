# Security API

The Security API provides authentication, authorization, encryption, sandboxing, audit logging, and secrets management.

## SecurityEngine

Central security engine coordinating all security subsystems.

```python
from supreme_terminal_agent.security import SecurityEngine
```

### Methods

#### `validate_command(command: str) -> ValidationResult`
Validates a command against security policies.

#### `audit_log(user: str, action: str, result: Any)`
Logs a security-relevant action to the audit trail.

#### `encrypt(data: bytes, context: str = "default") -> bytes`
Encrypts data using the configured encryption algorithm.

#### `decrypt(data: bytes, context: str = "default") -> bytes`
Decrypts data.

#### `get_secret(key: str) -> Optional[str]`
Retrieves a secret from the secrets store.

#### `set_secret(key: str, value: str)`
Stores a secret.

#### `check_permission(user: str, resource: str, action: str) -> bool`
Checks if a user has permission for an action.

## SecurityController

Controls security policies and settings.

```python
from supreme_terminal_agent.security import SecurityController
```

## Authentication

### AuthenticationManager

Multi-factor authentication management.

```python
from supreme_terminal_agent.security.authentication import AuthenticationManager
```

### Methods

#### `authenticate(username, password, **kwargs) -> AuthResult`
Authenticates a user with credentials.

#### `authenticate_mfa(username, code) -> AuthResult`
Authenticates with MFA code.

#### `verify_token(token) -> AuthResult`
Verifies an authentication token.

#### `logout(session_id)`
Terminates a session.

### Supported Methods

| Method | Description |
|---|---|
| `password` | Password-based authentication |
| `ssh_key` | SSH public key authentication |
| `totp` | Time-based one-time passwords |
| `saml` | SAML SSO |
| `ldap` | LDAP/Active Directory |

## Authorization

### AuthorizationManager

Role-based access control.

```python
from supreme_terminal_agent.security.authorization import AuthorizationManager
```

### Methods

#### `check_permission(user, resource, action) -> bool`
Checks authorization.

#### `grant_permission(role, resource, action)`
Grants a permission to a role.

#### `revoke_permission(role, resource, action)`
Revokes a permission from a role.

#### `list_permissions(role) -> List[str]`
Lists permissions for a role.

### RBAC Model

```yaml
security:
  authorization:
    roles:
      admin:
        permissions: ["*"]
      developer:
        permissions: ["command.*", "fs.read", "fs.write"]
      operator:
        permissions: ["command.execute", "fs.read"]
      viewer:
        permissions: ["command.read"]
```

## Encryption

### EncryptionManager

Data encryption and decryption.

```python
from supreme_terminal_agent.security.encryption import EncryptionManager
```

### Methods

#### `encrypt(data: bytes, key: Optional[bytes] = None) -> bytes`
Encrypts data.

#### `decrypt(data: bytes, key: Optional[bytes] = None) -> bytes`
Decrypts data.

#### `generate_key() -> bytes`
Generates a new encryption key.

#### `rotate_key(context: str)`
Rotates the encryption key for a context.

### Algorithms

- AES-256-GCM (authenticated encryption)
- AES-256-CBC
- ChaCha20-Poly1305
- RSA-OAEP (asymmetric)

## Sandbox

### SandboxManager

Isolated command execution environment.

```python
from supreme_terminal_agent.security.sandbox import SandboxManager
```

### Methods

#### `execute(command, **kwargs) -> SandboxResult`
Executes a command in the sandbox.

#### `create_sandbox(**kwargs) -> Sandbox`
Creates a new sandbox environment.

#### `destroy_sandbox(sandbox_id)`
Destroys a sandbox environment.

### Sandbox Types

| Type | Description |
|---|---|
| `docker` | Docker container sandbox |
| `subprocess` | OS-level subprocess sandbox |
| `firejail` | Firejail sandbox (Linux) |
| `none` | No sandboxing |

## Audit

### AuditManager

Immutable audit logging.

```python
from supreme_terminal_agent.security.audit import AuditManager
```

### Methods

#### `log(event: AuditEvent)`
Records an audit event.

#### `query(filters: Dict) -> List[AuditEvent]`
Queries audit log with filters.

#### `export(start_date, end_date, format="json") -> str`
Exports audit log for a time range.

### Audit Events

```json
{
  "timestamp": "2025-01-15T10:30:00Z",
  "session_id": "sess_abc123",
  "user": "alice",
  "action": "command.execute",
  "resource": "filesystem",
  "command": "rm -rf /tmp/test",
  "result": "success",
  "ip_address": "192.168.1.100"
}
```

## Secrets

### SecretsManager

Secure secrets storage and retrieval.

```python
from supreme_terminal_agent.security.secrets import SecretsManager
```

### Methods

#### `get(key: str) -> Optional[str]`
Retrieves a secret.

#### `set(key: str, value: str)`
Stores a secret.

#### `delete(key: str)`
Deletes a secret.

#### `list() -> List[str]`
Lists all secret keys.

#### `rotate()`
Rotates all secrets.

### Secrets Providers

| Provider | Description |
|---|---|
| `file` | Encrypted file storage |
| `env` | Environment variables |
| `vault` | HashiCorp Vault |
| `aws_secrets` | AWS Secrets Manager |
| `gcp_secrets` | GCP Secret Manager |

## Scanning

### SecurityScanner

Security vulnerability scanning.

```python
from supreme_terminal_agent.security.scanning import SecurityScanner
```

### Methods

#### `scan_file(path) -> ScanResult`
Scans a file for security issues.

#### `scan_directory(path) -> ScanResult`
Scans a directory for security issues.

#### `scan_command(command) -> ScanResult`
Scans a command for malicious patterns.

#### `scan_dependencies(path) -> ScanResult`
Scans dependencies for known vulnerabilities.

## Validation

### CommandValidator

Command validation against security policies.

```python
from supreme_terminal_agent.security.validation import CommandValidator
```

### Methods

#### `validate(command, context) -> ValidationResult`
Validates a command against allow/block lists and patterns.

#### `add_allowed(command_pattern)`
Adds a command to the allowed list.

#### `add_blocked(command_pattern)`
Adds a command to the blocked list.

## Configuration

```yaml
security:
  sandbox: true
  sandbox_type: docker
  audit: true
  audit_log: /var/log/supreme-terminal/audit.log
  audit_retention_days: 90
  encryption: true
  encryption_algorithm: AES-256-GCM
  secrets:
    provider: file
    file_path: /etc/supreme-terminal/secrets.enc
  authentication:
    enabled: true
    session_timeout: 3600
    max_attempts: 5
  authorization:
    enabled: true
    default_role: viewer
  validation:
    mode: strict
    dangerous_patterns:
      - "rm -rf /"
      - ":(){ :|:& };:"
```

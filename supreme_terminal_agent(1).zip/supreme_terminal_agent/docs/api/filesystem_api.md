# Filesystem API

The Filesystem API provides comprehensive file and directory operations with watching, encryption, compression, search, and virtual filesystem support.

## FSEngine

Core filesystem engine providing high-level file operations.

```python
from supreme_terminal_agent.filesystem import FSEngine
```

### Methods

#### `read(path, encoding="utf-8") -> str`
Reads a file's contents as text.

#### `read_binary(path) -> bytes`
Reads a file's contents as bytes.

#### `write(path, content)`
Writes content to a file.

#### `append(path, content)`
Appends content to a file.

#### `delete(path)`
Deletes a file or empty directory.

#### `move(src, dst)`
Moves a file or directory.

#### `copy(src, dst)`
Copies a file or directory.

#### `exists(path) -> bool`
Checks if a path exists.

#### `listdir(path=".") -> List[FileInfo]`
Lists directory contents.

#### `mkdir(path, parents=True, exist_ok=True)`
Creates a directory.

#### `info(path) -> FileInfo`
Returns file or directory metadata.

## FSController

Controls filesystem access policies and permissions.

```python
from supreme_terminal_agent.filesystem import FSController
```

### Methods

#### `set_working_directory(path)`
Sets the working directory for relative path resolution.

#### `allow_path(path)`
Adds a path to the allowed access list.

#### `block_path(path)`
Adds a path to the blocked access list.

## Directory Operations

### DirectoryManager

Advanced directory operations.

```python
from supreme_terminal_agent.filesystem.directory import DirectoryManager
```

### Methods

#### `walk(path, pattern=None) -> Iterator[FileInfo]`
Walks a directory tree with optional pattern filter.

#### `tree(path, max_depth=None) -> Dict`
Returns a directory tree structure.

#### `size(path) -> int`
Calculates total directory size.

## Path Operations

### PathManager

Path manipulation and resolution.

```python
from supreme_terminal_agent.filesystem.path import PathManager
```

### Methods

#### `resolve(path) -> str`
Resolves a path to its absolute form.

#### `relative(path, base=None) -> str`
Returns a relative path from base.

#### `expand(path) -> str`
Expands user (~) and environment variables.

## File Search

### SearchEngine

Powerful file search with multiple strategies.

```python
from supreme_terminal_agent.filesystem.search import SearchEngine
```

### Methods

#### `find(pattern, path=".", recursive=True) -> List[str]`
Finds files matching a glob pattern.

#### `grep(pattern, path=".", recursive=True) -> List[Match]`
Searches file contents with regex.

#### `find_by_size(min_size=None, max_size=None, path=".") -> List[str]`
Finds files by size range.

#### `find_by_date(before=None, after=None, path=".") -> List[str]`
Finds files by modification date.

## File Watching

### FileWatcher

Monitors filesystem for changes.

```python
from supreme_terminal_agent.filesystem.watching import FileWatcher
```

### Methods

#### `watch(path, recursive=True)`
Starts watching a path for changes.

#### `on_change(callback)`
Registers a callback for file change events.

#### `stop()`
Stops watching.

### Events

| Event | Description |
|---|---|
| `created` | File or directory created |
| `modified` | File or directory modified |
| `deleted` | File or directory deleted |
| `moved` | File or directory moved |

## Compression

### CompressionEngine

File and directory compression.

```python
from supreme_terminal_agent.filesystem.compression import CompressionEngine
```

### Methods

#### `compress(path, format="gz", output=None) -> str`
Compresses a file or directory.

#### `decompress(path, output_dir=None) -> str`
Decompresses an archive.

### Supported Formats

- gz, bz2, xz, zip, tar, tar.gz, tar.bz2, tar.xz

## Encryption

### EncryptionEngine

File encryption and decryption.

```python
from supreme_terminal_agent.filesystem.encryption import EncryptionEngine
```

### Methods

#### `encrypt(path, key, output=None) -> str`
Encrypts a file with the given key.

#### `decrypt(path, key, output=None) -> str`
Decrypts a file with the given key.

### Algorithms

- AES-256-GCM (default)
- AES-256-CBC
- ChaCha20-Poly1305

## Virtual Filesystem

### VirtualFS

In-memory virtual filesystem for isolated operations.

```python
from supreme_terminal_agent.filesystem.virtual import VirtualFS
```

### Methods

#### `mount(path, fs)`
Mounts a filesystem at a path.

#### `unmount(path)`
Unmounts a filesystem.

## Permissions

### PermissionManager

Manages file permissions and ownership.

```python
from supreme_terminal_agent.filesystem.permissions import PermissionManager
```

### Methods

#### `chmod(path, mode)`
Changes file permissions.

#### `chown(path, user, group)`
Changes file ownership.

#### `get_permissions(path) -> PermissionInfo`
Gets file permissions.

## File Analysis

### FileAnalyzer

Analyzes file content and metadata.

```python
from supreme_terminal_agent.filesystem.analysis import FileAnalyzer
```

### Methods

#### `analyze(path) -> AnalysisResult`
Analyzes a file's type, encoding, size, and metadata.

#### `mime_type(path) -> str`
Detects MIME type.

#### `checksum(path, algorithm="sha256") -> str`
Computes file checksum.

## Configuration

```yaml
filesystem:
  working_directory: .
  allowed_paths:
    - /home
    - /tmp
    - /var/log
  blocked_paths:
    - /etc/shadow
    - /etc/sudoers
  max_file_size_mb: 100
  follow_symlinks: false
  encoding: utf-8
  watching:
    enabled: true
    poll_interval: 1.0
```

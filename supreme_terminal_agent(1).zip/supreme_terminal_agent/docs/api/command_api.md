# Command API

The Command API provides command parsing, validation, execution, history management, and macro support.

## CommandEngine

Executes shell commands and dispatches to registered handlers.

```python
from supreme_terminal_agent.commands import CommandEngine
```

### Constructor

```python
CommandEngine(handler_registry: Optional[Any] = None)
```

### Methods

#### `execute(command_line: str, **kwargs) -> Dict`
Parses and executes a command line. Returns a dictionary with success status, output, error, and return code.

```python
result = engine.execute("ls -la")
# {'success': True, 'output': '...', 'error': '', 'returncode': 0}
```

#### `execute_async(command_line: str, **kwargs) -> subprocess.Popen`
Starts asynchronous command execution and returns the Popen object.

#### `set_context(key: str, value: Any)`
Sets a context value available to command handlers.

#### `get_context(key: str, default: Any) -> Any`
Gets a context value.

## CommandOrchestrator

High-level command orchestration with pre/post processing.

```python
from supreme_terminal_agent.commands import CommandOrchestrator
```

## Command Parsing

### ArgumentValidator

Validates command arguments against expected types and constraints.

```python
from supreme_terminal_agent.commands.validation import ArgumentValidator
```

### SafetyValidator

Validates commands against security policies (allow/block lists, dangerous patterns).

```python
from supreme_terminal_agent.commands.validation import SafetyValidator
```

### SemanticValidator

Performs semantic analysis of commands for correctness.

```python
from supreme_terminal_agent.commands.validation import SemanticValidator
```

## Command History

### HistoryManager

Manages command history with search and persistence.

```python
from supreme_terminal_agent.commands.history import HistoryManager
```

### Methods

#### `add(command: str)`
Adds a command to history.

#### `get_all() -> List[str]`
Returns all history entries.

#### `search(pattern: str) -> List[str]`
Searches history for matching commands.

#### `clear()`
Clears history.

#### `export(path: str)`
Exports history to a file.

## Macros

### MacroManager

Manages command macros and aliases.

```python
from supreme_terminal_agent.commands.macros import MacroManager
```

### Methods

#### `define(name: str, command: str)`
Defines a new macro.

#### `expand(name: str) -> Optional[str]`
Expands a macro to its command string.

#### `list() -> Dict`
Lists all defined macros.

#### `remove(name: str)`
Removes a macro.

## Command Handlers

The system supports custom command handlers for built-in commands:

```python
from supreme_terminal_agent.commands.handlers import BaseCommandHandler

class MyHandler(BaseCommandHandler):
    command = "mycommand"

    def handle(self, args, context):
        return {"success": True, "output": "handled"}
```

## Command Intelligence

### CommandIntelligence

AI-powered command suggestions and analysis.

```python
from supreme_terminal_agent.commands.intelligence import CommandIntelligence
```

### Methods

#### `suggest(input_text: str) -> List[str]`
Suggests commands based on input context.

#### `analyze(command: str) -> Dict`
Analyzes a command for potential issues.

## Validation Pipeline

Commands pass through a validation pipeline before execution:

1. **Syntax Validation** – Checks for basic syntax errors
2. **Safety Validation** – Checks against security policies
3. **Semantic Validation** – Checks for logical correctness

```python
# Custom validator
from supreme_terminal_agent.commands.validation import BaseValidator

class MyValidator(BaseValidator):
    def validate(self, command: str, context: dict) -> bool:
        # Custom validation logic
        return True
```

## Command Result Format

```python
{
    "success": bool,        # Whether command succeeded
    "output": str,          # Standard output
    "error": str,           # Standard error
    "returncode": int,      # Exit code
    "command": str,         # Original command
    "duration": float,      # Execution time in seconds
    "pid": int,             # Process ID (if applicable)
}
```

## Configuration

```yaml
commands:
  history_size: 10000
  history_file: data/history/history.db
  aliases:
    ll: ls -la
    gs: git status
  macros:
    enabled: true
    file: data/macros/macros.yaml
  validation:
    syntax: true
    safety: true
    semantic: true
```

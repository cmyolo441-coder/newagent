# Plugin API

The Plugin API provides interfaces for creating, managing, and interacting with plugins.

## PluginEngine

Central plugin management engine.

```python
from supreme_terminal_agent.plugins import PluginEngine
```

### Methods

#### `load_all()`
Loads all installed plugins from plugin directories.

#### `load(name: str)`
Loads a specific plugin by name.

#### `enable(name: str)`
Enables a loaded plugin.

#### `disable(name: str)`
Disables an enabled plugin.

#### `install(source: str, **kwargs)`
Installs a plugin from a path, URL, or package name.

```python
engine.install("/path/to/my-plugin")
engine.install("my-plugin", source="pypi")
engine.install("https://github.com/user/plugin.git")
```

#### `uninstall(name: str)`
Uninstalls and removes a plugin.

#### `update(name: str)`
Updates a plugin to the latest version.

#### `list() -> List[PluginInfo]`
Lists all installed plugins.

#### `get_info(name: str) -> PluginInfo`
Returns detailed plugin information.

## BasePlugin

Abstract base class for all plugins.

```python
from supreme_terminal_agent.plugins.base import BasePlugin
```

### Attributes

| Attribute | Description |
|---|---|
| `name` | Plugin name |
| `version` | Plugin version |
| `description` | Plugin description |
| `config` | Plugin configuration |
| `logger` | Plugin logger |
| `services` | Access to agent services |

### Lifecycle Methods

#### `async on_load()`
Called when the plugin is loaded into memory. Initialize resources here.

#### `async on_enable()`
Called when the plugin is enabled. Start active operations here.

#### `async on_disable()`
Called when the plugin is disabled. Stop operations and clean up.

#### `async on_install()`
Called after the plugin is installed.

#### `async on_uninstall()`
Called before the plugin is uninstalled. Remove all plugin data.

#### `async on_update(old_version: str)`
Called after the plugin is updated.

### Example

```python
class MyPlugin(BasePlugin):
    name = "my-plugin"
    version = "1.0.0"
    description = "Example plugin"

    async def on_load(self):
        self.logger.info(f"{self.name} v{self.version} loaded")
        config_value = self.config.get("my_setting", "default")

    async def on_enable(self):
        self.logger.info(f"{self.name} enabled")
        self.services.events.subscribe("command.executed", self.on_command)

    async def on_disable(self):
        self.logger.info(f"{self.name} disabled")
        self.services.events.unsubscribe("command.executed", self.on_command)

    async def on_command(self, event):
        self.logger.debug(f"Command: {event.data['command']}")
```

## Plugin Config

### PluginConfigManager

Manages plugin-specific configuration.

```python
from supreme_terminal_agent.plugins import PluginConfigManager
```

### Methods

#### `get(key: str, default: Any = None) -> Any`
Gets a configuration value.

#### `set(key: str, value: Any)`
Sets a configuration value.

#### `get_all() -> Dict`
Returns all configuration values.

## Plugin Dependencies

### PluginDependencyResolver

Resolves inter-plugin dependencies.

```python
from supreme_terminal_agent.plugins import PluginDependencyResolver
```

### Methods

#### `resolve(plugin_name: str) -> List[str]`
Returns the dependency chain for a plugin.

#### `check(plugin_name: str) -> bool`
Checks if all dependencies are satisfied.

## Plugin Registry

### PluginRegistry

Plugin registration and discovery.

```python
from supreme_terminal_agent.plugins import PluginRegistry
```

### Methods

#### `register(plugin_class)`
Registers a plugin class.

#### `get(name: str) -> Optional[BasePlugin]`
Gets a plugin instance by name.

#### `get_all() -> List[BasePlugin]`
Returns all registered plugin instances.

## Plugin Events

### PluginEventManager

Event hooks for plugins.

```python
from supreme_terminal_agent.plugins import PluginEventManager
```

### Methods

#### `subscribe(event: str, callback)`
Subscribes to an event.

#### `unsubscribe(event: str, callback)`
Unsubscribes from an event.

#### `emit(event: str, data: Dict)`
Emits an event to all subscribers.

### Available Events

| Event | Description |
|---|---|
| `plugin.loaded` | Plugin loaded |
| `plugin.enabled` | Plugin enabled |
| `plugin.disabled` | Plugin disabled |
| `command.executed` | Command executed |
| `session.created` | Session created |
| `session.destroyed` | Session destroyed |
| `ai.generated` | AI response generated |
| `file.changed` | File changed |

## Plugin Loader

### PluginLoader

Discovers and loads plugins from various sources.

```python
from supreme_terminal_agent.plugins import PluginLoader
```

### Methods

#### `load_from_directory(path: str)`
Loads plugins from a directory.

#### `load_from_package(name: str)`
Loads a plugin from an installed Python package.

#### `load_from_entrypoint(group: str)`
Loads plugins from setuptools entry points.

## Plugin Validator

### PluginValidator

Validates plugin structure and metadata.

```python
from supreme_terminal_agent.plugins import PluginValidator
```

### Methods

#### `validate(plugin_path: str) -> ValidationResult`
Validates a plugin's structure and manifest.

#### `validate_manifest(manifest: Dict) -> ValidationResult`
Validates a plugin manifest.

## Plugin Sandbox

### PluginSandbox

Restricted execution environment for plugins.

```python
from supreme_terminal_agent.plugins import PluginSandbox
```

### Methods

#### `execute(fn, *args, **kwargs)`
Executes a function in the sandbox.

#### `check_permission(permission: str) -> bool`
Checks if a permission is granted.

## Plugin Installer/Uninstaller/Updater

### PluginInstaller

```python
from supreme_terminal_agent.plugins import PluginInstaller
```

### PluginUninstaller

```python
from supreme_terminal_agent.plugins import PluginUninstaller
```

### PluginUpdater

```python
from supreme_terminal_agent.plugins import PluginUpdater
```

## Configuration

```yaml
plugins:
  directories:
    - data/plugins
    - /usr/local/share/supreme-terminal/plugins
  auto_load: true
  sandbox:
    enabled: true
    network_access: false
    filesystem_access: restricted
    max_memory_mb: 128
    max_execution_time: 30
  registries:
    official: https://plugins.supreme-ai.com
  allow_unofficial: true
```

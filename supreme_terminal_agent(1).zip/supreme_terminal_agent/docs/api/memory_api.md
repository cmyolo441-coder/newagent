# Memory API

The Memory API provides persistent and ephemeral memory management with vector search, learning, and context management.

## MemoryEngine

Central memory engine that coordinates all memory types.

```python
from supreme_terminal_agent.memory import MemoryEngine
```

### Methods

#### `async store(key: str, value: Any, metadata: Optional[Dict] = None)`
Stores a value in memory with optional metadata.

```python
await memory.store("user_preference", {"editor": "neovim"})
```

#### `async recall(key: str) -> Optional[Any]`
Retrieves a value from memory by key.

```python
pref = await memory.recall("user_preference")
```

#### `async search(query: str, limit: int = 10) -> List[SearchResult]`
Semantic search across all memory stores.

```python
results = await memory.search("python debugging techniques")
```

#### `async forget(key: str)`
Removes a value from memory.

#### `async clear()`
Clears all memory stores.

#### `async get_stats() -> Dict`
Returns memory usage statistics.

## Memory Types

### ShortTermMemory

Ephemeral memory for current session context.

```python
from supreme_terminal_agent.memory.types import ShortTermMemory
```

- Automatically expires after session end
- Used for conversation context
- LRU eviction policy
- Configurable capacity

### LongTermMemory

Persistent memory that survives restarts.

```python
from supreme_terminal_agent.memory.types import LongTermMemory
```

- Stored on disk with configurable backend
- Used for user preferences and learned patterns
- Indexed for fast retrieval
- Automatic cleanup of stale entries

### EpisodicMemory

Memory of past interactions and outcomes.

```python
from supreme_terminal_agent.memory.types import EpisodicMemory
```

- Records agent actions and their results
- Used for learning from experience
- Timestamped and searchable
- Supports reinforcement learning

### VectorMemory

Embedding-based semantic search memory.

```python
from supreme_terminal_agent.memory.types import VectorMemory
```

- Stores text as vector embeddings
- Supports similarity search
- Multiple index types (IVF, HNSW, Flat)
- Configurable embedding models

## Context Management

### ContextManager

Manages conversational and task context.

```python
from supreme_terminal_agent.memory.context import ContextManager
```

### Methods

#### `set(key: str, value: Any)`
Sets a context value.

#### `get(key: str) -> Optional[Any]`
Gets a context value.

#### `update(context: Dict)`
Updates context with a dictionary.

#### `clear()`
Clears context.

#### `get_all() -> Dict`
Returns all context values.

## Memory Storage

### StorageManager

Manages persistent storage backends.

```python
from supreme_terminal_agent.memory.storage import StorageManager
```

### Supported Backends

| Backend | Description |
|---|---|
| `sqlite` | SQLite database (default) |
| `postgresql` | PostgreSQL database |
| `redis` | Redis cache |
| `chromadb` | ChromaDB vector store |
| `faiss` | FAISS vector index |

### Configuration

```yaml
memory:
  storage: sqlite
  sqlite_path: data/memory/memory.db

  short_term:
    capacity: 1000
    ttl: 3600

  long_term:
    enabled: true
    max_entries: 100000
    cleanup_interval: 86400

  vector:
    enabled: true
    dimension: 384
    index_type: IVF
    embedding_model: all-MiniLM-L6-v2
    similarity: cosine

  episodic:
    enabled: true
    max_entries: 50000
```

## Learning

### LearningManager

Learns from user interactions and feedback.

```python
from supreme_terminal_agent.memory.learning import LearningManager
```

### Methods

#### `observe(action: str, outcome: Any)`
Records an action and its outcome for learning.

#### `get_recommendations(context: Dict) -> List[str]`
Returns recommendations based on learned patterns.

#### `get_stats() -> Dict`
Returns learning statistics.

## Memory Operations

### OperationsManager

Advanced memory operations.

```python
from supreme_terminal_agent.memory.operations import OperationsManager
```

### Methods

#### `merge(source_keys: List[str], target_key: str)`
Merges multiple memory entries into one.

#### `diff(key1: str, key2: str) -> Dict`
Compares two memory entries.

#### `backup(path: str)`
Creates a memory backup.

#### `restore(path: str)`
Restores memory from a backup.

## Search Results

```python
@dataclass
class SearchResult:
    key: str
    value: Any
    score: float
    source: str
    timestamp: datetime
    metadata: Dict
```

# Terminal API

The Terminal API provides full PTY-based terminal emulation, session management, and I/O operations.

## TerminalController

Manages the lifecycle of a terminal instance including PTY process, emulation, rendering, and I/O.

```python
from supreme_terminal_agent.terminal import TerminalController
```

### Constructor

```python
TerminalController(rows: int = 24, cols: int = 80, terminal_id: Optional[str] = None)
```

### Properties

| Property | Type | Description |
|---|---|---|
| `status` | TerminalStatus | Current terminal status |
| `is_active` | bool | Whether terminal is running |
| `is_paused` | bool | Whether terminal is paused |
| `rows` | int | Terminal height |
| `cols` | int | Terminal width |
| `state` | TerminalState | Current terminal state |
| `emulator` | TerminalEmulator | Terminal emulator instance |
| `renderer` | TerminalRenderer | Terminal renderer instance |
| `capabilities` | TerminalCapabilities | Terminal capability detection |
| `metadata` | SessionMetadata | Session metadata |
| `uptime` | float | Seconds since creation |
| `last_activity` | float | Timestamp of last I/O |
| `idle_time` | float | Seconds since last activity |

### Methods

#### `initialize(shell, env, cwd, term)`
Initializes the terminal with a PTY and shell process. This creates a child process running the specified shell connected to the PTY.

```python
term.initialize(shell="/bin/bash", term="xterm-256color")
```

#### `read(size=4096) -> bytes`
Reads raw data from the PTY master. Data is automatically fed to the emulator for parsing.

#### `write(data: bytes) -> int`
Writes raw data to the PTY master. Returns the number of bytes written.

#### `writeline(text: str) -> int`
Writes a line of text (with newline) to the terminal.

#### `resize(rows, cols)`
Resizes the terminal PTY and emulator. Sends SIGWINCH to the child process.

#### `render() -> RenderedFrame`
Renders the current terminal state including visible content and cursor position.

#### `get_plain_text() -> str`
Gets the visible terminal content as plain text.

#### `pause()`
Pauses terminal processing.

#### `resume()`
Resumes a paused terminal.

#### `reset(hard=False)`
Resets the terminal state. Hard reset reinitializes capability negotiation.

#### `close()`
Closes the terminal, kills the child process, and releases all resources.

#### `get_state() -> Dict`
Returns serializable terminal state for persistence.

#### `load_state(data: Dict)`
Restores terminal state from a dictionary.

#### `on_data(callback)`
Registers a callback for incoming PTY data.

#### `on_status_change(callback)`
Registers a callback for status changes.

#### `on_error(callback)`
Registers a callback for errors.

### Terminal Status

```python
class TerminalStatus(Enum):
    CREATED = "created"
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    CLOSED = "closed"
    ERROR = "error"
```

## TerminalEmulator

Parses escape sequences and maintains the terminal screen state.

```python
from supreme_terminal_agent.terminal import TerminalEmulator
```

### Methods

#### `feed(data: bytes)`
Feeds raw terminal data to the emulator for parsing.

#### `render() -> RenderedFrame`
Renders the current screen state.

#### `get_plain_text() -> str`
Returns visible text content.

#### `start()` / `stop()`
Starts or stops the emulator processing loop.

#### `resize(rows, cols)`
Resizes the emulated terminal.

#### `reset(hard=False)`
Resets the emulator state.

## TerminalRenderer

Renders terminal state to displayable output.

```python
from supreme_terminal_agent.terminal import TerminalRenderer
```

### Methods

#### `render(state: TerminalState) -> RenderedFrame`
Renders the terminal state to a displayable frame.

## TerminalCapabilities

Detects and manages terminal capabilities.

```python
from supreme_terminal_agent.terminal import TerminalCapabilities
```

### Properties

| Property | Description |
|---|---|
| `color_depth` | Supported color depth (8, 256, truecolor) |
| `unicode` | Unicode support |
| `mouse` | Mouse tracking support |
| `bracketed_paste` | Bracketed paste mode |

## TerminalNegotiation

Negotiates terminal capabilities with the connected terminal.

```python
from supreme_terminal_agent.terminal import TerminalNegotiation
```

### Methods

#### `negotiate() -> NegotiationResult`
Performs capability negotiation and returns the result.

## TerminalState

Holds the current state of the terminal screen.

```python
from supreme_terminal_agent.terminal import TerminalState
```

### Properties

| Property | Description |
|---|---|
| `rows` / `cols` | Terminal dimensions |
| `cursor_x` / `cursor_y` | Cursor position |
| `scroll_top` / `scroll_bottom` | Scroll region |

## ScreenManager

Manages multiple terminal screens and buffer switching.

```python
from supreme_terminal_agent.terminal.screen import ScreenManager
```

## SessionMetadata

Stores metadata about a terminal session.

```python
from supreme_terminal_agent.terminal.session import SessionMetadata
```

## Terminal Config

```yaml
terminal:
  shell: /bin/bash
  emulator: xterm-256color
  scrollback: 100000
  max_sessions: 100
  default_rows: 24
  default_cols: 80
  cursor_style: block
  bell_style: visual
  idle_timeout: 3600
```

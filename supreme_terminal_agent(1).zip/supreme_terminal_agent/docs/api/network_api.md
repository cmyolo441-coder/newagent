# Network API

The Network API provides comprehensive networking capabilities including HTTP, SSH, WebSocket, DNS, firewall management, and secure communications.

## NetworkEngine

Core network engine managing all network operations.

```python
from supreme_terminal_agent.network import NetworkEngine
```

### Methods

#### `http_request(method, url, **kwargs) -> Response`
Makes an HTTP request with connection pooling and retry support.

```python
resp = engine.http_request("GET", "https://api.example.com/data")
resp = engine.http_request("POST", "https://api.example.com/data", json={"key": "value"})
```

#### `ssh_connect(host, username, **kwargs) -> SSHConnection`
Establishes an SSH connection to a remote host.

```python
conn = engine.ssh_connect("example.com", username="admin", key_file="~/.ssh/id_rsa")
```

#### `websocket_connect(url, **kwargs) -> WebSocketConnection`
Connects to a WebSocket endpoint.

```python
ws = engine.websocket_connect("wss://example.com/ws")
```

#### `resolve_dns(hostname, record_type="A") -> List[str]`
Resolves DNS records for a hostname.

## NetworkController

Controls network access policies and connection limits.

```python
from supreme_terminal_agent.network import NetworkController
```

### Methods

#### `set_proxy(proxy_url)`
Sets the HTTP/HTTPS proxy.

#### `set_timeout(seconds)`
Sets the default network timeout.

#### `set_max_connections(count)`
Sets maximum concurrent connections.

## HTTP Client

### HTTPClient

Advanced HTTP client with connection pooling.

```python
from supreme_terminal_agent.network.http import HTTPClient
```

### Methods

| Method | Description |
|---|---|
| `get(url, **kwargs)` | HTTP GET request |
| `post(url, **kwargs)` | HTTP POST request |
| `put(url, **kwargs)` | HTTP PUT request |
| `delete(url, **kwargs)` | HTTP DELETE request |
| `patch(url, **kwargs)` | HTTP PATCH request |
| `head(url, **kwargs)` | HTTP HEAD request |
| `options(url, **kwargs)` | HTTP OPTIONS request |

### Features

- Connection pooling with keep-alive
- Automatic retry with exponential backoff
- TLS/SSL certificate verification
- Proxy support (HTTP, HTTPS, SOCKS)
- Cookie persistence
- Streaming response support
- Timeout management
- Rate limiting

## SSH Client/Server

### SSHClient

SSH client for remote command execution and file transfer.

```python
from supreme_terminal_agent.network.ssh import SSHClient
```

### Methods

#### `connect(host, port=22, username, password=None, key_file=None)`
Establishes an SSH connection.

#### `execute(command) -> SSHResult`
Executes a command on the remote host.

#### `upload(local_path, remote_path)`
Uploads a file via SCP/SFTP.

#### `download(remote_path, local_path)`
Downloads a file via SCP/SFTP.

#### `forward(local_port, remote_host, remote_port)`
Creates an SSH tunnel/port forward.

#### `close()`
Closes the SSH connection.

### SSHServer

Embedded SSH server for remote agent access.

```python
from supreme_terminal_agent.network.ssh import SSHServer
```

### Methods

#### `start(host="0.0.0.0", port=22)`
Starts the SSH server.

#### `stop()`
Stops the SSH server.

#### `authenticate(username, password) -> bool`
Custom authentication handler.

## WebSocket

### WebSocketClient

WebSocket client for real-time communication.

```python
from supreme_terminal_agent.network.socket import WebSocketClient
```

### Methods

#### `connect(url)`
Connects to a WebSocket endpoint.

#### `send(data)`
Sends data over the WebSocket.

#### `receive() -> str`
Receives data from the WebSocket.

#### `close()`
Closes the WebSocket connection.

## DNS

### DNSResolver

DNS resolution and network information.

```python
from supreme_terminal_agent.network.dns import DNSResolver
```

### Methods

#### `resolve(hostname, record_type="A") -> List[str]`
Resolves DNS records.

#### `reverse_lookup(ip_address) -> str`
Performs reverse DNS lookup.

## Firewall

### FirewallManager

Manages network access rules.

```python
from supreme_terminal_agent.network.firewall import FirewallManager
```

### Methods

#### `allow_rule(host, port, protocol="tcp")`
Adds an allow rule.

#### `block_rule(host, port, protocol="tcp")`
Adds a block rule.

#### `list_rules() -> List[FirewallRule]`
Lists all firewall rules.

## SSL/TLS

### SSLManager

Manages SSL/TLS certificates and connections.

```python
from supreme_terminal_agent.network.ssl import SSLManager
```

### Methods

#### `generate_certificate(common_name, **kwargs) -> CertResult`
Generates a self-signed certificate.

#### `verify_certificate(cert_path) -> bool`
Verifies a certificate.

#### `get_certificate_info(cert_path) -> CertInfo`
Returns certificate information.

## Socket

### SocketManager

Raw socket management.

```python
from supreme_terminal_agent.network.socket import SocketManager
```

### Methods

#### `create_socket(family=AF_INET, type=SOCK_STREAM) -> socket`
Creates a new socket.

#### `listen(host, port, backlog=5)`
Starts listening on a port.

#### `connect(host, port) -> socket`
Connects to a remote host.

## Transfer

### TransferManager

File transfer management across protocols.

```python
from supreme_terminal_agent.network.transfer import TransferManager
```

### Methods

#### `upload(source, destination, protocol="auto")`
Uploads a file using the best available protocol.

#### `download(source, destination, protocol="auto")`
Downloads a file using the best available protocol.

## Network Monitoring

### NetworkMonitor

Monitors network connections and traffic.

```python
from supreme_terminal_agent.network.monitoring import NetworkMonitor
```

### Methods

#### `get_connections() -> List[ConnectionInfo]`
Lists active network connections.

#### `get_bandwidth() -> BandwidthInfo`
Returns current bandwidth usage.

#### `get_latency(host) -> float`
Measures latency to a host.

## Configuration

```yaml
network:
  timeout: 30
  max_connections: 100
  proxy: null
  user_agent: "SupremeTerminalAgent/1.0"
  tls_verify: true
  dns_servers:
    - 8.8.8.8
    - 1.1.1.1
  ssh:
    key_file: ~/.ssh/id_rsa
    timeout: 30
    keepalive_interval: 60
  http:
    pool_size: 20
    max_retries: 3
    backoff_factor: 0.5
```

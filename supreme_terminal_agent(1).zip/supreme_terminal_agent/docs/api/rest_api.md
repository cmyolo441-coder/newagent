# REST API

The Supreme Terminal AI Agent provides a comprehensive REST API for remote control and integration.

## Base URL

```
http://localhost:8080/api/v1
```

## Authentication

### API Key Authentication

```
Authorization: Bearer <api-key>
```

### Session Token Authentication

```
Authorization: Bearer <session-token>
```

## Endpoints

### Health

#### `GET /health`

Returns agent health status.

```json
{
  "status": "healthy",
  "version": "1.0.0",
  "uptime": 86400,
  "checks": {
    "agent": "passed",
    "ai": "passed",
    "terminal": "passed"
  }
}
```

### Agent

#### `GET /api/v1/agent/status`

Returns agent status and statistics.

#### `POST /api/v1/agent/process`

Process natural language input.

```json
{
  "input": "list all Python files",
  "session_id": "sess_abc123"
}
```

Response:

```json
{
  "success": true,
  "output": "Found 15 Python files...",
  "plan": ["find . -name '*.py'", "count results"],
  "duration_ms": 1234
}
```

#### `POST /api/v1/agent/execute`

Execute a direct shell command.

```json
{
  "command": "ls -la",
  "timeout": 30,
  "session_id": "sess_abc123"
}
```

#### `GET /api/v1/agent/metrics`

Returns agent performance metrics.

### Sessions

#### `GET /api/v1/sessions`

Lists all active sessions.

#### `POST /api/v1/sessions`

Creates a new session.

```json
{
  "name": "my-session",
  "shell": "/bin/bash",
  "rows": 24,
  "cols": 80
}
```

#### `GET /api/v1/sessions/{id}`

Returns session details.

#### `DELETE /api/v1/sessions/{id}`

Closes and destroys a session.

#### `POST /api/v1/sessions/{id}/write`

Writes data to a session.

```json
{
  "data": "ls -la\n"
}
```

#### `GET /api/v1/sessions/{id}/read`

Reads output from a session.

#### `POST /api/v1/sessions/{id}/resize`

Resizes a session.

```json
{
  "rows": 40,
  "cols": 120
}
```

### AI

#### `POST /api/v1/ai/generate`

Generate AI response.

```json
{
  "prompt": "Explain what ls -la does",
  "model": "gpt-4",
  "max_tokens": 500,
  "temperature": 0.7
}
```

#### `POST /api/v1/ai/generate/stream`

Streaming AI response (Server-Sent Events).

#### `GET /api/v1/ai/stats`

Returns AI engine statistics.

#### `DELETE /api/v1/ai/cache`

Clears the AI response cache.

### Commands

#### `POST /api/v1/commands/execute`

Execute a command.

```json
{
  "command": "ls -la",
  "timeout": 30,
  "working_dir": "/tmp"
}
```

#### `GET /api/v1/commands/history`

Returns command history.

#### `DELETE /api/v1/commands/history`

Clears command history.

### Filesystem

#### `GET /api/v1/fs/read/{path}`

Reads a file.

#### `POST /api/v1/fs/write/{path}`

Writes to a file.

#### `DELETE /api/v1/fs/{path}`

Deletes a file or directory.

#### `GET /api/v1/fs/list/{path}`

Lists directory contents.

#### `POST /api/v1/fs/mkdir/{path}`

Creates a directory.

#### `POST /api/v1/fs/move`

Moves a file or directory.

```json
{
  "source": "/tmp/file.txt",
  "destination": "/home/user/file.txt"
}
```

### Tools

#### `GET /api/v1/tools`

Lists all registered tools.

#### `POST /api/v1/tools/{name}/execute`

Executes a tool.

```json
{
  "parameters": {
    "pattern": "*.py",
    "directory": "./src"
  }
}
```

### Plugins

#### `GET /api/v1/plugins`

Lists all plugins.

#### `POST /api/v1/plugins/install`

Installs a plugin.

```json
{
  "source": "/path/to/plugin"
}
```

#### `POST /api/v1/plugins/{name}/enable`

Enables a plugin.

#### `POST /api/v1/plugins/{name}/disable`

Disables a plugin.

#### `DELETE /api/v1/plugins/{name}`

Uninstalls a plugin.

### Pipelines

#### `GET /api/v1/pipelines`

Lists all pipelines.

#### `POST /api/v1/pipelines`

Creates a pipeline.

```json
{
  "name": "deploy",
  "steps": ["build", "test", "deploy"]
}
```

#### `POST /api/v1/pipelines/{name}/run`

Runs a pipeline.

#### `GET /api/v1/pipelines/{name}/status`

Returns pipeline status.

### Configuration

#### `GET /api/v1/config`

Returns all configuration.

#### `GET /api/v1/config/{key}`

Returns a specific configuration value.

#### `PUT /api/v1/config/{key}`

Sets a configuration value.

```json
{
  "value": "gpt-4"
}
```

### Monitoring

#### `GET /api/v1/monitoring/health`

Health check endpoint.

#### `GET /api/v1/monitoring/metrics`

Prometheus metrics.

#### `GET /api/v1/monitoring/logs`

Returns recent log entries.

### Security

#### `POST /api/v1/security/validate`

Validates a command.

```json
{
  "command": "ls -la"
}
```

#### `GET /api/v1/security/audit`

Returns audit log entries.

## Error Responses

```json
{
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Rate limit exceeded. Try again in 30 seconds.",
    "status": 429
  }
}
```

### HTTP Status Codes

| Code | Description |
|---|---|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 429 | Rate Limit Exceeded |
| 500 | Internal Server Error |

## Rate Limiting

Rate limits are enforced per API key:

```json
{
  "X-RateLimit-Limit": "100",
  "X-RateLimit-Remaining": "87",
  "X-RateLimit-Reset": "1705312800"
}
```

## Pagination

List endpoints support pagination:

```
GET /api/v1/sessions?limit=20&offset=0
```

Response includes pagination metadata:

```json
{
  "data": [...],
  "pagination": {
    "total": 150,
    "limit": 20,
    "offset": 0,
    "next": "/api/v1/sessions?limit=20&offset=20"
  }
}
```

## WebSocket API

Connect to `ws://localhost:8766/ws` for real-time events:

```json
{
  "type": "command.executed",
  "data": {
    "command": "ls -la",
    "success": true,
    "timestamp": "2025-01-15T10:30:00Z"
  }
}
```

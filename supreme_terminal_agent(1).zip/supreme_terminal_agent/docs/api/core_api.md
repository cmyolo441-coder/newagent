# Core API

The Core API provides the foundational classes and interfaces for the Supreme Terminal AI Agent.

## SupremeTerminalAgent

The main entry point for the agent, managing initialization, lifecycle, and top-level coordination.

```python
from supreme_terminal_agent import SupremeTerminalAgent
```

### Constructor

```python
SupremeTerminalAgent(config: Optional[Config] = None)
```

Creates a new agent instance. If no configuration is provided, the agent loads defaults from the standard configuration paths.

### Methods

#### `async initialize()`
Initializes all subsystems: brain, consciousness, orchestrator, and lifecycle manager. Must be called before `run()`.

```python
agent = SupremeTerminalAgent()
await agent.initialize()
```

#### `async run()`
Starts the agent's main loop. In interactive mode, this presents the REPL. In daemon mode, it starts background processing.

```python
await agent.run()
```

#### `async shutdown()`
Gracefully shuts down all subsystems, saves state, and cleans up resources.

```python
await agent.shutdown()
```

#### `async process(input_text: str) -> Dict`
Processes natural language input through the cognition-reasoning-planning pipeline and returns the agent's response.

```python
response = await agent.process("list all Python files")
```

## Brain

The central decision engine that coordinates cognition, reasoning, and planning.

```python
from supreme_terminal_agent.core import Brain
```

### Constructor

```python
Brain()
```

### Methods

#### `async initialize()`
Initializes the cognition, reasoning, and planning subsystems.

#### `async process(input_data: str) -> Plan`
Processes input through the full pipeline: cognition -> reasoning -> planning.

## Config

Singleton configuration manager.

```python
from supreme_terminal_agent.config import Config
```

### Methods

#### `load(path: str) -> Config`
Loads configuration from a YAML file. Environment variables in `${VAR}` format are expanded automatically.

#### `get(key: str, default: Any) -> Any`
Gets a configuration value by dot-notation key (e.g., `ai.provider`).

#### `set(key: str, value: Any)`
Sets a configuration value by dot-notation key.

## StateMachine

Finite state machine for agent lifecycle management.

```python
from supreme_terminal_agent.core import StateMachine, AgentState
```

### States

- `AgentState.INIT` – Initializing
- `AgentState.IDLE` – Ready and waiting
- `AgentState.PROCESSING` – Executing a task
- `AgentState.ERROR` – Error state
- `AgentState.SHUTDOWN` – Shutting down

### Methods

#### `transition_to(new_state: AgentState) -> bool`
Attempts to transition to the given state. Returns `True` if the transition was valid and successful.

#### `add_transition(from_state, to_state, condition=None)`
Registers a valid state transition with an optional condition function.

## PriorityEngine

Priority-based task queue.

```python
from supreme_terminal_agent.core import PriorityEngine
```

### Methods

#### `add(item: str, priority: int)`
Adds an item with the given priority. Higher values are processed first.

#### `pop() -> Optional[str]`
Returns and removes the highest-priority item, or `None` if the queue is empty.

## InferenceEngine

Rule-based inference engine.

```python
from supreme_terminal_agent.core import InferenceEngine
```

### Methods

#### `add_rule(rule)`
Registers an inference rule.

#### `add_fact(key, value)`
Adds a fact to the knowledge base.

#### `infer(query) -> Any`
Applies rules to answer a query based on known facts.

## SelfMonitor

Runtime metrics and monitoring.

```python
from supreme_terminal_agent.core import SelfMonitor
```

### Methods

#### `record(metric: str, value: float)`
Records a metric value.

#### `get_uptime() -> float`
Returns agent uptime in seconds.

#### `get_metrics() -> Dict`
Returns all recorded metrics as a dictionary.

## SelfHealer

Automatic error recovery.

```python
from supreme_terminal_agent.core import SelfHealer
```

### Methods

#### `register_procedure(error_type: str, procedure)`
Registers a recovery procedure for a specific error type.

#### `async heal(error) -> bool`
Attempts to recover from the given error using registered procedures.

## FailoverHandler

Graceful degradation with fallback chains.

```python
from supreme_terminal_agent.core import FailoverHandler
```

### Methods

#### `add_fallback(fallback_fn)`
Adds a fallback function to the chain.

#### `async execute_with_failover(primary_fn, *args, **kwargs)`
Executes the primary function, falling back through registered fallbacks on failure.

## RecoveryManager

State persistence and recovery.

```python
from supreme_terminal_agent.core import RecoveryManager
```

### Methods

#### `save_checkpoint(state)`
Saves a state checkpoint.

#### `restore_latest() -> Any`
Restores the most recent checkpoint, or `None` if none exist.

## GoalManager

Hierarchical goal management.

```python
from supreme_terminal_agent.core import GoalManager, Goal, GoalStatus
```

### Methods

#### `add_goal(goal: Goal)`
Registers a new goal.

#### `get_active_goals() -> List[Goal]`
Returns all goals with status `ACTIVE`.

## TaskDecomposer

Task breakdown into subtasks.

```python
from supreme_terminal_agent.core import TaskDecomposer
```

### Methods

#### `decompose(goal: str) -> Task`
Breaks a high-level goal into a tree of tasks.

#### `add_subtask(parent: Task, name: str) -> Task`
Adds a subtask to a parent task.

## Heartbeat

Health monitoring heartbeat.

```python
from supreme_terminal_agent.core import Heartbeat
```

### Methods

#### `start()`
Starts the heartbeat.

#### `stop()`
Stops the heartbeat.

#### `beat()`
Records a heartbeat timestamp.

#### `is_alive -> bool`
Returns whether the heartbeat is within the expected interval.

## Watchdog

System watchdog with timeout detection.

```python
from supreme_terminal_agent.core import Watchdog
```

### Methods

#### `start()`
Starts the watchdog thread.

#### `feed()`
Resets the watchdog timer.

#### `stop()`
Stops the watchdog thread.

# Installation

This guide covers installing the Supreme Terminal AI Agent on various platforms and environments.

## Standard Installation

### Via pip (Recommended)

```bash
pip install supreme-terminal-agent
```

To install with specific extras:

```bash
# AI provider support
pip install supreme-terminal-agent[openai]
pip install supreme-terminal-agent[anthropic]
pip install supreme-terminal-agent[gemini]

# All AI providers
pip install supreme-terminal-agent[all-ai]

# Development tools
pip install supreme-terminal-agent[dev]

# Full installation
pip install supreme-terminal-agent[all]
```

### From Source

```bash
git clone https://github.com/supreme-ai/supreme-terminal-agent.git
cd supreme-terminal-agent
python -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
```

## Platform-Specific Instructions

### Linux (Ubuntu/Debian)

```bash
sudo apt update
sudo apt install -y python3.11 python3.11-venv gcc build-essential
pip install supreme-terminal-agent
```

### Linux (RHEL/Fedora)

```bash
sudo dnf install python3.11 python3.11-devel gcc
pip install supreme-terminal-agent
```

### macOS

```bash
brew install python@3.11
pip install supreme-terminal-agent
```

### Windows (WSL2)

```bash
# Install WSL2 with Ubuntu from Microsoft Store
# Then follow Linux instructions above
```

## Docker Installation

### Using Pre-built Image

```bash
docker pull supreme-ai/terminal-agent:latest
docker run -it --rm \
  -v ~/.config/supreme-terminal:/app/config \
  -v ~/.supreme-terminal:/app/data \
  supreme-ai/terminal-agent:latest
```

### Building Locally

```bash
git clone https://github.com/supreme-ai/supreme-terminal-agent.git
cd supreme-terminal-agent
docker build -t supreme-terminal-agent .
docker run -it --rm supreme-terminal-agent
```

See the [Docker Guide](guides/docker_guide.md) for advanced Docker usage.

## Kubernetes Deployment

```bash
kubectl apply -f deployment/kubernetes/deployment.yaml
kubectl apply -f deployment/kubernetes/service.yaml
```

See the [Kubernetes Guide](guides/kubernetes_deployment.md) for production deployment details.

## Systemd Service

```bash
sudo cp deployment/systemd/supreme-terminal.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable supreme-terminal
sudo systemctl start supreme-terminal
```

## Verifying Installation

```bash
terminal-agent --version
```

Expected output: `Supreme Terminal AI Agent v1.0.0`

## Troubleshooting

### Permission Errors

Ensure the installation directory is writable or use a virtual environment:

```bash
python -m venv ~/supreme-terminal-env
source ~/supreme-terminal-env/bin/activate
pip install supreme-terminal-agent
```

### Missing Dependencies

If you encounter build errors for native extensions, install system packages:

```bash
# Ubuntu/Debian
sudo apt install build-essential python3-dev

# macOS
xcode-select --install
```

See the [Troubleshooting Guide](troubleshooting.md) for more issues.

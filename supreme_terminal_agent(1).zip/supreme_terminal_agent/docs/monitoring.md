# Monitoring

The Supreme Terminal AI Agent provides comprehensive monitoring, metrics, logging, and alerting capabilities.

## Monitoring Architecture

```
┌──────────────────────────────────────────────────────┐
│                   Agent Instance                      │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────┐   │
│  │  Metrics  │  │  Logging │  │  Health Checks    │   │
│  └────┬─────┘  └────┬─────┘  └────────┬──────────┘   │
│       │              │                 │              │
└───────┼──────────────┼─────────────────┼──────────────┘
        │              │                 │
        ▼              ▼                 ▼
┌──────────────────────────────────────────────────────┐
│                  Export Layer                         │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────┐   │
│  │Prometheus│  │   File   │  │  Elasticsearch    │   │
│  └──────────┘  └──────────┘  └───────────────────┘   │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────┐   │
│  │  StatsD  │  │  Syslog  │  │   OpenTelemetry   │   │
│  └──────────┘  └──────────┘  └───────────────────┘   │
└──────────────────────────────────────────────────────┘
```

## Metrics

### Built-in Metrics

The agent collects metrics across all subsystems:

```yaml
monitoring:
  metrics:
    enabled: true
    export_interval: 15
    exporter: prometheus    # prometheus, statsd, datadog, custom
    prometheus_port: 9090
    collect_cpu: true
    collect_memory: true
    collect_disk: true
    collect_network: true
```

### Available Metrics

| Metric | Type | Description |
|---|---|---|
| `agent_uptime_seconds` | Gauge | Agent uptime in seconds |
| `agent_status` | Gauge | Current agent status (0=init, 1=idle, 2=processing, 3=error) |
| `commands_executed_total` | Counter | Total commands executed |
| `commands_failed_total` | Counter | Failed commands |
| `commands_duration_seconds` | Histogram | Command execution duration |
| `ai_requests_total` | Counter | Total AI requests |
| `ai_requests_duration_seconds` | Histogram | AI request latency |
| `ai_tokens_total` | Counter | Total tokens consumed |
| `ai_cache_hits_total` | Counter | AI cache hits |
| `ai_cache_misses_total` | Counter | AI cache misses |
| `terminal_sessions_active` | Gauge | Active terminal sessions |
| `terminal_sessions_total` | Counter | Total sessions created |
| `memory_usage_bytes` | Gauge | Memory usage in bytes |
| `memory_queries_total` | Counter | Total memory queries |
| `cpu_usage_percent` | Gauge | CPU usage percentage |
| `process_count` | Gauge | Number of managed processes |
| `event_bus_messages` | Counter | Total event bus messages |
| `plugin_errors_total` | Counter | Plugin execution errors |
| `security_violations_total` | Counter | Security policy violations |
| `sandbox_escapes_total` | Counter | Attempted sandbox escapes |

### Custom Metrics

Register custom metrics from plugins or tools:

```python
from supreme_terminal_agent.monitoring import metrics

# Create (or get) metric
counter = metrics.counter("my_plugin.operations", "Total operations")
gauge = metrics.gauge("my_plugin.processing", "Currently processing")
histogram = metrics.histogram("my_plugin.duration", "Operation duration")

# Record values
counter.inc()
counter.inc(5)
gauge.set(42)
histogram.observe(0.5)
```

## Logging

### Configuration

```yaml
logging:
  level: INFO
  format: json              # json, text, structured
  file: /var/log/supreme-terminal/agent.log
  max_size_mb: 100
  backup_count: 10
  compress: true

  # Component-specific levels
  components:
    supreme_terminal_agent.ai: DEBUG
    supreme_terminal_agent.security: WARNING
    supreme_terminal_agent.plugins: INFO
    supreme_terminal_agent.terminal: ERROR

  # Handlers
  handlers:
    - type: file
      level: INFO
      path: /var/log/supreme-terminal/agent.log
    - type: stdout
      level: WARNING
      format: text
    - type: syslog
      level: ERROR
      address: /dev/log
    - type: elasticsearch
      level: INFO
      hosts: ["http://elasticsearch:9200"]
      index: "supreme-terminal-logs"
```

### Structured Logging

Logs are structured JSON by default:

```json
{
  "timestamp": "2025-01-15T10:30:00.123Z",
  "level": "INFO",
  "logger": "supreme_terminal_agent.ai.engine",
  "message": "AI request completed",
  "session_id": "sess_abc123",
  "request_id": "req_xyz789",
  "model": "gpt-4",
  "tokens_input": 512,
  "tokens_output": 128,
  "duration_ms": 2340,
  "cache_hit": false
}
```

### Log Queries

```bash
# View recent logs
> logs --tail 50

# Filter by level
> logs --level ERROR

# Search within logs
> logs --search "timeout"

# Filter by time range
> logs --since "2h"
> logs --since "2025-01-15" --until "2025-01-16"

# Filter by component
> logs --component ai

# Follow logs in real-time
> logs --follow

# Export logs
> logs --export logs.json
```

## Health Checks

### Configuration

```yaml
monitoring:
  health:
    endpoint: /health
    port: 9091
    interval: 30
    timeout: 5
    checks:
      - name: agent_alive
        critical: true
      - name: ai_engine
        critical: true
        timeout: 10
      - name: terminal_pool
        critical: false
      - name: memory_usage
        critical: true
        threshold: 90
      - name: disk_space
        critical: true
        threshold: 85
      - name: database_connection
        critical: true
```

### Health Check Response

```json
{
  "status": "healthy",
  "timestamp": "2025-01-15T10:30:00Z",
  "uptime": 86400,
  "checks": {
    "agent_alive": {"status": "passed", "duration_ms": 1},
    "ai_engine": {"status": "passed", "duration_ms": 230},
    "terminal_pool": {"status": "passed", "duration_ms": 5},
    "memory_usage": {"status": "passed", "duration_ms": 2, "value": 45},
    "disk_space": {"status": "passed", "duration_ms": 3, "value": 62},
    "database_connection": {"status": "passed", "duration_ms": 15}
  }
}
```

## Alerting

### Configuration

```yaml
monitoring:
  alerting:
    enabled: true
    provider: webhook     # webhook, email, slack, pagerduty, custom
    slack_webhook: https://hooks.slack.com/services/...
    pagerduty_key: "${PAGERDUTY_KEY}"
    email:
      smtp_host: smtp.example.com
      smtp_port: 587
      from: agent@example.com
      to: ["admin@example.com"]

    rules:
      - name: high_error_rate
        condition: "commands_failed_total / commands_executed_total > 0.1"
        duration: 5m
        severity: warning
        channels: [slack, email]

      - name: ai_latency_high
        condition: "ai_requests_duration_seconds_p99 > 10"
        duration: 2m
        severity: critical
        channels: [slack, pagerduty]

      - name: memory_critical
        condition: "memory_usage_percent > 90"
        duration: 1m
        severity: critical
        channels: [slack, pagerduty]

      - name: security_violation
        condition: "security_violations_total > 0"
        duration: 0m
        severity: critical
        channels: [slack, email, pagerduty]
```

## Distributed Tracing

```yaml
monitoring:
  tracing:
    enabled: true
    provider: jaeger
    jaeger_endpoint: http://jaeger:14268/api/traces
    sample_rate: 0.1
    tags:
      environment: production
      version: "1.0.0"
```

## Status Command

```bash
> status
```

Output:

```
Agent Status: Running
Uptime: 2d 14h 32m
Active Sessions: 3
Commands Today: 1,247
AI Requests Today: 892
Memory Usage: 342 MB / 2 GB (17%)
CPU Usage: 23%
Process Count: 12
```

## Metrics Dashboard

Export metrics to Prometheus and visualize with Grafana:

```yaml
monitoring:
  metrics:
    exporter: prometheus
    prometheus_port: 9090
```

Prometheus scrape config:

```yaml
scrape_configs:
  - job_name: 'supreme-terminal'
    static_configs:
      - targets: ['localhost:9090']
```

See the [Monitoring Guide](guides/monitoring_guide.md) for advanced monitoring setup and Grafana dashboard templates.

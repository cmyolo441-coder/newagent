# Kubernetes Deployment Guide

Deploy the Supreme Terminal AI Agent on Kubernetes for production-grade orchestration.

## Prerequisites

- Kubernetes 1.24+
- Helm 3.0+ (optional)
- kubectl configured

## Quick Start

```bash
kubectl apply -f deployment/kubernetes/namespace.yaml
kubectl apply -f deployment/kubernetes/
```

## Configuration

### Namespace

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: supreme-terminal
```

### Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: supreme-terminal-agent
  namespace: supreme-terminal
spec:
  replicas: 3
  selector:
    matchLabels:
      app: supreme-terminal-agent
  template:
    metadata:
      labels:
        app: supreme-terminal-agent
    spec:
      containers:
      - name: agent
        image: supreme-ai/terminal-agent:1.0.0
        ports:
        - containerPort: 8080
          name: api
        - containerPort: 9090
          name: metrics
        env:
        - name: SUPREME_TERMINAL_AI_API_KEY
          valueFrom:
            secretKeyRef:
              name: ai-credentials
              key: api-key
        - name: SUPREME_TERMINAL_SECURITY_ENCRYPTION_KEY
          valueFrom:
            secretKeyRef:
              name: security-keys
              key: encryption-key
        volumeMounts:
        - name: config
          mountPath: /app/config
        - name: data
          mountPath: /app/data
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 15
        readinessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 10
      volumes:
      - name: config
        configMap:
          name: supreme-terminal-config
      - name: data
        persistentVolumeClaim:
          claimName: supreme-terminal-data
```

### Service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: supreme-terminal-agent
  namespace: supreme-terminal
spec:
  selector:
    app: supreme-terminal-agent
  ports:
  - port: 8080
    targetPort: 8080
    name: api
  - port: 9090
    targetPort: 9090
    name: metrics
```

### ConfigMap

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: supreme-terminal-config
  namespace: supreme-terminal
data:
  config.yaml: |
    agent:
      name: "${HOSTNAME}"
    logging:
      level: INFO
      format: json
    security:
      sandbox: true
```

### Secrets

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: ai-credentials
  namespace: supreme-terminal
type: Opaque
stringData:
  api-key: "sk-..."
```

### PersistentVolumeClaim

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: supreme-terminal-data
  namespace: supreme-terminal
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
```

## Helm Chart

```bash
# Add repository
helm repo add supreme-terminal https://helm.supreme-ai.com

# Install
helm install supreme-terminal-agent supreme-terminal/supreme-terminal-agent \
  --namespace supreme-terminal \
  --create-namespace \
  --set ai.apiKey=sk-...
```

## Horizontal Pod Autoscaling

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: supreme-terminal-agent
  namespace: supreme-terminal
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: supreme-terminal-agent
  minReplicas: 3
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

## Ingress

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: supreme-terminal
  namespace: supreme-terminal
spec:
  tls:
  - hosts:
    - terminal.example.com
    secretName: terminal-tls
  rules:
  - host: terminal.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: supreme-terminal-agent
            port:
              number: 8080
```

## StatefulSet (for Stateful Deployments)

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: supreme-terminal-agent
  namespace: supreme-terminal
spec:
  serviceName: supreme-terminal-agent
  replicas: 3
  selector:
    matchLabels:
      app: supreme-terminal-agent
  template:
    ...
  volumeClaimTemplates:
  - metadata:
      name: data
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 10Gi
```

## Redis Backend

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: supreme-terminal-redis
  namespace: supreme-terminal
spec:
  replicas: 3
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        ports:
        - containerPort: 6379
```

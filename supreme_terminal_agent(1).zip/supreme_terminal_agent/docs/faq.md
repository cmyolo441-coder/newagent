# Frequently Asked Questions

## General

### What is the Supreme Terminal AI Agent?

It is an AI-powered terminal intelligence platform that combines deep terminal emulation, multi-provider AI orchestration, autonomous planning and reasoning, and a plugin-based extensible architecture into a self-aware command-line co-pilot.

### Do I need an AI API key to use the agent?

Basic terminal emulation and command execution work without an AI provider. However, AI features such as natural language processing, command explanations, and intelligent task planning require at least one configured AI provider (OpenAI, Anthropic, Google Gemini, or a local LLM).

### What operating systems are supported?

Linux (primary, all major distributions), macOS, and Windows via WSL2. Native Windows support is limited due to PTY requirements.

### Is this a replacement for my shell?

No. The agent integrates with your existing shell (bash, zsh, fish, etc.) and enhances it with AI capabilities. You can always use your shell directly.

## Installation & Setup

### How do I install the agent?

```bash
pip install supreme-terminal-agent
```

See the [Installation Guide](installation.md) for platform-specific instructions.

### Can I run the agent in Docker?

Yes. We provide a Dockerfile and docker-compose.yml. See the [Docker Guide](guides/docker_guide.md) for details.

### How do I configure AI providers?

Set your API key via environment variable or configuration file:

```bash
export OPENAI_API_KEY="sk-..."
```

Or in `config.yaml`:

```yaml
ai:
  provider: openai
  api_key: "${OPENAI_API_KEY}"
```

## Usage

### How do I run a shell command?

Use the `run:` prefix:

```
> run: ls -la
```

Or just type a command directly and the AI will interpret it.

### Can the agent execute dangerous commands?

The agent has several safety mechanisms:
- Sandboxing isolates command execution
- Command validation blocks dangerous patterns
- Destructive commands require confirmation
- Audit logging records all actions

### How does the agent handle multiple sessions?

Each session is isolated with its own terminal, history, and context. Sessions persist in the background when detached.

```
> sessions create work
> sessions attach work
> detach
```

### Can I use the agent offline?

Basic terminal features work offline. AI features require network access to AI providers unless you run a local model (e.g., through Ollama or LM Studio).

## Technical

### What AI providers are supported?

OpenAI (GPT-4, GPT-3.5), Anthropic (Claude 3), Google (Gemini), and any OpenAI-compatible API (local models via Ollama, vLLM, etc.).

### How does the agent ensure security?

Security is implemented at multiple layers: sandboxed execution, command validation, audit logging, encryption, secrets management, authentication, and RBAC.

### What is the plugin system?

Plugins extend the agent's functionality. They can add commands, tools, event hooks, and integrate with external services. See [Plugin Development](plugin_development.md).

### Can I create custom tools?

Yes. The tool system allows you to register custom Python functions that the AI can invoke. See [Tool Development](tool_development.md).

### Does the agent support automation?

Yes. You can create pipelines, event-driven triggers, and scheduled tasks. See the [Automation Tutorial](tutorials/automation.md).

## Performance

### How much memory does the agent use?

Base usage is approximately 200-500 MB. With AI features and vector memory, usage can range from 500 MB to 2 GB depending on configuration and workload.

### How many concurrent sessions are supported?

This depends on system resources. A typical server can support 50-100 concurrent sessions. See [Scaling](scaling.md) for performance benchmarks.

### Can I run the agent in production?

Yes. The agent is designed for production use with support for Docker, Kubernetes, systemd, monitoring, audit logging, and high availability.

## Troubleshooting

### The agent won't start. What should I do?

Run `terminal-agent --debug` to see diagnostic output. Check Python version (`python --version` must be 3.11+). Validate configuration with `terminal-agent config validate`.

### AI responses are slow or failing.

Check your API key, network connectivity, and rate limits. Use `> metrics ai` to see AI engine statistics. Try configuring a fallback provider.

### How do I reset the agent?

```bash
terminal-agent --reset
```

This clears session data and memory while preserving configuration files.

### Where are logs stored?

Default location: `data/logs/agent/agent.log`. Configured via `logging.file` in the config.

## Development

### How do I contribute?

See [Contributing](contributing.md) and [Code of Conduct](code_of_conduct.md). We welcome pull requests, bug reports, and feature requests.

### How do I build from source?

```bash
git clone https://github.com/supreme-ai/supreme-terminal-agent.git
cd supreme-terminal-agent
pip install -r requirements.txt
pip install -e .
```

### What's the roadmap?

See the [Roadmap](roadmap.md) for planned features and improvements.

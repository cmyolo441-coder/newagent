# Quick Start

Get the Supreme Terminal AI Agent running in under 5 minutes.

## 1. Install

```bash
pip install supreme-terminal-agent
```

## 2. Set Up AI Provider

Export your API key:

```bash
export OPENAI_API_KEY="sk-..."
```

Or configure in `~/.config/supreme-terminal/config.yaml`:

```yaml
ai:
  provider: openai
  api_key: "${OPENAI_API_KEY}"
```

## 3. Launch the Agent

```bash
terminal-agent
```

## 4. Run Your First Commands

### Natural Language Commands

```
> find all Python files modified in the last week
```

The agent will translate this into a shell command, execute it, and explain the results.

### Direct Shell Commands

```
> run: ls -la
```

Prefix commands with `run:` to execute them directly in the shell.

### Multi-Step Tasks

```
> archive the logs folder, compress it, and upload to a remote server
```

The agent breaks complex requests into sequential steps and executes them with your approval.

### Ask for Explanations

```
> explain: git rebase -i HEAD~3
```

Get AI-powered explanations of any command or concept.

## 5. Use the Built-in Help

```
> help
```

Lists all available commands, tools, and features.

## 6. Exit

```
> exit
```

Or press `Ctrl+D` to quit the agent.

## What's Next?

- [Installation Guide](installation.md) – Detailed setup for all platforms
- [User Guide](user_guide.md) – Comprehensive feature walkthrough
- [Tutorials](tutorials/basic_usage.md) – Step-by-step tutorials
- [CLI Reference](cli_reference.md) – All command-line options

# Configuration

The Supreme Terminal AI Agent is configured through YAML files, environment variables, and command-line flags. Configuration is loaded hierarchically, with more specific sources overriding general ones.

## Configuration Files

### Default Locations

| Platform | Config Path |
|---|---|
| Linux | `~/.config/supreme-terminal/config.yaml` |
| macOS | `~/Library/Application Support/supreme-terminal/config.yaml` |
| Windows | `%APPDATA%\supreme-terminal\config.yaml` |
| Custom | `$SUPREME_TERMINAL_CONFIG` environment variable |

### Default Configuration

The agent ships with sensible defaults defined in `config/defaults/default_config.yaml`:

```yaml
agent:
  name: SupremeTerminalAI
  version: "1.0.0"
  debug: false

terminal:
  emulator: xterm-256color
  scrollback: 10000

ai:
  provider: openai
  model: gpt-4

security:
  sandbox: true
  audit: true

execution:
  timeout: 30
  max_processes: 100

logging:
  level: INFO
  file: data/logs/agent/agent.log
```

## Configuration Hierarchy

Configuration is resolved in the following order (later sources override earlier ones):

1. Built-in defaults
2. System-wide config (`/etc/supreme-terminal/config.yaml`)
3. User config (`~/.config/supreme-terminal/config.yaml`)
4. Local config (`./.supreme-terminal.yaml`)
5. Environment variables
6. Command-line flags

## Key Configuration Sections

### Agent Settings

```yaml
agent:
  name: my-agent
  debug: false
  log_level: INFO
  data_dir: /var/lib/supreme-terminal
```

### Terminal

```yaml
terminal:
  shell: /bin/bash
  emulator: xterm-256color
  scrollback: 100000
  max_processes: 500
  default_rows: 24
  default_cols: 80
  cursor_style: block
  bell_style: visual
```

### AI Provider

```yaml
ai:
  provider: openai
  model: gpt-4
  api_key: "${OPENAI_API_KEY}"
  temperature: 0.7
  max_tokens: 2048
  top_p: 0.95
  fallback_provider: anthropic
  rate_limit: 60
  cache_enabled: true
```

Multiple providers can be configured:

```yaml
ai:
  providers:
    primary:
      provider: openai
      model: gpt-4
    fallback:
      provider: anthropic
      model: claude-3-opus
    local:
      provider: ollama
      model: llama3
```

### Security

```yaml
security:
  sandbox: true
  sandbox_type: docker
  audit: true
  audit_log: /var/log/supreme-terminal/audit.log
  encryption: true
  encryption_key: "${ENCRYPTION_KEY}"
  allowed_commands:
    - ls
    - cat
    - grep
  blocked_commands:
    - rm -rf /
    - dd
  command_validation: strict
  session_timeout: 3600
```

### Execution

```yaml
execution:
  timeout: 30
  max_processes: 100
  max_memory_mb: 512
  working_dir: /tmp
  env_whitelist:
    - PATH
    - HOME
    - USER
  confirm_destructive: true
```

### Logging

```yaml
logging:
  level: INFO
  format: json
  file: /var/log/supreme-terminal/agent.log
  max_size_mb: 100
  backup_count: 10
  components:
    ai: DEBUG
    terminal: INFO
    security: WARNING
```

## Environment Variables

All configuration options can be set via environment variables using the prefix `SUPREME_TERMINAL_`:

```bash
export SUPREME_TERMINAL_AI_PROVIDER=anthropic
export SUPREME_TERMINAL_AI_MODEL=claude-3-opus
export SUPREME_TERMINAL_SECURITY_SANDBOX=true
export SUPREME_TERMINAL_EXECUTION_TIMEOUT=60
```

Nested keys are separated by underscores. See the [Environment Variables Reference](reference/environment_variables.md) for the complete list.

## Dynamic Reconfiguration

Configuration changes can be applied at runtime without restarting:

```bash
> config set ai.temperature 0.9
> config set security.sandbox false
> config get ai.provider
> config reload
```

## Configuration Validation

The agent validates configuration at startup and logs warnings for invalid or deprecated options. Use the `config validate` command to check your configuration manually:

```bash
> config validate
```

See the [Configuration Options Reference](reference/configuration_options.md) for all available settings.

# CLI Reference

The Supreme Terminal AI Agent provides a comprehensive command-line interface for launching and controlling the agent.

## Synopsis

```bash
terminal-agent [OPTIONS] [COMMAND]
```

## Global Options

| Option | Description |
|---|---|
| `--version` | Show version information and exit |
| `--help` | Show help message and exit |
| `--config FILE` | Path to configuration file |
| `--debug` | Enable debug output |
| `--verbose` | Enable verbose logging |
| `--quiet` | Suppress non-essential output |
| `--log-level LEVEL` | Set log level (DEBUG, INFO, WARNING, ERROR) |
| `--log-file FILE` | Path to log file |

## Mode Options

| Option | Description |
|---|---|
| `--mode MODE` | Operating mode: `interactive`, `daemon`, `oneshot`, `script` |
| `--daemon` | Run as background daemon (equivalent to `--mode daemon`) |
| `--connect` | Connect to a running daemon instance |
| `--exec COMMAND` | Execute a single command and exit (one-shot mode) |
| `--file FILE` | Execute commands from a file (script mode) |
| `--session NAME` | Session name for session management |

## Terminal Options

| Option | Description |
|---|---|
| `--shell PATH` | Shell executable path (default: `/bin/bash`) |
| `--term TYPE` | Terminal type (default: `xterm-256color`) |
| `--rows N` | Terminal rows (default: 24) |
| `--cols N` | Terminal columns (default: 80) |
| `--scrollback N` | Scrollback buffer size (default: 10000) |

## AI Options

| Option | Description |
|---|---|
| `--ai-provider NAME` | AI provider name (openai, anthropic, gemini, etc.) |
| `--ai-model NAME` | AI model name |
| `--ai-temperature FLOAT` | AI temperature (0.0-2.0) |
| `--ai-max-tokens N` | Maximum tokens per response |
| `--ai-timeout SECONDS` | AI request timeout |

## Security Options

| Option | Description |
|---|---|
| `--sandbox BOOL` | Enable/disable sandboxing |
| `--audit BOOL` | Enable/disable audit logging |
| `--allow COMMANDS` | Comma-separated allowed commands |
| `--block COMMANDS` | Comma-separated blocked commands |
| `--no-confirm` | Skip confirmation for destructive commands |

## Network Options

| Option | Description |
|---|---|
| `--host ADDRESS` | API server host (default: 127.0.0.1) |
| `--port PORT` | API server port (default: 8765) |
| `--rest-port PORT` | REST API port (default: 8080) |
| `--grpc-port PORT` | gRPC API port (default: 50051) |
| `--ws-port PORT` | WebSocket port (default: 8766) |
| `--tls-cert FILE` | TLS certificate file |
| `--tls-key FILE` | TLS key file |

## Automation Options

| Option | Description |
|---|---|
| `--workflow FILE` | Run a workflow file |
| `--pipeline NAME` | Run a named pipeline |
| `--trigger NAME` | Run a named trigger |

## Configuration Options

| Option | Description |
|---|---|
| `--config-dir DIR` | Configuration directory |
| `--data-dir DIR` | Data directory |
| `--no-env` | Ignore environment variables |
| `--no-defaults` | Ignore default configuration |

## Subcommands

### `config`

Manage configuration:

```bash
terminal-agent config get <key>
terminal-agent config set <key> <value>
terminal-agent config list
terminal-agent config validate
terminal-agent config reload
```

### `session`

Manage sessions:

```bash
terminal-agent session list
terminal-agent session attach <name>
terminal-agent session close <name>
terminal-agent session destroy <name>
```

### `plugin`

Manage plugins:

```bash
terminal-agent plugin list
terminal-agent plugin install <name>
terminal-agent plugin uninstall <name>
terminal-agent plugin enable <name>
terminal-agent plugin disable <name>
terminal-agent plugin update <name>
```

### `tool`

Manage tools:

```bash
terminal-agent tool list
terminal-agent tool register <name> <path>
terminal-agent tool unregister <name>
```

### `pipeline`

Manage pipelines:

```bash
terminal-agent pipeline list
terminal-agent pipeline create <name> --steps <steps>
terminal-agent pipeline run <name>
terminal-agent pipeline delete <name>
```

### `trigger`

Manage triggers:

```bash
terminal-agent trigger list
terminal-agent trigger create <name> --event <event> --action <action>
terminal-agent trigger delete <name>
```

## Exit Codes

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | General error |
| 2 | Configuration error |
| 3 | Connection error |
| 4 | Permission denied |
| 5 | Timeout |
| 6 | Invalid input |

## Environment Variables

All CLI options can be set via environment variables with the `SUPREME_TERMINAL_` prefix:

```bash
export SUPREME_TERMINAL_MODE=daemon
export SUPREME_TERMINAL_AI_PROVIDER=anthropic
export SUPREME_TERMINAL_DEBUG=true
terminal-agent
```

See the [Environment Variables Reference](reference/environment_variables.md) for the complete list.

## Examples

```bash
# Start interactive session
terminal-agent

# Run in daemon mode
terminal-agent --daemon

# Execute single command
terminal-agent --exec "git log --oneline -5"

# Run with custom config
terminal-agent --config ~/my-config.yaml

# Start with specific AI model
terminal-agent --ai-provider anthropic --ai-model claude-3-opus

# Enable debug logging
terminal-agent --debug --log-level DEBUG

# Connect to running daemon
terminal-agent --connect

# Run script from file
terminal-agent --file commands.txt
```

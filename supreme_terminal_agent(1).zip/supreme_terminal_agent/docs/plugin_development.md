# Plugin Development

The Supreme Terminal AI Agent features a comprehensive plugin system that allows developers to extend functionality in a modular, sandboxed manner.

## Plugin Architecture

Plugins are Python packages that implement the plugin interface and are loaded dynamically at runtime. The plugin system provides:

- **Lifecycle Management** – Install, load, enable, disable, uninstall, update
- **Dependency Resolution** – Automatic resolution of inter-plugin dependencies
- **Sandboxing** – Isolated execution environment for security
- **Event Hooks** – Subscribe to agent lifecycle and command events
- **Configuration** – Plugin-specific configuration with validation
- **Versioning** – Semantic versioning with compatibility checking

## Plugin Structure

A plugin is a Python package with the following structure:

```
my-plugin/
├── __init__.py
├── plugin.yaml              # Plugin manifest
├── hooks.py                 # Event hooks (optional)
├── commands.py              # Custom commands (optional)
├── tools.py                 # Custom tools (optional)
└── config.yaml              # Default configuration (optional)
```

### Plugin Manifest (`plugin.yaml`)

```yaml
name: my-plugin
version: 1.0.0
description: A useful plugin for the Supreme Terminal Agent
author: Your Name
license: MIT

supreme-terminal:
  min_version: 1.0.0
  max_version: 2.0.0

dependencies:
  - another-plugin>=1.0.0

hooks:
  - post_command
  - pre_execute

commands:
  - my-command

tools:
  - my-tool

config:
  setting1: default_value
  setting2: 42
```

## Creating a Plugin

### 1. Define the Plugin Class

```python
# __init__.py
from supreme_terminal_agent.plugins.base import BasePlugin

class MyPlugin(BasePlugin):
    name = "my-plugin"
    version = "1.0.0"
    description = "A useful plugin"

    async def on_load(self):
        """Called when plugin is loaded."""
        self.logger.info(f"{self.name} loaded")

    async def on_enable(self):
        """Called when plugin is enabled."""
        self.logger.info(f"{self.name} enabled")

    async def on_disable(self):
        """Called when plugin is disabled."""
        self.logger.info(f"{self.name} disabled")

    async def on_uninstall(self):
        """Called when plugin is uninstalled."""
        self.logger.info(f"{self.name} uninstalled")
```

### 2. Add Event Hooks

```python
# hooks.py
from supreme_terminal_agent.hooks import hook

@hook("post_command")
async def on_post_command(context):
    command = context.get("command", "")
    result = context.get("result", {})
    print(f"Executed: {command} -> {result.get('success')}")
```

### 3. Register Custom Commands

```python
# commands.py
from supreme_terminal_agent.commands import BaseCommand

class MyCommand(BaseCommand):
    name = "my-command"
    description = "Does something useful"

    async def execute(self, args, context):
        # Your implementation
        return {"success": True, "output": "Done!"}
```

### 4. Register Custom Tools

```python
# tools.py
from supreme_terminal_agent.tools import BaseTool

class MyTool(BaseTool):
    name = "my-tool"
    description = "A custom tool"
    parameters = {
        "input": {"type": "string", "description": "Input value"}
    }

    async def execute(self, input: str) -> dict:
        result = f"Processed: {input}"
        return {"result": result}
```

## Installing a Plugin

### From Local Path

```bash
terminal-agent plugin install /path/to/my-plugin
```

### From Registry

```bash
terminal-agent plugin install my-plugin
```

### From Git

```bash
terminal-agent plugin install https://github.com/user/my-plugin.git
```

### From PyPI

```bash
terminal-agent plugin install my-plugin --source pypi
```

## Plugin Configuration

Plugins can access configuration via `self.config`:

```python
class MyPlugin(BasePlugin):
    async def on_load(self):
        setting = self.config.get("setting1", "default")
        timeout = self.config.get("timeout", 30)
```

Users can override plugin config:

```yaml
# config.yaml
plugins:
  my-plugin:
    setting1: custom_value
    timeout: 60
```

## Plugin API

### BasePlugin Methods

| Method | Description |
|---|---|
| `on_load()` | Called when plugin is loaded into memory |
| `on_enable()` | Called when plugin is enabled |
| `on_disable()` | Called when plugin is disabled |
| `on_install()` | Called after plugin is installed |
| `on_uninstall()` | Called before plugin is uninstalled |
| `on_update(old_version)` | Called after plugin is updated |

### Available Hooks

| Hook Point | Description |
|---|---|
| `pre_init` | Before agent initialization |
| `post_init` | After agent initialization |
| `pre_start` | Before agent starts |
| `post_start` | After agent starts |
| `pre_stop` | Before agent stops |
| `post_stop` | After agent stops |
| `pre_shutdown` | Before agent shutdown |
| `post_shutdown` | After agent shutdown |
| `pre_command` | Before command execution |
| `post_command` | After command execution |
| `pre_execute` | Before shell execution |
| `post_execute` | After shell execution |
| `session_create` | When a session is created |
| `session_connect` | When a session connects |
| `session_disconnect` | When a session disconnects |
| `session_destroy` | When a session is destroyed |
| `session_restore` | When a session is restored |

### Plugin Services

Plugins can access agent services:

```python
class MyPlugin(BasePlugin):
    async def on_enable(self):
        # Access agent subsystems
        ai = self.services.ai
        terminal = self.services.terminal
        memory = self.services.memory
        security = self.services.security
        events = self.services.events

        # Register event listener
        events.subscribe("file.changed", self.on_file_changed)
```

## Best Practices

- Follow semantic versioning for your plugin
- Declare all dependencies explicitly in plugin.yaml
- Use the sandbox API for any file system or network access
- Register cleanup handlers in `on_disable()` and `on_uninstall()`
- Test your plugin with `plugin test` before distribution
- Keep plugins focused on a single concern
- Use the built-in logging system rather than print statements
- Handle configuration validation in `on_load()`

## Publishing

Plugins can be distributed as:

- **Python packages** on PyPI
- **Git repositories** with a plugin manifest
- **Directory archives** (tar.gz, zip)
- **Plugin registry** (self-hosted or official registry)

## Plugin Sandbox

By default, plugins run in a restricted environment:

- Access to agent APIs is controlled
- File system access is limited to plugin directories
- Network access requires explicit permissions
- System calls are intercepted and validated
- Resource usage is monitored and limited

Sandbox restrictions can be configured in the agent config:

```yaml
plugins:
  sandbox:
    enabled: true
    network_access: false
    filesystem_access: restricted
    max_memory_mb: 128
    max_execution_time: 30
```

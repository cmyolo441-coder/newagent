# Custom Tools Tutorial

Learn how to create and register custom tools for the Supreme Terminal AI Agent.

## Introduction to Tools

Tools are reusable Python functions that the agent can invoke. They extend the agent's capabilities with custom logic, external API integrations, or specialized data processing.

## Creating Your First Tool

### Basic Tool Structure

Create a file `my_tools.py`:

```python
from supreme_terminal_agent.tools import BaseTool

class HelloTool(BaseTool):
    name = "hello"
    description = "Says hello to someone"
    version = "1.0.0"
    category = "custom"

    parameters = {
        "name": {
            "type": "string",
            "description": "Name to greet",
            "required": True
        }
    }

    async def execute(self, name: str) -> dict:
        return {
            "success": True,
            "message": f"Hello, {name}!"
        }
```

### Registering the Tool

```python
from supreme_terminal_agent.tools import ToolRegistry

registry = ToolRegistry()
registry.register(HelloTool())
```

Or via CLI:

```
> tool register hello /path/to/my_tools.py:HelloTool
```

### Testing the Tool

```
> tool test hello --args '{"name": "Alice"}'
```

Output:
```json
{
  "success": true,
  "message": "Hello, Alice!"
}
```

## Tool with Complex Parameters

```python
class FileAnalyzerTool(BaseTool):
    name = "analyze_file"
    description = "Analyzes a file and returns metadata"
    version = "1.0.0"
    category = "filesystem"

    parameters = {
        "path": {
            "type": "string",
            "description": "Path to the file",
            "required": True
        },
        "include_checksum": {
            "type": "boolean",
            "description": "Whether to compute checksum",
            "default": False
        },
        "max_size_mb": {
            "type": "integer",
            "description": "Maximum file size in MB",
            "default": 100,
            "minimum": 1,
            "maximum": 10000
        }
    }

    async def execute(self, path: str, include_checksum: bool = False, max_size_mb: int = 100) -> dict:
        import os, hashlib

        if not os.path.exists(path):
            return {"success": False, "error": "File not found"}

        stat = os.stat(path)
        size_mb = stat.st_size / (1024 * 1024)

        if size_mb > max_size_mb:
            return {"success": False, "error": f"File too large ({size_mb:.1f} MB)"}

        result = {
            "success": True,
            "path": path,
            "size_bytes": stat.st_size,
            "size_mb": round(size_mb, 2),
            "modified": stat.st_mtime,
            "permissions": oct(stat.st_mode)[-3:]
        }

        if include_checksum:
            sha256 = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    sha256.update(chunk)
            result["sha256"] = sha256.hexdigest()

        return result
```

## Tool with External API Integration

```python
import aiohttp

class WeatherTool(BaseTool):
    name = "get_weather"
    description = "Gets current weather for a city"
    version = "1.0.0"
    category = "network"

    parameters = {
        "city": {
            "type": "string",
            "description": "City name",
            "required": True
        },
        "units": {
            "type": "string",
            "enum": ["metric", "imperial"],
            "default": "metric"
        }
    }

    async def execute(self, city: str, units: str = "metric") -> dict:
        api_key = self.config.get("weather_api_key")
        if not api_key:
            return {"success": False, "error": "API key not configured"}

        url = f"https://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": city,
            "units": units,
            "appid": api_key
        }

        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                if resp.status != 200:
                    return {"success": False, "error": f"API error: {resp.status}"}
                data = await resp.json()

                return {
                    "success": True,
                    "city": data["name"],
                    "temperature": data["main"]["temp"],
                    "humidity": data["main"]["humidity"],
                    "conditions": data["weather"][0]["description"],
                    "wind_speed": data["wind"]["speed"]
                }
```

## Tool Chaining

Tools can be chained together:

```python
from supreme_terminal_agent.tools import ToolChain

chain = ToolChain()
chain.add("file_search", pattern="*.log", directory="/var/log")
chain.add("analyze_file", path="{file_search.result.matches[0]}", include_checksum=True)
result = await chain.execute()
```

## Tool Lifecycle

```python
class MonitoredTool(BaseTool):
    cache_ttl = 60

    async def validate(self, **kwargs) -> bool:
        # Validate parameters before execution
        return all(kwargs.values())

    async def before_execute(self, **kwargs):
        self._start = time.time()
        self.logger.info(f"Starting {self.name}")

    async def after_execute(self, result: dict):
        elapsed = time.time() - self._start
        self.logger.info(f"Completed {self.name} in {elapsed:.2f}s")

    async def on_error(self, error: Exception):
        self.logger.error(f"Tool failed: {error}")
```

## Registering via Plugin

Include tools in a plugin's `tools.py`:

```python
from supreme_terminal_agent.plugins.base import BasePlugin
from supreme_terminal_agent.tools import BaseTool

class PluginTool(BaseTool):
    name = "plugin-tool"
    description = "Tool provided by plugin"

    async def execute(self, **kwargs):
        return {"result": "done"}

class MyPlugin(BasePlugin):
    name = "my-plugin"
    version = "1.0.0"

    async def on_load(self):
        self.register_tool(PluginTool())
```

## Best Practices

- Use descriptive names and descriptions so the AI can discover tools
- Validate all parameters explicitly
- Return structured dicts with success/error keys
- Handle errors gracefully with meaningful messages
- Use async/await for I/O operations
- Cache expensive results when appropriate
- Set timeouts for network operations
- Log execution for debugging
- Use type hints for all parameters

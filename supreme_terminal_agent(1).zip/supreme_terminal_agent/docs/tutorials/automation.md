# Automation Tutorial

Learn how to automate repetitive tasks using pipelines, triggers, and scheduled tasks.

## Pipelines

Pipelines let you define multi-step automation sequences.

### Creating a Pipeline

```
> pipeline create cleanup --steps "find-temp,remove-temp,report"
```

### Defining Steps

Each step can be configured:

```
> pipeline create deploy --steps "build,test,package,deploy"
> pipeline step configure deploy.build --command "make build"
> pipeline step configure deploy.test --command "make test"
> pipeline step configure deploy.package --command "docker build -t app:latest ."
> pipeline step configure deploy.deploy --command "kubectl apply -f deploy.yaml"
```

### Running a Pipeline

```
> pipeline run deploy
```

The agent executes each step and reports results:

```
Pipeline 'deploy' started
Step 1/4: build -> SUCCESS (2.3s)
Step 2/4: test -> SUCCESS (5.1s)
Step 3/4: package -> SUCCESS (34.2s)
Step 4/4: deploy -> SUCCESS (1.8s)
Pipeline completed in 43.4s
```

### Monitoring Pipeline Status

```
> pipeline status deploy
> pipeline logs deploy
```

## Event-Driven Triggers

Triggers automatically execute actions when specific events occur.

### File Change Trigger

```
> trigger create watch-src \
    --event file.change \
    --path ./src \
    --action "run: make test"
```

Now whenever a file changes in `./src`, the tests automatically run.

### Command Failure Trigger

```
> trigger create on-deploy-fail \
    --event command.fail \
    --action "notify:slack Deployment failed!"
```

### Timer Trigger

```
> trigger create nightly-backup \
    --event timer.cron \
    --expression "0 2 * * *" \
    --action "run: backup.sh"
```

## Scheduled Tasks

Schedule tasks to run at specific times.

### Using Cron Expressions

```
> schedule daily-cleanup "0 3 * * *" "run: find /tmp -mtime +7 -delete"
> schedule weekly-report "0 9 * * 1" "run: generate-report.sh"
> schedule hourly-health "0 * * * *" "run: health-check.sh"
```

### Managing Schedules

```
> schedule list
> schedule pause daily-cleanup
> schedule resume daily-cleanup
> schedule remove daily-cleanup
```

## Workflow Files

For complex automation, use workflow YAML files.

### Create a Workflow File

Save as `deploy.yaml`:

```yaml
name: deploy-production
version: "1.0"

variables:
  version: "1.2.3"

steps:
  - name: build
    type: command
    command: docker build -t app:${version} .

  - name: test
    type: command
    command: pytest tests/

  - name: deploy
    type: command
    command: kubectl set image deployment/app app=app:${version}

on_success:
  - notify: slack
    message: "Deployed v${version} to production"

on_failure:
  - notify: pagerduty
    severity: critical
```

### Run the Workflow

```
> workflow run deploy.yaml
> workflow validate deploy.yaml
```

## Practical Examples

### Automated Testing

```
> trigger create autotest \
    --event file.change \
    --path ./src \
    --action "run: pytest tests/ -x"
```

### Database Backups

```
> pipeline create db-backup \
    --steps "dump,compress,upload,cleanup"
> pipeline step configure db-backup.dump \
    --command "pg_dump mydb > /tmp/backup.sql"
> pipeline step configure db-backup.compress \
    --command "gzip /tmp/backup.sql"
> pipeline step configure db-backup.upload \
    --command "aws s3 cp /tmp/backup.sql.gz s3://backups/"
> pipeline step configure db-backup.cleanup \
    --command "rm /tmp/backup.sql.gz"
> schedule nightly-db-backup "0 4 * * *" "pipeline run db-backup"
```

### Log Rotation

```
> pipeline create rotate-logs \
    --steps "archive,compress,clean,report"
> schedule log-rotation "0 0 * * *" "pipeline run rotate-logs"
```

## Best Practices

- Name pipelines and triggers descriptively
- Test pipelines with `pipeline test` before scheduling
- Set up notifications for pipeline failures
- Use workflow files for complex automation
- Version control your workflow files
- Monitor trigger execution with `trigger list`
- Set appropriate timeouts for long-running pipelines

# Workflows Tutorial

Learn how to create and execute complex workflow files for sophisticated automation.

## What is a Workflow?

A workflow is a YAML file that defines a series of steps, conditions, triggers, and error handling logic. Unlike simple pipelines, workflows support conditional branching, parallel execution, variable substitution, and external integrations.

## Basic Workflow Structure

```yaml
name: my-workflow
version: "1.0"
description: Description of what this workflow does

variables:
  app_name: myapp
  environment: staging

steps:
  - name: step1
    type: command
    command: echo "Hello, ${app_name}"

  - name: step2
    type: command
    command: echo "Environment: ${environment}"
```

## Step Types

### Command Step

Execute a shell command:

```yaml
- name: build
  type: command
  command: make build
  timeout: 300
  working_dir: /project
```

### Pipeline Step

Run another pipeline:

```yaml
- name: run-tests
  type: pipeline
  pipeline: test-suite
  params:
    coverage: true
```

### Tool Step

Execute a registered tool:

```yaml
- name: search-files
  type: tool
  tool: file_search
  params:
    pattern: "*.py"
    directory: ./src
```

### HTTP Step

Make an HTTP request:

```yaml
- name: notify
  type: http
  url: https://hooks.slack.com/services/...
  method: POST
  headers:
    Content-Type: application/json
  body: '{"text": "Workflow completed"}'
```

### SSH Step

Execute a remote command:

```yaml
- name: deploy
  type: ssh
  host: prod-server
  port: 22
  command: ./deploy.sh ${version}
```

### Wait Step

Wait for a condition:

```yaml
- name: wait-for-deploy
  type: wait
  condition: http
  url: https://app.example.com/health
  timeout: 300
  interval: 10
```

### Condition Step

Conditional branching:

```yaml
- name: check-tests
  type: condition
  if: steps.run-tests.exit_code == 0
  then:
    - name: deploy
      type: command
      command: kubectl apply -f deploy.yaml
  else:
    - name: notify-failure
      type: http
      url: https://hooks.slack.com/...
      method: POST
```

## Parallel Execution

Run steps in parallel:

```yaml
steps:
  - name: parallel-tasks
    type: parallel
    branches:
      - name: lint
        type: command
        command: ruff check .
      - name: typecheck
        type: command
        command: mypy .
      - name: test
        type: command
        command: pytest tests/
  - name: after-parallel
    type: command
    command: echo "All parallel tasks completed"
    depends_on: parallel-tasks
```

## Variables and Context

### Defining Variables

```yaml
variables:
  version: "1.2.3"
  registry: docker.io/myorg
  image: "${registry}/app:${version}"
```

### Accessing Step Outputs

```yaml
- name: get-version
  type: command
  command: cat VERSION

- name: build-image
  type: command
  command: docker build -t app:${steps.get-version.output} .
```

### Environment Variables

```yaml
- name: deploy
  type: command
  command: ./deploy.sh
  env:
    API_KEY: "${API_KEY}"
    ENVIRONMENT: production
```

## Error Handling

### On Success

```yaml
on_success:
  - type: http
    url: https://hooks.slack.com/...
    body: '{"text": "Workflow completed successfully"}'
```

### On Failure

```yaml
on_failure:
  - type: http
    url: https://hooks.pagerduty.com/...
    body: '{"incident": "Workflow failed"}'
  - type: command
    command: ./rollback.sh
```

### Retry Logic

```yaml
- name: flaky-step
  type: command
  command: ./unreliable.sh
  retry:
    max_attempts: 3
    delay: 5
    backoff: exponential
```

## Triggering Workflows

### Manual

```
> workflow run deploy.yaml --param version=1.2.3
```

### Scheduled

```yaml
# In workflow file
triggers:
  - type: cron
    expression: "0 2 * * *"
```

### Event-Driven

```yaml
triggers:
  - type: event
    event: file.change
    path: ./src
```

## Complete Example

```yaml
name: ci-cd-pipeline
version: "2.0"
description: Full CI/CD pipeline with testing and deployment

variables:
  version: "${GIT_COMMIT:-latest}"
  environment: "${DEPLOY_ENV:-staging}"

triggers:
  - type: event
    event: git.push
    branch: main

steps:
  - name: lint
    type: command
    command: ruff check .

  - name: typecheck
    type: command
    command: mypy .

  - name: test
    type: command
    command: pytest tests/ --cov --junitxml=results.xml

  - name: build
    type: command
    command: docker build -t app:${version} .
    depends_on: [lint, typecheck, test]

  - name: integration-test
    type: command
    command: docker-compose -f docker-compose.test.yml up --abort-on-container-exit
    depends_on: build

  - name: push
    type: command
    command: docker push registry.example.com/app:${version}
    depends_on: integration-test

  - name: deploy
    type: condition
    if: environment == "production"
    then:
      - name: deploy-prod
        type: ssh
        host: prod-server
        command: kubectl set image deployment/app app=app:${version}
    else:
      - name: deploy-staging
        type: ssh
        host: staging-server
        command: kubectl set image deployment/app app=app:${version}
    depends_on: push

on_success:
  - type: http
    url: https://hooks.slack.com/...
    body: |
      {
        "text": "Deployment ${version} to ${environment} successful"
      }

on_failure:
  - type: http
    url: https://hooks.slack.com/...
    body: |
      {
        "text": "Deployment ${version} to ${environment} FAILED"
      }
  - type: command
    command: ./rollback.sh ${version}
```

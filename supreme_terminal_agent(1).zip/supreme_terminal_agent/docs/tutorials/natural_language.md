# Natural Language Tutorial

Learn how to effectively use natural language to interact with the Supreme Terminal AI Agent.

## Principles of Effective Prompts

### Be Specific

```
Less effective: "check the system"
More effective: "show me disk usage for each mounted partition in human-readable format"
```

### Provide Context

```
Less effective: "fix the error"
More effective: "I'm getting 'permission denied' when trying to write to /var/log/app.log. Find the issue and suggest a fix."
```

### State the Desired Output Format

```
Less effective: "find python files"
More effective: "find all Python files in the project, sorted by modification time, newest first"
```

## Common Patterns

### Information Retrieval

```
> what's the total disk space used by Docker images?
> show me the memory usage of the top 5 processes
> how many users are currently logged into this system?
```

### File Operations

```
> find all configuration files that contain the word "password"
> compress the logs directory and save it as logs_backup.tar.gz
> show me the differences between version1.py and version2.py
```

### System Administration

```
> check the status of all running services
> show me recent authentication failures from the system log
> list all open network connections on port 8080
```

### Development

```
> show me the git log for the last week with author names
> find all functions in the codebase that don't have docstrings
> what are the most recently modified dependencies in requirements.txt?
```

## Multi-Part Requests

Break complex requests into steps:

```
> first, find all PDF files in the downloads folder. then count how many are larger than 10MB
```

Or combine multiple conditions:

```
> show me all Python files that contain "import torch" and were modified this month
```

## Asking for Explanations

```
> explain: what does this command do: find . -type f -name "*.log" -exec grep -l "ERROR" {} \;
> show me the difference between soft and hard links in Linux
> why does this cron expression run at 3 AM on weekdays: "0 3 * * 1-5"
```

## Requesting Suggestions

```
> what's the best way to monitor log files in real-time?
> suggest an efficient way to backup this directory
> what command should I use to check network connectivity to a remote host?
```

## Correcting the Agent

```
> actually, I meant files larger than 50MB, not 10MB
> no, search in /var/log instead of /var/www
> let me clarify: I want to count lines, not words
```

The agent maintains context and adjusts its understanding.

## Using "Remember" for Context

Build persistent context:

```
> remember my project root is /home/user/projects/myapp
> remember I prefer vim for editing
> remember the database server is at db.internal:5432
```

Then reference it later:

```
> run the tests in my project root
> edit the main configuration file
> check if the database server is reachable
```

## Example Workflows

### System Diagnostics

```
> show me system health overview (CPU, memory, disk, uptime)
```

The agent runs: `uptime`, `free -h`, `df -h`, `top -bn1 | head -5`

### Project Cleanup

```
> find and remove all .pyc files, __pycache__ directories, and .DS_Store files in my project
```

The agent finds the files, confirms with you, then removes them.

### Deployment

```
> build the Docker image, tag it with today's date, and push it to the registry
```

The agent executes the build, tag, and push commands in sequence.

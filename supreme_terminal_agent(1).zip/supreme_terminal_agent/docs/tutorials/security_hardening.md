# Security Hardening Tutorial

Learn how to harden your Supreme Terminal AI Agent deployment for production environments.

## Initial Security Assessment

Run a security audit:

```
> security audit
> security check-config
```

## Step 1: Enable Sandboxing

Sandboxing isolates command execution from the host system.

```yaml
security:
  sandbox: true
  sandbox_type: docker
  sandbox_image: supreme-terminal/sandbox:latest
  sandbox_timeout: 30
  sandbox_memory_limit: 512m
  sandbox_network: isolated
  sandbox_readonly_fs: true
```

### Docker Sandbox

Build a minimal sandbox image:

```dockerfile
FROM alpine:3.19
RUN apk add --no-cache bash coreutils findutils grep
RUN adduser -D sandbox
USER sandbox
WORKDIR /home/sandbox
```

### Test the Sandbox

```
> run: rm -rf /
```

Should be blocked by the sandbox.

## Step 2: Configure Command Validation

```yaml
security:
  validation_mode: strict

  allowed_commands:
    - ls
    - cat
    - grep
    - find
    - ps
    - df
    - du
    - echo
    - git
    - docker ps
    - docker compose

  blocked_commands:
    - rm -rf /
    - dd
    - mkfs
    - fdisk
    - chmod -R 777
    - ":(){ :|:& };:"      # Fork bomb
    - "> /dev/sd[a-z]"     # Direct disk write

  blocked_patterns:
    - "rm\\s+-rf\\s+/"
    - "wget\\s+.*\\s*\\|\\s*bash"
    - "curl\\s+.*\\s*\\|\\s*bash"
    - "chmod\\s+-R\\s+777"

  require_confirmation:
    - rm
    - rmdir
    - mv
    - dd
    - format
    - mkfs
```

## Step 3: Enable Audit Logging

```yaml
security:
  audit: true
  audit_log: /var/log/supreme-terminal/audit.log
  audit_format: json
  audit_retention_days: 90
  audit_immutable: true

  audit_include:
    - commands
    - file_access
    - network_connections
    - authentication
    - configuration_changes
    - plugin_operations
```

### Audit Log Shipping

Forward audit logs to a central SIEM:

```yaml
logging:
  handlers:
    - type: syslog
      address: 192.168.1.100:514
      protocol: tcp
    - type: elasticsearch
      hosts: ["https://elastic:9200"]
      index: "supreme-terminal-audit"
```

## Step 4: Configure Encryption

```yaml
security:
  encryption: true
  encryption_algorithm: AES-256-GCM

  tls:
    enabled: true
    cert_file: /etc/supreme-terminal/cert.pem
    key_file: /etc/supreme-terminal/key.pem
    ca_file: /etc/supreme-terminal/ca.pem
    min_version: TLSv1.3
    verify_client: true
```

### Generate TLS Certificate

```bash
openssl req -x509 -nodes -days 365 -newkey rsa:4096 \
  -keyout /etc/supreme-terminal/key.pem \
  -out /etc/supreme-terminal/cert.pem \
  -subj "/CN=terminal.example.com"
```

## Step 5: Set Up Secrets Management

```yaml
security:
  secrets:
    provider: vault
    vault_addr: https://vault.example.com:8200
    vault_token: "${VAULT_TOKEN}"
    auto_rotate: true
    rotation_interval_days: 30
```

### Store Secrets

```bash
vault kv put supreme-terminal/ai api_key=sk-...
vault kv put supreme-terminal/db password=s3cr3t
```

Reference in config:

```yaml
ai:
  api_key: "${SUPREME_TERMINAL_AI_API_KEY}"
```

## Step 6: Authentication and RBAC

```yaml
security:
  authentication:
    enabled: true
    methods:
      - ssh_key
      - totp
    session_timeout: 3600
    max_login_attempts: 3
    lockout_duration: 600
    password_policy:
      min_length: 12
      require_uppercase: true
      require_numbers: true
      require_special: true

  authorization:
    enabled: true
    roles:
      admin:
        permissions: ["*"]
      developer:
        permissions: ["command.*", "fs.read", "fs.write"]
      operator:
        permissions: ["command.execute", "fs.read"]
      viewer:
        permissions: ["command.read"]
    default_role: viewer
```

## Step 7: Network Security

```yaml
network:
  bind_address: 127.0.0.1
  tls_verify: true

  firewall:
    enabled: true
    default_policy: deny
    rules:
      - allow: 127.0.0.1
        port: 8080
      - allow: 10.0.0.0/8
        port: 22
      - deny: 0.0.0.0/0
        port: 8080
```

## Step 8: Resource Limits

```yaml
execution:
  max_processes: 10
  max_memory_mb: 1024
  max_cpu_percent: 50
  timeout: 30
  working_dir: /tmp/supreme-terminal

security:
  sandbox_memory_limit: 256m
  sandbox_cpu_limit: 0.5
```

## Step 9: Disable Unused Features

```yaml
network:
  rest_api: false
  grpc_api: false
  websocket: false
  ssh_server: false

plugins:
  auto_load: false

automation:
  enabled: false
```

## Step 10: Regular Security Maintenance

### Update Cron

```bash
# /etc/cron.d/supreme-terminal-security
0 2 * * 0 root terminal-agent security audit --report
0 3 * * 0 root terminal-agent plugin update --all
0 4 * * 0 root terminal-agent security check-config
```

### Monitoring

```yaml
security:
  alerting:
    rules:
      - name: security_violation
        condition: "security_violations_total > 0"
        severity: critical
        channels: [pagerduty, slack]
```

## Security Checklist

- [ ] Sandbox enabled for command execution
- [ ] Command validation set to strict mode
- [ ] Audit logging enabled and shipping to SIEM
- [ ] TLS configured for all network endpoints
- [ ] Secrets stored in vault, not config files
- [ ] MFA enabled for all admin accounts
- [ ] RBAC roles defined with least privilege
- [ ] Firewall rules restrict access
- [ ] Resource limits configured
- [ ] Unused services disabled
- [ ] Regular security audits scheduled
- [ ] Plugin sandbox enabled
- [ ] File access restricted to allowed paths
- [ ] Session timeouts configured

# Basic Usage Tutorial

This tutorial walks you through the fundamental features of the Supreme Terminal AI Agent.

## Prerequisites

- Agent installed and configured
- AI provider API key set up

## Starting the Agent

Launch the agent in interactive mode:

```bash
terminal-agent
```

You'll be greeted with the agent prompt:

```
Supreme Terminal AI Agent v1.0.0
Type 'help' for available commands or ask me anything.
>
```

## Your First Commands

### Running a Shell Command

Use the `run:` prefix to execute shell commands directly:

```
> run: echo "Hello, World!"
```

Output:
```
Hello, World!
```

### Asking a Question

Ask the agent questions in natural language:

```
> what is the current date and time?
```

The agent will respond with the current date and time, using the `date` command internally.

### Getting Command Explanations

Use the `explain:` prefix to understand what a command does:

```
> explain: tar -xzf archive.tar.gz -C /tmp
```

The agent will explain each flag and what the command accomplishes.

## Working with Files

### Listing Files

```
> show me all files in the current directory
> list files sorted by size
> find all text files containing "error"
```

### Reading Files

```
> read the first 10 lines of server.log
> show me the contents of config.yaml
```

### Searching

```
> search for "TODO" in all Python files
> find files modified in the last 24 hours
```

## Multi-Step Tasks

The agent can break down complex requests:

```
> find all large files (>100MB), compress them into an archive, and show me the archive size
```

The agent will:
1. Identify the steps needed
2. Ask for confirmation if destructive
3. Execute each step sequentially
4. Report results

## Using History

```
> history          # Show command history
> history 5        # Show last 5 commands
> !!               # Repeat last command
> history search ls  # Find ls commands
```

## Session Management

Create isolated sessions for different tasks:

```
> sessions create work
> sessions attach work
> cd /var/log
> ... work in this session ...
> detach
```

## Getting Help

```
> help                # General help
> help run:           # Help for run: prefix
> help explain:       # Help for explain: prefix
> help sessions       # Help for session commands
```

## Next Steps

- [Advanced Commands Tutorial](advanced_commands.md) – More complex command patterns
- [Natural Language Tutorial](natural_language.md) – Using the AI effectively
- [Automation Tutorial](automation.md) – Automating repetitive tasks

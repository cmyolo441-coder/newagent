# Remote Execution Tutorial

Learn how to use the Supreme Terminal AI Agent to manage remote systems via SSH, HTTP, and WebSocket.

## SSH Connectivity

### Basic SSH Connection

Connect to a remote server:

```
> ssh admin@server.example.com
> ssh -p 2222 user@hostname -i ~/.ssh/deploy_key
```

Once connected, commands execute on the remote host:

```
> run: cat /etc/os-release
> run: df -h
> run: systemctl status nginx
```

### Disconnecting

```
> exit
```

Returns to the local agent session.

## Remote Command Execution

Execute commands on remote servers without starting a full session:

```
> ssh execute admin@server.example.com "df -h"
> ssh execute admin@server.example.com "uptime && free -h"
```

### Multiple Servers

```
> ssh execute web-01 "systemctl status nginx"
> ssh execute web-02 "systemctl status nginx"
> ssh execute db-01 "pg_isready"
```

### File Transfer

```
> scp localfile.txt admin@server.example.com:/remote/path/
> scp admin@server.example.com:/remote/file.txt localfile.txt
> scp -r /local/dir admin@server.example.com:/remote/dir/
```

## SSH Key Management

```
> ssh keygen -t ed25519 -C "deploy-key"
> ssh copy-id admin@server.example.com
> ssh list-keys
```

## Remote Session Management

### Persist Sessions

Remote sessions persist even if you disconnect:

```
> sessions create prod-server
> sessions attach prod-server
> ssh admin@prod.example.com
> ... work on remote server ...
> detach
```

The remote session continues running. Reconnect later:

```
> sessions attach prod-server
```

## HTTP Remote Access

### REST API Calls

```
> curl https://api.example.com/health
> curl -X POST https://api.example.com/deploy \
    -H "Content-Type: application/json" \
    -d '{"version": "1.2.3"}'
```

### WebSocket Connections

```
> ws connect wss://stream.example.com/events
```

## Remote Resource Monitoring

Monitor remote systems:

```
> ssh execute admin@server.example.com "top -bn1 | head -10"
> ssh execute admin@server.example.com "df -h | grep /dev/sda"
> ssh execute admin@server.example.com "netstat -tulpn | grep LISTEN"
```

## Automation with Remote Execution

### Remote Pipelines

```yaml
steps:
  - name: deploy-app
    type: ssh
    host: prod-server
    command: ./deploy.sh ${version}

  - name: verify
    type: ssh
    host: prod-server
    command: ./health-check.sh

  - name: clear-cache
    type: ssh
    host: web-01
    command: systemctl reload nginx
```

### Remote Triggers

```
> trigger create monitor-remote \
    --event timer.cron \
    --expression "*/5 * * * *" \
    --action "ssh execute admin@prod.example.com 'df -h | grep /dev/sda'"
```

## Multi-Hop SSH

Connect through a jump box:

```
> ssh -J jump@bastion.example.com admin@internal-server.example.com
```

## Security Considerations

### Key-Based Authentication

Always use SSH keys instead of passwords:

```
> ssh keygen
> ssh copy-id admin@server.example.com
```

### Known Hosts

```
> ssh add-known-host server.example.com
> ssh verify-host server.example.com
```

### Session Recording

All remote sessions are audited:

```
> ssh audit-log
> ssh audit-log --server prod.example.com
```

### SSH Config

Configure remote hosts in `~/.ssh/config`:

```
Host prod
  HostName prod.example.com
  User admin
  Port 22
  IdentityFile ~/.ssh/prod_key

Host *
  UseKeychain yes
  AddKeysToAgent yes
```

Then connect simply:

```
> ssh prod
```

## Best Practices

- Use SSH keys instead of passwords
- Set up a jump box for internal network access
- Use session persistence for long-running remote tasks
- Enable audit logging for all remote access
- Configure connection timeouts to avoid hung sessions
- Use the agent's sandbox for executing untrusted remote commands

# AI Customization Tutorial

Learn how to customize the AI behavior, add custom prompts, configure provider routing, and optimize the AI engine for your needs.

## AI Provider Configuration

### Single Provider

```yaml
ai:
  provider: openai
  model: gpt-4
  api_key: "${OPENAI_API_KEY}"
  temperature: 0.7
  max_tokens: 2048
```

### Multi-Provider Setup

Configure multiple providers with automatic routing:

```yaml
ai:
  providers:
    primary:
      provider: openai
      model: gpt-4
      weight: 3
    fallback:
      provider: anthropic
      model: claude-3-opus
      weight: 2
    local:
      provider: ollama
      model: llama3
      weight: 1

  routing:
    strategy: latency  # latency, cost, random, round_robin
```

### Local LLM Setup

```yaml
ai:
  providers:
    local:
      provider: ollama
      model: llama3
      base_url: http://localhost:11434
      options:
        num_ctx: 4096
        num_gpu: 1
```

## Custom Prompt Templates

### System Prompts

Customize the agent's system prompt for specialized behavior:

```yaml
ai:
  system_prompt: |
    You are a specialized DevOps assistant focused on Kubernetes.
    Always prefer kubectl commands when relevant.
    Explain commands before executing them.
    Provide context for all outputs.
```

### Task-Specific Prompts

```yaml
ai:
  prompts:
    explain: |
      Explain the following command in detail, breaking down
      each flag and argument. Provide usage examples.
    
    debug: |
      Analyze the following error output and suggest fixes.
      Consider common causes and provide step-by-step solutions.
```

### Custom Prompt Management

```
> prompt list
> prompt show explain
> prompt create custom-prompt "You are a helpful assistant..."
> prompt delete custom-prompt
```

## Temperature and Model Selection

### Per-Request Override

Override AI parameters for specific requests:

```
> config set ai.temperature 0.9
> explain: complex bash one-liner
> config set ai.temperature 0.7

> config set ai.model gpt-4-turbo
> run task: analyze this dataset
> config set ai.model gpt-4
```

### Use Case Profiles

Create profiles for different use cases:

```yaml
ai:
  profiles:
    creative:
      temperature: 0.9
      model: gpt-4
    precise:
      temperature: 0.1
      model: gpt-4
    fast:
      temperature: 0.3
      model: gpt-3.5-turbo
    coding:
      temperature: 0.2
      model: claude-3-opus
```

```
> config set ai.profile coding
> write a Python function to parse CSV files
> config set ai.profile creative
> suggest some naming conventions for this project
```

## Response Caching

Optimize performance with caching:

```yaml
ai:
  cache:
    enabled: true
    size: 10000
    ttl: 3600
    strategy: exact  # exact, semantic, hybrid
```

Clear cache when needed:

```
> ai clear-cache
```

## Rate Limiting

```yaml
ai:
  rate_limiter:
    requests_per_minute: 60
    requests_per_hour: 1000
    tokens_per_minute: 100000
    concurrency: 5
```

Monitor rate limits:

```
> metrics ai
```

## Cost Tracking

Track AI usage costs:

```yaml
ai:
  cost_tracker:
    enabled: true
    budget_daily: 10.00
    budget_monthly: 200.00
    notify_at_percent: 80
```

```
> metrics ai
```

Output:

```
AI Engine Statistics:
  Total Requests: 1,234
  Total Tokens: 245,678 (in: 180k, out: 65k)
  Total Cost: $12.34
  Avg Latency: 1.2s
  Cache Hit Rate: 45%
```

## Custom Model Registry

Add custom models:

```yaml
ai:
  models:
    custom-gpt:
      provider: openai
      model: gpt-4-custom
      max_tokens: 8192
      cost_per_1k_input: 0.03
      cost_per_1k_output: 0.06
    
    local-coder:
      provider: ollama
      model: codellama
      base_url: http://localhost:11434
```

## RAG Configuration

Configure Retrieval-Augmented Generation:

```yaml
ai:
  rag:
    enabled: true
    chunk_size: 1024
    chunk_overlap: 200
    embedding_model: all-MiniLM-L6-v2
    vector_store: chromadb
    top_k: 5
    similarity_threshold: 0.7
```

## Provider Fallback Behavior

```yaml
ai:
  fallback:
    strategy: chain  # chain, parallel, best-effort
    max_retries: 3
    retry_delay: 1.0
    timeout: 30
```

## Customizing Reasoning

Configure which reasoning strategies the agent uses:

```yaml
ai:
  reasoning:
    strategies:
      - chain_of_thought
      - tree_of_thought
      - self_consistency
    default: chain_of_thought
    ensemble: false  # Use multiple strategies and vote
```

## Advanced: Custom AI Module

Replace the AI engine with a custom implementation:

```python
from supreme_terminal_agent.ai import AIEngine
from supreme_terminal_agent.ai.llm import LLMEngine

class CustomLLM(LLMEngine):
    async def generate(self, prompt, **kwargs):
        # Your custom LLM logic
        return "Custom response"

class CustomAIEngine(AIEngine):
    def __init__(self):
        super().__init__(llm_engine=CustomLLM())
```

Register via plugin:

```python
class CustomAIPlugin(BasePlugin):
    async def on_load(self):
        self.services.register("ai", CustomAIEngine())
```

## Best Practices

- Use temperature 0.1-0.3 for factual/code tasks
- Use temperature 0.7-0.9 for creative tasks
- Configure a fallback provider for reliability
- Enable caching for repetitive queries
- Set cost budgets to prevent unexpected charges
- Monitor AI metrics to optimize performance
- Use local models for sensitive data
- Test different models for your use case

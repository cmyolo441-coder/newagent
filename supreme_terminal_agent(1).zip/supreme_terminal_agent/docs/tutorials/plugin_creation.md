# Plugin Creation Tutorial

Learn how to create plugins that extend the Supreme Terminal AI Agent with custom commands, tools, hooks, and integrations.

## Plugin Basics

A plugin is a Python package that implements the `BasePlugin` interface. Plugins can:

- Add custom commands
- Register tools
- Hook into lifecycle events
- Add middleware
- Integrate with external services

## Project Structure

```
my-awesome-plugin/
├── __init__.py          # Plugin class
├── plugin.yaml          # Plugin manifest
├── commands.py          # Custom commands (optional)
├── tools.py             # Custom tools (optional)
├── hooks.py             # Event hooks (optional)
├── middleware.py        # Middleware (optional)
├── config.yaml          # Default config (optional)
└── static/              # Static assets (optional)
```

## Creating the Plugin Manifest

`plugin.yaml`:

```yaml
name: my-awesome-plugin
version: 1.0.0
description: An awesome plugin for the Supreme Terminal Agent
author: Your Name
license: MIT

supreme-terminal:
  min_version: 1.0.0

dependencies: []

hooks:
  - post_command
  - pre_execute

commands:
  - greet
  - farewell

tools:
  - say-hello
```

## Writing the Plugin Class

`__init__.py`:

```python
import logging
from supreme_terminal_agent.plugins.base import BasePlugin

logger = logging.getLogger(__name__)

class MyAwesomePlugin(BasePlugin):
    name = "my-awesome-plugin"
    version = "1.0.0"
    description = "Adds greeting and farewell capabilities"

    async def on_load(self):
        """Initialize plugin resources."""
        self.greeting = self.config.get("greeting", "Hello")
        logger.info(f"{self.name} loaded with greeting: {self.greeting}")

    async def on_enable(self):
        """Start plugin operations."""
        logger.info(f"{self.name} enabled")
        # Subscribe to events
        self.services.events.subscribe("session.created", self.on_session_start)

    async def on_disable(self):
        """Stop plugin operations."""
        logger.info(f"{self.name} disabled")
        self.services.events.unsubscribe("session.created", self.on_session_start)

    async def on_install(self):
        """Run installation tasks."""
        logger.info(f"{self.name} installed")

    async def on_uninstall(self):
        """Clean up plugin data."""
        logger.info(f"{self.name} uninstalled")

    async def on_session_start(self, event):
        """Handle session created event."""
        session_name = event.data.get("name", "unknown")
        logger.info(f"Session started: {session_name}")

    @property
    def version_info(self):
        return f"{self.name} v{self.version}"
```

## Adding Custom Commands

`commands.py`:

```python
from supreme_terminal_agent.commands.handlers import BaseCommandHandler

class GreetCommand(BaseCommandHandler):
    name = "greet"
    description = "Greets a user"
    usage = "greet <name>"

    async def handle(self, args, context):
        name = args[0] if args else "World"
        greeting = context.get("greeting", "Hello")
        return {
            "success": True,
            "output": f"{greeting}, {name}!"
        }

class FarewellCommand(BaseCommandHandler):
    name = "farewell"
    description = "Says goodbye"
    usage = "farewell <name>"

    async def handle(self, args, context):
        name = args[0] if args else "World"
        return {
            "success": True,
            "output": f"Goodbye, {name}!"
        }
```

Register commands in the plugin:

```python
async def on_load(self):
    self.register_command(GreetCommand())
    self.register_command(FarewellCommand())
```

## Adding Custom Tools

`tools.py`:

```python
from supreme_terminal_agent.tools import BaseTool

class SayHelloTool(BaseTool):
    name = "say-hello"
    description = "Says hello to someone"
    parameters = {
        "name": {"type": "string", "description": "Name", "required": True},
        "language": {
            "type": "string",
            "enum": ["en", "es", "fr", "de"],
            "default": "en"
        }
    }

    async def execute(self, name: str, language: str = "en") -> dict:
        greetings = {
            "en": "Hello",
            "es": "Hola",
            "fr": "Bonjour",
            "de": "Hallo"
        }
        greeting = greetings.get(language, "Hello")
        return {
            "success": True,
            "message": f"{greeting}, {name}!",
            "language": language
        }
```

Register tools in the plugin:

```python
async def on_load(self):
    self.register_command(GreetCommand())
    self.register_command(FarewellCommand())
    self.register_tool(SayHelloTool())
```

## Adding Event Hooks

`hooks.py`:

```python
from supreme_terminal_agent.hooks import hook

@hook("pre_command")
async def log_command(context):
    command = context.get("command", "")
    print(f"[Plugin] About to execute: {command}")

@hook("post_command")
async def log_result(context):
    result = context.get("result", {})
    success = result.get("success", False)
    duration = result.get("duration", 0)
    print(f"[Plugin] Completed (success={success}, duration={duration}s)")
```

## Adding Middleware

`middleware.py`:

```python
from supreme_terminal_agent.middleware import BaseMiddleware

class TimingMiddleware(BaseMiddleware):
    """Middleware that measures command execution time."""

    async def before(self, context):
        context["_start_time"] = time.time()

    async def after(self, context):
        if "_start_time" in context:
            elapsed = time.time() - context["_start_time"]
            context["duration"] = elapsed
            print(f"Command took {elapsed:.2f}s")
```

## Plugin Configuration

`config.yaml`:

```yaml
greeting: "Hi there"
language: "en"
enable_logging: true
```

Access in plugin:

```python
async def on_load(self):
    greeting = self.config.get("greeting", "Hello")
    lang = self.config.get("language", "en")
```

Users can override in their config:

```yaml
plugins:
  my-awesome-plugin:
    greeting: "Howdy"
    language: "en"
```

## Testing the Plugin

```bash
# Install the plugin
terminal-agent plugin install /path/to/my-awesome-plugin

# List plugins
terminal-agent plugin list

# View plugin info
terminal-agent plugin info my-awesome-plugin

# Enable the plugin
terminal-agent plugin enable my-awesome-plugin

# Test commands
terminal-agent --exec "greet Alice"

# Test tools
terminal-agent --exec "run tool: say-hello --name Alice --language es"
```

## Publishing

### Package as Python Package

Create `setup.py`:

```python
from setuptools import setup, find_packages

setup(
    name="supreme-terminal-my-awesome-plugin",
    version="1.0.0",
    packages=find_packages(),
    entry_points={
        "supreme_terminal.plugins": [
            "my-awesome-plugin = my_awesome_plugin:MyAwesomePlugin",
        ],
    },
)
```

### Publish to PyPI

```bash
python setup.py sdist bdist_wheel
twine upload dist/*
```

## Best Practices

- Use semantic versioning
- Declare all dependencies explicitly
- Clean up resources in `on_disable()` and `on_uninstall()`
- Use the built-in logger instead of print
- Handle configuration validation in `on_load()`
- Test with `plugin test` before publishing
- Document your plugin's commands and tools
- Set appropriate sandbox permissions

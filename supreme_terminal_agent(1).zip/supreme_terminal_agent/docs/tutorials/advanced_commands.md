# Advanced Commands Tutorial

Learn advanced command patterns and techniques for the Supreme Terminal AI Agent.

## Command Chaining

Chain multiple commands together using the agent's reasoning:

```
> find all directories containing a main.py file, then check if they have a tests/ directory
```

The agent will execute multiple commands and correlate results.

## Piped Operations

Use shell pipes within `run:` commands:

```
> run: ps aux | grep python | awk '{print $2, $11}' | sort
```

## Conditional Execution

The agent handles conditional logic:

```
> if the server.log file exists, show me the last 100 lines; otherwise, create it
```

## Looping Over Results

```
> for each Python file in src/, count the lines of code and show me the total
```

The agent iterates and aggregates results.

## Working with Processes

```
> start a background process that monitors disk usage every 10 seconds
> list all running background processes
> stop the monitoring process
```

## Remote Execution

Execute commands on remote servers:

```
> ssh to the staging server and check disk usage
> connect to db.example.com and show me the database size
```

## Transactional Operations

Perform operations with rollback support:

```
> archive the logs directory with the ability to roll back if something goes wrong
```

## Batch Processing

Process multiple items:

```
> resize all PNG images in the current directory to 800x600
> convert all Markdown files to HTML
> rename all .txt files to .md
```

## File Watching

Monitor files for changes:

```
> watch the src/ directory for changes and run tests automatically
```

## Custom Aliases

Define and use command aliases:

```
> alias ll="ls -la"
> alias gs="git status"
> ll
```

## Using Environment Variables

```
> set MY_VAR=hello
> run: echo $MY_VAR
```

## Advanced Redirection

```
> run: ls -la | grep ".py" > python_files.txt
> run: sort < unsorted.txt > sorted.txt
> run: cat header.txt body.txt footer.txt > complete.txt
```

## Debug Mode

Enable debug to see the agent's internal reasoning:

```
> debug on
> find all files modified in the last week
```

You'll see the agent's chain-of-thought as it formulates the response.

## Performance Profiling

```
> time how long it takes to build the project
> profile the execution of my test suite
```

## Composite Commands

Combine multiple advanced features:

```
> for each git repository in ~/projects/, show me the current branch and whether it has uncommitted changes
```

The agent will:
1. Find all git repositories
2. Check each repository's branch and status
3. Format and display results

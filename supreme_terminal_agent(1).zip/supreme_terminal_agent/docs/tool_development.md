# Tool Development

The tool system in the Supreme Terminal AI Agent provides a framework for creating reusable, composable capabilities that can be invoked by the agent, plugins, or directly by users.

## Tool Architecture

Tools are registered in a central registry and can be:

- **Invoked directly** via the agent or command line
- **Chained together** to form complex operations
- **Selected automatically** by the AI reasoning engine
- **Validated** before and after execution
- **Optimized** based on usage patterns

## Creating a Tool

### Basic Tool

```python
from supreme_terminal_agent.tools import BaseTool

class FileSearchTool(BaseTool):
    name = "file_search"
    description = "Search for files matching a pattern"
    version = "1.0.0"
    category = "filesystem"

    parameters = {
        "pattern": {
            "type": "string",
            "description": "File pattern to search for (glob)",
            "required": True
        },
        "directory": {
            "type": "string",
            "description": "Directory to search in",
            "default": "."
        },
        "max_results": {
            "type": "integer",
            "description": "Maximum number of results",
            "default": 50
        }
    }

    async def execute(self, pattern: str, directory: str = ".", max_results: int = 50) -> dict:
        import glob
        matches = glob.glob(f"{directory}/**/{pattern}", recursive=True)
        matches = matches[:max_results]
        return {
            "success": True,
            "matches": matches,
            "count": len(matches)
        }
```

## Tool Registration

Tools can be registered in several ways:

### Programmatic Registration

```python
from supreme_terminal_agent.tools import ToolRegistry

registry = ToolRegistry()
registry.register(FileSearchTool())
registry.register(MyCustomTool(), name="custom_name")
```

### Plugin-Based Registration

Include tools in your plugin's `tools.py`:

```python
# tools.py
from supreme_terminal_agent.tools import BaseTool

class MyPluginTool(BaseTool):
    name = "plugin-tool"
    description = "A tool provided by my plugin"

    async def execute(self, **kwargs):
        return {"result": "plugin tool executed"}
```

### Configuration-Based Registration

```yaml
tools:
  custom:
    - name: my-tool
      module: mypackage.mytool
      class: MyTool
```

## Tool Parameters

Tools define their parameters using a JSON schema-like format:

```python
parameters = {
    "query": {
        "type": "string",
        "description": "Search query",
        "required": True
    },
    "limit": {
        "type": "integer",
        "description": "Result limit",
        "default": 10,
        "minimum": 1,
        "maximum": 1000
    },
    "format": {
        "type": "string",
        "enum": ["json", "text", "csv"],
        "default": "json"
    }
}
```

## Tool Execution

### Direct Invocation

```python
result = await registry.execute("file_search", pattern="*.py", directory="./src")
```

### Chained Execution

Tools can be chained to form pipelines:

```python
from supreme_terminal_agent.tools import ToolChain

chain = ToolChain()
chain.add("file_search", pattern="*.log", directory="/var/log")
chain.add("file_read", path="{file_search.matches[0]}")
chain.add("analyze_log", content="{file_read.content}")
result = await chain.execute()
```

### AI-Selected Execution

The reasoning engine can automatically select and execute tools based on user intent:

```
> find all Python files containing "TODO" and count them
```

The AI selects `file_search` and `grep` tools, chains them, and returns results.

## Return Values

Tools should return a dictionary with at minimum a `success` key:

```python
# Success
return {
    "success": True,
    "data": {...},
    "message": "Operation completed"
}

# Error
return {
    "success": False,
    "error": "File not found",
    "error_code": "FILE_NOT_FOUND"
}
```

## Tool Lifecycle Hooks

```python
class MyTool(BaseTool):
    async def before_execute(self, **kwargs):
        """Called before tool execution."""
        self.start_time = time.time()

    async def after_execute(self, result: dict):
        """Called after tool execution."""
        elapsed = time.time() - self.start_time
        self.logger.info(f"Execution took {elapsed}s")

    async def on_error(self, error: Exception):
        """Called when execution fails."""
        self.logger.error(f"Tool failed: {error}")

    async def validate(self, **kwargs) -> bool:
        """Validate parameters before execution."""
        return True
```

## Tool Categories

Tools are organized into categories for discovery and organization:

| Category | Description |
|---|---|
| `filesystem` | File and directory operations |
| `network` | HTTP, SSH, DNS operations |
| `system` | System information and process management |
| `database` | Database queries and operations |
| `text` | Text processing and analysis |
| `data` | Data transformation and validation |
| `ai` | AI/LLM operations |
| `security` | Security scanning and validation |
| `development` | Code analysis, git operations |
| `custom` | User-defined tools |

## Built-in Tools

The agent ships with many built-in tools:

| Tool | Description |
|---|---|
| `file_read` | Read file contents |
| `file_write` | Write content to a file |
| `file_search` | Search for files matching a pattern |
| `grep` | Search file contents |
| `http_request` | Make HTTP requests |
| `run_command` | Execute a shell command |
| `parse_json` | Parse JSON data |
| `format_text` | Format and transform text |
| `compress` | Compress files or directories |
| `encrypt` | Encrypt data |
| `decrypt` | Decrypt data |
| `ssh_execute` | Execute commands on remote hosts |

## Best Practices

- Keep tools focused on a single responsibility
- Validate all parameters in the `validate` method
- Return structured data (dict) rather than raw strings
- Include meaningful error messages and error codes
- Set appropriate timeouts for long-running operations
- Use the built-in logging for diagnostics
- Document all parameters with descriptions and types
- Handle edge cases gracefully
- Cache expensive operations when possible

## Tool Validation

Tools can implement custom validation:

```python
class SecureFileTool(BaseTool):
    async def validate(self, **kwargs) -> bool:
        path = kwargs.get("path", "")
        # Prevent path traversal
        if ".." in path or path.startswith("/"):
            return False
        return True
```

## Tool Optimization

The tool optimizer tracks usage patterns and can:

- Cache frequently used results
- Pre-warm tool instances
- Suggest parameter defaults based on history
- Parallelize independent tool chains
- Batch similar operations

```python
# Enable caching for a tool
class ExpensiveTool(BaseTool):
    cache_ttl = 300  # Cache results for 5 minutes
    cache_keys = ["query", "limit"]
```

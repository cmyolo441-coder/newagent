# Getting Started

Welcome to the Supreme Terminal AI Agent. This guide walks you through the initial setup and first use of the agent.

## Prerequisites

- Python 3.11 or newer installed on your system
- A supported operating system: Linux (recommended), macOS, or Windows via WSL2
- Basic familiarity with terminal/command-line usage
- (Optional) API keys for AI providers such as OpenAI, Anthropic, or Google

## Installation

The quickest way to install is via pip:

```bash
pip install supreme-terminal-agent
```

For development installation from source:

```bash
git clone https://github.com/supreme-ai/supreme-terminal-agent.git
cd supreme-terminal-agent
pip install -r requirements.txt
pip install -e .
```

See the [Installation Guide](installation.md) for detailed platform-specific instructions, including Docker, Kubernetes, and systemd setup.

## Configuration

Create a configuration file at `~/.config/supreme-terminal/config.yaml`:

```yaml
agent:
  name: "my-agent"
  debug: false

ai:
  provider: openai
  model: gpt-4
  api_key: "${OPENAI_API_KEY}"

terminal:
  shell: /bin/bash
  emulator: xterm-256color
  scrollback: 10000

security:
  sandbox: true
  audit: true
```

Environment variables are automatically expanded. Refer to the [Configuration Reference](reference/configuration_options.md) for all available options.

## Running the Agent

Start the agent in interactive mode:

```bash
terminal-agent
```

Or with explicit mode selection:

```bash
terminal-agent --mode interactive
```

You should see the agent prompt:

```
Supreme Terminal AI Agent v1.0.0
Type 'help' for available commands or ask me anything.
>
```

## Your First Session

Try asking the agent to perform a task using natural language:

```
> list all files larger than 10 MB in the current directory and sort them by size
```

The agent will reason about your request, formulate the appropriate shell command(s), execute them, and return the results with an explanation.

## Next Steps

- [Quick Start Guide](quick_start.md) – A 5-minute tutorial covering core features
- [User Guide](user_guide.md) – Comprehensive walkthrough of all features
- [Configuration Guide](configuration.md) – Detailed configuration options
- [CLI Reference](cli_reference.md) – All command-line flags and options

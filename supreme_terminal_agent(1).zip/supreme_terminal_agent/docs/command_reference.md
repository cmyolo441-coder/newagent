# Command Reference

This document describes the built-in commands available in the Supreme Terminal AI Agent interactive shell.

## General Commands

### `help` / `?`

Display help information.

```
> help
> help install
> help run:
```

### `exit` / `quit` / `Ctrl+D`

Exit the agent.

```
> exit
```

### `clear`

Clear the terminal screen.

```
> clear
```

### `version`

Display version information.

```
> version
```

## Command Execution

### `run:`

Execute a shell command directly.

```
> run: ls -la
> run: docker ps -a
> run: pip list | grep numpy
```

### `explain:`

Get an AI-powered explanation of a command.

```
> explain: rsync -avz --delete /src/ /dst/
> explain: git rebase -i HEAD~5
> explain: awk '{print $1}' file.txt
```

### `sudo:`

Execute a command with elevated privileges (requires configuration).

```
> sudo: apt update
> sudo: systemctl restart nginx
```

## Session Management

### `sessions`

Manage terminal sessions.

```
> sessions list
> sessions attach <name>
> sessions create <name>
> sessions close <name>
> sessions destroy <name>
> sessions rename <old> <new>
```

### `detach`

Detach from current session without closing it.

```
> detach
```

## Configuration

### `config`

Manage agent configuration at runtime.

```
> config list
> config get <key>
> config set <key> <value>
> config unset <key>
> config reload
> config validate
> config export
> config import <file>
```

Examples:

```
> config set ai.temperature 0.9
> config set security.sandbox false
> config get terminal.shell
```

## Memory

### `remember`

Store information in persistent memory.

```
> remember my name is Alice
> remember preferred editor = neovim
> remember db_host = db.example.com
```

### `recall`

Retrieve information from memory.

```
> recall
> recall name
> recall all
> recall search database
```

### `forget`

Clear memory.

```
> forget
> forget key
> forget all
```

## History

### `history`

View command history.

```
> history
> history 20
> history search docker
> history clear
> history export history.txt
```

Shortcuts:

```
> !!          # Re-run last command
> !42         # Re-run command #42
> !docker     # Re-run last command starting with docker
```

## Automation

### `pipeline`

Create and manage pipelines.

```
> pipeline list
> pipeline create deploy --steps "build,test,deploy"
> pipeline run deploy
> pipeline status deploy
> pipeline logs deploy
> pipeline delete deploy
```

### `trigger`

Create and manage event triggers.

```
> trigger list
> trigger create watch-src --event file.change --path ./src --action "run: make test"
> trigger enable watch-src
> trigger disable watch-src
> trigger delete watch-src
```

### `workflow`

Run workflow files.

```
> workflow run deploy.yaml
> workflow validate deploy.yaml
> workflow list
```

## Plugin Management

### `plugin`

Manage plugins.

```
> plugin list
> plugin list --enabled
> plugin list --disabled
> plugin install <name>
> plugin uninstall <name>
> plugin enable <name>
> plugin disable <name>
> plugin update <name>
> plugin info <name>
```

## Tool Management

### `tool`

Manage custom tools.

```
> tool list
> tool info <name>
> tool register <name> <module_path>
> tool unregister <name>
> tool test <name> --args "..."
```

## File System

### `ls`

List directory contents.

```
> ls
> ls -la
> ls /var/log
```

### `cd`

Change directory.

```
> cd /var/log
> cd ~
> cd -
```

### `pwd`

Print working directory.

```
> pwd
```

### `cat`

Display file contents.

```
> cat file.txt
> cat -n file.txt
```

### `find`

Search for files.

```
> find *.py
> find **/*.md
> find -size +10M
```

## Network

### `ssh`

Connect to remote host via SSH.

```
> ssh user@hostname
> ssh -p 2222 user@hostname
```

### `scp`

Copy files over SSH.

```
> scp file.txt user@host:/path/
> scp -r dir/ user@host:/path/
```

### `curl`

HTTP requests.

```
> curl https://api.example.com
> curl -X POST -d '{"key":"value"}' https://api.example.com
```

## Monitoring

### `status`

Show agent status.

```
> status
```

### `metrics`

Show agent performance metrics.

```
> metrics
> metrics cpu
> metrics memory
> metrics ai
```

### `health`

Run health checks.

```
> health
> health --verbose
```

### `logs`

View agent logs.

```
> logs
> logs --tail 50
> logs --level ERROR
> logs --since 1h
> logs --follow
```

### `top`

Show resource usage.

```
> top
> top --processes
> top --system
```

## System

### `env`

Display or set environment variables.

```
> env
> env PATH
> env MY_VAR=value
```

### `which`

Locate a command.

```
> which python
> which git
```

### `info`

Display system information.

```
> info
> info system
> info agent
```

## AI Prompts

### `prompt`

Manage AI prompt templates.

```
> prompt list
> prompt show <name>
> prompt create <name> <template>
> prompt delete <name>
```

## Debug

### `debug`

Toggle debug mode or run debug commands.

```
> debug on
> debug off
> debug state
> debug brain
> debug events
```

## Command Aliases

Custom aliases can be configured in the config file:

```yaml
aliases:
  gs: "git status"
  gl: "git log --oneline"
  ll: "ls -la"
  dc: "docker compose"
```

Or set at runtime:

```
> alias gs="git status"
> alias ll="ls -la"
> alias
```

## Input/Output Redirection

Standard shell redirection is supported:

```
> run: ls -la > output.txt
> run: grep error >> log.txt
> run: sort < input.txt
> run: command1 | command2
```
